"""Genuine M2/M3 ledger bytes and earlier registered experiment reports on M4 product."""
import datetime,hashlib,io,json,os,sqlite3,subprocess,sys,tarfile,tempfile,zipfile
from pathlib import Path
Q=Path(__file__).resolve().parent;INFO=json.loads((Q/'joined-source.json').read_bytes());C=INFO['source'];repo=Path(INFO['checkout']);project=Path('/Users/lookman/Projects/purser')
env={'PATH':'/usr/bin:/bin','LC_ALL':'C','TZ':'UTC'}
out=Q/'outputs';root=Path(tempfile.mkdtemp(prefix='purser-m4-historical.',dir='/private/tmp'));facts={'source':C,'trees':{},'archive_replay':{},'registered_reports':{}}
def git(*k):return subprocess.check_output(['/usr/bin/git',*k],cwd=project,env=env)
def sha(b):return hashlib.sha256(b).hexdigest()
def command(args,cwd=repo):
 r=subprocess.run(args,cwd=cwd,env=env,capture_output=True)
 if r.returncode:raise ValueError((args,r.returncode,r.stderr.decode()[-350:]))
 return r.stdout
def cli(db,*args):return json.loads(command([sys.executable,'-B','-m','purser','--db',str(db),*args]))
for path in ['purser','experiments/e1','experiments/e2','experiments/manifests/v1','docs/evidence/M2/development-log.zip','docs/evidence/M3/project-ledger.zip']:
 facts['trees'][path]=git('rev-parse',C+':'+path).decode().strip()
 if path!='purser':assert facts['trees'][path]==git('rev-parse','d865971fa3da20d0b82fa7bc56ca1b24c080270b:'+path).decode().strip()
vectors=command([sys.executable,'-B','docs/contracts/check_vectors.py']);facts['M0_vectors']={'stdout':vectors.decode(),'sha256':sha(vectors)}
for group,arc in [('M2','docs/evidence/M2/development-log.zip'),('M3','docs/evidence/M3/project-ledger.zip')]:
 zraw=git('show',C+':'+arc);z=zipfile.ZipFile(io.BytesIO(zraw));man=json.loads(z.read('manifest.json'))
 assert z.testzip() is None
 for key,hs in man['members'].items():assert sha(z.read(key))==hs
 db=root/(group+'.sqlite3');cli(db,'init');obs=Path(str(db)+'.artifacts');obs.mkdir(mode=0o700,exist_ok=True);n=0
 for k in z.namelist():
  if k.startswith('objects/'):
   d=z.read(k);assert k[8:]==sha(d);(obs/k[8:]).write_bytes(d);n+=1
 lines=z.read('events.jsonl').splitlines();assert len(lines)==man['revision']
 with sqlite3.connect(db) as cx:cx.executemany('insert into events(revision,body) values (?,?)',[(idx+1,x) for idx,x in enumerate(lines)])
 prior=json.loads(z.read('status.json')) if group=='M2' else json.loads(z.read('public-readback.json'))['status'];st=cli(db,'replay','--as-of',prior['as_of'])
 assert cli(db,'status','--as-of',prior['as_of'])==st and sorted(st['answers'])==[f'q{j:02}' for j in range(1,11)]
 for k in ['revision','as_of','head_hash','projection_hash','v']:assert st[k]==prior[k]
 assert set(st['answers'])-set(prior['answers'])<=set(['q03','q04','q05','q06'])
 assert all(st['answers'][k]==v for k,v in prior['answers'].items()) and all(not st['answers'][k] for k in st['answers'].keys()-prior['answers'].keys())
 with sqlite3.connect(db) as conn:assert [b for (b,) in conn.execute('select body from events order by revision')]==lines
 proof={'events':len(lines),'archive_sha256':sha(zraw),'artifacts_independently_content_checked':n,'head':st['head_hash'],'projection_hash':st['projection_hash'],'matched_original_keys':sorted(prior['answers']),'added_empty_keys':sorted(st['answers'].keys()-prior['answers'].keys())}
 if group=='M3':
  others=json.loads(z.read('public-readback.json'));commands={'m3':['why','W-m3-decision-impact'],'project':['why','W-purser-delivery'],'frontier':['frontier']}
  for key,args in commands.items():
   got=cli(db,*args,'--as-of',others[key]['as_of']);assert got==others[key],key
  proof['matched_cold_why_and_frontier']=sorted(commands)
 facts['archive_replay'][group]=proof
print('cold M0/M2/M3 verified',flush=True)
def attach_git_metadata(where,head):
 if not (where/'.git').is_dir():subprocess.run(['/usr/bin/git','init','-q',str(where)],env=env,check=True)
 alt=where/'.git/objects/info/alternates';alt.write_text(str((project/'.git/objects').resolve())+'\n')
 subprocess.run(['/usr/bin/git','-C',str(where),'update-ref','HEAD',head],env=env,check=True)
attach_git_metadata(repo,C)
v1=root/'old-reader';v1.mkdir();s1='70097e0a2b933713d4fe91e6eddb5c2132951f89'
with tarfile.open(fileobj=io.BytesIO(git('archive',s1,'purser','experiments/e1','experiments/manifests/v1'))) as t:t.extractall(v1,filter='data')
attach_git_metadata(v1,s1)
e2_original=root/'e2-original-reader';e2_original.mkdir();s2='6c16e8c7381cdef140e9db803be26bd8eaa82798'
with tarfile.open(fileobj=io.BytesIO(git('archive',s2,'purser','experiments/e1','experiments/e2','experiments/manifests/v1'))) as t:t.extractall(e2_original,filter='data')
attach_git_metadata(e2_original,s2)
for label,reader,source,mod,prefix,raw_sha,rep_sha in [
 ('E1-original',v1,s1,'experiments.e1','e1-scripted-v1','6f20110ba734ecdefb568147e2d3fcc41d541cef35ee8bec70978c9aed89c4da','43c0b17ea308f914fdafd311c9cbb2eaa4c6ce7faf0dce61d8aacd7396009658'),
 ('E1-current',repo,C,'experiments.e1','e1-scripted-v2','ddee5e3efa0360a10e56d0a947221aa7238a712fd34c155145f4bf62546eeb27','0a82c9a1bbc7addcb1789adf3aa403ab65dfcd4b858d28811bfdcb87faa1fd21'),
 ('E2-original',e2_original,s2,'experiments.e2','e2-scripted-v1','17af95a99e6cfd9258ec07434174751e67612a9fbaf5975ba2bb14312d1eaeb8','724f536e0163cf12290d37d017111eb9bfa657708e84e292bb276fba909313eb')]:
 arm=root/prefix;arm.mkdir()
 for f in ['raw.zip','freeze.json','report.md']:
  path='experiments/results/'+prefix+'/'+f;data=git('show',C+':'+path);assert data==git('show','d865971fa3da20d0b82fa7bc56ca1b24c080270b:'+path);(arm/f).write_bytes(data)
 assert sha((arm/'raw.zip').read_bytes())==raw_sha and sha((arm/'report.md').read_bytes())==rep_sha
 if label=='E2-original':
  attempt=subprocess.run([sys.executable,'-B','-m',mod,'report',str(arm)],cwd=repo,env=env,capture_output=True)
  assert attempt.returncode!=0 and b'use a checkout with the registered source bytes' in attempt.stderr
  facts['E2_unchanged_authority_check']={'integrated_source':C,'exit':attempt.returncode,'reported':attempt.stderr.decode().splitlines()[-1],'detail':'Actual integration contains a changed purser/ tree; E2 registers the entire historical Purser treatment together with its reader.'}
 before=datetime.datetime.now(datetime.timezone.utc).isoformat()
 result=command([sys.executable,'-B','-m',mod,'report',str(arm)],reader);assert sha(result)==rep_sha and result==(arm/'report.md').read_bytes(),(label,sha(result))
 facts['registered_reports'][label]={'public_reader':source,'raw_sha256':raw_sha,'reported_sha256':sha(result),'reproduced_bytes':len(result),'start_utc':before,'exit':0};print(label,sha(result),flush=True)
p=out/'legacy-originals.json';p.write_text(json.dumps(facts,sort_keys=True,indent=2)+'\n');print('result',sha(p.read_bytes()),flush=True)
