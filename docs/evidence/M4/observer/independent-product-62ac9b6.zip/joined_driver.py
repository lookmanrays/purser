"""Independent registered engineering witness through the public joined M4 foreground/CLI."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import argparse,hashlib,json,os,select,shutil,signal,sqlite3,subprocess,sys,tempfile,time
THIS=Path(__file__).resolve();Q=THIS.parent;A=Q.parent
CFG=argparse.ArgumentParser();CFG.add_argument('--repo',type=Path,required=True);CFG.add_argument('--source',required=True);CFG.add_argument('--job');CFG.add_argument('--input',type=Path);CFG.add_argument('--out',type=Path);cfg=CFG.parse_args()
sys.path[:0]=[str(cfg.repo),str(A)]
from purser.kernel.store import Store
from purser.kernel.gate import admit
from purser.kernel.artifacts import Artifacts
from purser.effects.git import GitRepository
from purser.effects.foreground import request_effect,dispatch_effect,reconcile_effect
from continuity_seed import Prefix,trace_where,ASOF,EXP
from golden_reference import build
from git_reference import canonical,digest,tag_intent,candidate,git,writer_identity
ENV={'PATH':'/usr/bin:/bin','LC_ALL':'C','TZ':'UTC'}
C='C-notify';W='W2';F='F-publish';G='G-publish';BR='refs/heads/purser-demo'
def clock(t):return lambda:datetime.fromisoformat(t.replace('Z','+00:00'))
def bind(role,who,assignment):return dict(principal_id='principal:local',role=role,actor_id=who,commitment=C,assignment=assignment)
def cur(db):return Store(db).snapshot()['revision']
def prop(db,c,pid,*ops):return dict(v=1,proposal_id=pid,commitment=c,base_revision=cur(db),ops=list(ops),justification=[])
def snapshot(db):return Store(db).snapshot()
def indexed(s):return {r['id']:r for r in s['projection']['records']}
def rawref(b):
 r=Path(b['git_dir']);logs=git(r,'reflog','show','--format=%H%x09%gs',BR,'--').decode().splitlines()
 return dict(branch=git(r,'rev-parse',BR).decode().strip(),refs=git(r,'for-each-ref','--format=%(refname)%09%(objectname)').decode().splitlines(),branch_log=logs)
def read_ro(db):
 x=sqlite3.connect(Path(db).resolve().as_uri()+'?mode=ro',uri=True)
 try:return list(x.execute('select revision,body from events order by revision'))
 finally:x.close()
def read_cli(db,*args):
 cmd=[sys.executable,'-B','-m','purser','--db',str(db),*args];r=subprocess.run(cmd,cwd=cfg.repo,env=ENV,capture_output=True,timeout=20)
 if r.returncode:raise ValueError((args,r.returncode,r.stdout.decode(),r.stderr.decode()))
 return json.loads(r.stdout)
def cold_events(db,dst):
 src=read_ro(db);read_cli(dst,'init')
 with sqlite3.connect(dst) as cx:cx.executemany('insert into events(revision,body) values (?,?)',src)
 arts=Path(str(db)+'.artifacts');there=Path(str(dst)+'.artifacts');there.mkdir(exist_ok=True,mode=0o700)
 for f in arts.iterdir():
  raw=f.read_bytes();assert digest(raw)==f.name;(there/f.name).write_bytes(raw)
 replay=read_cli(dst,'replay','--as-of',ASOF)
 assert src==read_ro(dst) and replay==read_cli(dst,'status','--as-of',ASOF)
 return replay
def later_object(stage,old):
 git(stage,'read-tree',old);git(stage,'checkout-index','-a','-f')
 f=stage/'notify/retry.py';f.write_bytes(f.read_bytes()+b'\n# A later independently authorized edit.\n');git(stage,'add','notify/retry.py')
 tree=git(stage,'write-tree').decode().strip();return git(stage,'commit-tree',tree,'-p',old,inputs=b'Later independently authorized retry comment\n',env=writer_identity()).decode().strip()
def hold_marker(which):
 print(json.dumps({'cut':which,'pid':os.getpid(),'monotonic_ns':time.monotonic_ns()}),flush=True);signal.pause()
def worker():
 x=json.loads(cfg.input.read_bytes());db=x['db'];store=Store(db);repo=GitRepository(x['binding']);p=x['proposal'];j=cfg.job
 if j=='before':hold_marker('before')
 ct={} if x.get('live_clock') else {'clock':clock(x['time'])}
 if j=='reconcile' or j=='reconcile_before_reply':
  result=reconcile_effect(store,repo,p,**ct)
  if j=='reconcile_before_reply':hold_marker(j)
 elif j=='owner':result=admit(store,dict(principal_id='principal:local',role='principal',actor_id='principal:local',commitment=None,assignment=None),p,**ct)
 elif j=='request':result=request_effect(store,repo,x['executor_binding'],p,**ct)
 else:
  def held_cutoff():
   print(json.dumps({'cut':j,'pid':os.getpid(),'monotonic_ns':time.monotonic_ns()}),flush=True)
   until=time.monotonic()+20
   while not Path(x['resume_flag']).exists() and time.monotonic()<until:time.sleep(.02)
   if not Path(x['resume_flag']).exists():raise TimeoutError('coordinator release')
  ks={'after_authorization':held_cutoff} if j=='authorized_pause' else {'after_authorization':lambda:hold_marker('authorized')} if j=='authorized' else {'after_write':lambda:hold_marker('written')} if j=='written' else {}
  result=dispatch_effect(store,repo,p,**ct,**ks)
 print(json.dumps({'signature':x['proposal']['proposal_id'],'value':result,'pid':os.getpid(),'ended_monotonic_ns':time.monotonic_ns()},sort_keys=True),flush=True)
def external(root,job,db,b,p,when=ASOF,hold=False,**opts):
 x=dict(db=str(db),binding=b,proposal=p,time=when,**opts);f=root/('io-'+digest(canonical([x,job]))+'.json');f.write_bytes(canonical(x))
 cmd=[sys.executable,'-B',str(THIS),'--repo',str(cfg.repo),'--source',cfg.source,'--job',job,'--input',str(f)]
 if not hold:
  z=subprocess.run(cmd,capture_output=True,cwd=cfg.repo,env=ENV,timeout=35)
  if z.returncode:raise ValueError((job,z.stdout.decode(),z.stderr.decode()))
  return json.loads(z.stdout)
 z=subprocess.Popen(cmd,cwd=cfg.repo,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if not select.select([z.stdout],[],[],35)[0]:z.kill();raise TimeoutError(job)
 line=z.stdout.readline()
 if not line:raise ValueError((job,z.wait(),z.stderr.read().decode()))
 cut=json.loads(line);assert cut['cut']==job
 return z,cut
def kill(z):z.kill();assert z.wait(timeout=6)==-signal.SIGKILL;return {'pid':z.pid,'returncode':z.returncode,'observed_monotonic_ns':time.monotonic_ns()}
def make_intent(ids,scope=C,work=W,key=F,old=None,target=None,assignment='AS-B',g=2,grant=G):
 return dict(repository='R-notify',commitment=scope,work=work,generation=g,assignment=assignment,slot='publish',effect=key,capability='git.commit',resource=BR,expected_old=candidate(old or ids['start']),target=candidate(target or ids['lifecycle_b']),purpose='Publish the verified retry change on the allowed local branch.',grant=grant)
class JoinedPrefix(Prefix):
 def __init__(self,root,src,ids,repo):
  super().__init__(root,src,ids);self.git=repo
 def criterion(self,c,w,name):
  if w==W:self.require(c,W,F)
  super().criterion(c,w,name)
 def require(self,c,w,key):return self.local(c,dict(op='effect.require',id=key,work=w,slot='publish',repository='R-notify',repository_instance=self.git.binding['repository_instance'],resource=BR,paths=['notify/retry.py']))
 def grant(self,c,w,key,assignment,generation,grantee,expires):
  r=self.local(c,dict(op='grant.request',id=key,work=w,slot='publish',repository='R-notify',resource=BR,paths=['notify/retry.py'],assignment=assignment,generation=generation,grantee=grantee,expires_at=expires),expected='pending')
  return self.local(c,dict(op='approval.answer',id=r['details']['approval_id'],request_digest=r['digest'],decision='approve'))
def start_case(which):
 root,src,ids=trace_where();ids['joining_later']=later_object(src,ids['lifecycle_b'])
 re=GitRepository.initialize(root/'canonical.git','R-notify',BR,src/'.git',ids['start'],candidates=[ids[k] for k in ['lifecycle_a','lifecycle_b','joining_later','e3']]);b=re.binding
 seed=JoinedPrefix(root,src,ids,re).run();db=seed.store.path
 for key,expiry in [('G-expired','2026-11-18T13:50:00.000000Z'),(G,EXP),('G-retired','2026-11-18T15:00:00.000000Z')]:seed.grant(C,W,key,'AS-B',2,'executor:beta',expiry)
 seed.local(C,dict(op='grant.revoke',id='G-retired'));i=make_intent(ids)
 req=prop(db,C,'p-native-request',dict(op='effect.request',id=F,intent=i));bound=external(root,'request',db,b,req,executor_binding=bind('executor','executor:beta','AS-B'))
 assert bound['value']['disposition']=='admitted'
 return root,ids,re,seed,db,i,req
def auth(db,tid,pid=None,work=F,scope=C):return prop(db,scope,pid or 'p-dispatch-'+tid,dict(op='effect.authorize',id=tid,effect=work))
def observation(db,tid,ident,scope=C,work=F):return prop(db,scope,'p-observe-'+ident,dict(op='effect.reconcile',id=ident,effect=work,attempt=tid))
def confirm(answer):assert answer['value']['disposition']=='admitted',answer
def second_advance(root,ids,re,seed,db):
 c='C-next';w='W-next';f='F-next';seed.active(c,w);seed.require(c,w,f)
 seed.local(c,dict(op='work.assign',id='AS-next',work=w,executor='executor:next'))
 seed.proposal(c,'executor','executor:next','AS-next',dict(op='result.submit',id='Result-next',assignment='AS-next',candidate=candidate(ids['joining_later'])))
 seed.grant(c,w,'G-next','AS-next',1,'executor:next',EXP)
 i=make_intent(ids,c,w,f,old=ids['lifecycle_b'],target=ids['joining_later'],assignment='AS-next',g=1,grant='G-next')
 bb=dict(principal_id='principal:local',role='executor',actor_id='executor:next',commitment=c,assignment='AS-next')
 requested=external(root,'request',db,re.binding,prop(db,c,'p-request-next',dict(op='effect.request',id=f,intent=i)),executor_binding=bb);confirm(requested)
 started=external(root,'dispatch',db,re.binding,auth(db,'T-next',work=f,scope=c));assert started['value'][1] is True
 rec=external(root,'reconcile',db,re.binding,observation(db,'T-next','Obs-Git-next',scope=c,work=f));confirm(rec)
 return dict(intent=i,request=requested,dispatch=started,reconciliation=rec,refs=rawref(re.binding))
def run():
 tag=cfg.source
 assert len(tag)==40 and cfg.out is not None
 info=json.loads((Q/'joined-source.json').read_bytes());assert Path(info['checkout'])==cfg.repo and info['source']==tag
 outdir=cfg.out;outdir.mkdir(parents=True,exist_ok=True)
 def put(k,value):
  f=outdir/(k+'.json');f.write_bytes(canonical(value)+b'\n');return {'name':f.name,'sha256':digest(f.read_bytes())}
 results={}
 for variant in ['landed','absent','revoked-first']:
  root,ids,repo,seed,db,intent,req=start_case(variant);b=repo.binding;res={'scope':variant,'real_fixture':str(root),'original_inputs':{'intent':intent,'binding':b,'m3_m4_original_proposals':seed.records},'at_initial_ready':read_cli(db,'status','--as-of',ASOF)}
  initial=rawref(b);assert len(initial['branch_log'])==1
  ready=cur(db);p1=auth(db,'T1');wanted=seed.human_pending['details']['approval_id']
  pre=external(root,'before',db,b,p1,hold=True);z,point=pre;res['original_process_before_dispatch']=dict(start=point,finish=kill(z));assert cur(db)==ready and rawref(b)==initial
  if variant=='landed':
   # I1: a role-bound multi-op domain change and forbidden second op must leave only its rejected receipt.
   m=prop(db,C,'p-atomic-principal-reject',dict(op='work.create',id='W-should-not-exist',parent='W-root',title='Atomic rollback control'),dict(op='grant.revoke',id='G-never-created'))
   invalid=external(root,'owner',db,b,m);assert invalid['value']['disposition']=='rejected' and 'W-should-not-exist' not in indexed(snapshot(db))
   res['atomic_I1']=invalid;p1=auth(db,'T1')
   original,after=external(root,'written',db,b,p1,hold=True)
   res['written_before_ack']=dict(cut=after,refs=rawref(b))
   historical=read_cli(db,'status','--as-of',ASOF);base=historical['revision'];gold=build(wanted,ids)
   assert historical['answers']==gold and repo.observe(intent,'T1')['state']=='pending'
   res['golden']=historical;res['actual_expiry_at_same_revision']=read_cli(db,'status','--revision',str(base),'--as-of',EXP)
   assert [k for k in gold if historical['answers'][k]!=res['actual_expiry_at_same_revision']['answers'][k]]==['q05']
   for name,args in [('why_W2',['why','W2']),('why_W1',['why','W1']),('why_Wdoc',['why','W-doc-stale']),('frontier',['frontier']),('context_B',['context','AS-B'])]:
    res[name]=read_cli(db,*args,'--revision',str(base),'--as-of',ASOF)
   assert res['frontier']['actions']==gold['q10'];witness=res['why_W1']['support']['basis']['obligations'];assert witness[0]['evidence']=='E-prefs'
   assert res['why_W2']['support']['basis']['obligations'][0]['evidence']=='E-B' and not res['why_W2']['support']['basis']['effects']
   # Rebuild from only original journal entries and each independently rehashed artifact.
   prefix=root/'original-prefix.sqlite3';assert cold_events(db,prefix)==historical
   assert rawref(b)==res['written_before_ack']['refs'];res['post_write_original_broker']=kill(original)
   settled,cut=external(root,'reconcile_before_reply',db,b,observation(db,'T1','Obs-Git-B'),hold=True)
   original_rec=observation(db,'T1','Obs-later-unused');res['reconcile_committed_before_reply']=dict(cut=cut,receiver_killed=kill(settled))
   # Recover the exact original proposal instead of sending the new one.
   just=next(json.loads(f.read_bytes())['proposal'] for f in root.glob('io-*.json') if json.loads(f.read_bytes())['proposal']['proposal_id']=='p-observe-Obs-Git-B')
   reac=external(root,'reconcile',db,b,just);confirm(reac)
   thisrec=indexed(snapshot(db))['Obs-Git-B'];stored=json.loads(Artifacts(db).read(thisrec['fields']['artifact_sha256']))
   assert stored['state']=='confirmed_happened' and stored['branch_tip']==stored['receipt_target']==ids['lifecycle_b'] and stored['matching_transitions']==1
   dup=external(root,'dispatch',db,b,p1);assert dup['value'][1] is False and rawref(b)==res['written_before_ack']['refs']
   subnone=external(root,'request',db,b,req,executor_binding=bind('executor','executor:beta','AS-B'));confirm(subnone)
   res['settled_original']=dict(transport_replay=reac,measured=stored,old_cutoff_replay=dup)
   res['after_settlement']=read_cli(db,'status','--as-of',ASOF)
   for subject in [W,'W-notify']:
    close=seed.proposal(C,'closure','closure:fixture',None,dict(op='work.close',id=subject));assert close['disposition']=='admitted'
   preacc=read_cli(db,'status','--as-of',ASOF);assert {'action':'principal_accept','subject':'W-root'} in preacc['answers']['q10']
   from purser.kernel.workview import WorkView
   vw=WorkView(snapshot(db)['projection']);valid=vw.outcome('W-root');basis=vw.basis('W2');assert basis['effects']==[{'effect':F,'observation':'Obs-Git-B'}]
   bad=seed.local(C,dict(op='work.accept',id='W-root',outcome='0'*64),expected='rejected')
   ok=seed.local(C,dict(op='work.accept',id='W-root',outcome=valid))
   assert indexed(snapshot(db))[C]['fields']['state']=='satisfied' and read_cli(db,'status','--revision',str(base),'--as-of',ASOF)==historical
   res['closure']=dict(current_basis=basis,root_outcome=valid,pre_accept=preacc,bad=bad,accepted=ok)
   advanced=second_advance(root,ids,repo,seed,db)
   for name in ('request','reconciliation'):confirm(advanced[name])
   after2=rawref(b);assert len(after2['branch_log'])==3 and after2['branch']==ids['joining_later']
   # Only the earlier ledger copy is used from here. No physical release is issued from it.
   cold=external(root,'reconcile',prefix,b,observation(prefix,'T1','Obs-cold-original'));confirm(cold)
   row=indexed(snapshot(prefix))['Obs-cold-original'];obs=json.loads(Artifacts(prefix).read(row['fields']['artifact_sha256']))
   assert (obs['state'],obs['receipt_target'],obs['branch_tip'],obs['matching_transitions'])==('confirmed_happened',ids['lifecycle_b'],ids['joining_later'],1) and rawref(b)==after2
   res['genuine_later_writer']=advanced;res['prefix_after_later_advance']=dict(receipt=cold,observation=obs)
   # I4,I8,I9,I11: original genuine old-vs-new evidence and original unchanged sibling basis/cutoffs.
   historical_checks={}
   for name,rev in [('opinion',seed.pre_opinion),('invalidated',seed.pre_replace),('late',seed.pre_current)]:
    st=read_cli(db,'status','--as-of',ASOF,'--revision',str(rev));historical_checks[name]=st
   assert {'decision':'D-original','state':'effective','support':['A1']} in historical_checks['opinion']['answers']['q03']
   assert next(s for s in historical_checks['invalidated']['answers']['q02'] if s['work']==W)['state']=='stale'
   assert next(s for s in historical_checks['late']['answers']['q07'] if s['obligation']=='O-retries')['state']=='open'
   before=read_cli(db,'context','AS-A','--as-of',ASOF,'--revision',str(seed.pre_opinion))
   assert ['E-prefs']==res['why_W1']['support']['basis']['obligations'][0:1][0:1][0]['evidence'].split()
   res['legacy_source_history']=historical_checks;res['old_executor_context']=before
  elif variant=='absent':
   z,point=external(root,'authorized',db,b,p1,hold=True)
   assert rawref(b)==initial and read_cli(db,'status','--as-of',ASOF)['answers']['q06']==[{'effect':F,'attempt':'T1','state':'dispatching'}]
   withheld=external(root,'reconcile',db,b,observation(db,'T1','Obs-pending'));confirm(withheld);assert withheld['value']['details']['state']=='pending'
   raw=repo.observe(intent,'T1');assert not raw['writer_quiescent'] and raw['state']=='pending'
   res['live_original']=dict(cut=point,public_observation=withheld,underlying=raw,refs=rawref(b));res['killed_before_mutation']=kill(z)
   same=external(root,'dispatch',db,b,p1);assert not same['value'][1] and rawref(b)==initial
   newer=external(root,'dispatch',db,b,auth(db,'T-forbidden'));assert not newer['value'][1] and rawref(b)==initial
   obs=external(root,'reconcile',db,b,observation(db,'T1','Obs-absent'));confirm(obs);assert obs['value']['details']['state']=='confirmed_absent'
   witness=indexed(snapshot(db))['Obs-absent'];facts=json.loads(Artifacts(db).read(witness['fields']['artifact_sha256']));assert facts['history_intact'] and facts['writer_quiescent'] and facts['receipt_target'] is None and facts['branch_tip']==ids['start']
   retry=external(root,'dispatch',db,b,auth(db,'T2'));assert retry['value'][1] and rawref(b)['branch']==ids['lifecycle_b']
   rec=external(root,'reconcile',db,b,observation(db,'T2','Obs-after-retry'));confirm(rec)
   assert rec['value']['details']['state']=='confirmed_happened' and len(rawref(b)['branch_log'])==2
   res['known_absent_and_retry']=dict(replayed=same,blocked=newer,original=obs,facts=facts,fresh=retry,settled=rec,refs=rawref(b))
  else:
   rev=external(root,'owner',db,b,prop(db,C,'p-revoke-first',dict(op='grant.revoke',id=G)));confirm(rev)
   d=external(root,'dispatch',db,b,auth(db,'T1'));assert not d['value'][1] and d['value'][0]['code']=='grant_revoked' and rawref(b)==initial
   res['revocation_wins_before_dispatch']=dict(revoke=rev,dispatch=d,native=rawref(b))
  results[variant]=put(variant,res);print(variant,results[variant],flush=True)
 return results
if __name__=='__main__':
 if cfg.job:worker()
 else:
  results=run();print(json.dumps(results,sort_keys=True))
