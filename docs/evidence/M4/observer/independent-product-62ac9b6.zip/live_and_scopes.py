"""Observe normal live CLI-authorized Git and the opposite real process ordering."""
from joined_driver import *
def live(case):
 root,src,ids=trace_where(); repo=GitRepository.initialize(root/'repo.git','R-notify',BR,src/'.git',ids['start'],candidates=[ids['lifecycle_b'],ids['e3']]);b=repo.binding
 seed=JoinedPrefix(root,src,ids,repo).run();db=seed.store.path
 before=datetime.now(timezone.utc);duration=5 if case=='wall-clock-expiry' else 600
 from purser.kernel.wire import format_time
 until=before+timedelta(seconds=duration);deadline=format_time(until)
 trusted=bind('principal','principal:local',None);trusted['commitment']=None
 grant=prop(db,C,'p-live-permission',dict(op='grant.request',id=G,work=W,slot='publish',repository='R-notify',resource=BR,paths=['notify/retry.py'],assignment='AS-B',generation=2,grantee='executor:beta',expires_at=deadline))
 held=admit(Store(db),trusted,grant);assert held['disposition']=='pending'
 ans=prop(db,C,'p-live-answer',dict(op='approval.answer',id=held['details']['approval_id'],request_digest=held['digest'],decision='approve'))
 yes=admit(Store(db),trusted,ans);assert yes['disposition']=='admitted'
 bound=prop(db,C,'p-live-intent',dict(op='effect.request',id=F,intent=make_intent(ids)))
 req=external(root,'request',db,b,bound,executor_binding=bind('executor','executor:beta','AS-B'),live_clock=True);confirm(req)
 alias='F-forbidden-alias';other=make_intent(ids,key=alias)
 alias_out=external(root,'request',db,b,prop(db,C,'p-duplicate-slot',dict(op='effect.request',id=alias,intent=other)),executor_binding=bind('executor','executor:beta','AS-B'),live_clock=True);assert alias_out['value']['code']=='slot_occupied'
 proof_v1=admit(Store(db),trusted,ans);assert proof_v1==yes
 source=read_cli(db,'status');assert {'action':'authorize_dispatch','subject':F} in source['answers']['q10']
 first=auth(db,'T-live');initial=rawref(b)
 bf=root/'registered-binding.json';bf.write_bytes(canonical(b));tracked=[]
 def cli():
  st=read_cli(db,'run','--git-binding',str(bf));tracked.append(st);return st
 u={'controlled_fixture':str(root),'initial_utc':format_time(before),'grant_expiry':deadline,'found_at_live_cutoff':source,'pending':held,'approval':yes,'human_answer_retry':proof_v1,'alias_refused':alias_out}
 if case=='wall-clock-expiry':
  while datetime.now(timezone.utc)<until+timedelta(milliseconds=25):time.sleep(.04)
  actual_now=format_time(datetime.now(timezone.utc));after=read_cli(db,'frontier')
  ack=external(root,'dispatch',db,b,first,live_clock=True);assert ack['value'][1] is False and ack['value'][0]['code']=='grant_expired'
  assert len(rawref(b)['branch_log'])==1 and {'action':'authorize_dispatch','subject':F} not in after['actions']
  normal=cli();assert normal['state']=='idle';u.update(actual_end_utc=actual_now,past=after,direct_live_denial=ack,ordinary_live_driver=normal,raw_refs=rawref(b))
 elif case=='cutoff-first':
  flag=root/'continue-original';proc,cut=external(root,'authorized_pause',db,b,first,hold=True,live_clock=True,resume_flag=str(flag))
  try:
   active=actual=read_cli(db,'status');assert active['answers']['q06']==[{'effect':F,'attempt':'T-live','state':'dispatching'}]
   rev=external(root,'owner',db,b,prop(db,C,'p-live-revoke',dict(op='grant.revoke',id=G)),live_clock=True);confirm(rev)
   during=indexed(snapshot(db));assert during[G]['fields']['in_flight_at_revocation']==['T-live']
   assert rawref(b)==initial
   flag.touch();stdout,stderr=proc.communicate(timeout=14);assert proc.returncode==0 and not stderr
   complete=json.loads(stdout);assert complete['value'][1] and rawref(b)['branch']==ids['lifecycle_b']
  finally:
   flag.touch(exist_ok=True)
   if proc.poll() is None:proc.kill();proc.wait()
  rec=cli();assert rec['action']=={'action':'reconcile','subject':F} and rec['observation']=='confirmed_happened'
  retried=external(root,'dispatch',db,b,first,live_clock=True);assert retried['value'][1] is False and len(rawref(b)['branch_log'])==2
  current=indexed(snapshot(db))
  u.update(cutoff=cut,cutoff_authorized_at=during['T-live']['fields']['authorized_at'],revoked_after_cutoff=rev,in_flight_at_revoke=during[G]['fields']['in_flight_at_revocation'],physical_release_after_revocation=complete,ordinary_cli_reconciled=rec,replay=retried,refs=rawref(b),q05=read_cli(db,'status')['answers']['q05'])
 elif case=='normal-cli':
  out=cli();assert out['action']=={'action':'authorize_dispatch','subject':F} and out['issued'] and rawref(b)['branch']==ids['lifecycle_b']
  rec=cli();assert rec['action']=={'action':'reconcile','subject':F} and rec['observation']=='confirmed_happened'
  closes=[cli(),cli()];assert [c['action'] for c in closes]==[{'action':'evaluate_close','subject':'W2'},{'action':'evaluate_close','subject':'W-notify'}]
  baseline=snapshot(db);refs=rawref(b);idle=cli();idle2=cli();assert idle['state']==idle2['state']=='idle' and baseline==snapshot(db) and refs==rawref(b) and len(refs['branch_log'])==2
  bad=prop(db,C,'p-claim-verifier',dict(op='evidence.record',id='E-executor-rejected',run='V-B',observation='Obs-B',verdict='pass'))
  refuse=admit(Store(db),bind('executor','executor:beta','AS-B'),bad);assert refuse['code']=='forbidden' and 'E-executor-rejected' not in indexed(snapshot(db))
  q=read_cli(db,'why','W2');u.update(ordinary_driver=tracked,current_basis=q['support']['basis'],idle_head=idle['revision'],no_extra_mutation=refs==rawref(b),executor_self_verdict_rejected=refuse)
 else:raise ValueError(case)
 return u
if __name__=='__main__':
 files={}
 for case in ['cutoff-first','normal-cli','wall-clock-expiry']:
  data=live(case);dest=cfg.out/(case+'.json');dest.write_bytes(canonical(data)+b'\n');files[case]=digest(dest.read_bytes());print(case,files[case],flush=True)
