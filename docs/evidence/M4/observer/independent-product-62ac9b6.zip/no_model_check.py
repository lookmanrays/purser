"""Observe cold, public runtime calls with isolated environment and an interpreter audit hook."""
from pathlib import Path
import atexit
import hashlib
import json
import os
import runpy
import subprocess
import sys

here = Path(__file__).resolve().parent
out = here / "outputs"
def packed(value):
    return json.dumps(value, sort_keys=True, indent=2).encode() + b"\n"

if len(sys.argv)>1 and sys.argv[1] == "child":
    target, db, stdio, *args = sys.argv[2:]
    facts = {"model_imports": [], "network": [], "subprocesses": []}
    providers = {"openai", "anthropic", "litellm", "ollama", "langchain", "langchain_openai", "transformers", "vertexai", "cohere"}
    def audit(event, arguments):
        if event == "import" and (arguments[0].partition(".")[0] in providers or arguments[0].startswith(("google.generativeai","google.genai"))):
            facts["model_imports"].append(arguments[0])
        if event in ("socket.connect","socket.getaddrinfo","socket.sendto"):
            facts["network"].append(event)
        if event == "subprocess.Popen":
            facts["subprocesses"].append(str(arguments[0]))
    sys.addaudithook(audit)
    atexit.register(lambda:Path(stdio).write_bytes(packed(facts)))
    sys.path.insert(0,target)
    sys.argv = ["purser","--db",db,*args]
    runpy.run_module("purser",run_name="__main__")
else:
    src=json.loads((here/"joined-source.json").read_bytes())["checkout"]
    control=Path(json.loads((out/"normal-cli.json").read_bytes())["controlled_fixture"])
    commands=[["status","--as-of","2026-11-18T13:59:59.000000Z"],["why","W2"],["frontier"],["run","--git-binding",str(control/"registered-binding.json")],["status","--as-of","2026-11-18T13:59:59.000000Z"]]
    all_evidence=[]
    statuses=[]
    for number,cmd in enumerate(commands):
        auditfile=out/(".audit-"+str(number))
        completed=subprocess.run([sys.executable,"-B",str(Path(__file__).resolve()),"child",src,str(control/"cutoff.sqlite3"),str(auditfile),*cmd],cwd=src,env={"PATH":"/usr/bin:/bin","LC_ALL":"C","TZ":"UTC"},capture_output=True,check=True)
        result=json.loads(completed.stdout); events=json.loads(auditfile.read_bytes()); auditfile.unlink()
        assert not completed.stderr and not any(events.values()), (cmd,events,completed.stderr)
        if cmd[0]=="run":
            assert result["state"]=="idle"
        if cmd[0]=="status":
            statuses.append(result)
        all_evidence.append({"public_call":cmd,"observed":events,"stdout_sha256":hashlib.sha256(completed.stdout).hexdigest()})
    assert statuses[0]==statuses[1]
    (out/"no-model-cold.json").write_bytes(packed({"source":json.loads((here/"joined-source.json").read_bytes())["source"],"environment_keys":["LC_ALL","PATH","TZ"],"fresh_processes":len(commands),"public_calls":all_evidence,"unchanged_head":statuses[0]["head_hash"],"revision":statuses[0]["revision"]}))
