"""The plain control defers before a stress exposure. The other arm genuinely holds on its current evidence."""
from pathlib import Path
import json,sys,threading,subprocess
import private_cli
from private_cli import Handler,Service,create_enrollment,play,save,launch,sha
from e3_join import choose as follow
def choose(mode,n,menu,history):
    if mode=='defer_early': return {"action":"defer","arguments":{"reason":"There is no safe first step selected in this fixture.","next_action":"Check the scope before dispatch."}}
    return follow(mode,n,menu,history)
def main():
    repo=Path(sys.argv[1]).resolve();work=Path(sys.argv[2]).resolve();work.mkdir();sys.path.insert(0,str(repo));private_cli.choose=choose
    from experiments.model_study.report import inspect
    s=Service(("127.0.0.1",0),Handler);s.calls={};s.errors=[];s.arrived=threading.Event();s.release=threading.Event()
    th=threading.Thread(target=s.serve_forever,daemon=True);th.start();out={}
    try:
        series=create_enrollment(repo,work,"stress",s.server_port)
        for label,arm,mode in (('unexposed','loop','defer_early'),('observed-pending','purser','follow')):
            u=('E3','inconclusive-observation',3001,arm)
            record=play(repo,work,s,series,'/'.join(map(str,u)),mode,label,qualify=False)
            _,cs=inspect(series);case=cs[u];facts=case['facts']
            git=Path(record['case'])/'trial'/'canonical.git';log=subprocess.check_output(['git','--git-dir',str(git),'reflog','show','--format=%H%x09%gs','refs/heads/notify']).decode().splitlines()
            physical=[line for line in log if '\tpurser.effect ' in line]
            assert not physical and facts['effect_count']==0
            if arm=='loop':
                assert facts.get('eligible') is not True and len(s.calls[label])==1
            else:
                assert facts['eligible'] and facts['stress_held_pending'] and facts['uncertainty_remaining']
            out[label]={'raw':record['raw_sha256'],'physical':physical,'cost':case['cost'].exact,'all_facts':{k:v for k,v in facts.items() if k in ('eligible','effect_count','duplicate_count','uncertainty_remaining','stress_held_pending','original_truth','original_report','last_decision','declarations','releases')}}
        report=launch(repo,'report',series).stdout;(work/'report.md').write_bytes(report)
        text=report.decode().split('## E3\n',1)[1]
        cols=next(r for r in text.splitlines() if r.startswith('Each cell subtracts that comparator')).split('order — ')[1].rstrip('.').split(', ')
        diff=next(r for r in text.splitlines() if r.startswith('| inconclusive-observation / 3001 |'))
        cells=diff.split('|')[2].strip().split(' / ')
        out['published_pair']=dict(zip(cols,cells,strict=True));out['case_rows']=[r for r in text.splitlines() if r.startswith('| inconclusive-observation | 3001 |') or 'inconclusive-observation / 3001' in r]
        out['source']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()
        out['report_sha256']=sha(report);save(work/'independent.json',out)
        print(out['published_pair'],sha((work/'independent.json').read_bytes()))
    finally:s.release.set();s.shutdown();s.server_close();th.join()
if __name__=='__main__':main()
