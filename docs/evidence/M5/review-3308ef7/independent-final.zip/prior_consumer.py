import json,sys
from pathlib import Path
from dataclasses import asdict
from private_cli import launch,save,sha
repo=Path(sys.argv[1]).resolve();mode=sys.argv[2];root=Path(sys.argv[3]).resolve();evidence=Path(sys.argv[4]).resolve();sys.path.insert(0,str(repo))
from experiments.model_study.report import render,inspect
from experiments.model_costs import ModelCaseCost
def body(t):
    if isinstance(t,bytes):t=t.decode()
    return t.split('## E1\n',1)[1].split('## E3\n',1)[0].encode()
if mode=='export':
 evidence.mkdir();results={}
 for row in json.loads((root/'controls.json').read_bytes()):
    case=Path(row['case']);series=case.parents[4];frozen,cases=inspect(series)
    public=launch(repo,'report',series).stdout
    assert render(frozen,cases).encode()==public
    portable=[(list(u),{**c,'cost':asdict(c['cost'])}) for u,c in cases.items()]
    results[row['index']]={'freeze':frozen,'cases':portable,'previous_native_report':sha(public),'previous_coding_sections':sha(body(public)),'source_raw':row['raw_sha256']}
 save(evidence/'authenticated-consumer-inputs.json',results)
else:
    data=json.loads((evidence/'authenticated-consumer-inputs.json').read_bytes());checks={}
    for label,obj in data.items():
        cases={tuple(u):{**c,'cost':ModelCaseCost(**c['cost'])} for u,c in obj['cases']}
        current=sha(body(render(obj['freeze'],cases)));assert current==obj['previous_coding_sections'],(label,current)
        checks[label]={'source_raw':obj['source_raw'],'old_cli_full_report':obj['previous_native_report'],'matched_coding_sections_sha256':current}
    save(evidence/'comparison.json',{'scope':'Binary-identical rendered E1/E2 sections using the old native case records and the new renderer. No re-registration of old data.','from_source':'bf705a4889245167c19a515025f8995cb318c434','consumer_source':'3308ef7b9e256c980e0b5c4186d3be7708b98fe0','rows':checks})
    print(len(checks),sha((evidence/'comparison.json').read_bytes()))
