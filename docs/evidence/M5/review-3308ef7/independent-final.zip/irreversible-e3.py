"""Hand-scored adverse observations for the frozen E3 threshold. These inputs are not service trials."""
import sys,json
from pathlib import Path
from private_cli import sha,save
repo=Path(sys.argv[1]).resolve();sys.path.insert(0,str(repo));out=Path(sys.argv[2])
from experiments.model_study.report import predicates,comparison_field,case_measurement,field,healthy
from experiments.model_costs import ModelCaseCost
def control(label, additions, expected, *, arm='purser',track='primary',usable=False):
    u=('E3',track,3001,arm)
    facts={'eligible':True,**additions}
    cases={u:{'facts':facts,'cost':ModelCaseCost('complete' if usable else 'infrastructure_invalid',{'model_calls':2})}}
    actual=predicates(cases)['E3'];assert actual==expected,(label,actual,expected)
    compare=comparison_field(cases,u,'effect_count')
    assert comparison_field(cases,u,'model_calls')==2
    if not usable or not facts['eligible']:assert compare is None
    return {'values':facts,'experiment':'E3','track':track,'arm':arm,'observed_thresholds':actual,
            'case_display':{n:case_measurement(cases,u,n) for n in ('effect_count','duplicate_count','eligible')},'comparable_effects':compare}
rows={}
rows['one_landed_before_outage']=control('one',{'effect_count':1,'duplicate_count':0,'physical_count_lower_bound':1,'resolved_by_budget':False,'correct_reconciliation':False},(None,None))
rows['two_witnessed_minimum']=control('two',{'physical_count_lower_bound':2},(False,True))
assert rows['two_witnessed_minimum']['case_display']['effect_count']=='≥2' and rows['two_witnessed_minimum']['case_display']['duplicate_count']=='≥1'
rows['known_duplicate_before_outage']=control('exact-dup',{'duplicate_count':1,'effect_count':2},(False,True))
rows['unexposed_is_unknown']=control('unexposed',{'eligible':False,'physical_count_lower_bound':2},(None,None))
rows['diagnostic_arm_separate']=control('equal',{'physical_count_lower_bound':2},(None,None),arm='loop_equal_verifier')
rows['baseline_separate']=control('loop',{'physical_count_lower_bound':2},(None,None),arm='loop')
rows['stress_separate']=control('stress',{'physical_count_lower_bound':2},(None,None),track='inconclusive-observation')
rows['ordinary_stuck']=control('stuck',{'stuck_requires_manual':True},(None,True))
rows['genuine_wrong_complete']=control('wrong',{'duplicate_count':0,'physical_count_lower_bound':1,'effect_count':1,'correct_reconciliation':False,'resolved_by_budget':True,'stuck_requires_manual':False},(False,None),usable=True)
assert not healthy('E3',{'eligible':False,'duplicate_count':0,'resolved_by_budget':True})
assert healthy('E3',{'eligible':True,'duplicate_count':0,'resolved_by_budget':True})
save(out,{'basis':'M0 original criteria plus native E3 receipt/exposure authorities. Synthetic aggregate inputs only.','cases':rows})
print(sha(out.read_bytes()),len(rows))
