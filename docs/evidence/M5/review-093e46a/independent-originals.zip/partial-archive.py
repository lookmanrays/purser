"""Read an explicit private copy missing one late protected receipt; preserve all original files."""
import json,shutil,subprocess,sys
from pathlib import Path
from cold_independent import get,ref
from private_cli import launch,save,sha
repo=Path(sys.argv[1]).resolve();sys.path.insert(0,str(repo))
from experiments.model_study.report import inspect,field
source=Path(sys.argv[2]).resolve();work=Path(sys.argv[3]).resolve()
shutil.copytree(source,work,copy_function=__import__('os').link)
unit=("E2","primary",2001,"loop")
case=work/"cases"/"E2"/"primary"/"2001"/"loop"
raw=get(case/"raw.json");journal=ref(case,raw["artifacts"]["journal"])
point=next(r["payload"] for r in journal if r["kind"]=="fault")
last=next(r["payload"] for r in reversed(journal) if r["kind"]=="oracle" and r["payload"]["criterion"]=="queue/composition" and r["payload"]["version"]==2)
# Only one verified report emitted after the original terminal, on a copied directory, is made unavailable.
removed=last["evidence"]
p=case/removed["path"];assert sha(p.read_bytes())==removed["sha256"]
p.unlink()
assert (source/p.relative_to(work)).is_file()
contents=launch(repo,"report",work).stdout;(work/"offline.md").write_bytes(contents)
_,cases=inspect(work);r=cases[unit]
summary={"scope":"disposable missing-object readback of an intact, separately preserved native canned original",
    "only_omitted":removed,"untouched_before_sha":point["before"]["plan_sha256"],"untouched_after_sha":point["after"]["plan_sha256"],
    "original_lower_bound_for_reopen":2,"original_native_registered_raw_sha256":sha((case/"raw.json").read_bytes()),
    "returned_facts":r["facts"],"returned_terminal":r["terminal"],"validity":r["cost"].validity,
    "visible_intervention":field(cases,unit,"intervention_reached"),"visible_w3_reopenings":field(cases,unit,"unaffected_reopened"),
    "returned_cost_exact":r["cost"].exact,"reported_errors":r["errors"]}
save(work/"independent.json",summary)
print(summary['validity'],summary['visible_intervention'],summary['returned_cost_exact'],summary['reported_errors'][:1])
