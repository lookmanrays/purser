"""A real zero-price HTTP error after one W3 reopen, through the standard CLI."""
from pathlib import Path
import json,sys,threading
from private_cli import Handler,Service,play,create_enrollment,save,launch
class LostResponse(Handler):
    def send_header(self,key,value):
        mode,label,_=self.server.mode
        if key=="Content-Type" and len(self.server.calls[label])==6:
            value="text/plain"
        return super().send_header(key,value)
def main():
    repo=Path(sys.argv[1]).resolve();folder=Path(sys.argv[2]).resolve();folder.mkdir();sys.path.insert(0,str(repo))
    service=Service(("127.0.0.1",0),LostResponse); service.errors=[];service.calls={};service.release=threading.Event();service.arrived=threading.Event()
    worker=threading.Thread(target=service.serve_forever,daemon=True);worker.start()
    try:
        series=create_enrollment(repo,folder,"witness",service.server_port)
        result=play(repo,folder,service,series,"E2/primary/2001/loop","E2-reopens","after-return-error")
        save(folder/"controls.json",[result]);(folder/"source.txt").write_text((repo/".git/HEAD").read_text())
        (folder/"adverse.md").write_bytes(launch(repo,"report",series).stdout)
    finally:
        service.release.set();service.shutdown();service.server_close();worker.join()
if __name__=="__main__":main()
