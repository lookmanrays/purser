"""Capture or independently replay the real M3 child in Purser's local project ledger."""
import argparse
from contextlib import closing
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
from zipfile import ZipFile, ZIP_DEFLATED


def load_helpers(repo):
    sys.path.insert(0,str(repo))
    loc=repo/'docs/evidence/M3/series_continuity.py'
    s=importlib.util.spec_from_file_location('m3_public_history',loc)
    module=importlib.util.module_from_spec(s)
    s.loader.exec_module(module)
    return module


def public(helper,db,rev,moment):
    options=('--revision',str(rev),'--as-of',moment)
    return {'status':helper.cli(db,'status',*options),'frontier':helper.cli(db,'frontier',*options),
            'm3':helper.cli(db,'why','W-m3-decision-impact',*options),
            'project':helper.cli(db,'why','W-purser-delivery',*options)}


def capture(repo,helper,db,dest):
    from purser.kernel.artifacts import Artifacts
    from purser.kernel.store import Store
    from purser.kernel.wire import canonical
    snap=Store(db).snapshot()
    rev=snap['revision']
    with closing(sqlite3.connect(db.resolve().as_uri()+'?mode=ro',uri=True)) as connection:
        raw=[row[0] for row in connection.execute('SELECT body FROM events WHERE revision<=? ORDER BY revision',(rev,))]
    events=[json.loads(line) for line in raw]
    assert len(raw)==rev and events[-1]['hash']==snap['head_hash']
    assert {e['data']['id'] for e in events if e['type']=='CommitmentCreated'}=={'C-m2-explain-work','C-purser-delivery'}
    with ZipFile(repo/'docs/evidence/M2/development-log.zip') as previous:
        assert raw[:24]==previous.read('events.jsonl').splitlines()
    observations=public(helper,db,rev,events[-1]['at'])
    work=observations['m3']['record']['fields']
    assert work['state']=='closed' and work['closed_outcome'] and work['result']=='R-794ec4970c8a41c39b70193a02a3c2ea'
    assert work['candidate']=={'kind':'git.commit','algorithm':'sha1','digest':'1baab9ec2d13c6ca5842199027df9a02f27487db'}
    manifest={'format':'purser.m3.project-ledger.v1','revision':rev,'head_hash':snap['head_hash'],
              'integration':work['candidate'],'m3_outcome':work['closed_outcome'],'real_verification_run':'V-real-m3-integration-1',
              'as_of':events[-1]['at'],'historical_M2_head':events[23]['hash'],'objects':[]}
    content={'events.jsonl':b'\n'.join(raw)+b'\n','public-readback.json':canonical(observations),
             'ledger_receipt.py':Path(__file__).read_bytes()}
    keys={v for e in events for k,v in e['data'].items() if k in ('definition_sha256','environment_sha256','artifact_sha256')}
    store=Artifacts(db)
    for key in sorted(keys):
        data=store.read(key);assert sha256(data).hexdigest()==key
        content['objects/'+key]=data;manifest['objects'].append(key)
    manifest['members']={name:sha256(value).hexdigest() for name,value in sorted(content.items())}
    with ZipFile(dest,'x',ZIP_DEFLATED) as z:
        for name,data in sorted(content.items()):z.writestr(name,data)
        z.writestr('manifest.json',canonical(manifest))


def verify(repo,helper,path):
    from purser.kernel.wire import canonical
    with ZipFile(path) as z:
        m=json.loads(z.read('manifest.json'))
        assert set(z.namelist())==set(m['members'])|{'manifest.json'} and len(z.namelist())==len(m['members'])+1
        assert all(sha256(z.read(n)).hexdigest()==digest for n,digest in m['members'].items())
        records=z.read('events.jsonl').splitlines()
        assert len(records)==m['revision'] and json.loads(records[-1])['hash']==m['head_hash']
        with ZipFile(repo/'docs/evidence/M2/development-log.zip') as old:
            assert records[:24]==old.read('events.jsonl').splitlines()
        objects={k:z.read('objects/'+k) for k in m['objects']}
        with tempfile.TemporaryDirectory(prefix='purser-m3-real-readback-') as scratch:
            db=helper.restore(Path(scratch)/'cold',records,objects)
            from_disk=public(helper,db,m['revision'],m['as_of'])
            assert canonical(from_disk)==z.read('public-readback.json')
            row=from_disk['m3']['record']['fields']
            assert row['closed_outcome']==m['m3_outcome'] and row['candidate']==m['integration']
            assert from_disk['project']['record']['fields']['state']!='closed'
        return {'revision':m['revision'],'head_hash':m['head_hash'],'original_M2_head':m['historical_M2_head'],
                'objects':len(objects),'candidate':row['candidate']['digest'],'child_outcome':m['m3_outcome'],
                'project_state':from_disk['project']['record']['fields']['state'],'archive_sha256':sha256(path.read_bytes()).hexdigest()}


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('repo',type=Path);p.add_argument('archive',type=Path);p.add_argument('--capture',type=Path)
    a=p.parse_args();root=a.repo.resolve();common=load_helpers(root)
    if a.capture:capture(root,common,a.capture,a.archive)
    print(json.dumps(verify(root,common,a.archive),sort_keys=True))
