import os,subprocess,sys,signal,json
from pathlib import Path
from experiments.e2.suite import freeze_series,collect_units
from experiments.e2.report import inspect_series
dest=Path('private-94')
freeze_series(dest,replicate=94,reason='Off-study abrupt observation commit before return')
subprocess.run(['git','add','--',str(dest/'freeze.json')],check=True)
subprocess.run(['git','commit','--quiet','-m','Register off-study private abrupt publication before controls'],check=True)
template="""from pathlib import Path
import os,signal
from experiments.e2 import policy
from experiments.e2.suite import collect_units
original=policy.CLASS.receive
def stop(self,message):
    result=original(self,message)
    os.kill(os.getpid(),signal.SIGKILL)
policy.CLASS.receive=stop
collect_units(Path('private-94'),[('closed-affected',2001,1,'ARM')])
"""
for arm,cl in [('purser','KernelArm'),('loop','PlanArm')]:
    r=subprocess.run([sys.executable,'-B','-c',template.replace('CLASS',cl).replace('ARM',arm)])
    assert r.returncode==-signal.SIGKILL,r.returncode
    collect_units(dest,[('closed-affected',2001,1,arm)])
    collect_units(dest,[('closed-affected',2001,1,arm)])
cases,stats=inspect_series(dest,strict=True,rerun=True)
print(stats)
for unit,c in cases.items():
    print(unit,c.raw['terminal'],c.basis,c.facts['intervention_reached'],c.facts['stale_at_delivery'],c.facts['affected_invalid_closure'],c.facts['rework_steps'],c.facts['rework_observed'],c.facts['final_pass'],c.issues)
    assert c.raw['terminal']=='harness_failure' and c.basis=='observed_lower_bound'
    assert c.facts['intervention_reached'] is True and c.facts['rework_steps'] is None
    assert c.facts['stale_at_delivery'] is (unit[-1]=='loop')
    assert c.facts['final_pass'] is False and not c.issues
