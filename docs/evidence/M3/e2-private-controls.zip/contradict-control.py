import json,zipfile,hashlib
from pathlib import Path
from experiments.e1.artifacts import encoded,sha
from experiments.e2.report import inspect_series,render
from experiments.e2.summary import aggregate,value
base=Path("private-93")
dest=Path("private-93-contradict")
dest.mkdir()
with zipfile.ZipFile(base/'raw.zip') as archive:
    files={name:archive.read(name) for name in archive.namelist()}
for track in ('primary','clean','closed-affected'):
    key=f"runs/{track}/2001/loop.json"
    raw=json.loads(files[key])
    p=json.loads(files[raw['artifacts']['platform']['path']])
    p['budget_reason']='step_limit'
    b=encoded(p); digest=sha(b); path=f"objects/{digest}.json"
    files[path]=b
    raw['artifacts']['platform']={'path':path,'bytes':len(b),'sha256':digest}
    files[key]=encoded(raw)
with zipfile.ZipFile(dest/'raw.zip','x',compression=zipfile.ZIP_DEFLATED) as out:
    for name,raw in files.items():out.writestr(name,raw)
cases,stats=inspect_series(dest)
plain=cases['primary',2001,'loop']
print('plain observed steps',plain.facts['charged_attempts_observed'],'eligible summed steps',aggregate([plain],'steps'),'elapsed',value(plain,'elapsed_ns'))
assert aggregate([plain],'steps')==(0,0)
assert plain.facts['rework_steps'] is None and plain.facts['rework_observed']==13
for a in ('loop_equal_verifier','purser'):
    assert value(cases['primary',2001,a],'steps')==48
assert cases['closed-affected',2001,'loop'].facts['affected_invalid_closure'] is True
markdown=render(dest)
for line in markdown.splitlines():
    if 'overhead flag' in line or line.startswith('| 2001 | +'):print(line)
assert 'overhead flag is **?**' in markdown
assert 'observed (total ?)' in markdown
try:inspect_series(dest,strict=True)
except ValueError as err:
    assert 'terminal and budget reasons disagree' in str(err)
else:raise ValueError('strict reader accepted contradictory endpoint')
for directory in (base,dest):
    print(directory,sha((directory/'raw.zip').read_bytes()))
(dest/'report.md').write_text(markdown)
