# Scripted E2 results

Twenty matched primary ranks were registered. Count columns show the total and the number of seeds with an observed value. Missing binary outcomes can range from zero to one. Thresholds use those bounds. a question mark marks an unavailable measurement.

| Arm | Complete | Incomplete | Invalid or missing | Checkpoint reached | Both retained | Bad W2 closure | Rework steps / measured | Final pass | Total steps / measured |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| loop | 1 | 0 | 19 | 1/1 | 1/1 | 0/1 | 13/1 | 1/1 | 30/1 |
| purser | 1 | 0 | 19 | 1/1 | 1/1 | 0/1 | 25/1 | 1/1 | 48/1 |
| loop_equal_verifier | 1 | 0 | 19 | 1/1 | 1/1 | 0/1 | 25/1 | 1/1 | 48/1 |

## Frozen thresholds

Each comparison uses the original rules. The half-cost test compares summed rework across all 20 ranks. The no-advantage predicate is true when Purser rework is equal or greater, or its final pass count is lower.

| Purser compared with | Both retained ≥18 | 2 × Purser rework ≤ comparator | Final passes ≥ comparator | E2 passes | No advantage | Rework ratio |
| --- | --- | --- | --- | --- | --- | ---: |
| loop | inconclusive | inconclusive | inconclusive | inconclusive | inconclusive | inconclusive |
| loop_equal_verifier | inconclusive | inconclusive | inconclusive | inconclusive | inconclusive | inconclusive |

## Paired primary results

Each signed difference is Purser minus its comparator. Columns within each cell give retention, bad affected closure, rework steps, final pass, total steps and elapsed seconds. Zero is a tie.

| Seed | Purser − plain loop | Purser − equal verifier |
| ---: | --- | --- |
| 2001 | +0 / +0 / +12 / +0 / +18 / +1.006 s | +0 / +0 / +0 / +0 / +0 / +0.755 s |
| 2002 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2003 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2004 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2005 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2006 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2007 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2008 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2009 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2010 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2011 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2012 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2013 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2014 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2015 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2016 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2017 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2018 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2019 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2020 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |

## Primary coverage · loop

| Seed | Validity / exit | Reached | Both retained | Siblings reopened | Invalid W2 closure | Rework | Final pass | Steps | Elapsed s |
| ---: | --- | --- | --- | ---: | --- | ---: | --- | ---: | ---: |
| 2001 | complete / done | yes | yes | 0 | no | 13 | yes | 30 | 1.442 |
| 2002 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2003 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2004 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2005 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2006 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2007 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2008 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2009 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2010 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2011 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2012 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2013 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2014 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2015 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2016 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2017 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2018 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2019 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2020 | missing | ? | ? | ? | ? | ? | ? | ? | ? |

## Primary coverage · purser

| Seed | Validity / exit | Reached | Both retained | Siblings reopened | Invalid W2 closure | Rework | Final pass | Steps | Elapsed s |
| ---: | --- | --- | --- | ---: | --- | ---: | --- | ---: | ---: |
| 2001 | complete / done | yes | yes | 0 | no | 25 | yes | 48 | 2.448 |
| 2002 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2003 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2004 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2005 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2006 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2007 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2008 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2009 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2010 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2011 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2012 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2013 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2014 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2015 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2016 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2017 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2018 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2019 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2020 | missing | ? | ? | ? | ? | ? | ? | ? | ? |

## Primary coverage · loop_equal_verifier

| Seed | Validity / exit | Reached | Both retained | Siblings reopened | Invalid W2 closure | Rework | Final pass | Steps | Elapsed s |
| ---: | --- | --- | --- | ---: | --- | ---: | --- | ---: | ---: |
| 2001 | complete / done | yes | yes | 0 | no | 25 | yes | 48 | 1.693 |
| 2002 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2003 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2004 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2005 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2006 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2007 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2008 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2009 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2010 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2011 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2012 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2013 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2014 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2015 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2016 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2017 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2018 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2019 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2020 | missing | ? | ? | ? | ? | ? | ? | ? | ? |

## Clean control · A1 retained

| Arm | Exit | Final pass | Steps | Elapsed s |
| --- | --- | --- | ---: | ---: |
| loop | done | yes | 24 | 1.245 |
| purser | done | yes | 42 | 1.905 |
| loop_equal_verifier | done | yes | 42 | 1.681 |

The twice-baseline clean overhead flag is **no**.

## Already-closed affected stress control

At delivery the affected W2 was already closed under the old schedule. The two bad-closure columns distinguish a stale closure still visible at delivery from a new bad closure asserted later.

| Arm | Exit | Old W2 candidate at delivery | Both siblings retained | Stale at delivery | New bad closure | Rework | Final pass | Steps | Elapsed s |
| --- | --- | --- | --- | --- | --- | ---: | --- | ---: | ---: |
| loop | done | 7df4a199e2ada1caafe78f5acec2f99b06f44771 | yes | yes | no | 13 | yes | 32 | 1.534 |
| purser | done | 7df4a199e2ada1caafe78f5acec2f99b06f44771 | yes | no | no | 25 | yes | 53 | 2.563 |
| loop_equal_verifier | done | 7df4a199e2ada1caafe78f5acec2f99b06f44771 | yes | yes | no | 25 | yes | 53 | 1.961 |

Scripted model calls, tokens and spend were zero.
