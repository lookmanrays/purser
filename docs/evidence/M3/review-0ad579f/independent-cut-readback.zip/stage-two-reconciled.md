# Independent disposition for E2 candidate-evidence recovery

**GO for the pre-implementation design.** I verified revised design SHA-256 `dd24d464d6da9d8ba589873e48652366c6141ea449bfa6066854e361c41be19f` on source `bdf316dbacfaa65f46634762988ac29a348f7a3e`. It resolves the material issue in stage two `20572d959cd817b70fb0f382db70aff41cf72e99d1c006ccf7a8b80563ad1938`.

Revision 2 counts each actual change by publication and subject. W2 and the parent each carry their declared candidate for the revised check. Rerunning the original frozen estimator on sealed input `bd67253dcf9639e19418f207fd75676a1d485587b3274ebbe3d330cd648a70bb` returned two reopenings, distinct W1 and W3, and retention false. The revision separates evidence that an OID belonged to the case from an ancestor or shared pack that can restore its bytes. It distinguishes historical protected observations, independently replayed criteria and unavailable measurements. The four physical pack-cut controls remain applicable at their exercised source.

This decision covers design only. The eventual immutable implementation requires its own qualification.
