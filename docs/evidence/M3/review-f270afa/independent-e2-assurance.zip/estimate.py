"""Independent rank-1 E2 estimator. Uses the standard library and never imports the evaluator."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys
import zipfile

LABELS=("W1/preferences","W2/retry","W3/delivery","scope/paths","legacy/compat","queue/composition")
ALLOWED={"notify/preferences.py","notify/retry.py","notify/delivery.py"}
CLOSED={"closed","done"}

def read(z,ref):
    x=z.read(ref["path"])
    assert hashlib.sha256(x).hexdigest()==ref["sha256"] and len(x)==ref["bytes"]
    return json.loads(x)
def canonical(x):
    return json.dumps(x,allow_nan=False,sort_keys=True,separators=(",",":"))
def grade(z,journal,oid,label,version):
    entry,=[e["payload"] for e in journal if e["kind"]=="oracle" and
        (e["payload"]["candidate"],e["payload"]["criterion"],e["payload"]["version"])==(oid,label,version)]
    report=read(z,entry["evidence"])
    assert (report["candidate"],report["criterion"],report["version"])==(oid,label,version)
    cells=report["cases"]
    if label=="legacy/compat":
        return len(cells)==1 and cells[0]["observed"]=={"tests":28,"errors":[],"failures":[],"skipped":[]}
    if label=="scope/paths":
        return len(cells)==1 and all(c["path"] in ALLOWED and c["old_mode"]==c["new_mode"]=="100644" for c in cells[0]["all_changes"])
    assert len(cells)==(2 if label=="queue/composition" else 3)
    for r in cells:
        spec=r["input"]
        assert spec["channel"]=="mail"
        ids=[] if "mail" in spec["disabled"] else list(dict.fromkeys(spec["ids"]))
        base=spec["base"]
        offsets=[0]+[base*(k if version==1 else 2**(k-1)) for k in range(1,spec["attempts"])]
        batches=[]; earlier=-1
        for t in spec["times"]:
            batches.append([[s,"mail",offset*1000000] for offset in offsets if earlier<offset<=t for s in ids])
            earlier=t
        expected={"enqueued":len(ids)*len(offsets),"samples":batches,"pending":0}
        if canonical(r["observed"])!=canonical(expected):
            return False
    return True

def state(z,checkpoint,w):
    item=read(z,checkpoint["view"])[w]
    oid=item["candidate"]
    return item["state"],oid["digest"] if isinstance(oid,dict) else oid

def one(z,key):
    raw=json.loads(z.read(key)); j=read(z,raw["artifacts"]["journal"]); p=read(z,raw["artifacts"]["platform"])
    arm,track=raw["arm"],raw["track"]; assert raw["seed"]==2001
    actions=[e for e in j if e["kind"]=="action"]
    fault=next((e for e in j if e["kind"]=="fault"),None)
    oid=p["exit_candidate"]["head"]
    version=1 if track=="clean" else 2
    final={label:grade(z,j,oid,label,version if label in ("W2/retry","queue/composition") else 1) for label in LABELS}
    after=[e for e in actions if fault and e["seq"]>fault["seq"]]
    outcome={"arm":arm,"track":track,"actions":len(actions),"post_input_work_actions":len(after) if fault else None,
             "final_candidate":oid,"final_six":final}
    if fault:
        payload=fault["payload"]
        assert all(state(z,payload["before"],w)[0] in CLOSED for w in ("W1","W3"))
        assert grade(z,j,payload["candidate"],"W2/retry",1)
        assert not grade(z,j,payload["candidate"],"W2/retry",2)
        st,co=state(z,payload["after"],"W2")
        outcome["input_old_candidate"]=payload["candidate"]
        outcome["stale_at_delivery"]=st in CLOSED and not grade(z,j,co,"W2/retry",2)
    if arm=="purser" and fault:
        origin=read(z,p["treatment_trace"])
        events=[json.loads(y) for y in origin["original_events"]]
        stop=fault["payload"]["after"]["revision"]
        names={(q["actor_id"],q["proposal_id"]) for e in after if (q:=e["payload"].get("proposal"))}
        committed={(e["actor_id"],e["proposal_id"]) for e in events if e["revision"]>stop and
            e["type"]=="ProposalReceipted" and e["data"]["disposition"]=="admitted"}
        extra=sorted(committed-names)
        outcome["additional_public_proposals"]=extra
        outcome["sibling_reopen_evidence"]=[{"revision":e["revision"],"kind":e["type"],"subject":e["data"].get("work",e["data"].get("id"))}
             for e in events if e["revision"]>stop and e["type"] in ("WorkAssigned","WorkReopened") and
             e["data"].get("work",e["data"].get("id")) in ("W1","W3")]
        outcome["minimum_work_actions"]=len(after)+len(extra)
    return outcome

if __name__=="__main__":
    for arg in sys.argv[1:]:
        source=Path(arg)
        with zipfile.ZipFile(source) as z:
            values=[one(z,key) for key in z.namelist() if key.startswith("runs/")]
        print(json.dumps({"archive":str(source),"cases":values},sort_keys=True))
