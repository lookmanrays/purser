"""A private isolated work executor decides whether its own already-submitted work needs reopening under the visible change."""
from hashlib import sha256
import json
import sys

payload=json.loads(sys.stdin.buffer.read())
public=payload["context"]
item=public["work"]
state=item.get("state",public.get("state"))
candidate=item.get("candidate",public.get("candidate"))
oid=candidate["digest"] if isinstance(candidate,dict) else candidate
identifier=item["id"]
assert identifier==payload["request"]["subject"] and payload["request"]["role"]=="executor"
assert item["title"] and isinstance(oid,str) and len(oid)==40
criterion={"W1":"W1/preferences","W3":"W3/delivery"}[identifier]
if "assignment" in public:
    assert public["assignment"]["executor"]=="executor:script"
    matches=[o for o in public["obligations"] if o["title"]==criterion]
    assert len(matches)==1 and matches[0]["state"]=="passed"
else:
    assert not public["verified"] or public["verified"][criterion]=="pass"
touched=payload["notice"]["criterion"]==criterion
retain=state in ("closed","done") and not touched
answer={"request":payload["request"],"title":item["title"],"subject":identifier,"own_criterion":criterion,"changed_criterion":payload["notice"]["criterion"],
        "prior_candidate":oid,"own_state":state,"work_disposition":"retain-submission" if retain else "needs-work",
        "response_sha256":sha256(json.dumps(public,sort_keys=True,separators=(",",":")).encode()).hexdigest()}
print(json.dumps(answer,sort_keys=True))
