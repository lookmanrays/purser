"""Restore the complete context for each genuine external release from the retained participant, digest and worker answer."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile

def sha(data):return hashlib.sha256(data).hexdigest()
def stable(obj):return json.dumps(obj,sort_keys=True,separators=(",",":")).encode()
def main(source,series,out):
    sys.path.insert(0,str(source))
    from purser.driver import context_pack
    from purser.kernel.projector import empty_projection,apply_event
    from purser.kernel.store import _event
    rows=json.loads((series/"summary.json").read_bytes())
    pack=[]
    for arm in rows:
        member=series/arm["arm"]/"raw.zip"
        with zipfile.ZipFile(member) as z:
            assert z.testzip() is None
            obj=lambda ref:json.loads(z.read(ref["path"]))
            raw=json.loads(z.read("runs/primary/2001/"+arm["arm"]+".json"))
            reg=json.loads(z.read("freeze.json"));assert reg["source_commit"]==arm["source"]
            platform=obj(raw["artifacts"]["platform"]);trace=obj(platform["treatment_trace"])
            journal=obj(raw["artifacts"]["journal"])
            contexts=[]
            for attempt,r in enumerate(arm["releases"],1):
                assert r["before"]==r["after"];ident=r["before"];work=r["context_work"]
                if arm["arm"]=="purser":
                    revision=ident["revision"];head="0"*64;projection=empty_projection()
                    for index,line in enumerate(trace["original_events"][:revision],1):
                        e=_event(line.encode(),index,head);head=e["hash"]
                        end=e["batch_start"]+e["batch_size"]-1
                        projection=apply_event(projection,e["type"],e["data"],index,end,event_version=e["event_version"])
                    assert end==revision and head==ident["head_hash"]
                    row=next(v for v in projection["records"] if v["id"]==work)
                    context=context_pack({"revision":revision,"head_hash":head,"projection":projection},row["fields"]["assignment"])
                else:
                    digest=ident["plan_sha256"]
                    refs=trace.get("plan_versions",[])
                    if refs:
                        full=obj(next(ref for ref in refs if ref["sha256"]==digest))
                    else:
                        cp=next(q for e in journal for key in ("before","after","checkpoint") if isinstance(q:=e["payload"].get(key),dict) and q.get("plan_sha256")==digest)
                        full=obj(cp["view"])
                    context=full[work].copy();context.pop("_publication",None);context.pop("_e2_plan_version",None)
                actual=sha(stable(context));assert actual==r["response_sha256"],(actual,r["response_sha256"])
                item={"ordinal":attempt,"work":work,"participant_id":ident,"context_sha256":actual,"context":context,"matched_external_response":r}
                contexts.append(item)
            counted=[e["payload"] for e in journal if e["kind"]=="action"]
            charged_release=[{"kind":x["action"],"subject":x["subject"],"attempt":x["attempt"],"parent_attempt":x.get("parent_attempt")} for x in counted if x["action"]=="context" and x.get("parent_attempt") is not None]
            pack.append({"arm":arm["arm"],"series_source":arm["source"],"private_replicate":raw["replicate"],"raw_sha256":sha(member.read_bytes()),
                         "freeze_sha256":sha(z.read("freeze.json")),"charged_nested_contexts":charged_release,"charged_steps":raw["cost"]["steps"],
                         "charged_rework":raw["score"]["rework_steps"],"external_work_releases":contexts})
    out.parent.mkdir(exist_ok=True,parents=True)
    out.write_text(json.dumps(pack,indent=2,sort_keys=True)+"\n")
    print(series.name,len(pack),sum(len(i["external_work_releases"]) for i in pack))
if __name__=="__main__":main(*[Path(p).resolve() for p in sys.argv[1:]])
