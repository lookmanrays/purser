"""Three extra actual work-context releases to an isolated receiving worker during W2 planning, with no publication."""
from copy import copy
import json
from pathlib import Path
import subprocess
import sys
import zipfile
from unittest.mock import patch
from hashlib import sha256

def run(source,dest,arm,rep):
    from experiments.e1.artifacts import Artifacts
    from experiments.e1.recovery import FileArchive
    from experiments.e1.suite import publish
    from experiments.e2 import policy,suite,trial
    from experiments.e2.report import inspect_series
    where=dest/arm;where.mkdir(parents=True)
    participant=where/"participant";participant.mkdir()
    stage=where/"stage";stage.mkdir();store=FileArchive(stage)
    suite.freeze_series(where,replicate=rep,reason="Independent extra nonmutating work-context releases to a separate receiver")
    reg=(where/"freeze.json").read_bytes();pin=json.loads(reg)
    cls=policy.KernelArm if arm=="purser" else policy.PlanArm
    handler=cls.revise
    witnessed=[]
    def again(self,*a,**kw):
        value=handler(self,*a,**kw)
        secondary=copy(self)
        for work in ("W1","W3","W1"):
            before=secondary.public_view()[1]
            released=secondary.context(work)
            data=json.dumps(released,sort_keys=True,separators=(",",":")).encode()
            child=subprocess.run([sys.executable,"-I","-B","-c","import hashlib,json,sys; r=sys.stdin.buffer.read(); print(json.dumps([json.loads(r)['work']['id'],hashlib.sha256(r).hexdigest()]))"],input=data,capture_output=True,check=True)
            confirmed,identity=json.loads(child.stdout)
            assert confirmed==work and identity==sha256(data).hexdigest()
            after=secondary.public_view()[1]
            witnessed.append({"context_work":work,"physical_receiver_confirmed":confirmed,"response_sha256":identity,"before":before,"after":after})
        return value
    with patch.object(cls,"revise",again):
        raw=trial.attempt(participant,Artifacts(store),pin,arm,"primary",2001,1)
    publish(where/"raw.zip",reg,set(),"primary/2001/"+arm,{"rank":1,"seed":2001,"track":"primary","arm":arm},store,raw)
    cases,_=inspect_series(where);c=cases["primary",2001,arm]
    answer={"source":pin["source_commit"],"arm":arm,"releases":witnessed,"terminal":raw["terminal"],"steps":raw["cost"]["steps"],"rework":c.facts.get("rework_steps"),"issues":c.issues}
    assert len(witnessed)==3 and all(r["before"]==r["after"] for r in witnessed)
    (where/"result.json").write_text(json.dumps(answer,indent=2,sort_keys=True)+"\n");print(arm,answer['steps'],answer['rework'],flush=True);return answer
if __name__=="__main__":
    source,dest=[Path(p).resolve() for p in sys.argv[1:]]
    sys.path.insert(0,str(source));dest.mkdir(parents=True)
    results=[run(source,dest,arm,i) for i,arm in enumerate(("loop","purser","loop_equal_verifier"),840)]
    (dest/"summary.json").write_text(json.dumps(results,indent=2,sort_keys=True)+"\n")
