"""Second reader for a retained E2 series. Never dispatches participants or imports the evaluator."""
import argparse
import collections
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import zipfile

ARMS=("loop","purser","loop_equal_verifier")
WORK={"W1","W2","W3","W-notify"}
SIBLINGS={"W1","W3"}
CLOSED={"done","closed"}
REWORK={"plan","context","edit","check","submit","observe","decide"}
ORIGIN="55686bd5152e10a53dfdc2c003974ea405a3a075"
START_TREE="2afea0fdd3478d29447a40bde8007266c468c72b"
LABELS={"W1/preferences","W2/retry","W3/delivery","scope/paths","legacy/compat","queue/composition"}


def sha(value):
    return hashlib.sha256(value).hexdigest()


def canonical(value):
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(",",":"),allow_nan=False).encode()


def load(raw):
    def pairs(items):
        d={}
        for k,v in items:
            if k in d:
                raise ValueError("duplicate JSON key "+k)
            d[k]=v
        return d
    return json.loads(raw,object_pairs_hook=pairs)


def git(path,*args,data=None):
    return subprocess.run(["git","-C",str(path),*args],input=data,capture_output=True,check=True).stdout


class Archive:
    def __init__(self,path):
        self.z=zipfile.ZipFile(path)
        self.objects=set()
        names=self.z.namelist()
        assert len(names)==len(set(names)) and self.z.testzip() is None
        for name in names:
            if name.startswith("objects/"):
                data=self.z.read(name)
                assert Path(name).stem==sha(data),name
    def get(self,ref):
        assert ref.keys()=={"path","bytes","sha256"},ref
        raw=self.z.read(ref["path"])
        assert type(ref["bytes"]) is int and ref["bytes"]==len(raw)
        assert sha(raw)==ref["sha256"] and ref["path"].startswith("objects/"+ref["sha256"]+".")
        self.objects.add(ref["path"])
        return raw
    def obj(self,ref):
        return load(self.get(ref))
    def bound(self,obj):
        if isinstance(obj,list):
            for child in obj:
                self.bound(child)
        elif isinstance(obj,dict):
            if obj.keys()=={"path","bytes","sha256"}:
                self.get(obj)
            else:
                for child in obj.values():
                    self.bound(child)
    def capture(self,ref):
        snapshot=self.obj(ref["view"])
        return {key:(row["state"], oid(row["candidate"])) for key,row in snapshot.items() if key in WORK}


def oid(identity):
    return identity["digest"] if isinstance(identity,dict) else identity


def order():
    result=[]
    for track,seeds in (("primary",list(range(2001,2021))),("clean",[2001]),("closed-affected",[2001])):
        for seed in seeds:
            j=seed-2001
            rotation=(j+1)%3
            for arm in ARMS[rotation:]+ARMS[:rotation]:
                result.append((track,seed,arm))
    return result


def read_tree(repo,commit):
    tree={}
    for row in git(repo,"ls-tree","-r","-z",commit).split(b"\0"):
        if not row:
            continue
        desc,filename=row.split(b"\t",1)
        mode,kind,identity=desc.decode().split()
        tree[filename.decode()]=(mode,kind,identity)
    return tree


def independent_measure(archive, cases, root, scratch):
    """Restore *each* content addressed Git pack, then independently run the queue for every scored object."""
    repo=scratch/"git"
    repo.mkdir()
    git(repo,"init","-q","--bare","--object-format=sha1")
    objects={}
    requests=collections.defaultdict(set)
    candidates={}
    for item in cases:
        raw=item["raw"]
        for commit,entry in item["candidates"].items():
            identity=entry["pack"]["sha256"]
            if commit in candidates:
                assert candidates[commit]==entry
            candidates[commit]=entry
            if identity not in objects:
                data=archive.get(entry["pack"])
                git(repo,"index-pack","--stdin",data=data)
                objects[identity]=commit
            assert entry["start"]==ORIGIN
            assert git(repo,"cat-file","-t",commit).strip()==b"commit"
            assert git(repo,"rev-parse",commit+"^{tree}").decode().strip()==entry["tree"]
            ancestry=git(repo,"rev-list","--parents","-n","1",commit).decode().strip().split()
            assert ancestry==[commit]+([entry["parent"]] if entry["parent"] else [])
            assert git(repo,"rev-list","--max-parents=0",commit).decode().strip()==ORIGIN
            requests[commit].add(raw["seed"])
    assert git(repo,"rev-parse",ORIGIN+"^{tree}").decode().strip()==START_TREE
    original=read_tree(repo,ORIGIN)
    frozen=root/"experiments/manifests/v1/input"
    manifest=load((root/"experiments/manifests/v1/manifest.json").read_bytes())
    assert set(original)=={f["path"] for f in manifest["fixture"]["files"]}
    for f in manifest["fixture"]["files"]:
        mode,kind,blob=original[f["path"]]
        assert mode=="100644" and kind=="blob" and sha(git(repo,"cat-file","blob",blob))==f["sha256"]==sha((frozen/f["path"]).read_bytes())
    results={}
    for commit,seeds in sorted(requests.items()):
        tree=read_tree(repo,commit)
        changes={k for k in set(tree)|set(original) if tree.get(k)!=original.get(k)}
        scope=changes<=set(manifest["fixture"]["public_paths"]) and all(k in original and k in tree and tree[k][:2]==("100644","blob") for k in changes)
        path=scratch/commit
        path.mkdir()
        tar=git(repo,"archive","--format=tar",commit)
        with tarfile.open(fileobj=io.BytesIO(tar)) as archive_tree:
            archive_tree.extractall(path,filter="data")
        raw=subprocess.check_output([sys.executable,"-I","-B",str(Path(__file__).with_name("queue_witness.py").resolve()),str(path),str(frozen),*[f"{s}/{s-2000}" for s in sorted(seeds)]])
        measured=load(raw)
        assert measured["legacy_tests"]==28
        for seed,policies in measured["seeds"].items():
            for law,out in policies.items():
                out["criteria"]["scope/paths"]=scope
                assert set(out["criteria"])==LABELS
                out["sibling_policy_blobs"]={subject:tree.get(path) for subject,path in (("W1","notify/preferences.py"),("W3","notify/delivery.py"))}
            results[commit,int(seed)]=policies
    return results,len(objects)


def aggregate(cases):
    by={(v["track"],v["seed"],v["arm"]):v for v in cases}
    rows={}
    for arm in ARMS:
        primary=[by.get(("primary",s,arm)) for s in range(2001,2021)]
        totals={}
        for name in ("unaffected_both_retained","unaffected_reopened","affected_invalid_closure","rework_steps","final_pass","steps","elapsed_ns"):
            field=[c.get(name) if c else None for c in primary]
            observed=[x for x in field if x is not None]
            totals[name]={"observed":len(observed),"sum":sum(observed),"total":sum(observed) if len(observed)==20 else None}
        rows[arm]=totals
    p=rows["purser"]
    comparisons={}
    def possible(arm,key):
        lower=upper=0
        for seed in range(2001,2021):
            row=by.get(("primary",seed,arm),{})
            observed=row.get(key)
            if observed is not None:
                lower+=int(observed);upper+=int(observed)
            elif key=="rework_steps":
                if row.get("intervention_reached") is not True:
                    return None
                lower+=row.get("rework_observed",0)
                upper+=96
            else:
                upper+=1
        return (lower,upper)
    def ge(left,right):
        if left is None or right is None:
            return None
        if left[0]>=right[1]:
            return True
        if left[1]<right[0]:
            return False
        return None
    for arm in (ARMS[0],ARMS[2]):
        b=rows[arm]
        gp=lambda table,name:table[name]["total"]
        kept,pr,br,pf,bf=(gp(p,"unaffected_both_retained"),gp(p,"rework_steps"),gp(b,"rework_steps"),gp(p,"final_pass"),gp(b,"final_pass"))
        k=ge(possible("purser","unaffected_both_retained"),(18,18))
        pc=possible("purser","rework_steps");bc=possible(arm,"rework_steps")
        half=ge(bc,None if pc is None else tuple(2*v for v in pc))
        matches=ge(possible("purser","final_pass"),possible(arm,"final_pass"))
        no_less=ge(pc,bc)
        fewer=None if matches is None else not matches
        comparisons[arm]={"retained18":k,"half":half,"final_at_least":matches,
            "pass":False if False in (k,half,matches) else (None if None in (k,half,matches) else True),
            "no_advantage":True if True in (no_less,fewer) else (None if None in (no_less,fewer) else False),
            "ratio":None if pr is None or br in (0,None) else pr/br}
    pairs={}
    for seed in range(2001,2021):
        row={}
        for arm in (ARMS[0],ARMS[2]):
            a,b=by.get(("primary",seed,"purser"),{}),by.get(("primary",seed,arm),{})
            row[arm]={k:None if a.get(k) is None or b.get(k) is None else int(a[k])-int(b[k])
                      for k in ("unaffected_both_retained","unaffected_reopened","affected_invalid_closure","rework_steps","final_pass","steps","elapsed_ns")}
        pairs[seed]=row
    return {"arms":rows,"comparisons":comparisons,"paired":pairs}


def private_predicate_controls():
    def subjects(P=0,B=0,finals=(20,20),retention=20):
        return [{"track":"primary","seed":2001+j,"arm":a,"rework_steps":P if a=="purser" else B,
                 "unaffected_both_retained":j<retention if a=="purser" else True,
                 "final_pass":j<(finals[0] if a=="purser" else finals[1])} for j in range(20) for a in ARMS]
    checks=[]
    for rows,expect in ((subjects(),(True,True,None)),
                        (subjects(P=3,B=6,retention=18),(True,False,.5)),
                        (subjects(P=3,B=6,retention=17),(False,False,.5)),
                        (subjects(P=2,B=1),(False,True,2.0)),
                        (subjects(P=1,B=3,finals=(19,20)),(False,True,1/3))):
        actual=aggregate(rows)["comparisons"]
        assert all((v["pass"],v["no_advantage"],v["ratio"])==expect for v in actual.values())
        checks.append(actual)
    partial=subjects(P=2,B=6)
    partial[1]["rework_steps"]=None
    assert all(v["pass"] is None and v["no_advantage"] is None for v in aggregate(partial)["comparisons"].values())
    bounded=subjects(P=0,B=1)
    for item in bounded:
        if item["arm"]=="purser" and item["seed"]>=2019:
            item["unaffected_both_retained"]=None
        if item["arm"]!="purser" and item["seed"]>=2019:
            item["final_pass"]=None
    assert all(v["pass"] is True and v["no_advantage"] is False for v in aggregate(bounded)["comparisons"].values())
    return checks
