"""Match independently measured E2 cases and integer predicates to the published Markdown, cell by cell."""
import argparse
from collections import defaultdict
import json
from pathlib import Path
import re
from registered_readback import ARMS,sha

def check(ground,document):
    rows={(c['track'],c['seed'],c['arm']):c for c in ground['rows']}
    target=''
    table=defaultdict(dict)
    for line in document.splitlines():
        if line.startswith('## '):
            target=line[3:].strip()
        if line.startswith('|'):
            cells=[c.strip() for c in line.strip('|').split('|')]
            if not cells[0].startswith('-'):
                table[target][cells[0]]=cells[1:]
    count=0
    def match(actual,expected,identity):
        nonlocal count
        assert actual==expected,(identity,actual,expected)
        count+=len(expected)
    def outcome(v):
        return 'inconclusive' if v is None else 'met' if v else 'not met'
    def binary(v):
        return '?' if v is None else 'yes' if v else 'no'
    def signed(v,time=False):
        return '?' if v is None else f'{v/1e9:+.3f} s' if time else f'{v:+d}'
    aggregate=ground['aggregate']
    for arm in ARMS:
        primary=[rows.get(('primary',seed,arm)) for seed in range(2001,2021)]
        sums=[]
        for term in ('intervention_reached','unaffected_both_retained','affected_invalid_closure','rework_steps','final_pass','steps'):
            observed=[c[term] for c in primary if c and c.get(term) is not None]
            sums.append(f'{sum(observed)}/{len(observed)}')
        complete=sum(c is not None and c['validity']=='complete' for c in primary)
        incomplete=sum(c is not None and c['validity']=='arm_incomplete' for c in primary)
        match(table[''][arm],[str(complete),str(incomplete),str(20-complete-incomplete),*sums],('summary',arm))
        for seed in range(2001,2021):
            c=rows.get(('primary',seed,arm))
            cells=table['Primary coverage · '+arm][str(seed)]
            if c is None:
                match(cells,['missing']+['?']*8,('coverage:missing',seed,arm))
            elif c['validity']=='complete':
                match(cells,[f"{c['validity']} / {c['terminal']}",binary(c['intervention_reached']),binary(c['unaffected_both_retained']),str(c['unaffected_reopened']),binary(c['affected_invalid_closure']),str(c['rework_steps']),binary(c['final_pass']),str(c['steps']),f"{c['elapsed_ns']/1e9:.3f}"],('coverage',seed,arm))
    for arm in ('loop','loop_equal_verifier'):
        facts=aggregate['comparisons'][arm]
        ratio=facts['ratio']
        units=aggregate['arms']
        r=('undefined (zero denominator)' if units[arm]['rework_steps']['total']==0 and units['purser']['rework_steps']['total'] is not None else 'inconclusive') if ratio is None else f'{ratio:.3f}'
        match(table['Frozen thresholds'][arm],[outcome(facts[k]) for k in ('retained18','half','final_at_least','pass','no_advantage')]+[r],('thresholds',arm))
    for seed in range(2001,2021):
        actual=table['Paired primary results'][str(seed)]
        expected=[]
        for arm in ('loop','loop_equal_verifier'):
            row=aggregate['paired'][str(seed)][arm]
            expected.append(' / '.join(signed(row[k],k=='elapsed_ns') for k in ('unaffected_both_retained','affected_invalid_closure','rework_steps','final_pass','steps','elapsed_ns')))
        match(actual,expected,('paired',seed))
    for arm in ARMS:
        c=rows.get(('clean',2001,arm))
        if c:
            match(table['Clean control · A1 retained'][arm],[c['terminal'],binary(c['final_pass']),str(c['steps']),f"{c['elapsed_ns']/1e9:.3f}"],('clean',arm))
        s=rows.get(('closed-affected',2001,arm))
        if s:
            match(table['Already-closed affected stress control'][arm],[s['terminal'],s['checkpoint']['W2'][1],binary(s['unaffected_both_retained']),binary(s['visible_invalid_immediately']),binary(s['new_bad_closure']),str(s['rework_steps']),binary(s['final_pass']),str(s['steps']),f"{s['elapsed_ns']/1e9:.3f}"],('stress',arm))
    a,b=rows.get(('clean',2001,'purser')),rows.get(('clean',2001,'loop'))
    flag=(a['steps']>2*b['steps']) if a and b and all(c['final_pass'] and c['healthy_final_closure'] for c in (a,b)) else None
    assert 'The twice-baseline clean overhead flag is **'+binary(flag)+'**.' in document
    assert 'Scripted model calls, tokens and spend were zero.' in document
    return {'matched_cells':count,'model_usage_zero':True,'clean_overhead':flag,'archive':ground['raw_sha256'],'report_sha256':sha(document.encode()),'cases':len(ground['rows'])}
if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('independent',type=Path);parser.add_argument('report',type=Path);parser.add_argument('out',type=Path)
    a=parser.parse_args()
    result=check(json.loads(a.independent.read_bytes()),a.report.read_text())
    a.out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result))
