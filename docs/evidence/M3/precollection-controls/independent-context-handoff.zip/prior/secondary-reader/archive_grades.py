"""Derive complete E2 case observations independently using retained participant and Git state."""
import argparse
from datetime import datetime
import json
from pathlib import Path
import re
import tempfile

from registered_readback import *
from public_stream import check as measure_public_stream
from public_stream import plan as measure_plan_stream

def participant_check(archive,case):
    p=case["platform"]
    trace=archive.obj(p["treatment_trace"])
    run=case["raw"]
    if run["arm"]!="purser":
        final=archive.obj(p["final_public"]["view"])
        assert trace["plan"]==final
        return {"plan_final":p["final_public"].get("plan_sha256"),"original_events":0,"original_public_stream":measure_plan_stream(archive,case,trace)}
    original=trace["original_events"]
    previous="0"*64
    hashes={0:previous}
    completed={0:previous}
    high=0
    for i,line in enumerate(original,1):
        event=load(line)
        assert canonical(event)==line.encode()
        assert event["revision"]==i and event["prev_hash"]==previous
        computed=sha(b"purser/event/v1\0"+canonical({k:v for k,v in event.items() if k!="hash"}))
        assert computed==event["hash"]
        hashes[i]=previous=computed
        if i>high:
            assert event["batch_start"]==i and event["batch_size"]>=1
            high=i+event["batch_size"]-1
            curr=(event["at"],event["actor_id"],event["proposal_id"],event["batch_start"],event["batch_size"])
        assert curr==(event["at"],event["actor_id"],event["proposal_id"],event["batch_start"],event["batch_size"])
        if i==high:
            completed[i]=computed
    assert high==len(original) and completed[high]==trace["snapshot"]["head_hash"]
    for ref in case["checkpoints"]:
        assert completed[ref["revision"]]==ref["head_hash"]
    final=archive.capture(p["final_public"])
    records={r["id"]:r for r in trace["snapshot"]["projection"]["records"]}
    assert final=={k:(records[k]["fields"]["state"],oid(records[k]["fields"]["candidate"])) for k in WORK}
    return {"head":previous,"revision":len(original),"original_events":len(original),"original_public_stream":measure_public_stream(archive,case)}

def getseries(archive):
    freeze=load(archive.z.read("freeze.json"))
    cases=[]
    for name in archive.z.namelist():
        match=re.fullmatch(r"runs/([^/]+)/(\d+)/([^/]+)\.json",name)
        if not match:
            continue
        track,seed,arm=match.group(1),int(match.group(2)),match.group(3)
        raw=load(archive.z.read(name))
        assert (raw["experiment"],raw["mode"],raw["track"],raw["seed"],raw["arm"],raw["replicate"])==("E2","scripted",track,seed,arm,freeze["replicate"])
        key=f"{track}/{seed}/{arm}"
        marker=load(archive.z.read("started/"+key+".json"))
        assert (marker["track"],marker["seed"],marker["rank"],marker["arm"])==(track,seed,seed-2000,arm)
        assert all(raw["cost"][k]==0 for k in ("model_calls","input_tokens","output_tokens","spend_usd_micros"))
        assert raw["artifacts"]["model"] is None
        archive.bound(raw)
        j=archive.obj(raw["artifacts"]["journal"]); archive.bound(j)
        p=archive.obj(raw["artifacts"]["platform"]); archive.bound(p)
        candidates=archive.obj(raw["artifacts"]["candidates"]); archive.bound(candidates)
        checkpoints=[]
        for cp in (p.get("initial_public"),p.get("final_public")):
            if cp:
                checkpoints.append(cp)
        for event in j:
            for cp_key in ("before","after","checkpoint"):
                cp=event["payload"].get(cp_key)
                if cp and isinstance(cp,dict) and "view" in cp:
                    checkpoints.append(cp)
        assert [e["seq"] for e in j]==list(range(1,len(j)+1))
        actions=[e for e in j if e["kind"]=="action"]
        assert [e["payload"]["attempt"] for e in actions]==list(range(1,len(actions)+1))
        assert raw["cost"]["steps"]==len(actions)<=96
        t=next((e for e in j if e["kind"]=="terminal"),None)
        assert t is None or t==j[-1]
        intact=(raw["terminal"]=="done" and raw["validity"]=="complete")
        if intact:
            assert p["end_monotonic_ns"]-p["start_monotonic_ns"]==raw["cost"]["elapsed_ns"]<=60_000_000_000
            assert p["budget_reason"]=="done" and p["participant_exit"]["reason"]=="done"
            assert p["end_monotonic_ns"]==p["participant_exit"]["end_monotonic_ns"]==t["payload"]["end_monotonic_ns"]
            assert all(e["offset_ns"]>=0 for e in j)
        case={"raw":raw,"platform":p,"journal":j,"candidates":candidates,"checkpoints":checkpoints,"intact":intact}
        if intact:
            case["participant"]=participant_check(archive,case)
        cases.append(case)
    return freeze,cases


def grade(archive,case,gitgrades):
    r=case["raw"]; j=case["journal"]; p=case["platform"]
    seed=r["seed"]
    def tested(candidate,law,label):
        return gitgrades[candidate,seed][law]["criteria"][label]
    def view(c):
        return archive.capture(c) if c else {}
    oracle_count=0
    for ev in j:
        if ev["kind"]=="oracle":
            o=ev["payload"]; version=o["version"]; cid=o["candidate"]; label=o["criterion"]
            protected=archive.obj(o["evidence"])
            assert (protected["candidate"],protected["criterion"],protected["version"])==(cid,label,version)
            law="exponential" if version==2 else "linear"
            assert version in (1,2) and (version==1 or label in ("W2/retry","queue/composition"))
            assert (o["verdict"]=="pass")==tested(cid,law,label),(r["arm"],r["track"],seed,cid,label,version,o["verdict"])
            oracle_count+=1
    fault_idx=next((i for i,row in enumerate(j) if row["kind"]=="fault"),None)
    assert sum(row["kind"]=="fault" for row in j)<=1
    info={"arm":r["arm"],"track":r["track"],"seed":seed,"terminal":r["terminal"],"validity":r["validity"],
          "steps":len([e for e in j if e["kind"]=="action"]),"elapsed_ns":r["cost"]["elapsed_ns"],
          "oracle_verdicts":oracle_count,"participant":case.get("participant")}
    intact=case["intact"]
    if not intact:
        return info
    assert (fault_idx is None)==(r["track"]=="clean")
    changed=fault_idx is not None
    final=view(p["final_public"])
    endpoint=p["exit_candidate"]
    terminal_candidate=oid(endpoint.get("head",endpoint.get("candidate"))) if isinstance(endpoint,dict) else oid(endpoint)
    assert terminal_candidate in case["candidates"],endpoint
    assert not endpoint.get("dirty",False),endpoint
    final_grades=gitgrades[terminal_candidate,seed]["exponential" if changed else "linear"]["criteria"]
    info.update(final_pass=all(final_grades.values()),terminal_candidate=terminal_candidate,final_public=final["W-notify"],
                final_grades=final_grades,intervention_reached=changed)
    if not changed:
        info["healthy_final_closure"]=final["W-notify"]==( "closed",terminal_candidate) or final["W-notify"]==("done",terminal_candidate)
        return info
    fault=j[fault_idx]["payload"]
    before,after=view(fault["before"]),view(fault["after"])
    assert all(before[k][0] in CLOSED and tested(before[k][1],"linear",{"W1":"W1/preferences","W3":"W3/delivery"}[k]) for k in SIBLINGS)
    unchanged={}
    for subject,criterion in (("W1","W1/preferences"),("W3","W3/delivery")):
        prior=gitgrades[before[subject][1],seed]["linear"]["sibling_policy_blobs"][subject]
        current=gitgrades[fault["candidate"],seed]["linear"]["sibling_policy_blobs"][subject]
        assert prior and current==prior and prior[:2]==("100644","blob")
        assert tested(fault["candidate"],"linear",criterion)
        unchanged[subject]=prior[2]
    stressed=r["track"]=="closed-affected"
    assert bool(before["W2"][0] in CLOSED)==stressed
    assert tested(before["W2"][1],"linear","W2/retry")
    assert not tested(before["W2"][1],"exponential","W2/retry")
    assert fault["candidate"]==before["W2"][1]
    rework=[]
    checked_post=[after]
    transitions=[]
    for event in j[fault_idx+1:]:
        payload=event["payload"]
        if event["kind"]=="action":
            for key in ("before","after"):
                if payload.get(key):
                    checked_post.append(view(payload[key]))
            if payload["action"] in REWORK and payload["subject"] in WORK:
                rework.append([payload["attempt"],payload["action"],payload["subject"]])
        elif event["kind"]=="public_state":
            if payload.get("checkpoint"):
                checked_post.append(view(payload["checkpoint"]))
            transitions.append({"subject":payload["subject"],"from":payload["from"],"to":payload["to"],"candidate":oid(payload["candidate"])})
    checked_post.append(final)
    reopened={k for state in checked_post for k in SIBLINGS if state[k][0] not in CLOSED}
    reopened.update(t["subject"] for t in transitions if t["subject"] in SIBLINGS and t["to"] not in CLOSED)
    invalid=any(state["W2"][0] in CLOSED and not tested(state["W2"][1],"exponential","W2/retry") for state in checked_post)
    invalid |= any(t["subject"]=="W2" and t["to"] in CLOSED and not tested(t["candidate"],"exponential","W2/retry") for t in transitions)
    last=after["W2"]
    later_bad=False
    for states in checked_post[1:]:
        current=states["W2"]
        if current[0] in CLOSED and (last[0] not in CLOSED or last[1]!=current[1]):
            later_bad |= not tested(current[1],"exponential","W2/retry")
        last=current
    later_bad |= any(t["subject"]=="W2" and t["to"] in CLOSED and t["from"] not in CLOSED and not tested(t["candidate"],"exponential","W2/retry") for t in transitions)
    info.update(unaffected_both_retained=not reopened,unaffected_reopened=len(reopened),affected_invalid_closure=invalid,
                rework_steps=len(rework),reopened=sorted(reopened),rework_actions=rework,checkpoint=before,release=after,sibling_policy_blobs=unchanged,
                new_bad_closure=later_bad,
                visible_invalid_immediately=after["W2"][0] in CLOSED and not tested(after["W2"][1],"exponential","W2/retry"))
    stream=info["participant"].get("original_public_stream")
    if stream is not None:
        assert {k for k in stream["reopened"]}==reopened
        real_bad=[(rev,cid,first) for rev,cid,first in stream["W2_postlaw_closures"] if not tested(cid,"exponential","W2/retry")]
        assert invalid==bool(real_bad) and later_bad==any(not first for _,_,first in real_bad)
    if r["score"]:
        assert {k:info[k] for k in r["score"]}==r["score"],(r["track"],r["arm"],r["seed"],r["score"],info)
    return info


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("source",type=Path)
    parser.add_argument("raw",type=Path)
    parser.add_argument("out",type=Path)
    parser.add_argument("--registered",action="store_true")
    args=parser.parse_args()
    a=Archive(args.raw)
    source=args.source.resolve()
    freeze,cases=getseries(a)
    actual=[(c["raw"]["track"],c["raw"]["seed"],c["raw"]["arm"]) for c in cases]
    assert len(set(actual))==len(actual)
    if args.registered:
        assert actual==order()
        total_started=[name for name in a.z.namelist() if name.startswith("started/")]
        assert len(total_started)==66 and len(actual)==66
        assert (args.raw.parent/"freeze.json").read_bytes()==a.z.read("freeze.json")
    with tempfile.TemporaryDirectory(prefix="m3-independent-objects-") as s:
        measurements,nobjects=independent_measure(a,cases,source,Path(s))
    report=[grade(a,case,measurements) for case in cases]
    outputs={"source":freeze["source_commit"],"raw_sha256":sha(args.raw.read_bytes()),
             "starting_commit":ORIGIN,"retained_packs":nobjects,"candidate_seed_pairs":len(measurements),
             "scored_revision_criterions":sum(row["oracle_verdicts"] for row in report),
             "original_purser_events":sum(row.get("participant",{}).get("original_events",0) for row in report if row.get("participant")),
             "rows":report,"aggregate":aggregate(report),"registered_units":len(report),"dispatched_arms":0}
    args.out.write_text(json.dumps(outputs,indent=2,sort_keys=True)+"\n")
    print(json.dumps({k:v for k,v in outputs.items() if k not in ("rows","aggregate")},sort_keys=True))
    print(json.dumps(outputs["aggregate"]["comparisons"]))


if __name__=="__main__":
    main()
