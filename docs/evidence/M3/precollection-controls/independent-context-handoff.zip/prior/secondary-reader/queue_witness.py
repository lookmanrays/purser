"""Independent local behavioral oracle. Does not import the project, adapters or evaluator."""
import argparse
from datetime import datetime, timedelta
import hashlib
import json
from pathlib import Path
import sys
import unittest
from io import StringIO

ORIGIN = datetime(2001,1,1,12)
CHANNELS = ("mail","push","digest","inbox","desktop")
ALLOWED = {"notify/preferences.py","notify/retry.py","notify/delivery.py"}


def cases(seed, rank, law):
    i = rank - 1
    chan = CHANNELS[i % len(CHANNELS)]
    alt = CHANNELS[(i+1) % len(CHANNELS)]
    ids = [f"{seed}-{letter}" for letter in "abc"]
    a,b,c = ids
    n = 4+i%4
    base = 2+i%5
    def case(label, content, disabled, count, scale, times=None):
        offsets = [0] + [scale*(j if law=="linear" else 2**(j-1)) for j in range(1,count)]
        if times is None:
            times = sorted({0, offsets[-1]+1, *offsets, *[o-1 for o in offsets if o>0]})
        planned = [(name,chan,ORIGIN+timedelta(seconds=offset)) for offset in offsets
                   for name in dict.fromkeys(content)] if chan not in disabled else []
        return label, (chan, content, disabled, count, scale), times, planned
    for disabled in ((),(chan,),(alt,)):
        yield case("W1/preferences",[a],disabled,1,base)
    for count,scale in ((1,base),(n,base),(n,1)):
        yield case("W2/retry",[a],(),count,scale)
    for group in ([a,b,a,c,b],[c,c],[]):
        yield case("W3/delivery",group,(),1,base)
    for disabled in ((),(chan,)):
        yield case("queue/composition",[a,b,a,c,b],disabled,n,base)


def measure(queue_class,seed,rank,law):
    observed = {}
    for label,spec,times,planned in cases(seed,rank,law):
        queue = queue_class(ORIGIN)
        channel, IDs, disabled, n, scale = spec
        count = queue.enqueue(channel,IDs, disabled=disabled,attempts=n,base=scale)
        rows = []
        passed = type(count) is int and count == len(planned)
        last = None
        for offset in times:
            now=ORIGIN+timedelta(seconds=offset)
            actual=[(d.event_id,d.channel,d.due_at) for d in queue.advance(now)]
            expected=[p for p in planned if (last is None or p[2]>last) and p[2]<=now]
            exact=all(type(x) is str and type(y) is str and type(t) is datetime and t.tzinfo is None for x,y,t in actual)
            passed &= exact and actual==expected
            rows.append({"at":offset,"expected":expected,"actual":actual})
            last=now
        pending=len(queue.scheduler.get_jobs())
        passed &= pending==0
        observed.setdefault(label,[]).append({"passed":passed,"enqueued":count,"remaining":pending,"points":rows})
    return observed


def tree(path):
    from stat import S_IMODE
    def stable(p):
        return ("regular",bool(p.stat().st_mode & 0o111),hashlib.sha256(p.read_bytes()).hexdigest()) if not p.is_symlink() else ("symlink",p.readlink().as_posix())
    return {p.relative_to(path).as_posix():stable(p) for p in path.rglob("*") if (p.is_file() or p.is_symlink()) and ".git" not in p.relative_to(path).parts and "__pycache__" not in p.relative_to(path).parts}


def execute(candidate, fixture, seeds):
    candidate=candidate.resolve()
    fixture=fixture.resolve()
    sys.path.insert(0,str(candidate))
    from notify.service import NotificationQueue
    frozen,actual=tree(fixture),tree(candidate)
    changed=sorted(k for k in set(frozen)|set(actual) if frozen.get(k)!=actual.get(k))
    scope=all(k in ALLOWED and k in frozen and k in actual and actual[k][:2]==("regular",False) for k in changed)
    suite=unittest.TestLoader().discover(str(fixture/"tests"))
    log=unittest.TextTestRunner(stream=StringIO(),verbosity=0).run(suite)
    legacy=log.testsRun==28 and log.wasSuccessful() and not log.skipped
    result={"tree_changes":changed,"legacy_tests":log.testsRun,"seeds":{}}
    for seed,rank in seeds:
        grades={}
        for law in ("linear","exponential"):
            records=measure(NotificationQueue,seed,rank,law)
            facts = {k:all(case["passed"] for case in v) for k,v in records.items()}
            facts["legacy/compat"]=legacy
            facts["scope/paths"]=scope
            grades[law]={"criteria":facts,"probes":sum(map(len,records.values()))}
        result["seeds"][str(seed)]=grades
    return result


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("candidate",type=Path)
    p.add_argument("fixture",type=Path)
    p.add_argument("seed_ranks",nargs="+")
    args=p.parse_args()
    print(json.dumps(execute(args.candidate,args.fixture,[tuple(map(int,s.split("/"))) for s in args.seed_ranks]),sort_keys=True))
