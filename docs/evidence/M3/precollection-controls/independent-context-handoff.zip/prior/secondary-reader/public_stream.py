"""Independent experiment-specific fold of every original published SQLite batch and operation disposition."""
from collections import defaultdict
from registered_readback import WORK,CLOSED,canonical,sha,load,oid

def receipt(value):
    if not isinstance(value,dict):return None
    fixed={"actor_id","proposal_id","digest","disposition","code","revision"}
    if fixed<=value.keys():return {k:value[k] for k in fixed}
    for key in ("receipt","response"):
        found=receipt(value.get(key))
        if found:return found
    return None

def identity(reply):return (reply['actor_id'],reply['proposal_id'],reply['digest'])

def plan(archive,case,trace):
    chain=trace.get('plan_versions')
    if chain is None:return None
    previous=None
    publication={}
    evidence=[]
    start=case['platform']['initial_public']['plan_sha256']
    end=case['platform']['final_public']['plan_sha256']
    for number,ref in enumerate(chain,1):
        contents=archive.get(ref);rows=load(contents);stamp=rows['W-notify']['_e2_plan_version']
        assert sha(contents)==ref['sha256'] and stamp['number']==number and stamp['previous']==previous
        previous=ref['sha256']
        state={k:(rows[k]['state'],oid(rows[k]['candidate'])) for k in WORK}
        assert previous not in publication
        publication[previous]=(number,state)
        evidence.append((number,state,rows['W2'].get('premise'),stamp.get('attempt')))
    assert previous==end and trace['plan']==load(archive.get(chain[-1]))
    left=publication[start][0];right=publication[end][0]
    for ck in case['checkpoints']:
        assert publication[ck['plan_sha256']][1]==archive.capture(ck)
    changes=[];previous_notice=None
    for no,published,notice,invocation in evidence:
        if no<left:continue
        if notice!=previous_notice:
            changes.append([no,notice,invocation]);previous_notice=notice
    first=next((no for no,notice,_ in changes if notice is not None),None)
    reopened=set();new_closures=[];last=None
    for no,s,notice,inv in evidence:
        if first is None or no<first:continue
        reopened.update(k for k in ('W1','W3') if s[k][0] not in CLOSED)
        curr=s['W2']
        if curr[0] in CLOSED and curr!=last:
            new_closures.append([no,curr[1],no==first])
        last=curr
    return {'chain_length':len(chain),'active_versions':right-left,'initial_number':left,'terminal_number':right,
            'received_changes':changes,'reopened':sorted(reopened),'W2_postlaw_closures':new_closures,'terminal_public':publication[end][1]}

def fold(trace):
    by_revision={0:{}}
    op_receipts={}
    events=trace["original_events"]
    marks={}
    supports=defaultdict(set)
    triggers={}
    observations=set()
    active=set()
    state={}
    refs={}
    batch=[]
    for original in events:
        event=load(original)
        kind=event["type"];d=event["data"];key=d.get("id");rev=event["revision"]
        if kind=="WorkCreated":state[key]=("open",None)
        elif kind=="WorkAssigned":
            refs[key]=d["work"]
            state[d["work"]]=("assigned",None)
        elif kind=="ResultSubmitted":
            refs[key]=d["work"]
            state[d["work"]]=("submitted",oid(d["candidate"]))
        elif kind=="WorkClosed":state[key]=("closed",state[key][1])
        elif kind in ("WorkReopened","WorkSupportUpdated"):state[key]=(d["state"],state[key][1])
        elif kind in ("ObligationSet","RunOpened"):refs[key]=d["work"]
        elif kind in ("ObservationRecorded","EvidenceRecorded"):
            refs[key]=refs[d["run"]]
        elif kind=="AssumptionCreated":active.add(key)
        elif kind=="DecisionRecorded":
            triggers[key]=set(d["triggers"]);supports[key]=set(d["support"])
            if d["supersedes"]:
                old=d["supersedes"]
                for choices in supports.values():
                    if old in choices:
                        choices.remove(old);choices.add(key)
        elif kind=="DependencyAdded":supports[key].add(d["support"])
        elif kind=="DependencyRemoved":supports[key].remove(d["support"])
        elif kind=="PremiseObserved" and d["finding"]=="contradicts" and d["assumption"] in active:
            start=d["assumption"];active.remove(start)
            reached={start}
            while True:
                new={x for x,s in supports.items() if (s&reached) and (x not in triggers or triggers[x]&reached)}
                if new<=reached:break
                reached.update(new)
            for key in reached&state.keys():
                state[key]=("stale",state[key][1])
            observations.add(d["id"])
            marks[rev]={"observation":d,"affected":sorted(reached&state.keys())}
        batch.append(event)
        end=event["batch_start"]+event["batch_size"]-1
        if rev!=end:continue
        assert kind=="ProposalReceipted",event
        assert d["proposal_id"]==event["proposal_id"] and d["actor_id"]==event["actor_id"]
        rid=identity(d)
        assert rid not in op_receipts
        subjects=set()
        ops=[]
        for item in batch[:-1]:
            tag=item["type"];fields=item["data"];lookup=fields.get("id")
            if tag in ("WorkClosed","WorkReopened","WorkAssigned","ResultSubmitted","RunOpened","EvidenceRecorded","ObservationRecorded","DecisionRecorded","PremiseObserved","DependencyAdded","DependencyRemoved","ObligationSet"):
                subj=fields.get("work") or refs.get(lookup) or (lookup if lookup in WORK else None)
                if subj:subjects.add(subj)
                ops.append(tag)
        op_receipts[rid]={"revision":rev,"first":event["batch_start"],"subjects":sorted(subjects),"domain":ops,
                          "receipt":{**d,"revision":rev}}
        by_revision[rev]={k:v for k,v in state.items() if k in WORK}
        batch=[]
    assert not batch
    return by_revision,op_receipts,marks

def check(archive,case,*,require_all=True):
    platform=case["platform"]
    trace=archive.obj(platform["treatment_trace"])
    public,batches,marks=fold(trace)
    start=platform["initial_public"]["revision"]
    end=platform["final_public"]["revision"]
    expected={rid for rid,r in batches.items() if start<r["revision"]<=end}
    seen=set();contradictions=[]
    for coupled in case["journal"]:
        payload=coupled["payload"];proposal=payload.get("proposal")
        if coupled["kind"] not in ("action","fault") or not proposal:continue
        body=proposal["body"]
        actor=proposal["actor_id"]
        checksum=sha(b"purser/proposal/v1\0"+canonical({"actor_id":actor,"proposal":body}))
        assert checksum==proposal["digest"] and proposal["proposal_id"]==body["proposal_id"],proposal
        rid=identity(proposal)
        expected_r=batches.get(rid)
        returned=receipt(payload.get("return"))
        if expected_r is None:
            if returned:contradictions.append(["unknown request",rid])
        elif returned:
            if not all(returned[k]==expected_r["receipt"][k] for k in returned):
                contradictions.append(["wrong receipt",rid,returned,expected_r["receipt"]])
        if expected_r:seen.add(rid)
    for ck in case["checkpoints"]:
        if ck.get("view"):
            actual=archive.capture(ck)
            assert actual==public[ck["revision"]],(ck["revision"],actual,public[ck["revision"]])
    absent=sorted((batches[rid] for rid in expected-seen),key=lambda a:a["revision"])
    ending=platform["final_public"]["revision"]
    notice_end=next((next(r["revision"] for r in batches.values() if r["first"]<=rev<=r["revision"]) for rev in marks),None)
    post=[(rev,s) for rev,s in public.items() if notice_end is not None and notice_end<=rev<=ending]
    reopened={k for rev,s in post for k in ("W1","W3") if s[k][0] not in CLOSED}
    transitions=[];prior={}
    for rev,states in post:
        pair=states["W2"]
        if pair[0] in CLOSED and pair!=prior.get("W2"):
            transitions.append([rev,pair[1],rev==notice_end])
        prior=states
    if require_all:
        assert not absent and not contradictions,(absent,contradictions)
    return {"verified_public_batches":sum(start<rev<=ending for rev in public),"original_bound_proposals":len(seen),
            "unattributed_genuine_proposals":absent,"receipt_contradictions":contradictions,"reopened":sorted(reopened),
            "W2_postlaw_closures":transitions,"incoming_revision":notice_end,"terminal_public":public[ending]}
