"""Qualify the two E2 comparison columns independently with opposite outcomes, missingness, exact ties and zero costs."""
import argparse
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import json
import sys

from registered_readback import ARMS,aggregate

def mk(p=(2,20),loop=(4,20),equal=(1,20),pkeep=18):
    result={}
    for i in range(20):
        for arm,(cost,passed) in zip(ARMS,(loop,p,equal)):
            row={"track":"primary","arm":arm,"seed":2001+i,"intervention_reached":True,"rework_steps":cost,
                 "unaffected_both_retained":i<pkeep if arm=="purser" else True,"final_pass":i<passed}
            result[arm,2001+i]=row
    return result

def conditions():
    yield "half-equality-vs-expensive",mk()
    yield "final-adverse-one-control",mk(p=(1,19),loop=(4,18),equal=(3,20))
    yield "zero-over-zero-vs-positive",mk(p=(0,20),loop=(0,20),equal=(4,20))
    yield "seventeenth-retention",mk(pkeep=17)
    a=mk(p=(0,20),loop=(4,19),equal=(1,20))
    a["purser",2019]["unaffected_both_retained"]=None
    a["purser",2020]["unaffected_both_retained"]=None
    a["loop",2020]["final_pass"]=None
    yield "decisive-despite-partial-binary",a
    a=mk(p=(3,20),loop=(1,20),equal=(7,20))
    a["purser",2020]["rework_steps"]=None;a["purser",2020]["rework_observed"]=3
    yield "positive-lower-bound-split-comparators",a
    a=mk(p=(3,19),loop=(2,20),equal=(7,18))
    a["loop",2005]["intervention_reached"]=False;a["loop",2005]["rework_steps"]=None
    yield "unreached-undefined-and-definite-lower-final",a
    a=mk(p=(3,20),loop=(2,20),equal=(7,18))
    a.pop(("loop",2004))
    yield "entire-missing-one-column",a

def av(case):
    if case is None:return None
    return SimpleNamespace(facts=case,raw={"cost":{},"validity":"complete","terminal":"done"},issues=(),comparable_cost=True,healthy_clean=False,basis="measured")

def main(source,dest):
    sys.path.insert(0,str(source))
    from experiments.e2 import summary
    result={}
    for name,cases in conditions():
        independently=aggregate(list(cases.values()))["comparisons"]
        candidate={}
        for comp in ("loop","loop_equal_verifier"):
            group=lambda arm:[av(cases.get((arm,seed))) for seed in range(2001,2021)]
            proposed=summary.predicates(group("purser"),group(comp))
            q=independently[comp]
            expected=(q["retained18"],q["half"],q["final_at_least"],q["pass"],q["no_advantage"])
            measured=tuple(proposed[k] for k in ("retention","half","final","passed","no_advantage"))
            assert expected==measured,(name,comp,proposed,q)
            if q["ratio"] is not None:
                assert abs(float(proposed["ratio"])-q["ratio"])<0.00050001,(name,comp,q,proposed)
            elif all(cases.get((a,s),{}).get("rework_steps") is not None for a in ("purser",comp) for s in range(2001,2021)) and sum(cases[comp,s]["rework_steps"] for s in range(2001,2021))==0:
                assert str(proposed["ratio"]).startswith("undefined")
            else: assert proposed["ratio"]=="inconclusive"
            candidate[comp]=proposed
        result[name]={"independent":independently,"candidate":candidate}
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
    print(f"independently matched {len(result)*2} asymmetric threshold groups")
if __name__=="__main__":main(*[Path(p).resolve() for p in sys.argv[1:]])
