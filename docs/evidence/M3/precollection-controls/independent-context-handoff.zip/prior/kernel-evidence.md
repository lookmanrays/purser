# Independent kernel and compatibility record

The original product source was e29b0927a4986ed97afbdfa80bfe6fe43a9ed63a. The retained assistant-generated controls use only public caller bindings, real SQLite/WAL Store connections and the CLI, with independent expected graph closures. A valid bound verifier accidentally referencing a premise-family observation crashed before any receipt. All three independent changed aggregate-witness cases let the direct consumer reclose on its earlier result, pass, generation and outcome. Three equal selected-witness cases correctly retained their existing work. These initial outcomes are in observation-a1/observed.json and support-a1/summary.json.

The replacement product is 1243dde2d23f9dc67986d78ea2d60099bff2b7c4, tree c2d2e50c748324fc0b4fe697ccf490efc47c15f9. The independent rerun used integration source 69f193586de83a7c4eb72974f2038e3ba72d4c5e, with the identical product tree and frozen fixture subtree f1d8dd89981771249389b0b713aa389eca98c1fd. The reviewer detached checkout held no changes.

| Observation | Independent retained result |
| --- | --- |
| Bound verifier cites a premise observation instead of a verification observation | Durable rejected witness_mismatch, advancing revision 45 to 46; the old raw KeyError disappeared. |
| All/any/k-of-n selecting a different repaired child outcome | Every prior-generation closure rejected with closure_blocked; fresh assignment, submission and verification close successfully. |
| Any/all/k-of-n retaining the identical independent selected witness or temporarily losing it and restoring the exact identity | The direct consumer retains its earlier genuine closure and outcome, with old work confirmed already_decided. Raw A1 blast radius excludes structural ancestry and the separate consumer. |
| Mixed typed-edge cycle, parent and independent sibling | The closed affected leaf becomes stale at the premise revision, the parent loses only its selected eligibility, and unrelated retained evidence and outcome identity remain observable at historical and current public revisions. |
| Concurrent close/invalidate in both orders | Separate OS processes contended inside SQLite BEGIN IMMEDIATE. Only the eligible transaction could close. A closure that committed first remained historical and was reopened by the later invalidation. |
| In-flight and delayed-duplicate local dispatch | One callback released before invalidation, outcome submission then refused. A delayed second invocation from the same initial snapshot never started a second callback. |
| Stale relation read set | Added/removed dependency relations and unaffected read sets behaved as observed in the committed public responses. |
| Genuine human M2 ledger and previous study series | Reconstructed original 24 events and four artifacts, compared old answer keys, historical projections and heads via 17 new CLI processes, redelivered the saved principal receipt, and reproduced both E1/E1v2 reports byte for byte with their original readers. |
| Existing product regressions | tests.test_decisions, gate, store, work, cli, driver and retained_history ran 55 tests on each of Python 3.11 and 3.14. Both suites completed successfully. |

The product-a2 outputs contain public proof records and original event lines. The support-a2, observation-a2 and history-a2 outputs give exact identities and receipts. Final qualification binds the final immutable joined source and its registration separately.
