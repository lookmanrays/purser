"""Rebuild the measurable prefix from case-bound original plan and Git bytes."""
import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

RAW_SHA = "49b575a8406e6c3d23d8dc7def5d06d87c79fde0479b235b55bf5f53fc825691"
SOURCE = "82e880734539bbd8d2af2b0b44fbdcff2b4062f3"
ORACLE_SHA = "a1612991ddb556a0737adb849e152d3b0c25bfa8043dd76d0251467daf07b5e4"
CHECKPOINTS = ("before","after","checkpoint","required_before","pre_issue_head","port_before","port_after","context_source")
PARENT = "W-notify"
OLD = "7df4a199e2ada1caafe78f5acec2f99b06f44771"
NEW = "a5cd7dfec079a2b38d8b673c47d736ce3161f22a"
def sha(raw): return hashlib.sha256(raw).hexdigest()
def encode(v): return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()

def main(path, oracle):
    assert sha(path.read_bytes())==RAW_SHA and sha(oracle.read_bytes())==ORACLE_SHA
    spec=importlib.util.spec_from_file_location("independent_queue",oracle)
    queue=importlib.util.module_from_spec(spec); spec.loader.exec_module(queue)
    with zipfile.ZipFile(path) as z:
        def blob(ref):
            raw=z.read(ref["path"])
            assert sha(raw)==ref["sha256"] and len(raw)==ref["bytes"]
            return raw
        def obj(ref): return json.loads(blob(ref))
        freeze=json.loads(z.read("freeze.json"));assert freeze["source_commit"]==SOURCE and freeze["replicate"]>1
        marker=json.loads(z.read("started/primary/2001/loop.json"))
        assert marker=={"arm":"loop","rank":1,"seed":2001,"track":"primary"}
        raw=json.loads(z.read("runs/primary/2001/loop.json"))
        plt=obj(raw["artifacts"]["platform"]);j=obj(raw["artifacts"]["journal"]);candidates=obj(raw["artifacts"]["candidates"])
        assert raw["terminal"]=="harness_failure" and plt["participant_exit"] is None and plt["treatment_trace"] is None
        pause=plt["checkpoint_measurement"];original=obj(pause["submission_source"])
        generations={}
        def bind(ref):
            rows=obj(ref);assert sha(encode(rows))==ref["sha256"]
            stamp=rows[PARENT]["_e2_plan_version"];n=stamp["number"]
            record=(ref["sha256"],stamp,rows)
            assert n not in generations or record==generations[n]
            generations[n]=record
        for ref in original["plan_versions"]: bind(ref)
        assert len(generations)==7 and original["plan"]==generations[7][2]
        for row in j:
            for field in CHECKPOINTS:
                ck=row["payload"].get(field)
                if type(ck) is dict and "view" in ck:
                    assert ck["plan_sha256"]==ck["view"]["sha256"]
                    bind(ck["view"])
        assert sorted(generations)==list(range(1,15))
        prev=None; chain=[]
        for n,(digest,stamp,rows) in sorted(generations.items()):
            assert stamp["previous"]==prev; prev=digest
            chain.append({"generation":n,"digest":digest,"previous":stamp["previous"],"attempt":stamp["attempt"],
                          "W2":{k:rows["W2"].get(k) for k in ("state","candidate","retry_choice","premise")},
                          "W-notify":{k:rows[PARENT][k] for k in ("state","candidate")}})
        old=generations[7][2];change=generations[8][2]; f,=[e["payload"] for e in j if e["kind"]=="fault"]
        assert all(generations[n][2]["W2"]["retry_choice"]=="linear" and generations[n][2]["W2"]["premise"] is None for n in range(2,8))
        assert old["W2"]["_publication"]=={"actor":"executor","attempt":17,"candidate":OLD,"diagnosis":[],"subject":"W2"}
        assert (old["W2"]["state"],old["W2"]["candidate"],old["W2"]["criterion"])==("submitted",OLD,"W2/retry")
        assert pause["submission_attempt"]==17 and pause["checkpoint"]["plan_sha256"]==generations[7][0]
        assert f["before"]["plan_sha256"]==generations[7][0] and f["after"]["plan_sha256"]==generations[8][0]
        assert change["W2"]["_publication"]["attempt"]=="Obs-A1-changed" and change["W2"]["_publication"]["actor"]=="fixture_observer"
        assert f["released"]==change["W2"]["premise"] and f["released"]["retry_schedule"]=="exponential"
        assert sha(encode(f["released"]))==f["released_sha256"] and f["released"]["seed"]==2001
        assert generations[9][2]["W2"]["retry_choice"]=="exponential"
        actions={e["payload"]["attempt"]:e["payload"] for e in j if e["kind"]=="action"}
        assert sorted(actions)==list(range(1,31)) and actions[17]["action"]=="submit" and actions[17]["candidate"]==OLD
        later=[p for p in actions.values() if p["issued_monotonic_ns"]>=f["finished_monotonic_ns"]]
        assert [p["attempt"] for p in later]==list(range(18,31))
        assert all(p["arm"]=="loop" and p["action"] in ("plan","context","edit","check","submit","observe","decide") and p["subject"] in ("W1","W2","W3",PARENT) for p in later)
        assert actions[18]["input"]["adopt"]=="Obs-A1-changed"
        assert actions[28]["action"]=="submit" and actions[28]["subject"]==PARENT and actions[28]["candidate"]==NEW
        assert generations[13][2][PARENT]["_publication"]["attempt"]==28 and generations[13][2][PARENT]["candidate"]==NEW
        assert generations[14][2][PARENT]["state"]=="closed" and generations[14][2][PARENT]["_publication"]["attempt"]==30
        assert all(old[s]["state"]=="closed" for s in ("W1","W3"))
        with tempfile.TemporaryDirectory() as d:
            repo=Path(d); subprocess.run(["git","init","--quiet","--bare"],cwd=repo,check=True)
            def git(*args,data=None):return subprocess.run(["git",*args],cwd=repo,input=data,capture_output=True,check=True).stdout.decode().strip()
            for oid,e in candidates.items():
                git("index-pack","--stdin",data=blob(e["pack"]));assert git("rev-parse",oid+"^{tree}")==e["tree"]
            git("fsck","--full","--no-dangling")
            checks={}; grade=lambda o:queue.measure(repo,o,2001,"linear")["criteria"]
            checks[OLD]=grade(OLD)
            for subject,rel,label in (("W1","notify/preferences.py","W1/preferences"),("W3","notify/delivery.py","W3/delivery")):
                oid=old[subject]["candidate"];checks[oid]=grade(oid)
                assert checks[oid][label] and checks[OLD][label]
                assert git("ls-tree",oid,"--",rel)==git("ls-tree",OLD,"--",rel)
            assert checks[OLD]["W2/retry"] and all(queue.measure(repo,NEW,2001,"revised")["criteria"].values())
        return {"raw_sha256":RAW_SHA,"source":SOURCE,"private_replicate":freeze["replicate"],"marker":marker,
                "missing_final_treatment_trace":True,"original_checkpoint_ref":pause["submission_source"],"original_plan_generations":chain,
                "protected_queue_sha256":ORACLE_SHA,"independent_old_checks":checks,
                "verified_old_W2_submission_attempt":17,"revised_premise_generation":8,
                "observed_rework_attempts":[{"attempt":p["attempt"],"subject":p["subject"],"action":p["action"]} for p in later],
                "rework_observed_lower_bound":len(later),"exact_rework":None,"observed_action_count":len(actions),
                "last_witnessed_public_submission":{"attempt":28,"generation":13,"subject":PARENT,"candidate":NEW},
                "last_public_parent_closure":{"attempt":30,"generation":14,"candidate":NEW},"physical_participant_exit":None,
                "final_participant_score":None}
if __name__=="__main__":
    print(json.dumps(main(Path(sys.argv[1]),Path(sys.argv[2])),sort_keys=True,indent=2))
