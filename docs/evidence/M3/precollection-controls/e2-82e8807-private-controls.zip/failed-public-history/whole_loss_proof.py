"""Read the case's own recorded plan-head references after the original trial directory was lost."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

base=Path(sys.argv[1]).resolve()
repo=base/"repo"
case_dir=base/"kill-parent-trial"
raw_path=case_dir/"archive-only/raw.zip"
sys.path.insert(0,str(repo))
from experiments.e1.report import Objects
from experiments.e2 import checkpoint,measure
from experiments.e2.public_history import read_participant

def H(blob):
    return hashlib.sha256(blob).hexdigest()

def emit(path,obj):
    encoded=json.dumps(obj,sort_keys=True,indent=2)+"\n"
    path.write_text(encoded)

def git(where,args,*,input=None):
    return subprocess.run(["git","-C",str(where),*args],input=input,check=True,capture_output=True).stdout

with zipfile.ZipFile(raw_path) as z:
    assert z.testzip() is None
    reg=json.loads(z.read("freeze.json"))
    raw=json.loads(z.read("runs/primary/2001/loop.json"))
    objects=Objects(z)
    def read(ref):
        data=z.read(ref["path"])
        assert H(data)==ref["sha256"] and len(data)==ref["bytes"]
        return data
    def parse(ref):
        return json.loads(read(ref))
    platform=parse(raw["artifacts"]["platform"])
    journal=parse(raw["artifacts"]["journal"])
    candidates=parse(raw["artifacts"]["candidates"])
    assert platform["treatment_trace"] is None and not platform["participant_exit"] and platform.get("exit_candidate") is None
    pause=platform["checkpoint_measurement"]
    prefix=parse(pause["submission_source"])
    source_heads=set()
    def locate(v):
        if isinstance(v,list):
            for it in v:
                locate(it)
        elif isinstance(v,dict):
            if type(v.get("plan_sha256")) is str and isinstance(v.get("view"),dict):
                assert H(read(v["view"]))==v["plan_sha256"]
                source_heads.add(v["plan_sha256"])
            for it in v.values():
                locate(it)
    locate(journal)
    locate(platform["initial_public"])
    locate(pause["checkpoint"])
    closure=[r for r in journal if r["kind"]=="public_state" and r["payload"]["subject"]=="W-notify" and r["payload"]["to"]=="closed"]
    assert len(closure)==1
    anchor=closure[0]["payload"]["checkpoint"]
    assert H(read(anchor["view"]))==anchor["plan_sha256"]
    where=anchor["plan_sha256"]
    chain=[]
    while where:
        assert where not in {d for d,_ in chain}
        data=z.read("objects/"+where+".json")
        assert H(data)==where
        plan=json.loads(data)
        if chain:
            assert chain[-1][1]["W-notify"]["_e2_plan_version"]["number"]==1+plan["W-notify"]["_e2_plan_version"]["number"]
        chain.append((where,plan))
        where=plan["W-notify"]["_e2_plan_version"]["previous"]
    chain.reverse()
    assert chain[0][1]["W-notify"]["_e2_plan_version"]["number"]==1
    assert source_heads<=set(d for d,s in chain)
    assert [r["sha256"] for r in prefix["plan_versions"]]==[d for d,_ in chain[:len(prefix["plan_versions"])]]
    old=prefix["plan"]
    assert old["W2"]["candidate"]==pause["candidate"] and old["W2"]["state"]=="submitted"
    assert old["W2"]["retry_choice"]=="linear" and old["W2"]["premise"] is None
    assert all(old[w]["state"]=="closed" for w in ("W1","W3"))
    original_submissions=[]
    ingress=None
    for i,(d,plan) in enumerate(chain[1:],1):
        prev=chain[i-1][1]
        for work in ("W1","W2","W3","W-notify"):
            current=plan[work]
            if (current["state"]=="submitted" and (prev[work]["state"],prev[work]["candidate"])!=("submitted",current["candidate"])):
                original_submissions.append({"publication":d,"number":i+1,"attempt":plan["W-notify"]["_e2_plan_version"]["attempt"],"subject":work,"candidate":current["candidate"]})
        new=plan["W2"].get("premise")
        if new and not prev["W2"].get("premise"):
            assert new["criterion"]=="W2/retry" and new["retry_schedule"]=="exponential"
            ingress={"publication":d,"old_head":chain[i-1][0],"number":i+1,"notice":new["id"]}
    assert ingress["old_head"]==pause["checkpoint"]["plan_sha256"]
    last_submission=original_submissions[-1]
    assert last_submission["subject"]=="W-notify" and last_submission["attempt"]==28
    assert anchor==closure[0]["payload"]["checkpoint"] and closure[0]["payload"]["candidate"]==last_submission["candidate"]
    checkpoint_issues=[]
    trial_prefix=dict(platform,treatment_trace=pause["submission_source"],final_public=pause["checkpoint"])
    history=read_participant("loop",journal[:pause["preceding_events"]],trial_prefix,objects.item,checkpoint_issues.append,
                             seed=raw["seed"],track=raw["track"])
    accepted,attempt=checkpoint.accepted_submission(history,pause["checkpoint"],pause["candidate"])
    old_law=checkpoint.old_assignment(history,pause["checkpoint"],attempt)
    assert accepted is True and old_law is True and attempt==17 and not checkpoint_issues,checkpoint_issues
    protected={}
    for r in journal:
        if r["kind"]=="oracle":
            pay=r["payload"]
            protected[pay["candidate"],pay["criterion"],pay["version"]]=parse(pay["evidence"])
    checkpoint.validate(pause,history.checkpoint(pause["checkpoint"]),raw["track"],raw["seed"],1,objects,platform["policy_blobs"],
                        protected, complete=False, submitted=accepted, old_assignment=old_law)
    reference=case_dir/"queue_reference.py"
    with zipfile.ZipFile(repo/"docs/evidence/M3/precollection-controls/e2-0ad579f-private-controls.zip") as original:
        reference.write_bytes(original.read("stopped/queue_reference.py"))
    independent={}
    with tempfile.TemporaryDirectory() as temp:
        bare=Path(temp)
        git(bare,["init","-q","--bare"])
        for oid,entry in sorted(candidates.items()):
            git(bare,["index-pack","--stdin","--strict"],input=read(entry["pack"]))
            assert git(bare,["rev-parse",oid+"^{tree}"]).decode().strip()==entry["tree"]
            old_ver,new_ver=[json.loads(subprocess.check_output([sys.executable,"-I","-B",str(reference),str(bare),oid,str(raw["seed"]),mode])) for mode in ("linear","revised")]
            result={label+"/v1":v for label,v in old_ver["criteria"].items()}
            result.update({label+"/v2":new_ver["criteria"][label] for label in ("W2/retry","queue/composition")})
            assert all(type(v) is bool and v is (protected[oid, key.rsplit("/v",1)[0],int(key.rsplit("/v",1)[1])]["verdict"]=="pass") for key,v in result.items())
            independent[oid]=result
    result={"candidate":reg["source_commit"],"raw_sha256":H(raw_path.read_bytes()),"retained_authorities":{
               "checkpoint_original":pause["submission_source"],"original_checkpoint_versions":len(prefix["plan_versions"]),
               "old_w2_candidate":pause["candidate"],"original_accepted_submission":accepted,"old_linear_assignment":old_law,
               "submission_attempt":attempt,"checkpoint_issues_replaying_its_own_prefix":checkpoint_issues,
               "checkpoint_validate_using_original_prefix":"passed",
               "retained_protected_checkpoint_reports":len(pause["checks"]),
               "latest_journal_anchor":{"seq":closure[0]["seq"],**anchor},
               "single_contiguous_archived_plan_chain":[d for d,_ in chain],
               "all_case_named_heads_on_one_chain":sorted(source_heads),
               "original_submissions":original_submissions,"last_witnessed_submission":last_submission,
               "physically_closed_parent":chain[-1][1]["W-notify"]["state"]=="closed",
               "closure_candidate":chain[-1][1]["W-notify"]["candidate"],"original_ingress":ingress},
               "independent_seeded_git_slots":independent,"physical_participant_exit":platform["participant_exit"],
               "independent_oracle_sha256":H(reference.read_bytes())}
    emit(case_dir/"original-prefix-proof.json",result)
    print("verified",len(chain),"contiguous plan publications,",len(prefix["plan_versions"]),"precheckpoint originals,",len(protected),"independent Git slots")
