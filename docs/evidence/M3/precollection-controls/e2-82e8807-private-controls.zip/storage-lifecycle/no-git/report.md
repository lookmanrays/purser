# Scripted E2 results

Private replicate 562 has 1 of 66 registered records, 65 are missing.

Twenty matched primary ranks were registered. Count columns show the total and the number of seeds with an observed value. Missing binary outcomes can range from zero to one. Thresholds use those bounds. A question mark marks an unavailable measurement.

| Arm | Complete | Incomplete | Invalid or missing | Checkpoint reached | Both retained | Invalid affected closure | Rework steps / measured | Final pass | Total steps / measured |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| loop | 0 | 0 | 20 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 |
| purser | 0 | 0 | 20 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 |
| loop_equal_verifier | 0 | 0 | 20 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 |

## Frozen thresholds

Each comparison uses the original rules. The half-cost test compares summed rework across all 20 ranks. The no-advantage predicate is true when Purser rework is equal or greater, or its final pass count is lower.

| Purser compared with | Both retained ≥18 | 2 × Purser rework ≤ comparator | Final passes ≥ comparator | E2 passes | No advantage | Rework ratio |
| --- | --- | --- | --- | --- | --- | ---: |
| loop | inconclusive | inconclusive | inconclusive | inconclusive | inconclusive | inconclusive |
| loop_equal_verifier | inconclusive | inconclusive | inconclusive | inconclusive | inconclusive | inconclusive |

## Paired primary results

Each signed difference is Purser minus its comparator. Columns within each cell give retention, bad affected closure, rework steps, final pass, total steps and elapsed seconds. Zero is a tie.

| Seed | Purser − plain loop | Purser − equal verifier |
| ---: | --- | --- |
| 2001 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2002 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2003 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2004 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2005 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2006 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2007 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2008 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2009 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2010 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2011 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2012 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2013 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2014 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2015 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2016 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2017 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2018 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2019 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2020 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |

## Primary coverage · loop

| Seed | Validity / exit | Reached | Both retained | Reopen transitions | Invalid affected closure | Rework | Final pass | Steps | Elapsed s |
| ---: | --- | --- | --- | ---: | --- | ---: | --- | ---: | ---: |
| 2001 | infrastructure_invalid / harness_failure (disputed) | ? | ? | ? | ? | ? | ? | 4 observed (total ?) | ≥0.134 |
| 2002 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2003 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2004 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2005 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2006 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2007 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2008 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2009 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2010 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2011 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2012 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2013 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2014 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2015 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2016 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2017 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2018 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2019 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2020 | missing | ? | ? | ? | ? | ? | ? | ? | ? |

## Primary coverage · purser

| Seed | Validity / exit | Reached | Both retained | Reopen transitions | Invalid affected closure | Rework | Final pass | Steps | Elapsed s |
| ---: | --- | --- | --- | ---: | --- | ---: | --- | ---: | ---: |
| 2001 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2002 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2003 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2004 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2005 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2006 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2007 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2008 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2009 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2010 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2011 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2012 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2013 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2014 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2015 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2016 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2017 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2018 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2019 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2020 | missing | ? | ? | ? | ? | ? | ? | ? | ? |

## Primary coverage · loop_equal_verifier

| Seed | Validity / exit | Reached | Both retained | Reopen transitions | Invalid affected closure | Rework | Final pass | Steps | Elapsed s |
| ---: | --- | --- | --- | ---: | --- | ---: | --- | ---: | ---: |
| 2001 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2002 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2003 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2004 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2005 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2006 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2007 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2008 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2009 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2010 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2011 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2012 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2013 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2014 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2015 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2016 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2017 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2018 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2019 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2020 | missing | ? | ? | ? | ? | ? | ? | ? | ? |

## Clean control · A1 retained

| Arm | Exit | Clean exposure | Final pass | Steps | Elapsed s |
| --- | --- | --- | --- | ---: | ---: |
| loop | missing | ? | ? | ? | ? |
| purser | missing | ? | ? | ? | ? |
| loop_equal_verifier | missing | ? | ? | ? | ? |

The twice-baseline clean overhead flag is **?**.

## Already-closed affected stress control

At delivery the affected W2 was already closed under the old schedule. The two bad-closure columns distinguish a stale closure still visible at delivery from a new bad closure asserted later.

| Arm | Exit | Old W2 candidate at delivery | Both siblings retained | Stale at delivery | New bad closure | Rework | Final pass | Steps | Elapsed s |
| --- | --- | --- | --- | --- | --- | ---: | --- | ---: | ---: |
| loop | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| purser | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| loop_equal_verifier | missing | ? | ? | ? | ? | ? | ? | ? | ? |

## Unavailable or disputed observations

- primary / 2001 / loop — captured Git evidence: original candidate 55686bd5152e10a53dfdc2c003974ea405a3a075 was missing its staged pack objects/ab3fec4e7fd7128beeeb085306b2315a5ea6b9dbaded7afb65ffa1b4ef92d09e.pack · captured Git evidence: candidate map 55686bd5152e10a53dfdc2c003974ea405a3a075: unavailable object objects/ab3fec4e7fd7128beeeb085306b2315a5ea6b9dbaded7afb65ffa1b4ef92d09e.pack · captured Git evidence: case candidate Git bytes unavailable for 55686bd5152e10a53dfdc2c003974ea405a3a075 · case candidate Git bytes unavailable for 55686bd5152e10a53dfdc2c003974ea405a3a075 · candidate map lacks case observation 55686bd5152e10a53dfdc2c003974ea405a3a075 · protected 55686bd5152e10a53dfdc2c003974ea405a3a075 v1 W1/preferences: missing protected journal row · protected 55686bd5152e10a53dfdc2c003974ea405a3a075 v1 W1/preferences: independent replay unavailable: authenticated Git bytes unavailable · protected 55686bd5152e10a53dfdc2c003974ea405a3a075 v1 W2/retry: missing protected journal row · protected 55686bd5152e10a53dfdc2c003974ea405a3a075 v1 W2/retry: independent replay unavailable: authenticated Git bytes unavailable · protected 55686bd5152e10a53dfdc2c003974ea405a3a075 v1 W3/delivery: missing protected journal row · protected 55686bd5152e10a53dfdc2c003974ea405a3a075 v1 W3/delivery: independent replay unavailable: authenticated Git bytes unavailable · protected 55686bd5152e10a53dfdc2c003974ea405a3a075 v1 scope/paths: missing protected journal row · protected 55686bd5152e10a53dfdc2c003974ea405a3a075 v1 scope/paths: independent replay unavailable: authenticated Git bytes unavailable · protected 55686bd5152e10a53dfdc2c003974ea405a3a075 v1 legacy/compat: missing protected journal row · protected 55686bd5152e10a53dfdc2c003974ea405a3a075 v1 legacy/compat: independent replay unavailable: authenticated Git bytes unavailable · protected 55686bd5152e10a53dfdc2c003974ea405a3a075 v1 queue/composition: missing protected journal row · protected 55686bd5152e10a53dfdc2c003974ea405a3a075 v1 queue/composition: independent replay unavailable: authenticated Git bytes unavailable · protected 55686bd5152e10a53dfdc2c003974ea405a3a075 v2 W2/retry: missing protected journal row · protected 55686bd5152e10a53dfdc2c003974ea405a3a075 v2 W2/retry: independent replay unavailable: authenticated Git bytes unavailable · protected 55686bd5152e10a53dfdc2c003974ea405a3a075 v2 queue/composition: missing protected journal row · protected 55686bd5152e10a53dfdc2c003974ea405a3a075 v2 queue/composition: independent replay unavailable: authenticated Git bytes unavailable · original participant trace unavailable · initial public release does not match original completed participant setup · final public checkpoint lacks an identical original participant head
  Observed facts — witnessed participant exit no, clean exposure ?, both siblings continuously retained ?, invalid affected closure ?, stale closure at receipt ?, new invalid affected closure ?, final Git criteria pass ?.
  Last measured candidate `55686bd5152e10a53dfdc2c003974ea405a3a075` (recorded_candidate_with_unavailable_git), registered criteria pass ?. W1/preferences ?, W2/retry ?, W3/delivery ?, scope/paths ?, legacy/compat ?, queue/composition ?.

## Protected Git observations

| Case | Candidate | Criterion | Version | Retained verdict | Available grade | Grade source | Original journal row | Independent replay |
| --- | --- | --- | ---: | --- | --- | --- | --- | --- |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W1/preferences | 1 | ? | ? | unavailable | missing | unavailable |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 1 | ? | ? | unavailable | missing | unavailable |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W3/delivery | 1 | ? | ? | unavailable | missing | unavailable |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | scope/paths | 1 | ? | ? | unavailable | missing | unavailable |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | legacy/compat | 1 | ? | ? | unavailable | missing | unavailable |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 1 | ? | ? | unavailable | missing | unavailable |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 2 | ? | ? | unavailable | missing | unavailable |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 2 | ? | ? | unavailable | missing | unavailable |

The scripted protocol permits zero model calls, tokens and spend.
