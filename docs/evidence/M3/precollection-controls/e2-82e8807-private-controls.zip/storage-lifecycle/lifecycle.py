"""Exercise collector persistence cuts on private, committed E2 registrations."""
import hashlib
import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import zipfile
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch

BASE = Path(__file__).resolve().parent
SOURCE = BASE / "life-source"
PIN = "82e880734539bbd8d2af2b0b44fbdcff2b4062f3"
UNIT = [("primary", 2001, 1, "loop")]
SCENARIOS = ("empty", "uninstalled", "start-head", "start-bare", "mapped", "setup-exception",
             "first-release", "edit-head", "edit-bare", "missing-map", "missing-pack", "damaged-pack",
             "no-git", "staged-raw", "tentative-zip", "published-zip")
SHA = lambda value: hashlib.sha256(value).hexdigest()
sys.path.insert(0, str(SOURCE))
from experiments.e1 import artifacts, recovery, suite as common
from experiments.e1.artifacts import START, Artifacts, Candidates
from experiments.e2 import report, suite, trial
sys.path.append("/Users/lookman/.local/state/purser/development/m3-independent-reference")
import queue_reference as independent

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")

def git(directory, *args):
    return subprocess.run(["git", *args], cwd=directory, text=True, check=True, capture_output=True).stdout.strip()

def series(scenario):
    return SOURCE / "private-life" / scenario

def stage(scenario):
    return series(scenario) / ".attempt-primary-2001-loop"

def killed(scenario, point):
    path = stage(scenario)
    progress = path / "progress.json"
    receipt = {"point": point, "marker": json.loads((path / "started.json").read_bytes()),
               "progress": json.loads(progress.read_bytes()) if progress.exists() else None,
               "packs": [p.name for p in sorted((path / "objects").glob("*.pack"))],
               "stage_raw": (path / "raw.json").exists(),
               "tentative_zip": (series(scenario) / ".raw-next.zip").exists(),
               "published_zip": (series(scenario) / "raw.zip").exists()}
    save(BASE / (scenario + "-" + point + ".json"), receipt)
    os.kill(os.getpid(), signal.SIGKILL)

def first(scenario):
    real_git = artifacts.git
    real_release = trial.clock.ParticipantClock.release
    pack_no = head_no = bare_no = 0
    def git_cut(directory, *args, **kwargs):
        nonlocal head_no, bare_no
        actual = real_git(directory, *args, **kwargs)
        if args[0] == "commit-tree" and scenario == "uninstalled":
            killed(scenario, "commit-object")
        if args[:2] == ("update-ref","HEAD"):
            head_no += 1
            if (scenario, head_no) in (("start-head",1),("edit-head",2)):
                killed(scenario, "installed-head")
        if args[:2] == ("index-pack","--stdin"):
            bare_no += 1
            if (scenario, bare_no) in (("start-bare",1),("edit-bare",2)):
                killed(scenario, "indexed-bare")
        return actual
    original_put = Artifacts.put
    def pack_cut(self, data, suffix):
        nonlocal pack_no
        ref = original_put(self, data, suffix)
        if suffix == "pack":
            pack_no += 1
            if pack_no == 2 and scenario in ("missing-map", "missing-pack", "damaged-pack", "no-git"):
                killed(scenario, "sealed-edit")
        return ref
    def release(self):
        if scenario in ("mapped","staged-raw","tentative-zip","published-zip"):
            assert START in self.candidates and not self.released and self.steps == 0
            killed(scenario, "mapped-start")
        result = real_release(self)
        if scenario == "first-release":
            killed(scenario,"released")
        return result
    with ExitStack() as stack:
        stack.enter_context(patch.object(artifacts, "git", git_cut))
        stack.enter_context(patch.object(Artifacts, "put", pack_cut))
        stack.enter_context(patch.object(trial.clock.ParticipantClock, "release", release))
        if scenario == "empty":
            stack.enter_context(patch.object(Candidates,"__init__",side_effect=lambda *a, **k: killed(scenario,"empty")))
        if scenario == "setup-exception":
            stack.enter_context(patch.object(trial,"definitions",side_effect=OSError("private setup failed after actual START seal")))
        suite.collect_units(series(scenario), UNIT)

def second(scenario):
    raw = stage(scenario) / "raw.json"
    archive = series(scenario) / "raw.zip"
    real_write, real_replace = common.write_atomic, common.os.replace
    def raw_cut(path, data):
        real_write(path, data)
        if path == raw and scenario == "staged-raw":
            killed(scenario,"raw-written")
    def replace_cut(a, b):
        if b == archive and scenario == "tentative-zip":
            killed(scenario,"before-replace")
        real_replace(a,b)
        if b == archive and scenario == "published-zip":
            killed(scenario,"after-replace")
    with (patch.object(common,"write_atomic",raw_cut),patch.object(common.os,"replace",replace_cut),
          patch.object(trial,"attempt",side_effect=AssertionError("redispatched"))):
        suite.collect_units(series(scenario), UNIT)

def exercise(scenario):
    path = series(scenario)
    out = BASE / "readback" / scenario
    out.mkdir(parents=True)
    def run_child(mode):
        result=subprocess.run([sys.executable,"-B",str(Path(__file__).resolve()),mode,scenario],
                              cwd=SOURCE,capture_output=True,timeout=65)
        (out / (mode + ".log")).write_bytes(result.stdout+result.stderr)
        assert result.returncode == (0 if scenario=="setup-exception" else -signal.SIGKILL), (mode,scenario,result.returncode,result.stderr[-900:])
    run_child("first")
    staged = stage(scenario)
    if staged.exists():
        if scenario in ("start-bare","edit-bare"):
            (staged/"trial/worker").rename(out/"prior-worker")
        if scenario in ("missing-map","missing-pack","damaged-pack","no-git"):
            (staged/"trial").rename(out/"prior-trial")
            progress_path=staged/"progress.json"
            progress=json.loads(progress_path.read_bytes())
            if scenario=="missing-map":
                progress["candidates"]={START:None, "bad":"invalid"}
                recovery.write_atomic(progress_path,artifacts.encoded(progress))
            if scenario in ("missing-pack","damaged-pack"):
                target=staged / progress["candidates"][START]["pack"]["path"]
                target.rename(out/"missing-start.pack")
                if scenario=="damaged-pack":
                    target.write_bytes(b"corrupted original pack")
            if scenario == "no-git":
                for pack in sorted((staged/"objects").glob("*.pack")):
                    pack.rename(out/pack.name)
        if scenario in ("staged-raw","tentative-zip","published-zip"):
            run_child("second")
    with patch.object(trial,"attempt",side_effect=AssertionError("redispatched")) as dispatch:
        suite.collect_units(path,UNIT)
        raw_hash=SHA((path/"raw.zip").read_bytes())
        suite.collect_units(path,UNIT)
        assert dispatch.call_count==0 and raw_hash==SHA((path/"raw.zip").read_bytes()) and not staged.exists()
    (out/"raw.zip").write_bytes((path/"raw.zip").read_bytes())
    results, stats=report.inspect_series(out)
    case=next(iter(results.values()))
    text=subprocess.run([sys.executable,"-B","-m","experiments.e2","report",str(out)],cwd=SOURCE,capture_output=True,check=True,timeout=55).stdout
    (out/"report.md").write_bytes(text)
    strict=subprocess.run([sys.executable,"-B","-m","experiments.e2","verify",str(out)],cwd=SOURCE,capture_output=True,timeout=55)
    (out/"strict.log").write_bytes(strict.stdout+strict.stderr)
    raw=case.raw
    assert stats["started"]==stats["records"]==1 and raw["terminal"]=="harness_failure" and raw["score"] is None
    assert case.facts["final_candidate"] is None and case.facts["physical_exit"] is False and case.facts["final_pass"] is None
    disputed=scenario in ("missing-map","missing-pack","damaged-pack","no-git")
    before=scenario not in ("first-release","edit-head","edit-bare","missing-map","missing-pack","damaged-pack","no-git")
    assert (strict.returncode != 0)==disputed, (scenario,case.issues,strict.stderr[-1000:])
    if before:
        assert case.basis=="before_release" and raw["cost"]["steps"]==raw["cost"]["elapsed_ns"]==0
        assert case.facts["active_lower_ns"]==0 and case.facts["intervention_reached"] is False, (scenario,case.facts)
    expected_no=0 if scenario in ("empty","uninstalled","no-git") else 2 if scenario in ("edit-head","edit-bare","missing-map","missing-pack","damaged-pack") else 1
    with zipfile.ZipFile(out/"raw.zip") as z, tempfile.TemporaryDirectory() as temp:
        assert json.loads(z.read("freeze.json"))["source_commit"]==PIN
        items=lambda key: json.loads(z.read(raw["artifacts"][key]["path"]))
        mappings, journal=items("candidates"),items("journal")
        assert len(mappings)==expected_no,(scenario,len(mappings),expected_no)
        verdicts={(r["payload"]["candidate"],r["payload"]["criterion"],r["payload"]["version"]):r["payload"]["verdict"] for r in journal if r["kind"]=="oracle"}
        assert len(verdicts)==expected_no*8,(scenario,len(verdicts),expected_no)
        grades={}
        for oid,entry in mappings.items():
            repo=Path(temp)/oid
            repo.mkdir()
            git(repo,"init","-q","--bare")
            pack=z.read(entry["pack"]["path"])
            subprocess.run(["git","index-pack","--stdin"],cwd=repo,input=pack,capture_output=True,check=True)
            assert git(repo,"rev-parse",oid+"^{tree}")==entry["tree"]
            by_key={}
            for ver,phase in ((1,"linear"),(2,"revised")):
                obs=independent.measure(repo,oid,2001,phase)
                for label,v in obs["criteria"].items():
                    if ver==1 or label in ("W2/retry","queue/composition"):
                        assert verdicts[oid,label,ver]==("pass" if v else "fail")
                        by_key[f"{label}/v{ver}"]=v
            grades[oid]=by_key
            assert oid.encode() in text and all(s["verdict"]==verdicts[oid,s["criterion"],s["version"]] for s in case.facts["protected_slots"][oid])
        if not disputed:
            counts=json.loads(strict.stdout)
            assert counts["reexecuted_seed_candidate_versions"]==2*expected_no
            assert counts["reexecuted_seed_candidate_criteria"]==8*expected_no
        elif scenario=="no-git":
            assert case.facts["protected_slots"].keys()=={START}
            assert all(s["verdict"] is None for s in case.facts["protected_slots"][START])
    result={"source":PIN,"registration":git(SOURCE,"rev-parse","HEAD"),"case":scenario,"basis":case.basis,"cost":raw["cost"],"sha256":raw_hash,"independent":grades,"candidate_map":sorted(mappings),"original_criteria":len(verdicts),"strict_exit":strict.returncode,"strict_counts":json.loads(strict.stdout) if strict.returncode==0 else None,"issues":case.issues,"final_candidate":case.facts["final_candidate"],"participant_exit":case.facts["physical_exit"],"redispatches":dispatch.call_count}
    save(out/"result.json",result)
    print(scenario,case.basis,len(mappings),len(verdicts),strict.returncode,flush=True)

if __name__=="__main__":
    if sys.argv[1:] and sys.argv[1] in ("first","second"):
        (first if sys.argv[1]=="first" else second)(sys.argv[2])
    else:
        assert git(SOURCE,"rev-parse","HEAD")==PIN
        for offset,scenario in enumerate(SCENARIOS):
            suite.freeze_series(series(scenario),replicate=550+offset,reason="Private source qualification at "+scenario)
        git(SOURCE,"add","--","private-life")
        git(SOURCE,"-c","user.name=Purser evaluator","-c","user.email=evaluator@example.invalid","commit","-q","-m","Register private Git and publication lifecycle controls")
        git(SOURCE,"bundle","create",str(BASE/"lifecycle-registration.bundle"),"HEAD","^"+PIN)
        for scenario in SCENARIOS:
            exercise(scenario)
