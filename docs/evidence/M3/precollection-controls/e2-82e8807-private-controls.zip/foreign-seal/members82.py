import sys
from pathlib import Path
from unittest.mock import patch
b=Path(__file__).resolve().parent;repo=b/'membership-repo';sys.path.insert(0,str(repo))
from experiments.e2 import policy,suite
from experiments.e2.driver import Driver
original=Driver.submit_work
impl=policy.edit
def submit(d,w):
    if d.seed!=2002 or w!='W2':return original(d,w)
    def changed(repo,work,phase):
        r=impl(repo,work,phase)
        p=Path(repo)/'notify/retry.py'
        p.write_text(p.read_text()+'\n# Local reader-control comparison case.\n')
        return r
    with patch.object(policy,'edit',changed):return original(d,w)
with patch.object(Driver,'submit_work',submit):
    folder=repo/'docs/private-membership'
    suite.collect_units(folder,[u for u in suite.schedule() if u[3]=='loop' and u[0]=='primary' and u[1] in (2001,2002)])
