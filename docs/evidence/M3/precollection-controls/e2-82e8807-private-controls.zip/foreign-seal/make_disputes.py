import copy,hashlib,json,zipfile
from pathlib import Path
base=Path(__file__).resolve().parent
def enc(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()
def sha(x):return hashlib.sha256(x).hexdigest()
def target_zip():
    return zipfile.ZipFile(base/'membership-repo/docs/private-membership/raw.zip')
def create(case,transform):
    dest=base/'disputes'/case;dest.mkdir(parents=True,exist_ok=True)
    with target_zip() as inp:
        path='runs/primary/2001/loop.json';other='runs/primary/2002/loop.json'
        raw=json.loads(inp.read(path));second=json.loads(inp.read(other)); updates={}; omitted=set()
        def read(r):return json.loads(inp.read(r['path']))
        def put(x):
            b=enc(x);dig=sha(b);n=f'objects/{dig}.json';updates[n]=b;return {'path':n,'sha256':dig,'bytes':len(b)}
        p,c,j=(read(raw['artifacts'][n]) for n in ('platform','candidates','journal'))
        pp,cc=(read(second['artifacts'][n]) for n in ('platform','candidates'))
        final=p['exit_candidate']['head'];old=p['checkpoint_measurement']['candidate'];foreign=pp['exit_candidate']['head']
        assert foreign not in c and final not in cc and foreign in cc
        def oracle(oid):return next(e for e in j if e['kind']=='oracle' and (lambda q:q['candidate']==oid and q['criterion']=='W2/retry' and q['version']==2)(e['payload']))
        chosen=oracle(final);loc=j.index(chosen);meta={'recipient_final':final,'recipient_old':old,'foreign':foreign,'criterion':'W2/retry','version':2}
        if case=='late_action_identity_only':
            event=next(e for e in reversed(j) if e['kind']=='action' and e['payload']['action']=='check')
            assert event['seq']>next(e['seq'] for e in j if e['kind']=='fault')
            assert event['payload']['subject']=='W-notify'
            event['payload']['work_request']['subject']='W3'
        if case=='missing':
            r=chosen['payload']['evidence'];j.pop(loc);p['referenced_files']=[ref for ref in p['referenced_files'] if ref!=r]
        if case=='duplicate':
            j.insert(loc+1,copy.deepcopy(chosen))
        if case=='conflicting':
            different=copy.deepcopy(oracle(old));different['offset_ns']=chosen['offset_ns'];report=read(different['payload']['evidence']);assert report['verdict']=='fail';report['candidate']=final
            u=different['payload'];u['candidate']=final;u['evidence']=put(report);j.insert(loc+1,different)
        if case=='foreign_map':
            c[foreign]=cc[foreign]
        if case in ('partial_no_start','partial_no_final'):
            erased=next(oid for oid,e in c.items() if e['parent'] is None) if case=='partial_no_start' else final
            p['case_git_packs']=[k for k in p['case_git_packs'] if k['candidate']!=erased]
        if case=='no_map':
            c.clear()
        if case=='scope_only_missing':
            del p['case_git_packs']
        if case=='foreign_map_missing_scope':
            del p['case_git_packs'];c[foreign]=cc[foreign]
        if case=='foreign_map_empty_scope':
            p['case_git_packs']=[];c[foreign]=cc[foreign]
        if case=='reversed_seal':
            for i,seal in enumerate(p['case_git_packs']):
                if seal['candidate']==final:p['case_git_packs'][i]=dict(candidate=final,pack=cc[foreign]['pack'])
        if case=='missing_real_content':
            omitted.add(c[final]['pack']['path'])
        if case=='only_public_members_pool_content':
            own_packs={v['pack']['path'] for v in c.values()};donor_packs={v['pack']['path'] for v in cc.values()}
            omitted.update(own_packs-donor_packs)
            c.clear();p['case_git_packs']=[];p['referenced_files']=[r for r in p['referenced_files'] if not r['path'].endswith('.pack')]
        if case=='missing_map':
            del c[final]
        if case=='false_tree':
            c[final]['tree']=c[old]['tree']
        if case=='bad_seal':
            # A single cross-case identity on a still-present genuine local pack is contradicted by the original tip.
            assert p['case_git_packs'][-1]['pack']
            p['case_git_packs']+= [dict(candidate=foreign,pack=c[old]['pack'])]
        if case=='unreadable_foreign_seal':
            # An implausible local body is genuinely missing, while a different unit can supply an otherwise valid commit.
            # The recipient's map/public heads and every actual SHA-verified own seal exclude the foreign-only OID.
            wrong=dict(c[old]['pack']);wrong['bytes']+=1
            p['case_git_packs']+= [dict(candidate=foreign,pack=wrong)]
        if case in ('missing','duplicate','conflicting'):
            for ix,e in enumerate(j,1):e['seq']=ix
            j[-1]['payload']['last_observation']=len(j)-1
        for nm,data in [('platform',p),('candidates',c),('journal',j)]:raw['artifacts'][nm]=put(data)
        updates[path]=enc(raw)
        with zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
            for n in inp.namelist():
                if n not in omitted:z.writestr(n,updates.pop(n,inp.read(n)))
            for n,b in updates.items():z.writestr(n,b)
    return meta
cases=['missing','duplicate','conflicting','foreign_map','missing_map','false_tree','bad_seal','unreadable_foreign_seal']
import sys
prior=base/'dispute-identities.json'
g=json.loads(prior.read_bytes()) if prior.exists() else {}
g.update({name:create(name,None) for name in (sys.argv[1:] or cases)})
(base/'dispute-identities.json').write_bytes(enc(g)+b'\n')
