"""Replay the independent two-case seal dispute using only the three provided archives and Git."""
import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

SOURCE = "82e880734539bbd8d2af2b0b44fbdcff2b4062f3"
FOREIGN = "1a3550e0ed9c92cd004e96848a34a4fb1f2ac8f4"
OWN = "a5cd7dfec079a2b38d8b673c47d736ce3161f22a"
DIGESTS = {
    "baseline": "6140f0587c6f5a0b1c5882c942842baa0a5acf5c71732a41e440f17b025508da",
    "readable": "60839068bf4562af572834c999f5be281cb1798ab2ed9750232390eb94b37ed0",
    "bad-length": "6c42bed04aec7433e505b6986d011c4cc887183a2e066041e69c96c42093e5dc",
}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read_case(archive, seed):
    raw = json.loads(archive.read(f"runs/primary/{seed}/loop.json"))
    def read(ref):
        content = archive.read(ref["path"])
        assert len(content) == ref["bytes"] and sha(content) == ref["sha256"]
        return json.loads(content)
    return raw, read(raw["artifacts"]["candidates"]), read(raw["artifacts"]["platform"])

def git_commits(data):
    with tempfile.TemporaryDirectory() as tmp:
        def git(*args, stdin=None):
            return subprocess.run(["git", *args],cwd=tmp,input=stdin,capture_output=True,check=True).stdout
        git("init","-q","--bare")
        git("index-pack","--stdin",stdin=data)
        git("fsck","--strict","--no-reflogs")
        refs=git("cat-file","--batch-all-objects","--batch-check=%(objectname) %(objecttype)").decode().splitlines()
        return sorted(line.split()[0] for line in refs if line.endswith(" commit"))

def main(directory):
    out, baseline, genuine = {}, None, None
    for name, expected in DIGESTS.items():
        raw = (directory/name/"raw.zip").read_bytes()
        assert sha(raw)==expected
        with zipfile.ZipFile(directory/name/"raw.zip") as archive:
            freeze = json.loads(archive.read("freeze.json"))
            assert freeze["source_commit"]==SOURCE and freeze["replicate"]>1
            own, own_map, own_platform = read_case(archive,2001)
            neighbor, other_map, other_platform = read_case(archive,2002)
            journal = archive.read(own["artifacts"]["journal"]["path"])
            assert FOREIGN not in own_map and FOREIGN.encode() not in journal
            assert own_platform["exit_candidate"]["head"]==OWN and other_platform["exit_candidate"]["head"]==FOREIGN
            assert FOREIGN in other_map and OWN not in other_map
            scopes = own_platform["case_git_packs"]
            stable = (own["artifacts"]["journal"], own["artifacts"]["candidates"], neighbor,
                      own_platform["exit_candidate"], {k:v for k,v in own_platform.items() if k!="case_git_packs"})
            if baseline is None:
                baseline, genuine = stable, scopes
                assert {s["candidate"] for s in genuine}==set(own_map)
            else:
                assert stable==baseline and scopes[:-1]==genuine and scopes[-1]["candidate"]==FOREIGN
                disputed = scopes[-1]["pack"]
                blob = archive.read(disputed["path"])
                assert sha(blob)==disputed["sha256"] and len(blob)==disputed["bytes"]-int(name=="bad-length")
                assert FOREIGN not in git_commits(blob)
            own_commits=set()
            for seal in genuine:
                ref=seal["pack"]
                body=archive.read(ref["path"])
                assert len(body)==ref["bytes"] and sha(body)==ref["sha256"]
                commits=git_commits(body)
                assert seal["candidate"] in commits
                own_commits.update(commits)
            assert FOREIGN not in own_commits
            other_ref=other_map[FOREIGN]["pack"]
            data=archive.read(other_ref["path"])
            assert len(data)==other_ref["bytes"] and sha(data)==other_ref["sha256"] and FOREIGN in git_commits(data)
            text=(directory/name/"reviewer-report.md").read_text()
            def rows(seed, oid):
                return [line for line in text.splitlines() if line.startswith(f"| primary / {seed} / loop | `{oid}` |")]
            wrong_rows, donor_rows = rows(2001, FOREIGN), rows(2002, FOREIGN)
            assert len(wrong_rows)==(8 if name=="bad-length" else 0) and len(donor_rows)==8
            assert all("| replay | missing | measured |" in line for line in wrong_rows)
            if name=="readable":
                assert "case Git seal disagrees with original pack tip" in text
            out[name]={"archive":expected,"replicate":freeze["replicate"],"receiver_seed":2001,
                       "receiver_genuine_candidates":sorted(own_map),"receiver_sealed_commit_closure":sorted(own_commits),
                       "foreign_candidate":FOREIGN,"foreign_seed":2002,"donor_original_pack_digest":other_ref["sha256"],
                       "foreign_grades_shown_for_seed_2001":wrong_rows,"foreign_grades_shown_for_seed_2002":len(donor_rows)}
            if name!="baseline":
                out[name].update(disputed_pack_digest=disputed["sha256"],actual_bytes=len(blob),claimed_bytes=disputed["bytes"])
    return out

if __name__=="__main__":
    print(json.dumps(main(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent),sort_keys=True,indent=2))
