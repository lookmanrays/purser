"""Observe a controlled collector between case-local pack publication and inventory update."""
import hashlib
import json
import os
from pathlib import Path
import selectors
import signal
import subprocess
import sys
import tempfile
from unittest.mock import patch
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "source"
sys.path.insert(0, str(SOURCE))
from experiments.e1.artifacts import Artifacts
from experiments.e2 import suite, trial

UNITS = [("primary", 2001, 1, "loop")]
SHA = lambda b: hashlib.sha256(b).hexdigest()
RUNS = [(1, True), (1, False), (2, True), (2, False)]

def git(where, *args, data=None):
    result = subprocess.run(["git", *args], cwd=where, input=data, capture_output=True, check=True)
    return result.stdout.decode().strip()

def run_dir(number, has_work):
    return SOURCE / "private-pack-cuts" / f"pack{number}-work{int(has_work)}"

def stop_inside(number, has_work):
    counter = 0
    original = Artifacts.put
    def observed_write(self, raw, suffix):
        nonlocal counter
        ref = original(self, raw, suffix)
        if suffix == "pack":
            counter += 1
            if counter == number:
                stage = self.archive.directory
                assert SHA((stage / ref["path"]).read_bytes()) == ref["sha256"]
                progress = json.loads((stage / "progress.json").read_bytes())
                print(json.dumps({"ref": ref, "worker_oid": git(stage/"trial"/"worker", "rev-parse", "HEAD"),
                                  "progress_oids": sorted(progress.get("candidates",{})),
                                  "clock": progress.get("cost_basis")}), flush=True)
                signal.pause()
                raise AssertionError("reader termination did not win")
        return ref
    with patch.object(Artifacts, "put", observed_write):
        suite.collect_units(run_dir(number, has_work), UNITS)

def run_case(number, has_work):
    path = run_dir(number, has_work)
    stage = path / ".attempt-primary-2001-loop"
    proc = subprocess.Popen([sys.executable,"-B",str(Path(__file__).resolve()),"child",str(number),str(int(has_work))],
                            stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    with selectors.DefaultSelector() as sel:
        sel.register(proc.stdout, selectors.EVENT_READ)
        if not sel.select(20):
            proc.kill()
            proc.communicate()
            raise AssertionError("controlled pack did not publish")
    line=proc.stdout.readline()
    if not line:
        raise RuntimeError(proc.communicate()[1].decode()[-1000:])
    witness = json.loads(line)
    proc.kill()
    proc.communicate(timeout=10)
    assert proc.returncode == -signal.SIGKILL
    assert witness["worker_oid"] not in witness["progress_oids"]
    pack=(stage / witness["ref"]["path"]).read_bytes()
    marker=json.loads((stage / "started.json").read_bytes())
    assert marker["registration_sha256"]==SHA((path/"freeze.json").read_bytes())
    with tempfile.TemporaryDirectory(dir=ROOT) as temp:
        git(temp, "init", "-q", "--bare")
        git(temp, "index-pack", "--stdin", data=pack)
        oid=witness["worker_oid"]
        tree=git(temp, "rev-parse", oid+"^{tree}")
        tips=git(temp, "fsck", "--no-reflogs", "--full").splitlines()
        assert "dangling commit "+oid in tips
    if not has_work:
        (stage/"trial").rename(ROOT/(path.name+"-preserved-worker"))
    with patch.object(trial, "attempt", side_effect=AssertionError("redispatch")) as launch:
        suite.collect_units(path, UNITS)
        first=SHA((path/"raw.zip").read_bytes())
        suite.collect_units(path, UNITS)
        assert launch.call_count==0 and first==SHA((path/"raw.zip").read_bytes())
    with ZipFile(path/"raw.zip") as archive:
        raw=json.loads(archive.read("runs/primary/2001/loop.json"))
        stored=lambda name:json.loads(archive.read(raw["artifacts"][name]["path"]))
        candidates=stored("candidates")
        journal=stored("journal")
        named=set(candidates)
        assert archive.read(witness["ref"]["path"])==pack
        oracles=[x for x in journal if x["kind"]=="oracle"]
    check=subprocess.run([sys.executable,"-B","-m","experiments.e2","verify",str(path)],cwd=SOURCE,capture_output=True)
    return {"pack_publication":number,"worker_tree_retained":has_work,"collector_signal":proc.returncode,
            "registered_case":marker,"before_map_write":witness,"pack_tree":tree,"restored_target":oid,
            "archived_pack_bytes":len(pack),"native_candidate_map":sorted(named),
            "native_protected_rows":len(oracles),"raw_cost":raw["cost"],"terminal":raw["terminal"],
            "raw_sha256":first,"strict_exit":check.returncode,
            "strict_result":json.loads(check.stdout) if check.returncode==0 else check.stderr.decode().splitlines()[-1],
            "same_bytes_on_reopen":True}

if sys.argv[1:2]==["child"]:
    stop_inside(int(sys.argv[2]),bool(int(sys.argv[3])))
else:
    assert git(SOURCE,"rev-parse","HEAD")=="82e880734539bbd8d2af2b0b44fbdcff2b4062f3"
    for index,(n,w) in enumerate(RUNS):
        suite.freeze_series(run_dir(n,w),replicate=511+index,reason="Private physical case-scoped pack-to-inventory persistence cut")
    git(SOURCE,"add","--","private-pack-cuts")
    git(SOURCE,"-c","user.name=Purser project verifier","-c","user.email=verifier@example.invalid",
        "commit","--quiet","-m","Register four private case-local pack timing controls")
    output={"source":"82e880734539bbd8d2af2b0b44fbdcff2b4062f3","private_registration":git(SOURCE,"rev-parse","HEAD"),
            "controls":[run_case(n,w) for n,w in RUNS]}
    payload=(json.dumps(output,sort_keys=True,indent=2)+"\n").encode()
    (ROOT/"observed.json").write_bytes(payload)
    print(SHA(payload))
    for row in output["controls"]:
        print(row["pack_publication"],row["worker_tree_retained"],row["restored_target"][:10],
              row["native_candidate_map"],row["native_protected_rows"],row["strict_result"])

