"""Cold, independent queue and Git readback of the four native, pre-map SIGKILL runs."""
import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

HERE=Path(__file__).resolve().parent
SRC=HERE/"source"
sys.path.insert(0,str(SRC))
from experiments.e2 import report
REF=Path("/Users/lookman/.local/state/purser/development/m3-independent-reference")
sys.path.append(str(REF))
import queue_reference
h=lambda b:hashlib.sha256(b).hexdigest()
assert h((REF/"queue_reference.py").read_bytes())=="a1612991ddb556a0737adb849e152d3b0c25bfa8043dd76d0251467daf07b5e4"
results=[]
for trial in json.loads((HERE/"observed.json").read_text())["controls"]:
    n,w=trial["pack_publication"],int(trial["worker_tree_retained"])
    path=SRC/"private-pack-cuts"/f"pack{n}-work{w}"
    assert h((path/"raw.zip").read_bytes())==trial["raw_sha256"]
    native,stats=report.inspect_series(path,strict=True,rerun=True)
    case=next(iter(native.values()))
    assert case.facts["final_candidate"] is None and case.facts["final_pass"] is None and not case.facts["physical_exit"]
    assert case.raw["cost"]["steps"]==(0 if n==1 else 4)
    if n==1:
        assert case.basis=="before_release" and case.facts["witnessed_elapsed_ns"]==0 and case.raw["cost"]["elapsed_ns"]==0
    rows={}
    with zipfile.ZipFile(path/"raw.zip") as z:
        objects=lambda field:json.loads(z.read(case.raw["artifacts"][field]["path"]))
        for oid,e in objects("candidates").items():
            data=z.read(e["pack"]["path"]); assert len(data)==e["pack"]["bytes"] and h(data)==e["pack"]["sha256"]
            with tempfile.TemporaryDirectory() as temp:
                subprocess.run(["git","init","-q","--bare"],cwd=temp,check=True)
                subprocess.run(["git","index-pack","--stdin"],cwd=temp,input=data,capture_output=True,check=True)
                for v,phase in ((1,"linear"),(2,"revised")):
                    actual=queue_reference.measure(Path(temp),oid,2001,phase)
                    for label,grade in actual["criteria"].items():
                        if v==2 and label not in ("queue/composition","W2/retry"):continue
                        slot,=[s for s in case.facts["protected_slots"][oid] if s["version"]==v and s["criterion"]==label]
                        assert slot["verdict"]==("pass" if grade else "fail") and slot["replay"]=="matched" and slot["original"]=="recorded"
                        rows[f"{oid}/{label}/v{v}"]=grade
    assert len(rows)==n*8
    (path/"cold-report.md").write_text(report.render(path))
    results.append({"scenario":path.name,"archive":trial["raw_sha256"],"steps":case.raw["cost"]["steps"],"basis":case.basis,
                    "physical_exit":case.facts["physical_exit"],"final_pass":case.facts["final_pass"],"last_observed":case.facts["last_observed_candidate"],
                    "criteria":rows,"strict":stats})
(HERE/"four-cold-readbacks.json").write_text(json.dumps(results,sort_keys=True,indent=2)+"\n")
print("4 independently remeasured raw archives;",sum(len(row["criteria"]) for row in results),"case-specific judgments")
