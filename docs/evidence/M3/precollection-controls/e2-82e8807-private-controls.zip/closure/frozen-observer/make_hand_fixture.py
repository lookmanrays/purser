import hashlib,json,os,subprocess
from pathlib import Path
from queue_reference import START,TREE,ENV,measure
HERE=Path(__file__).resolve().parent;SOURCE=Path('/Users/lookman/.codex/worktrees/purser-delivery/review')
BASE='4460381e44f3dd42d22848bf6d82fea9a817a833';PATH='experiments/manifests/v1/'
raw=lambda name:subprocess.check_output(['git','-C',str(SOURCE),'show',BASE+':'+PATH+name])
m=json.loads(raw('manifest.json'))['fixture'];repo=HERE/'hand-git';repo.mkdir()
env={**ENV,'GIT_AUTHOR_NAME':'Purser fixture','GIT_AUTHOR_EMAIL':'fixture@example.invalid','GIT_COMMITTER_NAME':'Purser fixture','GIT_COMMITTER_EMAIL':'fixture@example.invalid','GIT_AUTHOR_DATE':m['git']['timestamp'],'GIT_COMMITTER_DATE':m['git']['timestamp']}
def g(*a,data=None):return subprocess.check_output(['git','-c','core.hooksPath=/dev/null','-C',str(repo),*a],env=env,input=data,stderr=subprocess.PIPE).decode().strip()
g('init','-q','--object-format=sha1')
for item in m['files']:
 path=repo/item['path'];path.parent.mkdir(parents=True,exist_ok=True);b=raw('input/'+item['path']);assert hashlib.sha256(b).hexdigest()==item['sha256'];path.write_bytes(b)
def commit(message):
    g('add','--all');g('commit','-q','--allow-empty','-F','-',data=(message.rstrip('\n')+'\n').encode());return g('rev-parse','HEAD')
ids={'start':commit(m['git']['commit_message'])};assert ids['start']==START and g('rev-parse','HEAD^{tree}')==TREE
def policy(file,expr):
 out=repo/'notify'/(file+'.py');old=raw('input/notify/'+file+'.py').decode();out.write_text(old.rsplit('    return ',1)[0]+'    return '+expr+'\n')
policy('preferences','channel not in disabled');ids['w1']=commit('Independent fixture enables preferences')
policy('delivery','tuple(dict.fromkeys(event_ids))');ids['w3']=commit('Independent fixture deduplicates deliveries')
policy('retry','tuple(k * base for k in range(attempts))');ids['linear']=commit('Independent fixture uses a linear retry')
policy('retry','tuple(0 if k == 0 else base * (2 ** (k - 1)) for k in range(attempts))');ids['revised']=commit('Independent fixture uses the revised retry')
policy('delivery','tuple(event_ids)');ids['broken_sibling']=commit('Independent fixture regresses delivery ordering')
policy('delivery','tuple(dict.fromkeys(event_ids))');policy('retry','tuple(-0.000001 if k == 0 else base * (2 ** (k - 1)) for k in range(attempts))');ids['early_microsecond']=commit('Independent negative microsecond boundary')
checks={}
for key in ('w1','w3','linear','revised','broken_sibling','early_microsecond'):
 for phase in ('linear','revised'):
    result=measure(repo,ids[key],2001,phase);checks[key+':'+phase]=result['criteria'];assert result['legacy']['count']==28
    if key=='early_microsecond' and phase=='revised':
        off=result['observations'][3]['observed']['batches'][0][0][2];assert off==-1
assert checks['w1:linear']['W1/preferences'] and checks['w3:linear']['W3/delivery']
assert all(checks['linear:linear'].values()) and not checks['linear:revised']['W2/retry']
assert all(checks['revised:revised'].values()) and not checks['revised:linear']['W2/retry']
assert checks['broken_sibling:revised']['W2/retry'] and not checks['broken_sibling:revised']['W3/delivery']
assert not checks['early_microsecond:revised']['W2/retry']
(HERE/'hand-git-proofs.json').write_text(json.dumps({'fixture_commit':START,'fixture_tree':TREE,'candidates':ids,'seed':2001,'observed':checks,'earliest_measured_microseconds':-1},sort_keys=True,indent=2)+'\n')
print(ids)
