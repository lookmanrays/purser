"""Frozen M2-compatible consumer for history and blind M3 query observations. An enrollment driver is bound later."""
import hashlib,json,os,sqlite3,subprocess,sys
from pathlib import Path
ENV={'PATH':'/usr/bin:/bin','TZ':'UTC','LC_ALL':'C'}
def run(repo,db,*argv):
    p=subprocess.run([sys.executable,'-B','-m','purser','--db',str(db),*argv],cwd=repo,env=ENV,capture_output=True,timeout=30)
    return {'argv':list(argv),'exit':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()}
def ok(out):
    if out['exit']:raise ValueError((out['argv'],out['exit'],out['stdout'],out['stderr']))
    return json.loads(out['stdout'])
def sample(repo,db,revision,asof,subjects):
    def read(*argv):return run(repo,db,*argv,'--revision',str(revision),'--as-of',asof)
    return {'status':read('status'),'why':{k:read('why',k) for k in subjects},'frontier':read('frontier')}
def copied_events(repo,original,destination):
    def rows(db):
        conn=sqlite3.connect(Path(db).resolve().as_uri()+'?mode=ro',uri=True)
        try:return list(conn.execute('select revision,body from events order by revision'))
        finally:conn.close()
    source=rows(original);ok(run(repo,destination,'init'))
    with sqlite3.connect(destination) as conn:conn.executemany('insert into events(revision,body) values (?,?)',source)
    art=Path(str(original)+'.artifacts');dest=Path(str(destination)+'.artifacts');dest.mkdir(exist_ok=True,mode=0o700)
    for obj in art.iterdir():
        b=obj.read_bytes();assert obj.name==hashlib.sha256(b).hexdigest();(dest/obj.name).write_bytes(b)
    asof=json.loads(source[-1][1])['at'];replayed=ok(run(repo,destination,'replay','--as-of',asof))
    assert ok(run(repo,destination,'status','--as-of',asof))==replayed
    assert rows(destination)==source
    return replayed
def compare(original,cold):
    assert ok(original['status'])==ok(cold['status']) and ok(original['frontier'])==ok(cold['frontier'])
    assert {k:ok(v) for k,v in original['why'].items()}=={k:ok(v) for k,v in cold['why'].items()}
