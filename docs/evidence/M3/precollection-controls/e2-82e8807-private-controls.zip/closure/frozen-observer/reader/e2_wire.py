"""Adapt E2 bytes to the independent M0 queue/reference, without importing a study reporter."""
import argparse, datetime, json, sys, tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from e2_bytes import Archive,Candidates,checked_freeze,PINNED,PRODUCT,M0,START,TREE,LABEL,ARMS,enc,sha,parse,same,need,ordered,git
from e2_public import History,Actions,WORK,OBS,PARENT,notice,ckid
import e2_reference as frozen
FIELDS=('intervention_reached','unaffected_both_retained','unaffected_reopened','affected_invalid_closure','rework_steps','final_pass')
def physical(raw,j,p,actions,pause):
    clk=['issued_monotonic_ns','finished_monotonic_ns']; start,end=p['start_monotonic_ns'],p['end_monotonic_ns']
    stopped=p['participant_exit']; t=j[-1]['payload']
    need(j[-1]['kind']=='terminal' and p['clock_stopped'] is True and stopped['end_monotonic_ns']==end==t['end_monotonic_ns']
         and stopped['reason']==t['end_reason']==raw['terminal']==p['budget_reason']
         and p['end_utc']==t['end_utc']==stopped['end_utc'],'unwitnessed terminal stop')
    need(p['cost_basis']==t['cost_basis']=='exact' and p['failure'] is None and t['missing'] is None,'exact participant exit')
    parseutc=datetime.datetime.fromisoformat
    need(type(start) is int and end>=start and parseutc(p['start_utc'])<=parseutc(p['end_utc']),'start/end clock')
    spans=[];attempt_ids=set()
    for e in j:
        if e['kind'] not in ('action','fault'):continue
        a=e['payload']; l,r=[a[k] for k in clk];need(start<=l<=r<=end,'work outside physical interval');spans.append((l,r))
        need(a['attempt'] not in attempt_ids,'duplicate physical invocation');attempt_ids.add(a['attempt'])
        if a.get('delivery',{}).get('state')=='received':need(l<=a['delivery']['observed_monotonic_ns']<=r,'delivery time outside physical action')
    elapsed=end-start
    if pause:
        l,r=pause['start_monotonic_ns'],pause['end_monotonic_ns']
        need(start<=l<=r<=end and parseutc(pause['start_utc'])<=parseutc(pause['end_utc']),'checkpoint window')
        overlaps=[max(l,a) for a,b in spans if a<r and b>l]
        cut=min(overlaps) if overlaps else r
        need(pause.get('first_public_activity_ns')==(cut if overlaps else None),'pause/activity conflict')
        elapsed-=cut-l
    need(0<=elapsed and len(actions.res)<=96,'registered step bound')
    need(all(raw['cost'][k]==0 and type(raw['cost'][k]) is int for k in ('model_calls','input_tokens','output_tokens','spend_usd_micros')),'scripted costs')
    need(raw['cost']['steps']==len(actions.res) and raw['cost']['elapsed_ns']==elapsed,'observed exact accounting')
    need(elapsed>=60000000000 if raw['terminal']=='time_limit' else 0<=elapsed<=60000000000,'scripted time bound')
    if raw['terminal']=='step_limit':need(len(actions.res)==96,'scripted step terminal')
    return dict(steps=len(actions.res),elapsed_ns=elapsed,wall_ns=end-start,offline_ns=end-start-elapsed)
def one(raw,arc,packs,track,seed,rank,arm,*,compare_issued=True):
    refs=raw['artifacts'];need(refs.get('model') is None,'scripted model artifact')
    j=arc.item(refs['journal']);p=arc.item(refs['platform']); entries=arc.item(refs['candidates'])
    need([x['seq'] for x in j]==list(range(1,len(j)+1)) and all(a['offset_ns']<=b['offset_ns'] for a,b in zip(j,j[1:])),'journal sequence')
    original=arc.item(p['treatment_trace']);h=History(arm,original,arc,seed);first,final=h.boundary(p)
    cands=packs.restore(entries,arc)
    proof={(oid,phase):packs.truth(oid,seed,phase)['criteria'] for oid in cands for phase in ('linear','revised')}
    expected={(o,k,v) for o in cands for v,labels in [(1,LABEL),(2,['W2/retry','queue/composition'])] for k in labels}
    measured={}
    for e in j:
        if e['kind']!='oracle':continue
        u=e['payload'];key=u['candidate'],u['criterion'],u['version']
        need(key not in measured and key in expected,'duplicate or wrong protected identity')
        r=arc.item(u['evidence']);verdict=packs.report(r,u,seed)
        need(u['expected']=='all specified cases pass' and u['observed']==u['verdict']==verdict,'retained protected verdict')
        measured[key]=u['evidence']['sha256']
    if raw['validity']=='complete':need(set(measured)==expected,'missing protected output on complete row')
    replay_counts={'candidates':len(cands),'git_root':START,'protected_reports':len(measured),'original_publications':len(h.pubs),'original_events':h.events}
    union_refs=set()
    for r in arc.refs([original,p,j,entries]):
        n=r['path'];union_refs.add(n)
        if n in arc.names:arc.blob(r)

    act=Actions(h)
    for e in j:
        if e['kind']=='action':act.one(e)
        elif e['kind']=='public_state':
            u=e['payload'];pos=h.lookup(u['checkpoint']);w=u['subject']; oid=u['candidate']
            need(pos['states'][w]==(u['to'],oid),'journal transition disagrees with its original published state')
    notices=[i for i in range(first,final+1) if h.received_at(i)]
    faults=[e for e in j if e['kind']=='fault']
    need(len(notices)==len(faults) and len(notices)<=1,'unreported/duplicate actual or journal exposure')
    pause=p.get('checkpoint_measurement')
    post=[];basis=None;immediate={};release=None; worked=None; notice_idx=None; seq=None; boundary_oid=None
    stale_at_receipt=None; later_bad=[]; extra_bad_parent=[]; closures=[]; original_changes=[]; swapped_sibling_candidates=[]
    for i in range(first,final+1):
        law,premise=h.law(h.pubs[i])
        if track=='clean' or not notices or i<notices[0]:
            need(law=='linear' and premise is None,'prior unreleased or clean premise changed')
    for n,w,packet in act.packets:
        if w!='W2':continue
        if arm=='purser':
            choices=[d['choice'] for d in packet['decisions']]
            need(len(choices)==1,'physical W2 packet decision ambiguity')
            selected=choices[0]
        else:selected=packet['retry_choice']
        action=next(x for x in j if x['kind']=='action' and x['payload']['attempt']==n)
        if not notices or action['seq']<faults[0]['seq']:need(selected=='linear','early changed instruction physically delivered')
    if track=='clean':
        need(not notices and pause is None,'clean control contaminated')
    elif notices:
        notice_idx=notices[0]; f=faults[0];u=f['payload'];seq=f['seq'];after=h.pubs[notice_idx];pre=h.pubs[notice_idx-1]
        au=h.lookup(u['after']);be=h.lookup(u['before'])
        need(be is pre and au is after and h.lookup(u['required_before']) is pre,'wrong receipt predecessor')
        need(u['released']==notice(seed) and u['released_sha256']==sha(enc(notice(seed))) and u['subject']=='W2' and u['trigger']==track
             and u['observation_id']==OBS and u['actor']=='fixture_observer','registered exposure payload')
        if arm=='purser':
            rc,op=h.proposal(u['proposal'],u['return'],u['after']);need(rc['disposition']=='admitted' and op['op']=='assumption.observe' and op['id']==OBS,'actual observer admission')
        else:need(au['stamp']==OBS,'original notice version')
        ck=h.lookup(pause['checkpoint']);worked=pre['states']['W2'][1];bidx=notice_idx-1
        matches=[n for n,ix,w,oid in act.submitted if ix<=bidx and w=='W2' and oid==worked]
        need(ck is pre and u['candidate']==worked==pause['candidate'] and matches and pause['submission_attempt'] in matches,'worked public submission at the qualified head')
        for n,ix,w,oid in act.submitted:
            if n==pause['submission_attempt']:need(h.law(h.pubs[ix])==('linear',None),'old task at actual submission')
        if arm=='purser':
            pr=arc.item(pause['submission_source']);nh=pre['key'][0]
            need(pr['original_events']==original['original_events'][:nh] and same(pr['snapshot'],pre['snapshot']),'private before-notice source differs from participant prefix')
        else:
            pr=arc.item(pause['submission_source'])
            need(pr['plan']==pre['rows'] and pr['plan_versions']==original['plan_versions'][:bidx+1],'private checkpoint source differs from original plan prefix')
        required={(worked,'W2/retry'),(worked,'W1/preferences'),(worked,'W3/delivery')}
        for w,label,path in [('W1','W1/preferences','notify/preferences.py'),('W3','W3/delivery','notify/delivery.py')]:
            before_oid=pre['states'][w][1];required.add((before_oid,label))
            need(packs.tree(before_oid)[path]==packs.tree(worked)[path],'sibling repaired by swapping its policy blob')
        retained={(a['candidate'],a['criterion']):a['evidence']['sha256'] for a in pause['checks']}
        need(len(retained)==len(pause['checks']) and set(retained)==required,'private checkpoint measurements cover actual public candidates')
        for (oid,l),dig in retained.items():need(measured.get((oid,l,1))==dig and proof[oid,'linear'][l],'old requirement not independently qualified')
        need(pause['preceding_actions']==len([a for s,a in act.res if s<seq]) and pause['preceding_events']==seq-1,'checkpoint physical ordering')
        basis=dict(states=pre['states'],worked_w2_candidate=worked);immediate=after['states']
        release=dict(assumption='A1',rule='exponential',observation=OBS)
        last=immediate
        stale_at_receipt=immediate['W2'][0] in frozen.CLOSED and not proof[immediate['W2'][1],'revised']['W2/retry']
        for pp in h.pubs[notice_idx+1:]:
            new=pp['states'];law,_=h.law(pp)
            for w in sorted(WORK):
                if new[w]==last[w]:continue
                oid=new[w][1]; ev=dict(kind='public_state',work=w,**{'from':last[w]},to=new[w][0],candidate=oid,criterion_version=2 if law=='exponential' else 1 if law=='linear' else None)
                post.append(ev);original_changes.append([pp['key'],w,list(last[w]),list(new[w])])
                if w in ('W1','W3') and last[w][0] in frozen.CLOSED and new[w][0] in frozen.CLOSED:
                    label='W1/preferences' if w=='W1' else 'W3/delivery'
                    swapped_sibling_candidates.append([w,last[w][1],oid,proof[oid,'linear'][label],pp['key']])
                if w in ('W2',PARENT) and new[w][0] in frozen.CLOSED and (last[w][0] not in frozen.CLOSED or last[w][1]!=oid):
                    passed=proof[oid,'revised']['W2/retry'];closures.append([w,oid,passed])
                    if not passed:(later_bad if w=='W2' else extra_bad_parent).append(oid)
            last=new
        post.extend(a for s,a in act.res if s>seq)
    utc=p.get('participant_exit');ex=p.get('exit_candidate',{});terminal=None
    if utc and ex.get('source')=='after_participant_exit' and ex.get('dirty') is False and ex.get('status_hex')=='' and ex.get('head') in cands:
        terminal=ex['head']
    if raw['terminal']=='done':
        need(terminal is not None and h.pubs[final]['states'][PARENT] in (('closed',terminal),('done',terminal)),'observed completed parent and exiting clean Git candidate')
    valid_clock=physical(raw,j,p,act,pause)
    normalized=dict(track=track,checkpoint=basis,public_release=release,immediate_after_release=immediate,post_release=post,
                    terminal_candidate=terminal,history_complete=bool(utc),action_history_complete=bool(utc))
    grade,supp=frozen.assess(normalized,proof);grade.pop('population')
    raw_score=raw.get('score')
    if raw_score is not None:
        if compare_issued:need(same(raw_score,grade),f'issued vs independent grade {raw_score} {grade}')
    elif track!='clean' and raw['validity']=='complete':raise ValueError('completed changed row lacks available issuing score')
    if track=='clean':need(raw_score is None,'clean cohort raw score shape')
    missing=sorted(union_refs-set(arc.names)-set(h.resolved));need(not missing,'unavailable original object refs '+str(missing))
    return dict(**replay_counts,original_objects=len(union_refs),derived_views=sorted(h.resolved),grade=grade,detail=supp,closing_observations=closures,
                stale_at_delivery=stale_at_receipt,new_bad_W2_closures=later_bad,bad_parent_closures=extra_bad_parent,checkpoint_oid=worked,
                final_oid=terminal,original_transitions=original_changes,charged_work=[a['invocation'] for a in post if a['kind']=='action'],
                swapped_closed_sibling_candidates=swapped_sibling_candidates,actual_context_deliveries=len(act.packets),public_verifier_probes={'/'.join(k):v for k,v in act.public_probes.items()},cost=valid_clock,terminal=raw['terminal'],validity=raw['validity'],clean_exposure=track=='clean')
def bounded(raw,arc,packs):
    """Keep separately identified measurements when a damaged record needs human adjudication."""
    seed,arm=raw.get('seed'),raw.get('arm');out={'unavailability':[]}; refs=raw.get('artifacts',{})
    def try_get(name,r):
        try:return arc.item(r)
        except (KeyError,ValueError,TypeError) as e:out['unavailability'].append([name,str(e)]);return None
    j=try_get('journal',refs.get('journal')) or [];p=try_get('platform',refs.get('platform')) or {}
    candidates=try_get('candidate manifest',refs.get('candidates')) or {}; verified={}
    for oid,v in candidates.items():
        try:
            if oid not in packs.restore({oid:v},arc,full=False):continue
            verified[oid]=True
        except Exception as e:out['unavailability'].append(['candidate '+oid,str(e)])
    facts={}
    for e in j:
        if e.get('kind')!='oracle':continue
        try:
            u=e['payload'];oid,v,k=u['candidate'],u['version'],u['criterion'];need(oid in verified,'unverified OID')
            report=arc.item(u['evidence']);grade=packs.report(report,u,seed)
            need(u['verdict']==u['observed']==grade,'retained criterion disagreement');facts[f'{oid}/{v}/{k}']=grade
        except Exception as err:out['unavailability'].append(['criterion',str(err)])
    out['individually_retained_measured_criteria']=facts
    end=p.get('exit_candidate') or {};oid=end.get('head')
    if oid in verified and end.get('dirty') is False and end.get('status_hex')=='':
        phase='linear' if raw.get('track')=='clean' else 'revised'
        out['independent_remeasurement_on_readback_only']={'candidate':oid,'phase':phase,'criteria':packs.truth(oid,seed,phase)['criteria'],'source':end.get('source')}
    try:
        h=History(arm,arc.item(p['treatment_trace']),arc,seed)
        first,_=h.boundary(p);actual=[i for i in range(first,len(h.pubs)) if h.received_at(i)];out['original_publications']=len(h.pubs);out['received_publications']=[h.pubs[i]['key'] for i in actual]
        if actual:
            i=actual[0];last=h.pubs[i-1]['states'];reopened=[];wrong=[]
            for pub in h.pubs[i:]:
                new=pub['states']
                for w in ('W1','W3'):
                    if last[w][0] in frozen.CLOSED and new[w][0] not in frozen.CLOSED:reopened.append([w,pub['key']])
                for w in ('W2',PARENT):
                    if new[w][0] in frozen.CLOSED and (pub is h.pubs[i] or new[w]!=last[w]):
                        key=f'{new[w][1]}/2/W2/retry'
                        if facts.get(key)=='fail':wrong.append([w,new[w][1],pub['key']])
                last=new
            out['witnessed_sibling_reopens']=reopened;out['witnessed_bad_closures']=wrong
    except Exception as e:out['unavailability'].append(['public original',str(e)])
    out['journal_work_requests_observed']=len({(e.get('payload') or {}).get('attempt') for e in j if e.get('kind')=='action'})
    out['physical_exit_receipt']=p.get('participant_exit');out['recorded_terminal']=raw.get('terminal')
    return out
def inputs(f,a):
    return {**{k:f[k] for k in ('fixture_tree','fixture_commit','manifest_sha256','protocol_sha256','raw_schema_sha256','scorer_sha256','fault_driver_sha256','executor_sha256')},
            'treatment_sha256':f['treatments'][a],'worktree_head':f['source_commit']}
def shown(v):
    return '?' if v is None else ('yes' if v else 'no') if type(v) is bool else str(v)
def fmtelapsed(x):return f'{x/10**9:.3f}'
def verdict(v):return 'inconclusive' if v is None else 'met' if v else 'not met'
def report_tables(txt):
    heading='top';tables={}
    for line in txt.splitlines():
        if line.startswith('## '):heading=line[3:]
        if line.startswith('|'):
            row=[c.strip() for c in line.strip().strip('|').split('|')]
            tables.setdefault(heading,[]).append(row)
    return {k:{r[0]:r[1:] for r in rows[2:]} for k,rows in tables.items()}
def reports(txt,rows,registered):
    t=report_tables(txt); checks=0
    def verify(group,key,expected):
        nonlocal checks
        observed=t.get(group,{}).get(str(key));need(same(expected,observed),f'report {group}, {key}: {observed} versus {expected}');checks+=len(expected)
    for (track,seed,a),v in rows.items():
        g,c=v['grade'],v['cost'];steps=str(c['steps']);elapsed=fmtelapsed(c['elapsed_ns'])
        if track=='primary':
            verify('Primary coverage · '+a,seed,[v['validity']+' / '+v['terminal'],*[shown(g[k]) for k in FIELDS],steps,elapsed])
        if track=='clean':
            verify('Clean control · A1 retained',a,[v['terminal'],shown(v['clean_exposure']),shown(g['final_pass']),steps,elapsed])
        if track=='closed-affected':
            verify('Already-closed affected stress control',a,[v['terminal'],v['checkpoint_oid'],shown(g['unaffected_both_retained']),
                shown(v['stale_at_delivery']),shown(bool(v['new_bad_W2_closures'])),shown(g['rework_steps']),shown(g['final_pass']),steps,elapsed])
    summary={}
    for s in range(2001,2021):
        keys=[('primary',s,a) for a in ('purser','loop','loop_equal_verifier')]
        if not all(k in rows for k in keys):continue
        p,b,e=[rows[k] for k in keys];ds=[]
        for other in [b,e]:
            d=[f"{p['grade'][k]-other['grade'][k]:+d}" for k in ('unaffected_both_retained','affected_invalid_closure','rework_steps','final_pass')]
            d.extend([f"{p['cost']['steps']-other['cost']['steps']:+d}",f"{(p['cost']['elapsed_ns']-other['cost']['elapsed_ns'])/1e9:+.3f} s"]);ds.append(' / '.join(d))
        verify('Paired primary results',s,ds)
    if registered:
        for a in ARMS:
            ar=[rows['primary',s,a] for s in range(2001,2021)]
            metrics=[[q['grade'][k] for q in ar] for k in ('intervention_reached','unaffected_both_retained','affected_invalid_closure','rework_steps','final_pass')]+[[q['cost']['steps'] for q in ar]]
            vals=[f'{sum(v for v in vs if v is not None)}/{sum(v is not None for v in vs)}' for vs in metrics]
            ci=sum(v['validity']=='complete' for v in ar);inc=sum(v['validity']=='arm_incomplete' for v in ar)
            verify('top',a,[str(ci),str(inc),str(20-ci-inc),*vals])
        for b in ('loop','loop_equal_verifier'):
            primary=lambda a:{i:rows['primary',i,a]['grade'] for i in range(2001,2021)}
            x=frozen.comparisons(primary('purser'),primary(b));summary[b]=x
            ratio='undefined (zero denominator)' if x['baseline_rework']==0 else 'inconclusive' if x['ratio'] is None else f"{x['ratio']:.3f}"
            verify('Frozen thresholds',b,[*[verdict(x[k]) for k in ('retention_threshold','half_rework','final_at_least','absolute','original_no_advantage')],ratio])
        p,q=[rows['clean',2001,a] for a in ('purser','loop')]
        flag=(p['cost']['steps']>2*q['cost']['steps'] if all(v['terminal']=='done' and v['grade']['final_pass'] is True and v['clean_exposure'] is True for v in (p,q)) else None)
        need(f'The twice-baseline clean overhead flag is **{shown(flag)}**.' in txt,'clean overhead');summary['clean_overhead']=flag;checks+=1
    return {'matched_report_cells':checks,'predicates':summary}
def run(args):
    src_repo=Path(args.source_repo).resolve();sys.path.insert(0,str(src_repo))
    # The only imported candidate code is at the accepted kernel/driver interface. Rebuild participant Q02 at each original head.
    need(git(src_repo,'rev-parse','HEAD:purser').decode().strip()==PRODUCT,'local product runtime bytes')
    need(not git(src_repo,'status','--porcelain','--','purser'),'dirty local product runtime')
    src=args.source; rawpath=Path(args.archive);b=rawpath.read_bytes();rawsha=sha(b)
    if args.raw_sha:need(rawsha==args.raw_sha,'whole archive digest')
    arc=Archive(rawpath);fb=arc.z.read('freeze.json');f=checked_freeze(fb,src,src_repo)
    if args.freeze_sha:need(sha(fb)==args.freeze_sha,'detached freeze digest')
    if args.freeze_file:need(Path(args.freeze_file).read_bytes()==fb,'standalone freeze bytes')
    if args.registered:
        need(f['replicate']==1 and all([args.freeze_sha,args.raw_sha,args.result_commit,args.freeze_commit,args.published_dir,args.report,args.report_sha]),'official mode requires separate immutable registration, raw and report pointers')
        root=args.published_dir.strip('/');rc=args.result_commit;fc=args.freeze_commit
        need(fc!=rc and git(src_repo,'merge-base','--is-ancestor',fc,rc)==b'' and git(src_repo,'merge-base','--is-ancestor',src,fc)==b'','freeze ordering')
        need(git(src_repo,'show',fc+':'+root+'/freeze.json')==fb and git(src_repo,'show',rc+':'+root+'/freeze.json')==fb,'freeze before and after source')
        earlier=git(src_repo,'ls-tree','-r','--name-only',fc,'--',root).decode().splitlines()
        need(root+'/raw.zip' not in earlier and root+'/report.md' not in earlier,'results already existed at registration')
        need(git(src_repo,'show',rc+':'+root+'/raw.zip')==b,'published result archive')
        rp=Path(args.report).read_bytes();need(sha(rp)==args.report_sha and git(src_repo,'show',rc+':'+root+'/report.md')==rp,'published report bytes')
    else:need(f['replicate']>1 and f['replication_reason'],'private examples must carry private replicate and reason')
    units=ordered();paths={f'{t}/{s}/{a}.json':(t,s,n,a) for t,s,n,a in units}
    starts=[n[8:] for n in arc.names if n.startswith('started/')];runs=[n[5:] for n in arc.names if n.startswith('runs/')]
    need(set(starts)==set(runs) and starts==[s for s in paths if s in starts] and runs==starts,'start/run identities or order')
    if args.registered:need(starts==list(paths),'all 66 original starts and results required')
    rows={};disputed={}
    with tempfile.TemporaryDirectory() as tmp:
        pk=Candidates(tmp)
        for suf in starts:
            t,s,n,a=paths[suf];raw=parse(arc.z.read('runs/'+suf));mark=parse(arc.z.read('started/'+suf))
            need(same(mark,dict(arm=a,seed=s,rank=n,track=t)),'marker identity')
            need(same([raw[k] for k in ('experiment','suite','mode','track','seed','arm','replicate','schema_version')],['E2','purser-notify-v1','scripted',t,s,a,f['replicate'],1])
                 and same(raw['inputs'],inputs(f,a)),'raw identity or run inputs')
            try:rows[t,s,a]=one(raw,arc,pk,t,s,n,a)
            except Exception as e:disputed[t,s,a]={'reason':str(e),'retained':bounded(raw,arc,pk)}
        equal_probe_pairs=0
        for track,seed,rank,arm in units:
            if arm!='purser' or (track,seed,arm) not in rows or (track,seed,'loop_equal_verifier') not in rows:continue
            left=rows[track,seed,arm]['public_verifier_probes'];right=rows[track,seed,'loop_equal_verifier']['public_verifier_probes']
            for shared in set(left)&set(right):
                need(left[shared]==right[shared],'equipped arms received unequal fixed public measurements on exactly the same object')
                equal_probe_pairs+=1
        output={'equal_public_probe_pairs':equal_probe_pairs,'source':src,'product_tree':PRODUCT,'m0':M0,'registered':args.registered,'replicate':f['replicate'],'raw_sha256':rawsha,'freeze_sha256':sha(fb),'n_started':len(starts),
                'strict_complete_rows':len(rows),'rows':{'/'.join(map(str,k)):v for k,v in rows.items()},'disputed':{'/'.join(map(str,k)):v for k,v in disputed.items()},
                'distinct_packs_checked':len(pk.seen),'independent_candidate_seed_phases':pk.counts}
        if args.report:output['report_comparison']=reports(Path(args.report).read_text(),rows,args.registered and not disputed)
    Path(args.out).write_bytes(enc(output)+b'\n')
    print('rows',len(rows),'disputed',[(k,v['reason']) for k,v in disputed.items()],'digest',sha(Path(args.out).read_bytes()),flush=True)
    if disputed:raise SystemExit(2)
if __name__=='__main__':
    p=argparse.ArgumentParser()
    for k in ('source','source-repo','archive','out'):p.add_argument('--'+k,required=True)
    for k in ('report','report-sha','raw-sha','freeze-sha','freeze-file','freeze-commit','result-commit','published-dir'):p.add_argument('--'+k)
    p.add_argument('--registered',action='store_true');run(p.parse_args())
