"""Recover participant publications and charged work using original bytes and bounded receipts."""
from e2_bytes import enc,sha,same,parse,need
from e2_reference import WORK,REWORK
PARENT='W-notify'
OBS='Obs-A1-changed'
def notice(seed):
    return dict(id=OBS,seed=seed,assumption='A1',finding='contradicts',criterion='W2/retry',retry_schedule='exponential',
                statement='Use zero, then base times two to the power k minus one at attempt index k.')
def states(rows):
    result={}
    for k,r in rows.items():
        work=r['work'];oid=r['candidate']
        need((work if isinstance(work,str) else work['id'])==k,'participant row names a different work item')
        if isinstance(oid,dict):
            need(oid['kind']=='git.commit' and oid['algorithm']=='sha1','candidate type');oid=oid['digest']
        result[k]=(r['state'],oid)
    return result
def ckid(c):
    return ('plan',c['plan_sha256']) if 'plan_sha256' in c else (c['revision'],c['head_hash'])
class History:
    def __init__(self,arm,trace,arc,seed):
        self.arm,self.arc,self.seed=arm,arc,seed;self.pubs=[];self.index={};self.receipts={};self.resolved={}
        self.events=0;self.rows=0
        if arm=='purser':self.kernel(trace)
        else:self.plan(trace)
    def add(self,key,rows,**rest):
        need(key not in self.index,'duplicate original publication')
        self.index[key]=len(self.pubs);self.pubs.append(dict(key=key,rows=rows,states=states(rows),**rest))
    def plan(self,t):
        prev=None
        for i,r in enumerate(t['plan_versions'],1):
            b=self.arc.blob(r);j=parse(b);need(b==enc(j) and set(j)==WORK,'canonical plan publication')
            s=j[PARENT]['_e2_plan_version'];need((s['number'],s['previous'])==(i,prev),'disconnected original plan publication')
            prev=sha(b);self.add(('plan',prev),j,stamp=s['attempt'],events=(),snapshot=None,records={})
        need(same(j,t['plan']),'original plan head')
    def kernel(self,t):
        from purser.kernel.projector import apply_event,empty_projection
        from purser.kernel.workview import WorkView
        current=empty_projection(); last='0'*64; batch=[]
        for i,line in enumerate(t['original_events'],1):
            e=parse(line);h=e['hash'];k=e['type']
            need(enc(e)==line.encode() and e['revision']==i and e['prev_hash']==last and e['v']==1,'original kernel event bytes')
            need(sha(b'purser/event/v1\0'+enc({k:v for k,v in e.items() if k!='hash'}))==h,'event hash')
            if not batch: begin=i;length=e['batch_size']
            need(e['batch_start']==begin and e['batch_size']==length and i<begin+length,'kernel atomic batch shape')
            if batch:need((e['actor_id'],e['proposal_id'])==(batch[0]['actor_id'],batch[0]['proposal_id']),'mixed proposal')
            last=h;batch.append(e)
            if i!=begin+length-1:continue
            need(k=='ProposalReceipted','no terminal proposal receipt')
            for ent in batch: current=apply_event(current,ent['type'],ent['data'],ent['revision'],i,event_version=ent['event_version'])
            snap=dict(revision=i,head_hash=h,projection=current);rows={r['work']:r for r in WorkView(current).answers()['q02'] if r['work'] in WORK}
            receipt=dict(e['data'],revision=i);need((receipt['actor_id'],receipt['proposal_id'])==(e['actor_id'],e['proposal_id']),'receipt identity')
            rkey=(receipt['actor_id'],receipt['proposal_id'],receipt['digest']);need(rkey not in self.receipts,'duplicate proposal publication')
            self.receipts[rkey]=receipt
            if set(rows)==WORK:
                self.add((i,h),rows,events=[x for x in batch[:-1]],receipt=receipt,snapshot=snap,records={r['id']:r['fields'] for r in current['records']},stamp=None)
            batch=[]
        need(not batch and same(snap,t['snapshot']),'incomplete original log or stale final projection');self.events=i
        for dig,ref in t['kernel_artifacts'].items():need(sha(self.arc.blob(ref))==dig,'kernel witness bytes')
        self.witness=t['kernel_artifacts']
    def lookup(self,ck):
        p=self.pubs[self.index[ckid(ck)]];r=ck['view'];data=enc(p['rows']);h=sha(data)
        need(r=={'bytes':len(data),'sha256':h,'path':'objects/'+h+'.json'},'public checkpoint conflicts with original bytes')
        if r['path'] in self.arc.names:need(self.arc.blob(r)==data,'separately retained public view')
        else:self.resolved[r['path']]=h
        return p
    def law(self,p):
        if self.arm!='purser':
            w=p['rows']['W2'];return (w.get('retry_choice'),w.get('premise'))
        from purser.kernel.workview import WorkView
        d=WorkView(p['snapshot']['projection']).graph.decisions('W2')
        live=[(r['id'],r['choice']) for r in d]
        found=p['records'].get(OBS)
        return (live[0][1] if len(live)==1 else None, found)
    def packet(self,p,work):
        if self.arm!='purser':return {k:v for k,v in p['rows'][work].items() if k not in ('_e2_plan_version','_publication')}
        from purser.driver import context_pack
        return context_pack(p['snapshot'],p['records'][work]['assignment'])
    def proposal(self,req,reply,checkpoint):
        a,b=req['actor_id'],req['body'];pid=b['proposal_id']
        dig=sha(b'purser/proposal/v1\0'+enc({'actor_id':a,'proposal':b}))
        need(req['digest']==dig and req['proposal_id']==pid and b['commitment']=='C-notify','proposal digest or scope')
        record=self.receipts[a,pid,dig];ret=reply.get('receipt',reply.get('response',reply))
        need(all(ret.get(k)==v for k,v in record.items()),'retained reply and original receipt differ')
        pos=self.index[ckid(checkpoint)];need(record['revision']<=self.pubs[pos]['key'][0],'action return precedes publication')
        return record,b['ops'][0]
    def received_at(self,i):
        p=self.pubs[i]
        if self.arm=='purser':
            obs=[e for e in p['events'] if e['type']=='PremiseObserved' and e['data'].get('id')==OBS]
            if not obs:return False
            need(len(obs)==1 and obs[0]['actor_id']=='observer:queue','observer authority')
            f=obs[0]['data'];r=self.witness[f['artifact_sha256']]
            need(f['assumption']=='A1' and f['finding']=='contradicts' and f['commitment']=='C-notify'
                 and self.arc.item(r)==notice(self.seed) and p['receipt']['disposition']=='admitted','original notice witness')
            return True
        old=self.pubs[i-1]['rows']['W2'].get('premise') if i else None;new=p['rows']['W2'].get('premise')
        if new==old:return False
        need(new==notice(self.seed) and p['stamp']==OBS,'actual delivered plan premise')
        return True
    def boundary(self,public):
        initial=self.lookup(public['initial_public']);final=self.lookup(public['final_public']);first=self.index[initial['key']]
        want=('assigned',None) if self.arm=='purser' else ('open',None)
        need(initial['states']==dict.fromkeys(WORK,want) and self.law(initial)==('linear',None),'clean old initial task')
        need(final is self.pubs[-1],'final publication misses participant history')
        return first,len(self.pubs)-1
class Actions:
    WRITES={'assign_again':'work.assign','submit':'result.submit','opening':'run.open','observe':'observation.record','verify':'evidence.record','decide':'work.close','revise':'decision.record'}
    EXPECT={'assign_again':('plan','planner'),'submit':('submit','executor'),'opening':('plan','planner'),'observe':('observe','independent_observer'),
            'verify':('decide','independent_verifier'),'decide':('decide','closure'),'revise':('plan','planner'),
            'context':('context','executor'),'inspect':('context',None),'edit':('edit','executor'),'worker_check':('check','executor'),
            'review':('check','plan_reviewer'),'schedule':('plan','planner')}
    def __init__(self,h):self.h=h;self.res=[];self.submitted=[];self.packets=[];self.public_probes={}
    def one(self,e):
        h=self.h;u=e['payload'];kind,actor,work,oid,inputs=(u[k] for k in ('action','actor','subject','candidate','input'))
        n=u['attempt'];original=u['work_request'];method=original['method'];ek,ea=self.EXPECT[method]
        need(u['action_id']==f'action-{n}' and u['arm']==h.arm and type(n) is int and n==len(self.res)+1,'charged request order')
        need(kind==ek and (actor==ea if ea else actor in ('executor','planner')) and work in WORK,'public work method, actor or subject')
        need(same(original,dict(action=kind,actor=actor,subject=work,candidate=oid,input=inputs,method=method)),'admitted operation operands')
        if 'work_started' in u:need(same(u['work_started'],original),'started work differs from admitted request')
        pre=h.lookup(u['before']);post=h.lookup(u['after'])
        if 'return' in u:
            expected={k:u[k] for k in ('attempt','actor','subject','candidate','return')}
            need(h.arc.item(u['response_evidence'])==expected,'returned transport frame')
        if 'port_method' in u:
            need(u['port_method']==method,'port method');h.lookup(u['port_before']);h.lookup(u['port_after'])
        fk=inputs.get('work')
        if fk:need(fk==work,'work operand')
        if 'open_run' in inputs or 'criterion' in inputs:
            label=inputs.get('criterion',inputs.get('open_run'));need((label.split('/')[0] if label[:2] in ('W1','W2','W3') else PARENT)==work,'criterion subject')
        if method=='schedule':need(work==PARENT and inputs['schedule']==['W1','W3','W2'],'cross-work schedule')
        if method=='assign_again':need(inputs['assign']==work,'assignment operand')
        if method=='submit':need(inputs['candidate']==oid,'submit operand')
        if method=='revise':need(work=='W2' and inputs['adopt']==OBS,'revision operand')
        if method=='edit' and 'return' in u:need(u['return'].get('edited')==work,'edit return subject')
        if method=='decide' and 'return' in u and 'claim' in u['return']:
            need(u['return']['claim']['work']['id']==work,'plan closure subject')
        if 'proposal' in u:
            rc,op=h.proposal(u['proposal'],u.get('port_return',u['return']),u['after'])
            need(op['op']==self.WRITES[method],'kernel operation')
            records=pre['records']
            if method=='submit':
                need(records[op['assignment']]['work']==work and op['candidate']['digest']==oid,'physical result submission')
                if rc['disposition']=='admitted':self.submitted.append((n,h.index[post['key']],work,oid))
            if method=='decide':need(op['id']==work,'kernel closure subject')
            if method in ('opening','observe','verify'):
                r=records[op['result'] if method=='opening' else op['run']]
                need(r['work']==work and r['candidate']['digest']==oid,'actual run subject or candidate')
        elif h.arm!='purser' and method=='submit' and pre['key']!=post['key']:
            need(post['stamp']==n and post['states'][work]==('submitted',oid),'published plan submission')
            self.submitted.append((n,h.index[post['key']],work,oid))
        if method=='observe' and 'return' in u and isinstance(u['return'],dict) and 'witness' in u['return']:
            need(h.arm!='loop','plain arm received an independent verifier')
            witness=u['return']['witness'];report=h.arc.item(witness);label=inputs['criterion']
            keys={'version','input','expected','observed','candidate','criterion'}
            if label in ('W2/retry','queue/composition'):
                keys.add('schedule');need(report.get('schedule')==inputs['schedule'],'public verifier received a different retry law')
            need(report['candidate']==oid and report['criterion']==label and set(report)==keys,'public observation fixed probe')
            need(same(report,u['port_input']['observation']),'public report differs at observer port')
            token=(oid,label,inputs['schedule']);existing=self.public_probes.get(token)
            need(existing is None or existing==witness['sha256'],'different public results for same probe')
            self.public_probes[token]=witness['sha256']
        if method=='context' and 'delivery' in u and u['delivery']['state']=='received':
            delivery=u['delivery'];p=h.lookup(u['context_source']);actual=h.arc.item(delivery['payload'])
            need(delivery['attempt']==n and delivery['subject']==work and delivery['sha256']==sha(enc(actual))
                 and same(h.packet(p,work),actual) and same(actual,h.arc.item(u['prepared_context'])),'actual delivered assignment bytes')
            self.packets.append((n,work,actual))
        self.res.append((e['seq'],dict(kind='action',action=kind,subject=work,invocation=u['action_id'])))
