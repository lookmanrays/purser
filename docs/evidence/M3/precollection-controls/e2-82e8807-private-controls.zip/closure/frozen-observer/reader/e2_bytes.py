"""Verify content addresses, standalone registration, Git ancestry and seeded evidence."""
import hashlib, json, re, subprocess, tempfile
from pathlib import Path
from zipfile import ZipFile
from queue_reference import START, TREE, LABEL, measure, files, git
from e2_reference import order

M0='4460381e44f3dd42d22848bf6d82fea9a817a833'
PRODUCT='c2d2e50c748324fc0b4fe697ccf490efc47c15f9'
PINNED={'manifest_sha256':('manifest.json','1c51ce44eb1887bc5cf08ee98afd7714faa7b23cf8f9b62c998c128f9ce54b73'),
        'protocol_sha256':('protocol.md','5722774bffd56969b97c1575b2776cd7b9b3536da99dc1b4e49976be4835b2eb'),
        'raw_schema_sha256':('raw.schema.json','7886a6f9c2027281d51dd72ee21e093a4d06a7c3479f07e0efe55d0e2465eb1b')}
ARMS=('loop','purser','loop_equal_verifier')
def need(ok,msg):
    if not ok: raise ValueError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return json.dumps(v,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode()
def pairs(p):
    result={}
    for k,v in p:
        need(k not in result,'duplicate JSON key '+k);result[k]=v
    return result
def parse(b):return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
def same(x,y):return enc(x)==enc(y)
def ordered():
    return [(t,s,s-2000,a) for t,ss in [('primary',range(2001,2021)),('clean',(2001,)),('closed-affected',(2001,))]
            for s in ss for a in order(s)]
def checked_freeze(b,src,repo):
    reference=Path(__file__).resolve().parent.parent
    witness=(reference/'frozen-m3-reference.json').read_bytes()
    need(sha(witness)=='a514c3505f0d6236148f475a029ac26305a13e8ef3d279a5dd7eeb9875a9ad04','preimplementation reference bytes')
    for name,pin in parse(witness)['files'].items():
        original=(reference/name).read_bytes()
        need(len(original)==pin['bytes'] and sha(original)==pin['sha256'],'preimplementation independent reference member '+name)
    f=parse(b);need(f['source_commit']==src and f['experiment']=='E2','joined source or experiment pin')
    need(git(repo,'rev-parse',src+':purser').decode().strip()==PRODUCT,'accepted component tree')
    for key,(name,expected) in PINNED.items():
        path='experiments/manifests/v1/'+name
        need(f[key]==expected==sha(git(repo,'show',M0+':'+path))==sha(git(repo,'show',src+':'+path)),key)
    need(git(repo,'rev-parse',M0+':experiments/manifests/v1')==git(repo,'rev-parse',src+':experiments/manifests/v1'),'complete M0 fixture tree')
    need(f['fixture_tree']==TREE and f['fixture_commit']==START,'starting fixture identity')
    need(same(f['schedule'],ordered()),'schedule or rotation')
    sources={p:sha(git(repo,'show',src+':'+p)) for p in git(repo,'ls-tree','-r','--name-only',src,'--','purser','experiments/e1','experiments/e2').decode().splitlines() if p.endswith('.py')}
    need(sources==f['source_files'],'source byte closure')
    digest=sha(enc(sources))
    def fn(k):return sha(enc({'entrypoint':k,'source_sha256':digest}))
    for key,name in [('scorer','report.derive_case'),('fault_driver','driver.Driver.receive'),('executor','driver.Driver.execute'),('controller','suite.collect_units')]:
        need(f[key+'_sha256']==fn('experiments.e2.'+name),key+' pin')
    need(f['treatments']=={a:fn('experiments.e2.trial.attempt/'+a) for a in ARMS},'treatment pins')
    return f
class Archive:
    def __init__(self,path):
        self.z=ZipFile(path); self.names=self.z.namelist()
        need(len(self.names)==len(set(self.names)),'duplicate ZIP member')
        for n in self.names:
            if n=='freeze.json' or n.startswith(('runs/','started/')): continue
            m=re.fullmatch(r'objects/([0-9a-f]{64})\.(json|bin|pack)',n)
            need(m and m[1]==sha(self.z.read(n)),f'invalid object {n}')
    def blob(self,r):
        need(isinstance(r,dict) and set(r)=={'path','sha256','bytes'},'object reference shape')
        n=r['path']; m=re.fullmatch(r'objects/([0-9a-f]{64})\.(json|bin|pack)',n)
        b=self.z.read(n);need(m and m[1]==r['sha256']==sha(b) and type(r['bytes']) is int and len(b)==r['bytes'],'object bytes or checksum '+n)
        return b
    def item(self,r):return parse(self.blob(r))
    def refs(self,v):
        if type(v) is dict:
            if set(v)=={'path','sha256','bytes'}:yield v
            else:
                for e in v.values():yield from self.refs(e)
        elif type(v) is list:
            for e in v:yield from self.refs(e)
class Candidates:
    def __init__(self,tmp):
        self.repo=Path(tmp)/'objects.git'; self.repo.mkdir();git(self.repo,'init','--bare','-q','--object-format=sha1')
        self.seen={};self.trees={};self.cache={};self.counts=0
    def restore(self,entries,archive,*,full=True):
        originals={}
        for oid,v in entries.items():
            need(re.fullmatch('[0-9a-f]{40}',oid) is not None,'candidate oid')
            data=archive.blob(v['pack']);key=(oid,sha(data))
            if key not in self.seen:
                # Isolate each novel pack to rule out borrowing a missing parent from another arm.
                with tempfile.TemporaryDirectory() as directory:
                    git(directory,'init','-q','--bare','--object-format=sha1');git(directory,'index-pack','--strict','--stdin',data=data)
                    marker=git(directory,'show','-s','--format=%T %P',oid).decode().strip().split()
                    need(len(marker) in (1,2) and git(directory,'merge-base','--is-ancestor',START,oid)==b'', 'fixture ancestry')
                    need(git(directory,'rev-parse',START+'^{tree}').decode().strip()==TREE,'fixture tree in pack')
                self.seen[key]=(marker[0],marker[1] if len(marker)==2 else None);git(self.repo,'index-pack','--stdin',data=data)
            tree,parent=self.seen[key];need(v['tree']==tree and v['parent']==parent and v['start']==START,'archived Git identities')
            originals[oid]=parent
        if full:need(START in originals and originals[START] is None and all(x is None or x in originals for x in originals.values()),'missing retained START/parent entry')
        return originals
    def truth(self,oid,seed,phase):
        k=(oid,seed,phase)
        if k not in self.cache:self.cache[k]=measure(self.repo,oid,seed,phase);self.counts+=1
        return self.cache[k]
    def tree(self,oid):
        if oid not in self.trees:self.trees[oid]=files(self.repo,oid)
        return self.trees[oid]
    def report(self,report,ev,seed):
        oid,label,v=ev['candidate'],ev['criterion'],ev['version'];need(type(v) is int and (v==1 and label in LABEL or v==2 and label in ('W2/retry','queue/composition')),'registered criterion')
        truth=self.truth(oid,seed,'linear' if v==1 else 'revised')
        expected='pass' if truth['criteria'][label] else 'fail'
        need((report['candidate'],report['criterion'],report['version'],report['verdict'])==(oid,label,v,expected),'independent criterion verdict')
        cs=report['cases']
        if label=='legacy/compat':
            old=truth['legacy']; need(len(cs)==1 and cs[0]['expected']=={'tests':28,'errors':[],'failures':[],'skipped':[]},'legacy reference')
            actual=cs[0]['observed'];need({k:(len(actual[w]) if w!='tests' else actual[w]) for k,w in [('count','tests'),('fails','failures'),('skips','skipped'),('errors','errors')]}==old,'legacy outcomes')
        elif label=='scope/paths':
            first,now=self.tree(START),self.tree(oid)
            found=cs[0]['all_changes'];need(len(cs)==1 and [r['path'] for r in found]==truth['changed'],'changed tree paths')
            for change in found:
                name=change['path'];left=first.get(name,('000000',None,None))[0];right=now.get(name,('000000',None,None))[0]
                need((change['old_mode'],change['new_mode'])==(left,right),'changed file modes')
            need(cs[0]['expected']==[] and bool(cs[0]['observed'])==(expected=='fail'),'scope outcome')
        else:
            def value(v):
                if 'count' in v:return {'enqueued':v['count'],'samples':v['batches'],'pending':v['pending']}
                return v
            mapped=[{'input':q['input'],'expected':value(q['expected']),'observed':value(q['observed'])} for q in truth['observations'] if q['criterion']==label]
            need(same(cs,mapped),'raw ordered queue inputs/observation differs '+label)
        return expected
