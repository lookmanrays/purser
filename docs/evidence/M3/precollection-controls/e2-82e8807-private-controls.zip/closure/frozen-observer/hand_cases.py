import copy,json
from pathlib import Path
from e2_reference import assess,comparisons,order
from queue_reference import inputs,offsets
here=Path(__file__).resolve().parent
observed=json.loads((here/'hand-git-proofs.json').read_bytes());ids=observed['candidates']
proof={(ids[key.split(':')[0]],key.split(':')[1]):v for key,v in observed['observed'].items()}
w1,w3,old,new,bad,early=[ids[k] for k in ('w1','w3','linear','revised','broken_sibling','early_microsecond')]
def transition(w,fr,to,version=None):return {'kind':'public_state','work':w,'from':fr,'to':to[0],'candidate':to[1],'criterion_version':version}
def action(n,name,work='W2',**extra):return dict(kind='action',invocation=str(n),action=name,subject=work,**extra)
base={'track':'primary','checkpoint':{'states':{'W1':['closed',w1],'W3':['closed',w3],'W2':['submitted',old],'W-notify':['open',None]},'worked_w2_candidate':old},'public_release':{'assumption':'A1','rule':'exponential','observation':'received-observation-1'},'history_complete':True,'action_history_complete':True,'post_release':[action(i,k) for i,k in enumerate(['plan','edit','check','submit','observe','decide'],1)]+[transition('W2',['submitted',old],['submitted',new]),transition('W2',['submitted',new],['closed',new],2)],'terminal_candidate':new}
results={}
def test(n,case,expect):
    scores,facts=assess(case,proof);got=tuple(scores[k] for k in ('intervention_reached','unaffected_both_retained','unaffected_reopened','affected_invalid_closure','rework_steps','final_pass'))
    assert got==expect,(n,got,expect)
    results[n]={'case':case,'hand_expected':list(expect),'details':facts}
def modified(**kwargs):v=copy.deepcopy(base);v.update(kwargs);return v
test('worked six-action example',base,(True,True,0,False,6,True))
e=[transition('W3',['closed',w3],['open',w3]),transition('W3',['open',w3],['closed',w3])];test('same-OID temporary W3 reopening',modified(post_release=e+base['post_release']),(True,False,1,False,6,True))
test('two distinct reopening events for one sibling',modified(post_release=e+e+base['post_release']),(True,False,2,False,6,True))
temp=[transition('W2',['submitted',old],['closed',old],1),transition('W2',['closed',old],['submitted',old])]
test('stale v1 pass and closure on original OID before good v2 repair',modified(post_release=temp+base['post_release']),(True,True,0,True,6,True))
test('revised evidence label on actually linear OID',modified(post_release=[transition('W2',['submitted',old],['done',old],2)],terminal_candidate=old),(True,True,0,True,0,False))
test('bad parent closure at revised criterion independently identifiable',modified(post_release=[transition('W-notify',['open',None],['done',old],2)]),(True,True,0,True,0,True))
test('revised retry passes but final composition and sibling fail',modified(post_release=[transition('W2',['submitted',old],['closed',bad],2)],terminal_candidate=bad),(True,True,0,False,0,False))
test('signed one-microsecond revised retry defect',modified(post_release=[transition('W2',['submitted',old],['done',early],2)],terminal_candidate=early),(True,True,0,True,0,False))
test('no published invalidation yields undefined rework and retention',modified(public_release=None),(False,None,None,None,None,None))
v=modified();v['checkpoint']['states']['W2']=['closed',old];test('wrong primary checkpoint W2 already closed',v,(False,None,None,None,None,None))
v=modified();v['checkpoint']['states']['W1']=['closed',ids['start']];test('W1 is publicly closed on failing unchanged bytes',v,(False,None,None,None,None,None))
v=modified();v['checkpoint']['states']['W2']=['submitted',new];v['checkpoint']['worked_w2_candidate']=new;test('W2 had revised bytes before claimed intervention',v,(False,None,None,None,None,None))
test('passive observations, transport duplicates and retries',modified(post_release=[{'kind':'control'},{'kind':'idle'},action(1,'context'),action(1,'context'),action(2,'check',disposition='failed'),action(3,'check'),action(4,'observe',passive_scorer=True),action(5,'plan','W-notify'),action(6,'check','unrelated')]),(True,True,0,False,4,True))
test('incomplete history retains known incorrect closure and reopening',modified(post_release=e+temp,history_complete=False,action_history_complete=False,terminal_candidate=None),(True,False,None,True,None,None))
test('missing protected candidate cannot become passing',modified(post_release=[transition('W2',['submitted',old],['done','unknown-oid'],2)],terminal_candidate='unknown-oid'),(True,True,0,None,0,None))
v=modified(track='closed-affected',post_release=[]);v['checkpoint']['states']['W2']=['closed',old];v['immediate_after_release']={'W2':['closed',old]};test('stress retains old already-closed item after release',v,(True,True,0,True,0,True))
v=modified(track='closed-affected',post_release=[]);v['checkpoint']['states']['W2']=['closed',old];v['immediate_after_release']={'W2':['open',old]};test('stress invalidation atomically reopens W2',v,(True,True,0,False,0,True))
v=modified(track='clean',public_release=None,post_release=[],terminal_candidate=old);test('clean remains linear and does not enter E2 denominator',v,(False,None,None,None,None,True))
test('closed versus done reread on the same sibling keeps continuity',modified(post_release=[transition('W3',['closed',w3],['done',w3])]+base['post_release']),(True,True,0,False,6,True))
thresholds={}
def cohort(k,steps,passes):return {2001+i:{'unaffected_both_retained':i<k,'rework_steps':steps[i] if isinstance(steps,list) else steps,'final_pass':i<passes} for i in range(20)}
def agg(n,p,b,want):
    vals=comparisons(p,b);got=tuple(vals[k] for k in ('absolute','original_no_advantage','ratio'));assert got==want,(n,got,want);thresholds[n]={'hand_expected':list(want),'observed':vals}
agg('boundary 18 and exactly half, equal qualifying passes',cohort(18,2,17),cohort(20,4,17),(True,False,0.5))
agg('fewer than 18, lower rework, equal pass',cohort(17,2,17),cohort(20,4,17),(False,False,0.5))
agg('equal positive rework',cohort(20,4,20),cohort(20,4,20),(False,True,1.0))
agg('zero matched baseline (both predicates true; ratio undefined)',cohort(20,0,20),cohort(20,0,20),(True,True,None))
agg('fewer final passes despite lower rework',cohort(20,2,16),cohort(20,4,17),(False,True,0.5))
agg('more than half but still lower; two predicates can both be false',cohort(20,3,20),cohort(20,4,20),(False,False,0.75))
p=cohort(20,2,20);p[2008].update(rework_steps=None);agg('unknown rework denominator',p,cohort(20,4,20),(None,None,None))
assert order(2001)==['purser','loop_equal_verifier','loop'] and order(2002)==['loop_equal_verifier','loop','purser']
assert all(len(inputs(n,ph))==11 for n in range(2001,2021) for ph in ('linear','revised'))
assert offsets('linear',4,2)==[0,2,4,6] and offsets('revised',4,2)==[0,2,4,8]
out={'description':'Private, preimplementation hand-scored controls. Source-admission and criterion bytes are independently measured on Git inputs. Values in hand_expected were specified before calling the scorer. For multiple reopenings retain both exact events and the count of distinct siblings. Preserve W2 and parent invalid-declaration identities separately.','fixture':observed['fixture_commit'],'unit_order':['intervention_reached','unaffected_both_retained','unaffected_reopened','affected_invalid_closure','rework_steps','final_pass'],'trials':results,'thresholds':thresholds}
(here/'hand-cases.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(len(results),'trace cases and',len(thresholds),'threshold cases')
