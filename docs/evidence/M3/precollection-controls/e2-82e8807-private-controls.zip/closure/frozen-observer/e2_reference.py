"""Protocol-level E2 oracle. Wire adapters supply authenticated public observations; proof is measured on Git bytes."""
ARMS=('loop','purser','loop_equal_verifier');CLOSED={'closed','done'}
WORK={'W1','W2','W3','W-notify'}
REWORK={'plan','context','edit','check','submit','observe','decide'}
def order(seed):
    j=seed-2001
    if j not in range(20):raise ValueError('registered E2 seed required')
    return [ARMS[(j+1+i)%3] for i in range(3)]
def measure_work(proofs,oid,phase,label):
    return proofs.get((oid,phase),{}).get(label)
def all_six(proofs,oid,phase):
    if oid is None:return None
    judgments=proofs.get((oid,phase),{})
    labels={'W1/preferences','W2/retry','W3/delivery','scope/paths','legacy/compat','queue/composition'}
    if any(judgments.get(k) is False for k in labels):return False
    return True if all(judgments.get(k) is True for k in labels) else None
def assess(case,proof):
    track=case['track'];assert track in ('primary','clean','closed-affected')
    phase='linear' if track=='clean' else 'revised';grade={'population':track,'intervention_reached':False,'unaffected_both_retained':None,'unaffected_reopened':None,'affected_invalid_closure':None,'rework_steps':None,'final_pass':None}
    supplemental={'reopened_siblings':[],'reopen_transitions':[],'invalid_affected_declarations':[],'invalid_parent_declarations':[],'observed_criterion_versions':[],'known_steps':0,'lower_bound':False,'bad_checkpoint':[],'available_final_phase':None}
    ctx=case.get('checkpoint');release=case.get('public_release')
    if track=='clean':
        if release is not None:raise ValueError('changed premise delivered in a clean control')
        grade['final_pass']=all_six(proof,case.get('terminal_candidate'),'linear')
        supplemental['available_final_phase']='linear'
        return grade,supplemental
    if ctx is None or not release or release.get('assumption')!='A1' or release.get('rule')!='exponential' or not release.get('observation'):
        supplemental['bad_checkpoint'].append('no observed qualifying public intervention');return grade,supplemental
    states={k:tuple(v) for k,v in ctx['states'].items()}
    for work,label in (('W1','W1/preferences'),('W3','W3/delivery')):
        st,oid=states.get(work,(None,None))
        if st not in CLOSED or measure_work(proof,oid,'linear',label) is not True:supplemental['bad_checkpoint'].append(work)
    state,public_candidate=states.get('W2',(None,None));worked=ctx.get('worked_w2_candidate')
    if (not state or track=='primary' and state in CLOSED or track=='closed-affected' and state not in CLOSED
        or worked is None or public_candidate is not None and worked!=public_candidate or measure_work(proof,worked,'linear','W2/retry') is not True):supplemental['bad_checkpoint'].append('W2')
    if supplemental['bad_checkpoint']:return grade,supplemental
    grade['intervention_reached']=True;reopen=[];invalid=[];unknown=False;actions=set()
    known_history=case.get('history_complete',False)
    def declare(work,oid,version):
        nonlocal unknown
        if work not in ('W2','W-notify'):return
        good=measure_work(proof,oid,'revised','W2/retry')
        if good is False:
            dest='invalid_affected_declarations' if work=='W2' else 'invalid_parent_declarations'
            supplemental[dest].append(oid);invalid.append((work,oid))
        if good is None:unknown=True
        supplemental['observed_criterion_versions'].append([work,oid,version,good])
    # A closed affected item under the new premise can already be visible in stress before another action.
    boundary=case.get('immediate_after_release',{})
    if track=='closed-affected' and 'W2' not in boundary:unknown=True
    for work,new in boundary.items():
        old=states[work];new=tuple(new)
        if work in ('W1','W3') and old[0] in CLOSED and new[0] not in CLOSED:reopen.append(work)
        if new[0] in CLOSED and work in ('W2','W-notify'):declare(work,new[1],None)
        states[work]=new
    for e in case['post_release']:
        if e['kind']=='public_state':
            work=e['work'];old=states[work];new=(e['to'],e['candidate'])
            if tuple(e['from'])!=old:raise ValueError(('discontinuous public record',work,e['from'],old))
            if work in ('W1','W3') and old[0] in CLOSED and new[0] not in CLOSED:reopen.append(work)
            if new[0] in CLOSED and (old[0] not in CLOSED or new[1]!=old[1]):declare(work,new[1],e.get('criterion_version'))
            states[work]=new
        if e['kind']=='action' and e['action'] in REWORK and e['subject'] in WORK and not e.get('passive_scorer',False):
            actions.add(e['invocation'])
    terminal=case.get('terminal_candidate')
    grade['final_pass']=all_six(proof,terminal,phase);supplemental['available_final_phase']=phase
    grade['unaffected_both_retained']=False if reopen else (True if known_history else None)
    grade['unaffected_reopened']=len(reopen) if known_history else None
    grade['affected_invalid_closure']=True if invalid else (False if known_history and not unknown else None)
    supplemental['reopen_transitions']=reopen;supplemental['reopened_siblings']=sorted(set(reopen))
    supplemental['known_steps']=len(actions);supplemental['lower_bound']=not case.get('action_history_complete',False)
    grade['rework_steps']=None if supplemental['lower_bound'] else len(actions)
    return grade,supplemental
def comparisons(purser,plain):
    if set(purser)!=set(range(2001,2021)) or set(plain)!=set(purser):raise ValueError('twenty separate matched E2 seeds per arm required')
    def exact(rows,key):vals=[v[key] for v in rows.values()];return None if any(x is None for x in vals) else sum(vals)
    known_retain=sum(r['unaffected_both_retained'] is True for r in purser.values());remaining=sum(r['unaffected_both_retained'] is None for r in purser.values())
    ret=True if known_retain>=18 else (False if known_retain+remaining<18 else None)
    vals=[exact(rows,k) for rows,k in ((purser,'rework_steps'),(plain,'rework_steps'),(purser,'final_pass'),(plain,'final_pass'))];ps,bs,pf,bf=vals
    half=None if ps is None or bs is None else 2*ps<=bs
    at_least=None if pf is None or bf is None else pf>=bf
    monotone=None if ps is None or bs is None else ps>=bs
    clauses=(ret,half,at_least);absolute=False if False in clauses else (True if all(x is True for x in clauses) else None)
    no_adv=True if monotone is True or at_least is False else (False if monotone is False and at_least is True else None)
    return {'purser_retained':known_retain,'retention_threshold':ret,'purser_rework':ps,'baseline_rework':bs,'purser_final_pass':pf,'baseline_final_pass':bf,'half_rework':half,'final_at_least':at_least,'absolute':absolute,'original_no_advantage':no_adv,'ratio':None if ps is None or not bs else ps/bs}
