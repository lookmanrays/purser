"""Run the original private public-action programs on the committed E2 registration."""

import argparse
import ast
import hashlib
import os
from pathlib import Path
import sys
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
CASES = {
    "repeated": (341, "two actual reopenings of W3", "private_edges.py", "repeated"),
    "parent": (342, "old parent close is requested before W2 closes and refused", "private_edges.py", "parent"),
    "parent_closed": (343, "old parent closes after W2 passes revised retry", "private_parent_closed.py",
                      "public_work_after_W2_closes"),
}
PROGRAM_HASH = {
    "private_edges.py": "56da977ac266540d94d2602c99efa84ccf069e7af2a32db830e6723a6b24e6a2",
    "private_parent_closed.py": "15f4f724e2b7ad33b956e2e96be683741827b6af617877c2b5d9d6965b4c8617",
}

def run(repo, action, case):
    os.chdir(repo)
    sys.path.insert(0, str(repo))
    from experiments.e1.artifacts import git
    from experiments.e2 import policy, suite
    from experiments.e2.driver import Driver

    replicate, description, filename, program = CASES[case]
    directory = repo / "private-closure" / case
    if action == "freeze":
        suite.freeze_series(directory, replicate=replicate, reason=f"Private exact-source closure control, {description}.")
        return
    data = (HERE / "originals" / filename).read_bytes()
    assert hashlib.sha256(data).hexdigest() == PROGRAM_HASH[filename]
    fn, = [node for node in ast.parse(data).body if isinstance(node, ast.FunctionDef) and node.name == program]
    cls, method = (Driver, "finish") if case == "parent_closed" else (policy.PlanArm, "revise")
    # Execute the observer's original public-action function body, including every assertion.
    # Only the prior uncommitted ad-hoc registration wrapper is replaced.
    bindings = {"original": getattr(cls, method), "git": git}
    exec(compile(ast.Module([fn], type_ignores=[]), filename, "exec"), bindings)
    with patch.object(cls, method, bindings[program]):
        suite.collect_units(directory, [("primary", 2001, 1, "loop")])

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", type=Path)
    parser.add_argument("action", choices=["freeze", "collect"])
    parser.add_argument("case", choices=CASES)
    args = parser.parse_args()
    run(args.repo.resolve(), args.action, args.case)
