"""Compare native publication identities and protected judgments to the frozen reader."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

HERE = Path(__file__).resolve().parent
REPO = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(REPO))
from experiments.e2.report import inspect_series

def load(path):
    return json.loads(path.read_bytes())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

past_file = HERE / "originals/closure-controls.json"
assert sha(past_file) == "fc92858165c3ccd78d0ae2c10bccb07acb93fe070b7f44f7ed606f2ef64131a8"
past = load(past_file)
source = "82e880734539bbd8d2af2b0b44fbdcff2b4062f3"
registration = subprocess.check_output(["git", "-C", str(REPO), "rev-parse",
                                        "refs/heads/lookman/private-closure-82e8807"], text=True).strip()
assert subprocess.check_output(["git", "-C", str(REPO), "rev-parse", registration+"^"], text=True).strip() == source
rows = {}
for name in ("repeated", "parent", "parent_closed"):
    folder = HERE / name
    freeze = load(folder / "freeze.json")
    assert freeze["source_commit"] == source and freeze["replicate"] > 1
    assert (folder/"freeze.json").read_bytes() == subprocess.check_output(
        ["git","-C",str(REPO),"show",registration+f":private-closure/{name}/freeze.json"])
    reread, stats = inspect_series(folder)
    row = reread["primary",2001,"loop"]
    ex = load(folder/"frozen-readback.json")
    ref = ex["rows"]["primary/2001/loop"]
    prior = past[name]
    assert ex["source"] == source and ex["registered"] is False
    assert not ex["disputed"] and ex["n_started"] == ex["strict_complete_rows"] == 1
    assert not row.issues and not row.unavailable and row.raw["score"] == ref["grade"] == prior["independent_grade"]
    assert ref["original_transitions"] == prior["original_transitions"]
    facts = row.facts
    expected_reopens = [(ck[1], subject, old[1]) for ck,subject,old,new in ref["original_transitions"]
                         if subject in ("W1","W3") and old[0] in ("closed","done") and new[0] not in ("closed","done")]
    observed_reopens = [(e["publication"],e["subject"],e["candidate"]) for e in facts["reopen_observations"]]
    assert expected_reopens == observed_reopens
    assert facts["reopened_subjects"] == prior["distinct_reopened"] == ref["detail"]["reopened_siblings"]
    assert [w for _,w,_ in observed_reopens] == ref["detail"]["reopen_transitions"]
    asserted = [(ck[1],subject,new[1]) for ck,subject,old,new in ref["original_transitions"]
                if subject in ("W2","W-notify") and new[0] in ("closed","done") and
                   (old[0] not in ("closed","done") or old[1] != new[1])]
    declared = [(e["publication"],e["subject"],e["candidate"]) for e in facts["closure_observations"]]
    assert declared == asserted
    grades = [[e["subject"],e["candidate"],e["revised_pass"]] for e in facts["closure_observations"]]
    assert grades == ref["closing_observations"] == prior["actual_closures_and_exact_revised_verdicts"]
    raw_cost = row.raw["cost"]
    assert all(raw_cost[k]==0 for k in ("model_calls","input_tokens","output_tokens","spend_usd_micros"))
    strict = load(folder/"native-strict.json")
    assert (strict["records"],strict["started"],strict["git_packs"],strict["reexecuted_seed_candidate_versions"],
            strict["reexecuted_seed_candidate_criteria"]) == (1,1,5,10,40)
    parent_returns = []
    with zipfile.ZipFile(folder/"raw.zip") as archive:
        original_journal = json.loads(archive.read(row.raw["artifacts"]["journal"]["path"]))
        for event in original_journal:
            action = event["payload"]
            if event["kind"] != "action" or (action["subject"],action["actor"]) != ("W-notify","closure"):
                continue
            witness = action["response_evidence"]
            evidence_bytes = archive.read(witness["path"])
            assert hashlib.sha256(evidence_bytes).hexdigest() == witness["sha256"]
            reply = json.loads(evidence_bytes)
            assert reply["return"] == action["return"] and reply["candidate"] == action["candidate"]
            parent_returns.append({"attempt":reply["attempt"], "candidate":reply["candidate"],
                                   "state":reply["return"]["claim"]["state"], "witness_sha256":witness["sha256"]})
    if name != "repeated":
        before_repair = [r for r in parent_returns if r["candidate"] != facts["final_candidate"]]
        assert len(before_repair)==1 and before_repair[0]["state"] == ("submitted" if name=="parent" else "closed")
    rows[name] = {"replicate":freeze["replicate"],"source":source,"registration_commit":registration,
                  "raw_sha256":sha(folder/"raw.zip"),"freeze_sha256":sha(folder/"freeze.json"),
                  "frozen_readback_sha256":sha(folder/"frozen-readback.json"),"native_strict":strict,
                  "score":row.raw["score"],"participant_cost":raw_cost,
                  "observed_reopenings":facts["reopen_observations"],"distinct_reopened":facts["reopened_subjects"],
                  "closure_observations":facts["closure_observations"],"parent_returns":parent_returns,
                  "exiting_oid":facts["final_candidate"],
                  "original_plan_versions":ref["original_publications"],
                  "matched_original_transitions":len(ref["original_transitions"]),
                  "matched_frozen_report_cells":ex["report_comparison"]["matched_report_cells"]}

output={"source":source,"registration":registration,"archive_comparisons":rows,
        "simultaneous_input_and_variation":load(HERE/"simultaneous/readback.json")["measurements"]}
(HERE/"qualification.json").write_text(json.dumps(output,ensure_ascii=False,indent=2,sort_keys=True)+"\n")
print([(name,r["participant_cost"]["steps"],r["score"]["rework_steps"],r["score"]["unaffected_reopened"],
        r["score"]["affected_invalid_closure"]) for name,r in rows.items()])
