# Scripted E2 results

Private replicate 343 has 1 of 66 registered records, 65 are missing.

Twenty matched primary ranks were registered. Count columns show the total and the number of seeds with an observed value. Missing binary outcomes can range from zero to one. Thresholds use those bounds. A question mark marks an unavailable measurement.

| Arm | Complete | Incomplete | Invalid or missing | Checkpoint reached | Both retained | Invalid affected closure | Rework steps / measured | Final pass | Total steps / measured |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| loop | 1 | 0 | 19 | 1/1 | 1/1 | 1/1 | 18/1 | 1/1 | 35/1 |
| purser | 0 | 0 | 20 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 |
| loop_equal_verifier | 0 | 0 | 20 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 |

## Frozen thresholds

Each comparison uses the original rules. The half-cost test compares summed rework across all 20 ranks. The no-advantage predicate is true when Purser rework is equal or greater, or its final pass count is lower.

| Purser compared with | Both retained ≥18 | 2 × Purser rework ≤ comparator | Final passes ≥ comparator | E2 passes | No advantage | Rework ratio |
| --- | --- | --- | --- | --- | --- | ---: |
| loop | inconclusive | inconclusive | inconclusive | inconclusive | inconclusive | inconclusive |
| loop_equal_verifier | inconclusive | inconclusive | inconclusive | inconclusive | inconclusive | inconclusive |

## Paired primary results

Each signed difference is Purser minus its comparator. Columns within each cell give retention, bad affected closure, rework steps, final pass, total steps and elapsed seconds. Zero is a tie.

| Seed | Purser − plain loop | Purser − equal verifier |
| ---: | --- | --- |
| 2001 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2002 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2003 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2004 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2005 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2006 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2007 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2008 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2009 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2010 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2011 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2012 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2013 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2014 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2015 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2016 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2017 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2018 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2019 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2020 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |

## Primary coverage · loop

| Seed | Validity / exit | Reached | Both retained | Reopen transitions | Invalid affected closure | Rework | Final pass | Steps | Elapsed s |
| ---: | --- | --- | --- | ---: | --- | ---: | --- | ---: | ---: |
| 2001 | complete / done | yes | yes | 0 | yes | 18 | yes | 35 | 4.924 |
| 2002 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2003 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2004 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2005 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2006 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2007 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2008 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2009 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2010 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2011 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2012 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2013 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2014 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2015 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2016 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2017 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2018 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2019 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2020 | missing | ? | ? | ? | ? | ? | ? | ? | ? |

## Primary coverage · purser

| Seed | Validity / exit | Reached | Both retained | Reopen transitions | Invalid affected closure | Rework | Final pass | Steps | Elapsed s |
| ---: | --- | --- | --- | ---: | --- | ---: | --- | ---: | ---: |
| 2001 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2002 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2003 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2004 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2005 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2006 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2007 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2008 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2009 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2010 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2011 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2012 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2013 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2014 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2015 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2016 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2017 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2018 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2019 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2020 | missing | ? | ? | ? | ? | ? | ? | ? | ? |

## Primary coverage · loop_equal_verifier

| Seed | Validity / exit | Reached | Both retained | Reopen transitions | Invalid affected closure | Rework | Final pass | Steps | Elapsed s |
| ---: | --- | --- | --- | ---: | --- | ---: | --- | ---: | ---: |
| 2001 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2002 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2003 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2004 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2005 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2006 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2007 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2008 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2009 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2010 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2011 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2012 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2013 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2014 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2015 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2016 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2017 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2018 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2019 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2020 | missing | ? | ? | ? | ? | ? | ? | ? | ? |

## Clean control · A1 retained

| Arm | Exit | Clean exposure | Final pass | Steps | Elapsed s |
| --- | --- | --- | --- | ---: | ---: |
| loop | missing | ? | ? | ? | ? |
| purser | missing | ? | ? | ? | ? |
| loop_equal_verifier | missing | ? | ? | ? | ? |

The twice-baseline clean overhead flag is **?**.

## Already-closed affected stress control

At delivery the affected W2 was already closed under the old schedule. The two bad-closure columns distinguish a stale closure still visible at delivery from a new bad closure asserted later.

| Arm | Exit | Old W2 candidate at delivery | Both siblings retained | Stale at delivery | New bad closure | Rework | Final pass | Steps | Elapsed s |
| --- | --- | --- | --- | --- | --- | ---: | --- | ---: | ---: |
| loop | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| purser | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| loop_equal_verifier | missing | ? | ? | ? | ? | ? | ? | ? | ? |

## Observed sibling reopenings

An incomplete history gives a lower bound on the number of transitions.

| Case | Transitions observed | Distinct siblings observed reopening | Exact eligible total |
| --- | ---: | --- | ---: |
| primary / 2001 / loop | 0 | — | 0 |

## Public reopening and closure evidence

Each reopening identifies the previously closed candidate. Each closure grades revised retry on the candidate declared by that subject.

| Case | Plan digest or kernel revision / hash | Subject | Public observation | Git candidate | Revised retry passes |
| --- | --- | --- | --- | --- | --- |
| primary / 2001 / loop | `da4332bcfaa9db38fdc2f8e56dce4331b80a4920a60a496f75b421ea946a3277` | W2 | closed | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | yes |
| primary / 2001 / loop | `6252f540fa970e7c30deaab436c48b502b9bb2e7f8d60cafe58a3cdaab92bd28` | W-notify | closed | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | no |
| primary / 2001 / loop | `4548f17d5c2f6fffd684fd9cb9c684133704fe6b8871b3e554dcbe10863a3067` | W-notify | closed | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | yes |

## Protected Git observations

| Case | Candidate | Criterion | Version | Retained verdict | Available grade | Grade source | Original journal row | Independent replay |
| --- | --- | --- | ---: | --- | --- | --- | --- | --- |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W1/preferences | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W2/retry | 2 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | queue/composition | 2 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |

The scripted protocol permits zero model calls, tokens and spend.
