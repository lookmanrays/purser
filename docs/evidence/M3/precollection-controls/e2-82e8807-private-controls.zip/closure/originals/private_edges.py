import sys
from pathlib import Path
from unittest.mock import patch
base=Path(__file__).resolve().parent
sys.path.insert(0,str(base/'wire-0ad579f'))
from experiments.e1.artifacts import encoded
from experiments.e1.suite import collect_cases
from experiments.e2 import suite,trial,policy
original=policy.PlanArm.revise
def repeated(a,m):
    cand=a.context('W3')['candidate']
    for i in range(2):
        a.assign_again('W3');a.submit('W3',cand);a.decide('W3',{'missing':[]})
    return original(a,m)
def parent(a,m):
    old=a.context('W2')['candidate']
    a.submit('W-notify',old);a.decide('W-notify',{'missing':[]});a.assign_again('W-notify')
    return original(a,m)
for i,(name,fn) in enumerate([('repeated',repeated),('parent',parent)],83):
    f=dict(suite.source_pin(),replicate=i,replication_reason='Independent private '+name+' edge under observed participant operations')
    with patch.object(policy.PlanArm,'revise',fn):
        collect_cases(base/'private-edges'/name,f,encoded(f),[('primary',2001,1,'loop')],trial.attempt,recover=trial.recover,failure=trial.failure)
