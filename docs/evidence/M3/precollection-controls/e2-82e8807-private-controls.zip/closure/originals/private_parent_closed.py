from pathlib import Path
import sys
from unittest.mock import patch
base=Path(__file__).resolve().parent;sys.path.insert(0,str(base/'wire-0ad579f'))
from experiments.e1.artifacts import encoded,git
from experiments.e1.suite import collect_cases
from experiments.e2 import suite,trial
from experiments.e2.driver import Driver
original=Driver.finish
def public_work_after_W2_closes(driver,work,oid):
    if work=='W-notify':
        arm=driver.adapter
        good=arm.context('W2')
        assert good['state']=='closed' and good['candidate']==oid
        old=git(driver.candidates.work,'rev-parse',oid+'^').decode().strip()
        arm.submit(work,old)
        wrong=arm.decide(work,{'missing':[]})
        assert wrong['claim']['state']=='closed' and wrong['claim']['candidate']==old
        arm.assign_again(work);arm.submit(work,oid)
    return original(driver,work,oid)
f=dict(suite.source_pin(),replicate=85,replication_reason='Independent private parent falsely closes old Git integration while W2 stays closed on repaired Git under revised public schedule')
with patch.object(Driver,'finish',public_work_after_W2_closes):
    collect_cases(base/'private-edges'/'parent_closed',f,encoded(f),[('primary',2001,1,'loop')],trial.attempt,recover=trial.recover,failure=trial.failure)
