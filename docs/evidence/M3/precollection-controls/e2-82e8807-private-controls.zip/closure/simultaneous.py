"""Apply the frozen hand input to actual serial plan versions and cold-read both subjects."""
from copy import deepcopy
from functools import partial
import hashlib
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
REPO = Path(sys.argv[1]).resolve()
sys.path[:0] = [str(REPO), str(HERE / "frozen-observer")]
import e2_reference
from experiments.e1.artifacts import Artifacts, encoded, sha
from experiments.e1.recovery import FileArchive
from experiments.e1.report import Objects
from experiments.e2 import outcomes, plan_versions, policy
from experiments.e2.public_history import Participant
from experiments.e2.public_sources import Originals

manifest = json.loads((HERE / "frozen-observer/frozen-m3-reference.json").read_bytes())
proof_bytes = (HERE / "frozen-observer/hand-git-proofs.json").read_bytes()
assert sha(proof_bytes) == manifest["files"]["hand-git-proofs.json"]["sha256"]
proof_data = json.loads(proof_bytes)
proof = {(proof_data["candidates"][k.split(":")[0]], k.split(":")[1]): grades
         for k, grades in proof_data["observed"].items()}
verdicts = {(oid, label, 2 if phase == "revised" and label in ("W2/retry", "queue/composition") else 1):
            "pass" if passed else "fail"
            for (oid, phase), grades in proof.items() for label, passed in grades.items()}
input_file = (HERE / "originals/stage-two-simultaneous-input.json").read_bytes()
assert sha(input_file) == "bd67253dcf9639e19418f207fd75676a1d485587b3274ebbe3d330cd648a70bb"

def read_case(name, original, folder, joined_parent=False):
    case = deepcopy(original)
    old = case["checkpoint"]["worked_w2_candidate"]
    if joined_parent:
        case["post_release"].append({"kind":"public_state","work":"W-notify","from":["open",None],
                                     "to":"done","candidate":old,"criterion_version":2})
    expected, independent_detail = e2_reference.assess(case, proof)
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        plan = policy.PlanArm(root)
        assets = Artifacts(FileArchive(root))
        def checkpoint():
            return {"plan_sha256": sha(plan.file.read_bytes()), "view": assets.put(plan.read(), "json")}
        def publish(states, notice=False):
            rows = plan.read()
            for subject, (state, oid) in states.items():
                rows[subject].update(state=state, candidate=oid)
            if notice:
                rows["W2"]["premise"] = policy.notice(2001)
            plan.publish(rows)
            return checkpoint()
        initial = checkpoint()
        before = publish(case["checkpoint"]["states"])
        receipt = publish(case["immediate_after_release"], notice=True)
        fault = {"seq":1, "kind":"fault", "payload":{"before":before,"after":receipt,
                 "candidate":old,"publicly_delivered":True}}
        journal = [fault]
        for item in original["post_release"]:
            if item["kind"] == "action":
                journal.append({"seq":len(journal)+1,"kind":"action","payload":{"after_intervention":True,
                                "action":item["action"],"subject":item["subject"],"attempt":item["invocation"]}})
                continue
            changes = {item["work"]:(item["to"], item["candidate"])}
            if joined_parent and item["to"] == "closed":
                changes["W-notify"] = ("done", old)
            ck = publish(changes)
            for subject in changes:
                journal.append({"seq":len(journal)+1,"kind":"public_state","payload":{"checkpoint":ck,"subject":subject}})
        objects = Objects(assets.archive)
        refs = plan_versions.retain(root, assets, plan.file.read_bytes())
        trace = {"plan":plan.read(),"plan_versions":refs}
        platform = {"treatment_trace":assets.put(trace,"json"), "initial_public":initial,"final_public":checkpoint()}
        issues = []
        originals = Originals("loop",platform,objects.item,issues.append)
        assert originals.complete and not issues
        history = SimpleNamespace(arm="loop",journal=journal,source=originals,public_complete=originals.complete,
                                  checkpoint=originals.lookup)
        history.public_states_after = partial(Participant.public_states_after, history)
        found = outcomes.assess(history,"primary",verdicts,delivery=True,qualification=True,submitted=True,
                                unchanged={"W1":True,"W3":True},final_oid=case["terminal_candidate"],
                                endpoint_known=True,action_sequence_complete=True)
        grade = outcomes.raw_score(found)
        assert grade == {k:expected[k] for k in outcomes.FIELDS}
        reopens = found["reopen_observations"]
        assert found["reopened_subjects"] == independent_detail["reopened_siblings"] == ["W1","W3"]
        assert [e["subject"] for e in reopens] == independent_detail["reopen_transitions"] == ["W1","W3"]
        assert {e["publication"] for e in reopens} == {receipt["plan_sha256"]}
        declarations = found["closure_observations"]
        if joined_parent:
            assert [(e["subject"],e["candidate"],e["revised_pass"]) for e in declarations] == [
                ("W2",case["terminal_candidate"],True),("W-notify",old,False)]
            assert len({e["publication"] for e in declarations}) == 1
            assert independent_detail["invalid_parent_declarations"] == [old]
        data = [objects.item(ref) for ref in refs]
        (folder / (name + "-published-plans.json")).write_bytes(encoded(data))
        return dict(case=name, grade=grade, independent_grade=expected, independent_detail=independent_detail,
                    plan_versions=[r["sha256"] for r in refs], reopenings=reopens, declarations=declarations)

folder = HERE / "simultaneous"
folder.mkdir(exist_ok=True)
original = json.loads(input_file)
rows=[read_case("stage-two",original,folder),read_case("two-declarations",original,folder,True)]
result = {"boundary":"Frozen stipulated receipt, work, Git proofs and endpoint joined to real serialized plan versions",
          "input_sha256":sha(input_file), "hand_proof_sha256":sha(proof_bytes),"measurements":rows}
(folder/"readback.json").write_bytes(encoded(result)+b"\n")
print([(e["case"], e["grade"]["unaffected_reopened"], e["grade"]["affected_invalid_closure"]) for e in rows])
