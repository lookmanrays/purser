# Private E2 closure qualification

Source `82e880734539bbd8d2af2b0b44fbdcff2b4062f3` ran three original observer programs with committed private registrations. The registration commit `887a2bb1e03569b53f510d2a108da5defea2f215` adds three freeze files and has the tested source as its sole parent. The accepted product tree is `c2d2e50c748324fc0b4fe697ccf490efc47c15f9`. All cases used Python 3.11.15, UTC, the C locale, plain loop, primary seed 2001 and zero provider calls, tokens and spend.

| Private replicate | Physical control | Steps / rework | Counted reopenings | Invalid affected closure | Final pass |
| ---: | --- | ---: | --- | --- | --- |
| 341 | W3 closed, reopened and reclosed twice | 37 / 20 | 2 on W3 | No | Yes |
| 342 | The old parent close was refused while W2 remained open | 34 / 17 | 0 | No | Yes |
| 343 | The parent closed on the old candidate after W2 closed correctly | 35 / 18 | 0 | Yes | Yes |

Each native strict verifier restored five Git packs and reran 40 criteria across ten seed/candidate/version groups. Each independent reader accepted the raw score, the nine report-row cells and the original public transitions. In case 342, the return for attempt 21 retained `submitted` on `7df4a199`. In case 343, W2 closed on `a5cd7dfe` and passed revised retry. Parent attempt 31 actually closed `7df4a199`, which failed revised retry. Attempt 35 reclosed the corrected parent on `a5cd7dfe`. The report preserves all three declarations.

`qualification.json` compares exact publication, subject, Git candidate and grade with the independent readback. `originals/` holds the original case functions, staged independent hand input and historical closure evidence. The physical collection wrapper compiles the original, hash-checked function bodies unchanged and passes their effects through the source's registered collector. A separate plan control joins the frozen stage-two input and its existing Git proofs to real serialized plan versions. Both W1 and W3 reopened at one receipt. In a second variation W2 and the parent closed in the same publication on different Git candidates, with opposite protected verdicts. The hand controls stipulate receipt, work and exit and exercise the publication judgment boundary.

## Reproduce locally

Use a disposable checkout containing the candidate commit. Set `evidence` to this directory and `repo` to the absolute checkout path. Import the registration before collection.

```sh
git -C "$repo" fetch "$evidence/private-registration.bundle" refs/heads/lookman/private-closure-82e8807:refs/heads/lookman/private-closure-82e8807
git -C "$repo" switch lookman/private-closure-82e8807
python3.11 -B "$evidence/controls.py" "$repo" collect repeated
python3.11 -B "$evidence/controls.py" "$repo" collect parent
python3.11 -B "$evidence/controls.py" "$repo" collect parent_closed
```

The archived cases are already collected. To reproduce their cold readback, run from the source checkout with the archive path supplied as `unit`. Set `unit` to a directory containing one archived `raw.zip`. The independently frozen reader and queue grader are included.

```sh
python3.11 -B -m experiments.e2 report "$unit" > /tmp/purser-closure-report.md
python3.11 -B -m experiments.e2 verify "$unit"
python3.11 -B "$evidence/frozen-observer/reader/e2_wire.py" --source 82e880734539bbd8d2af2b0b44fbdcff2b4062f3 --source-repo "$repo" --archive "$unit/raw.zip" --report /tmp/purser-closure-report.md --out /tmp/purser-closure-independent.json
```

`simultaneous.py` and `compare.py` take the absolute checkout path. They regenerate their adjacent JSON outputs. The original archives and registrations are retained under the three case directories.
