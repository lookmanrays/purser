"""Check the two single-field differences and their first visible consequences."""
import copy
import hashlib
import json
import sys
import zipfile
from pathlib import Path

START = "55686bd5152e10a53dfdc2c003974ea405a3a075"
def sha(data):
    return hashlib.sha256(data).hexdigest()
def enc(value):
    return json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(",",":")).encode()

def recovered(path):
    with zipfile.ZipFile(path) as z:
        def contents(ref):
            data=z.read(ref["path"])
            assert sha(data)==ref["sha256"] and len(data)==ref["bytes"]
            return data
        raw=json.loads(z.read("runs/primary/2001/loop.json"))
        p,m,j=[json.loads(contents(raw["artifacts"][k])) for k in ("platform","candidates","journal")]
        witnesses={}
        for row in j:
            v=row["payload"]
            if row["kind"]=="oracle" and v["candidate"]==START:
                grade=json.loads(contents(v["evidence"]))
                assert grade["candidate"]==START and grade["verdict"]==v["verdict"]
                witnesses[f'{v["criterion"]}/v{v["version"]}']=v["verdict"]
        assert len(witnesses)==8
        return raw,p,m,j,witnesses,sha(contents(m[START]["pack"])),sha(z.read("runs/primary/2002/loop.json"))

def main(directory):
    baseline=directory.parent/"foreign-seal"/"baseline"
    old,platform,mapping,journal,grades,pack,donor=recovered(baseline/"raw.zip")
    name="partial_no_start"
    raw,altered,actual,events,observations,gitbytes,other=recovered(directory/name/"raw.zip")
    assert actual==mapping and events==journal and observations==grades and gitbytes==pack and other==donor
    expected=copy.deepcopy(platform)
    expected["case_git_packs"]=[r for r in expected["case_git_packs"] if r["candidate"]!=START]
    assert expected==altered and len(platform["case_git_packs"])==len(altered["case_git_packs"])+1
    def shown(path):
        return [line for line in path.read_text().splitlines() if line.startswith(f"| primary / 2001 / loop | `{START}` |")]
    assert len(shown(baseline/"reviewer-report.md"))==8 and len(shown(directory/name/"report.md"))==0
    partial={"source_archive":sha((directory/name/"raw.zip").read_bytes()),"pack_sha256":pack,
             "candidate_map_ref":raw["artifacts"]["candidates"],"original_grades":grades,
             "receiver_START_report_rows_before":8,"receiver_START_report_rows_after":0}
    name="late_action_identity_only"
    raw,p,m,j,g,pack2,other=recovered(directory/name/"raw.zip")
    assert (p,m,g,pack2,other)==(platform,mapping,grades,pack,donor)
    assert raw["artifacts"]["platform"]==old["artifacts"]["platform"]
    expected=copy.deepcopy(journal)
    row=expected[38]
    assert row["seq"]==39 and row["payload"]["attempt"]==29 and row["payload"]["work_request"]["subject"]=="W-notify"
    row["payload"]["work_request"]["subject"]="W3"
    assert expected==j
    fault=j[22]
    assert fault["kind"]=="fault" and row["payload"]["issued_monotonic_ns"]>fault["payload"]["finished_monotonic_ns"]
    assert p["checkpoint_measurement"]["qualified"] is True and p["checkpoint_measurement"]["preceding_events"]==22
    digest=sha(enc(j[:23]))
    assert digest==sha(enc(journal[:23]))=="72179477f7534ebb964656cf55ede371b2d97f3248a5bedc4730b71328e2cc33"
    def coverage(path):
        part=path.read_text().split("## Primary coverage · loop\n")[1].split("##",1)[0]
        return next(line for line in part.splitlines() if line.startswith("| 2001 |"))
    before=coverage(baseline/"reviewer-report.md")
    after=coverage(directory/name/"report.md")
    assert "| yes |" in before and "| complete / done (disputed) | ? |" in after
    return {"partial_no_start":partial,"late_action_identity_only":{"source_archive":sha((directory/name/"raw.zip").read_bytes()),
            "platform_ref":raw["artifacts"]["platform"],"identical_through_ingress_sha256":digest,
            "qualified":True,"ingress_row":23,"changed_row":39,"changed_attempt":29,
            "original_work_request_subject":"W-notify","altered_work_request_subject":"W3",
            "before":before,"after":after}}
if __name__=="__main__":
    print(json.dumps(main(Path(__file__).resolve().parent),sort_keys=True,indent=2))
