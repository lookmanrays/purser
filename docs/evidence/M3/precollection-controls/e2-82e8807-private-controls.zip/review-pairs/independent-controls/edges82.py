import ast,copy,hashlib,json,sys
from pathlib import Path
from unittest.mock import patch
BASE=Path(__file__).resolve().parent;repo=BASE/'edge-repo';sys.path.insert(0,str(repo))
from experiments.e1.artifacts import git
from experiments.e2 import policy,suite
from experiments.e2.driver import Driver
E2=BASE.parent/'e2-reader'
ORIGINALS={'private_edges.py':'56da977ac266540d94d2602c99efa84ccf069e7af2a32db830e6723a6b24e6a2','private_parent_closed.py':'15f4f724e2b7ad33b956e2e96be683741827b6af617877c2b5d9d6965b4c8617'}
spec={'repeated':(92,'private_edges.py','repeated','revise'),'refused':(93,'private_edges.py','parent','revise'),'parent':(94,'private_parent_closed.py','public_work_after_W2_closes','finish'),'both':(95,None,None,'revise'),'badW2':(96,'private_bad_closure.py','transient','revise')}
# Real ordinary-plan transport issues these original old- and new-state publications under a single public action.
def both(arm,msg):
    response=original(arm,msg)
    current=arm.read();opened=copy.deepcopy(current)
    assert current['W1']['state']==current['W3']['state']=='closed'
    for w in ('W1','W3'):opened[w].update(state='open',candidate=None,verified={})
    arm.publish(opened)
    observed=arm.read();proof=dict(publication=observed['W-notify']['_e2_plan_version'],W1=observed['W1'],W3=observed['W3'])
    (BASE/'both-live.json').write_text(json.dumps(proof,sort_keys=True))
    arm.publish(current)
    return response
action=sys.argv[1]
for label,(rep,path,fn,method) in spec.items():
    folder=repo/'docs'/'private-edges'/label
    if action=='freeze':
        suite.freeze_series(folder,replicate=rep,reason='Independent disposable public edge, '+label)
        continue
    owner=Driver if method=='finish' else policy.PlanArm;original=getattr(owner,method)
    if path:
        source=(E2/path).read_bytes()
        if path in ORIGINALS:assert hashlib.sha256(source).hexdigest()==ORIGINALS[path]
        tree=ast.parse(source);node=next(x for x in tree.body if getattr(x,'name','')==fn)
        ns={'original':original,'git':git};exec(compile(ast.Module(body=[node],type_ignores=[]),str(E2/path),'exec'),ns);control=ns[fn]
    else:control=both
    with patch.object(owner,method,control):suite.collect_units(folder,[('primary',2001,1,'loop')])
