# Scripted E2 results

Private replicate 91 has 12 of 66 registered records, 54 are missing.

Twenty matched primary ranks were registered. Count columns show the total and the number of seeds with an observed value. Missing binary outcomes can range from zero to one. Thresholds use those bounds. A question mark marks an unavailable measurement.

| Arm | Complete | Incomplete | Invalid or missing | Checkpoint reached | Both retained | Invalid affected closure | Rework steps / measured | Final pass | Total steps / measured |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| loop | 2 | 0 | 18 | 2/2 | 2/2 | 0/2 | 26/2 | 2/2 | 60/2 |
| purser | 2 | 0 | 18 | 2/2 | 2/2 | 0/2 | 50/2 | 2/2 | 96/2 |
| loop_equal_verifier | 2 | 0 | 18 | 2/2 | 2/2 | 0/2 | 50/2 | 2/2 | 96/2 |

## Frozen thresholds

Each comparison uses the original rules. The half-cost test compares summed rework across all 20 ranks. The no-advantage predicate is true when Purser rework is equal or greater, or its final pass count is lower.

| Purser compared with | Both retained ≥18 | 2 × Purser rework ≤ comparator | Final passes ≥ comparator | E2 passes | No advantage | Rework ratio |
| --- | --- | --- | --- | --- | --- | ---: |
| loop | inconclusive | inconclusive | inconclusive | inconclusive | inconclusive | inconclusive |
| loop_equal_verifier | inconclusive | inconclusive | inconclusive | inconclusive | inconclusive | inconclusive |

## Paired primary results

Each signed difference is Purser minus its comparator. Columns within each cell give retention, bad affected closure, rework steps, final pass, total steps and elapsed seconds. Zero is a tie.

| Seed | Purser − plain loop | Purser − equal verifier |
| ---: | --- | --- |
| 2001 | +0 / +0 / +12 / +0 / +18 / +4.416 s | +0 / +0 / +0 / +0 / +0 / +3.317 s |
| 2002 | +0 / +0 / +12 / +0 / +18 / +2.100 s | +0 / +0 / +0 / +0 / +0 / +0.491 s |
| 2003 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2004 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2005 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2006 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2007 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2008 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2009 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2010 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2011 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2012 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2013 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2014 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2015 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2016 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2017 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2018 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2019 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2020 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |

## Primary coverage · loop

| Seed | Validity / exit | Reached | Both retained | Reopen transitions | Invalid affected closure | Rework | Final pass | Steps | Elapsed s |
| ---: | --- | --- | --- | ---: | --- | ---: | --- | ---: | ---: |
| 2001 | complete / done | yes | yes | 0 | no | 13 | yes | 30 | 4.333 |
| 2002 | complete / done | yes | yes | 0 | no | 13 | yes | 30 | 3.099 |
| 2003 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2004 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2005 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2006 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2007 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2008 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2009 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2010 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2011 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2012 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2013 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2014 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2015 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2016 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2017 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2018 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2019 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2020 | missing | ? | ? | ? | ? | ? | ? | ? | ? |

## Primary coverage · purser

| Seed | Validity / exit | Reached | Both retained | Reopen transitions | Invalid affected closure | Rework | Final pass | Steps | Elapsed s |
| ---: | --- | --- | --- | ---: | --- | ---: | --- | ---: | ---: |
| 2001 | complete / done | yes | yes | 0 | no | 25 | yes | 48 | 8.749 |
| 2002 | complete / done | yes | yes | 0 | no | 25 | yes | 48 | 5.199 |
| 2003 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2004 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2005 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2006 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2007 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2008 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2009 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2010 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2011 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2012 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2013 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2014 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2015 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2016 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2017 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2018 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2019 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2020 | missing | ? | ? | ? | ? | ? | ? | ? | ? |

## Primary coverage · loop_equal_verifier

| Seed | Validity / exit | Reached | Both retained | Reopen transitions | Invalid affected closure | Rework | Final pass | Steps | Elapsed s |
| ---: | --- | --- | --- | ---: | --- | ---: | --- | ---: | ---: |
| 2001 | complete / done | yes | yes | 0 | no | 25 | yes | 48 | 5.432 |
| 2002 | complete / done | yes | yes | 0 | no | 25 | yes | 48 | 4.708 |
| 2003 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2004 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2005 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2006 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2007 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2008 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2009 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2010 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2011 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2012 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2013 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2014 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2015 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2016 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2017 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2018 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2019 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2020 | missing | ? | ? | ? | ? | ? | ? | ? | ? |

## Clean control · A1 retained

| Arm | Exit | Clean exposure | Final pass | Steps | Elapsed s |
| --- | --- | --- | --- | ---: | ---: |
| loop | done | yes | yes | 24 | 2.413 |
| purser | done | yes | yes | 42 | 3.853 |
| loop_equal_verifier | done | yes | yes | 42 | 3.121 |

The twice-baseline clean overhead flag is **no**.

## Already-closed affected stress control

At delivery the affected W2 was already closed under the old schedule. The two bad-closure columns distinguish a stale closure still visible at delivery from a new bad closure asserted later.

| Arm | Exit | Old W2 candidate at delivery | Both siblings retained | Stale at delivery | New bad closure | Rework | Final pass | Steps | Elapsed s |
| --- | --- | --- | --- | --- | --- | ---: | --- | ---: | ---: |
| loop | done | 7df4a199e2ada1caafe78f5acec2f99b06f44771 | yes | yes | no | 13 | yes | 32 | 3.445 |
| purser | done | 7df4a199e2ada1caafe78f5acec2f99b06f44771 | yes | no | no | 25 | yes | 53 | 6.569 |
| loop_equal_verifier | done | 7df4a199e2ada1caafe78f5acec2f99b06f44771 | yes | yes | no | 25 | yes | 53 | 3.979 |

## Observed sibling reopenings

An incomplete history gives a lower bound on the number of transitions.

| Case | Transitions observed | Distinct siblings observed reopening | Exact eligible total |
| --- | ---: | --- | ---: |
| closed-affected / 2001 / loop | 0 | — | 0 |
| closed-affected / 2001 / loop_equal_verifier | 0 | — | 0 |
| closed-affected / 2001 / purser | 0 | — | 0 |
| primary / 2001 / loop | 0 | — | 0 |
| primary / 2001 / loop_equal_verifier | 0 | — | 0 |
| primary / 2001 / purser | 0 | — | 0 |
| primary / 2002 / loop | 0 | — | 0 |
| primary / 2002 / loop_equal_verifier | 0 | — | 0 |
| primary / 2002 / purser | 0 | — | 0 |

## Public reopening and closure evidence

Each reopening identifies the previously closed candidate. Each closure grades revised retry on the candidate declared by that subject.

| Case | Plan digest or kernel revision / hash | Subject | Public observation | Git candidate | Revised retry passes |
| --- | --- | --- | --- | --- | --- |
| closed-affected / 2001 / loop | `7142e3cf1ba3125b81122088a1473d9320160cb7b52ae30624323e286c32033c` | W2 | closed at delivery | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | no |
| closed-affected / 2001 / loop | `994e3cb95f4d4598cc2e15826f3ccfe00997e6b5f167172d49d8a1d34f357fe3` | W2 | closed | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | yes |
| closed-affected / 2001 / loop | `227c39217275af8e8156f4329872ec9e36356aac92df9c4d196b1a25bfc5d53f` | W-notify | closed | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | yes |
| closed-affected / 2001 / loop_equal_verifier | `4d4279efd1534d411cd214f369b10f2da5dcc357e2ff4466b5cc883098801164` | W2 | closed at delivery | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | no |
| closed-affected / 2001 / loop_equal_verifier | `aa1e5319f728b26239f116852987f3be3dba25dafb536ca0e55d10020de83f24` | W2 | closed | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | yes |
| closed-affected / 2001 / loop_equal_verifier | `e5068f8727be72d22dcb691334926e858c09750d5e050501fda633d6c99c6d01` | W-notify | closed | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | yes |
| closed-affected / 2001 / purser | 80 / `927d6f6eb21c48cadcd566d9ca6b1f0f7dab5680b18ce5c29a07e543326ea6ce` | W2 | closed | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | yes |
| closed-affected / 2001 / purser | 102 / `05edd8ed38336b570245806a9aa247e97088ec8fe0b0f7160d6d6d6098d822de` | W-notify | closed | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | yes |
| primary / 2001 / loop | `da4332bcfaa9db38fdc2f8e56dce4331b80a4920a60a496f75b421ea946a3277` | W2 | closed | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | yes |
| primary / 2001 / loop | `cc39d65b107535a1a732df3196fb5cd774e7ce4ad18f5526d3eb9fc9c272d3c5` | W-notify | closed | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | yes |
| primary / 2001 / loop_equal_verifier | `627bacd82e71860a7f1887613cdc0a1b4f422db5da5dbb8e2331a8193d5ec978` | W2 | closed | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | yes |
| primary / 2001 / loop_equal_verifier | `0409f2998df8906c4cf91448385b04a5366f3831f698863762a88b70862865a9` | W-notify | closed | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | yes |
| primary / 2001 / purser | 72 / `ce0422a6bc3de04e7a20943e0540db5be3a83a63ceb8648fb004a9baf7deb99b` | W2 | closed | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | yes |
| primary / 2001 / purser | 94 / `c35e43e13a730d1ab5f1fc3efc7d2e67bc067e9d9b885d868a9117baa490c30f` | W-notify | closed | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | yes |
| primary / 2002 / loop | `2f4ee2fbe661aa708c10b826b9ee6060f57d7c046b7a864fd1591ca6c622c15c` | W2 | closed | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | yes |
| primary / 2002 / loop | `55b236e1441fb8d7779ed22a4d3f2e2f95f1ba62da76c729b3ddfb0afae9bf62` | W-notify | closed | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | yes |
| primary / 2002 / loop_equal_verifier | `f3605ed79381f151f8b40eb4a54c9dc608723670c581c01e2b9613155701d25d` | W2 | closed | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | yes |
| primary / 2002 / loop_equal_verifier | `03fd79abf99a1de05a8bdc6dc5aeb9b3d013f72c669eb9cd0da7200100e4a1c7` | W-notify | closed | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | yes |
| primary / 2002 / purser | 72 / `88d79ea72696b08de9e30e186667f991bdebe256567d81b705f72fa1bc422e71` | W2 | closed | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | yes |
| primary / 2002 / purser | 94 / `21c426f9449823b1c55d4cbeb4d2ac8dc4201d08071fd989116a7d124637fbc3` | W-notify | closed | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | yes |

## Protected Git observations

| Case | Candidate | Criterion | Version | Retained verdict | Available grade | Grade source | Original journal row | Independent replay |
| --- | --- | --- | ---: | --- | --- | --- | --- | --- |
| clean / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W1/preferences | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W1/preferences | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W1/preferences | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| clean / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| clean / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W1/preferences | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W2/retry | 2 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | queue/composition | 2 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W1/preferences | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W2/retry | 2 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | queue/composition | 2 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W1/preferences | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W2/retry | 2 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | queue/composition | 2 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| closed-affected / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W1/preferences | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W2/retry | 2 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | queue/composition | 2 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W1/preferences | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W2/retry | 2 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | queue/composition | 2 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W1/preferences | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W2/retry | 2 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | queue/composition | 2 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W1/preferences | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W2/retry | 2 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | queue/composition | 2 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W1/preferences | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W2/retry | 2 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | queue/composition | 2 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W1/preferences | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / purser | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / purser | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / purser | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W2/retry | 2 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / purser | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | queue/composition | 2 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2002 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2002 / purser | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |

The scripted protocol permits zero model calls, tokens and spend.
