import sys,tempfile,json,hashlib
from pathlib import Path
base=Path(__file__).resolve().parent;sys.path.insert(0,str(base.parent/'e2-reader'));sys.path.insert(0,str(base/'edge-repo'))
from e2_wire import *
from experiments.e2.report import inspect_series
result={}
for case in ('repeated','refused','parent','both','badW2'):
    folder=base/'edge-repo/docs/private-edges'/case;a=Archive(folder/'raw.zip');raw=parse(a.z.read('runs/primary/2001/loop.json'))
    pub=arcdata=a.item(raw['artifacts']['platform']);trace=a.item(pub['treatment_trace']);hist=History('loop',trace,a,2001)
    begin,end=hist.boundary(pub);idx=next(i for i in range(begin,end+1) if hist.received_at(i));proofs={}
    seenbad=[];closed=[];reopened=[];taken=[]
    with tempfile.TemporaryDirectory() as d:
        pk=Candidates(d);m=pk.restore(a.item(raw['artifacts']['candidates']),a)
        for pp in hist.pubs[idx:]:
            i=hist.index[pp['key']];prior=hist.pubs[i-1]['states'];now=pp['states']
            for w in ('W1','W3'):
                if prior[w][0] in frozen.CLOSED and now[w][0] not in frozen.CLOSED:reopened.append([pp['key'][1],w,prior[w][1]])
            for w in ('W2','W-notify'):
                if now[w][0] in frozen.CLOSED and (i==idx or prior[w][0] not in frozen.CLOSED or prior[w][1]!=now[w][1]):
                    oid=now[w][1];grade=pk.truth(oid,2001,'revised')['criteria']['W2/retry'];closed.append([pp['key'][1],w,oid,grade,i==idx])
                    if not grade:seenbad.append((w,oid))
        v=one(raw,a,pk,'primary',2001,1,'loop',compare_issued=False) if raw['validity']=='complete' else bounded(raw,a,pk)
    cases,_=inspect_series(folder,rerun=False);c=cases['primary',2001,'loop'];f=c.facts
    observed_r=[[i['publication'],i['subject'],i['candidate']] for i in f['reopen_observations']]
    observed_c=[[i['publication'],i['subject'],i['candidate'],i['revised_pass'],i['at_delivery']] for i in f['closure_observations']]
    need(observed_r==reopened and observed_c==closed,'native reporter versus independent chronological source')
    if raw['validity']=='complete':need(same(v['grade'],raw['score']),'issued state/rework differs from independent')
    if case=='both':need(len(reopened)==2 and reopened[0][0]==reopened[1][0] and {p[1] for p in reopened}=={'W1','W3'},'simultaneous public original')
    result[case]={'source':parse(a.z.read('freeze.json'))['source_commit'],'raw_sha256':sha((folder/'raw.zip').read_bytes()),'raw':raw['score'],
        'terminal':raw['terminal'],'actual_original_reopens':reopened,'actual_closures_and_revised_grade':closed,'actual_invalid':seenbad,
        'replay_work_steps':v.get('grade',{}).get('rework_steps'),'independent_charged_total':v.get('cost',{}).get('steps'),
        'reopening_lower_bound':f.get('observed_reopened'),'native_distinct':f['reopened_subjects'],'native_issues':list(c.issues)}
print([(k,len(v['actual_original_reopens']),len(v['actual_invalid']),v['terminal']) for k,v in result.items()]);(base/'edges-proof.json').write_bytes(enc(result)+b'\n')
