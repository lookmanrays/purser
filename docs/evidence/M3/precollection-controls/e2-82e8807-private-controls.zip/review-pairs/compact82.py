import json,sys,tempfile
from pathlib import Path
base=Path(__file__).resolve().parent;sys.path.insert(0,str(base.parent/'e2-reader'));sys.path.insert(0,str(base/'membership-repo'))
from e2_wire import *
def digestfile(path):return sha(path.read_bytes())
def apath(rel):return base/rel
def mdslots(path,seed):
    lines=path.read_text().split('## Protected Git observations\n')[1].splitlines()
    result={}
    for line in lines:
        if not line.startswith(f'| primary / {seed} / loop | '):continue
        _,oid,label,v,historical,available,source,original,replay=[c.strip() for c in line.strip('|').split('|')]
        k=(oid.strip('`'),label,int(v));need(k not in result,'duplicate protected output cell');result[k]=[historical,available,source,original,replay]
    return result
def coverage(path,seed=2001):
    lines=path.read_text().split('## Primary coverage · loop\n')[1].split('##')[0].splitlines()
    return next(line for line in lines if line.startswith(f'| {seed} |'))
z=Archive(apath('membership-repo/docs/private-membership/raw.zip'));orig={};truth={};pkinfo={}
normal=apath('membership-baseline.md');donor_baseline=mdslots(normal,2002)
with tempfile.TemporaryDirectory() as tmp:
    pk=Candidates(tmp)
    for s in (2001,2002):
        row=parse(z.z.read(f'runs/primary/{s}/loop.json'));p=z.item(row['artifacts']['platform']);c=z.item(row['artifacts']['candidates'])
        actual=pk.restore(c,z);h=History('loop',z.item(p['treatment_trace']),z,s);h.boundary(p)
        published={oid for point in h.pubs for _,oid in point['states'].values() if oid}
        sealed={v['candidate'] for v in p['case_git_packs']}
        need(sealed==set(c) and set(actual)==published|{START},'independently observed memberships')
        for seal in p['case_git_packs']:
            oid=seal['candidate'];b=z.blob(seal['pack']);need(c[oid]['pack']==seal['pack'],'same independent local ref')
            with tempfile.TemporaryDirectory() as d:
                git(d,'init','--bare','-q');git(d,'index-pack','--stdin',data=b);git(d,'fsck','--full','--no-dangling')
                objects=git(d,'cat-file','--batch-all-objects','--batch-check=%(objectname) %(objecttype)').decode().splitlines()
                commits={v.split()[0] for v in objects if v.endswith(' commit')}
                parents={r for o in commits for r in git(d,'show','-s','--format=%P',o).decode().split()}
                need(commits-parents=={oid},'case-specific pack unique tip')
        grades={}
        for oid in c:
            for v,phase,labels in [(1,'linear',LABEL),(2,'revised',['W2/retry','queue/composition'])]:
                q=pk.truth(oid,s,phase)['criteria'];grades.update({(oid,k,v):'pass' if q[k] else 'fail' for k in labels})
        truth[s]=grades
        for k,v in mdslots(normal,s).items():need(v[1]==grades[k],'clean original actual score')
        orig[s]={'independent_member_oids':sorted(actual),'publicly_observed_oids':sorted(published),'unique_case_pack_tips':sorted(sealed),
                 'frozen_fixture_observed_as_own_case_pack':START,'candidate_pack_refs':{oid:val['pack'] for oid,val in c.items()},
                 'protected_slot_count':len(grades),'original_plan_publications':len(h.pubs),'case_exit':p['exit_candidate']['head']}
    git_count=pk.counts
def important(path,seed=2001):
    key=f'- primary / {seed} / loop'; lines=path.read_text().splitlines();return [x for x in lines if x.startswith(key)]
status={}
for f in sorted(apath('disputes').iterdir()):
    md=f/'report.md';cells=mdslots(md,2001);peer=mdslots(md,2002);wrong={k[0] for k in cells if k not in truth[2001]}
    current_valid=sum(r[1]==truth[2001][k] for k,r in cells.items() if k in truth[2001]);unavailable=sum(r[1]=='?' for k,r in cells.items() if k in truth[2001])
    dk=tuple(next((k for k in d if k[0]==orig[2001]['case_exit'] and k[1:] ==('W2/retry',2)),None) for d in (cells,))
    focus=cells.get(dk[0]);report_id=digestfile(md)
    status[f.name]=dict(original_expected=40,receiving_cells=len(cells),present_genuine_slots=len(set(cells)&truth[2001].keys()),
        original_slots_matching_independent_Git_measurement=current_valid,historical_only_genuine_slots=unavailable,
        missing_from_report=sorted({k[0] for k in truth[2001].keys()-cells.keys()}),
        foreign_cells=len(cells.keys()-truth[2001].keys()),foreign_oids=sorted(wrong),
        exact_unaffected_donor_slots=sum(peer[k]==v for k,v in donor_baseline.items() if k in peer),donor_slot_count=len(peer),
        final_revised_W2=focus,recipient_coverage_line=coverage(md),raw_sha256=digestfile(f/'raw.zip'),report_sha256=report_id,
        issues=important(md),strict_stderr_tail=((f/'strict.stderr').read_text().splitlines()[-1][:550] if (f/'strict.stderr').exists() and (f/'strict.stderr').stat().st_size else None))
# Establish chronological independence at the actual checkpoint.
path=apath('disputes/late_action_identity_only/raw.zip');za=Archive(path);rr=parse(z.z.read('runs/primary/2001/loop.json'));rd=parse(za.z.read('runs/primary/2001/loop.json'))
j=z.item(rr['artifacts']['journal']);jj=za.item(rd['artifacts']['journal']);p=z.item(rr['artifacts']['platform'])
fault=next(e for e in j if e['kind']=='fault');a,b=next((x,y) for x,y in zip(j,jj) if x!=y)
need(all(x==y for x,y in zip(j[:fault['seq']],jj[:fault['seq']])) and rr['artifacts']['platform']==rd['artifacts']['platform']
     and sum(x!=y for x,y in zip(j,jj))==1,'prefix equality and isolated changed entry')
w=dict(journal_seq=a['seq'],charged_attempt=a['payload']['attempt'],original_subject=a['payload']['work_request']['subject'],
       damaged_subject=b['payload']['work_request']['subject'],genuine_issue_ns=a['payload']['issued_monotonic_ns'],notice_finish_ns=fault['payload']['finished_monotonic_ns'])
need(w['genuine_issue_ns']>w['notice_finish_ns'],'chronological locality')
timeline=dict(qualified=p['checkpoint_measurement']['qualified'],pre_notice_actions=p['checkpoint_measurement']['preceding_actions'],
          pre_notice_rows=p['checkpoint_measurement']['preceding_events'],receipt_sequence=fault['seq'],qualified_old_git=p['checkpoint_measurement']['candidate'],
          pre_notice_head=fault['payload']['before']['plan_sha256'],receipt_head=fault['payload']['after']['plan_sha256'],
          byte_identical_entire_platform_ref=rr['artifacts']['platform'],unchanged_prefix_hash=sha(enc(j[:fault['seq']])),late_change=w,
          original_first_consumer=coverage(normal),disputed_first_consumer=status['late_action_identity_only']['recipient_coverage_line'])
normaldata=parse(apath('independent-normal-with-report.json').read_bytes());edge=parse(apath('edges-proof.json').read_bytes())
out={'source':'82e880734539bbd8d2af2b0b44fbdcff2b4062f3','M0':M0,'accepted_product_tree':PRODUCT,'design_sha256':'dd24d464d6da9d8ba589873e48652366c6141ea449bfa6066854e361c41be19f',
 'frozen_independent_reference_sha256':digestfile(base.parent/'frozen-m3-reference.json'),'independent_reader_manifest_sha256':digestfile(base.parent/'e2-reader/reader-manifest.json'),
 'legitimate_case_members_and_protected_verdicts':orig,'independent_measured_seed_candidate_phases':git_count,
 'unchanged_membership_archive_sha256':digestfile(apath('membership-repo/docs/private-membership/raw.zip')),
 'unchanged_membership_registration_sha256':digestfile(apath('membership-repo/docs/private-membership/freeze.json')),
 'unchanged_membership_report_sha256':digestfile(normal),'case_matrix':status,'chronological_control':timeline,
 'ordinary':{'private_replicate':normaldata['replicate'],'keys':normaldata['strict_complete_rows'],'disputes':normaldata['disputed'],
  'protected_reports':sum(r['protected_reports'] for r in normaldata['rows'].values()),'public_probe_pairs':normaldata['equal_public_probe_pairs'],
  'independent_comparison':normaldata['report_comparison'],'proof_sha256':digestfile(apath('independent-normal-with-report.json')),
  'native_strict':parse(apath('normal-verify.json').read_bytes()),'ordinary_readback_sha256':normaldata['raw_sha256']},
 'closure_controls':edge,'closure_proof_sha256':digestfile(apath('edges-proof.json'))}
apath('independent-qualification.json').write_bytes(json.dumps(out,sort_keys=True,indent=2).encode()+b'\n')
print('proof',digestfile(apath('independent-qualification.json')))
for n,v in status.items():print(n, v['present_genuine_slots'],v['original_slots_matching_independent_Git_measurement'],v['foreign_cells'],v['exact_unaffected_donor_slots'])
