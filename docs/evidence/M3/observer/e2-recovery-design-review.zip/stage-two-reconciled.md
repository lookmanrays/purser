# M3-B independent design reconciliation

**GO for the pre-implementation design.** The fresh primary resolved the material exposure issue and the receipt provenance error in its immutable addendum. The review covers the local scripted E2 worker interfaces and frozen scoring protocol. Qualification of the eventual implementation and official collection are separate gates.

I checked the Git object for `docs/evidence/M3/e2-recovery-design.md` at `6cc20a0fad50cd058893693739739c1756ec54e9`, SHA-256 `654ff1456a06944fc6fe1d5b31b3c4c1640ac28bb4df7552175b3720a5626701`. The original at `51ad199a68b0f00f04ab31160c5421ef2a317661` hashes to `aef8af31a5f2ef6b7e6ae79a203a5740eb9667659ba657cc28ada985304938bc`. The design is the sole changed path between these two commits.

- Lines 62–70 give each newly admitted public request one charge and keep preparation, actual delivery, and dependent rework distinct. They preserve known failures before transfer, witnessed unexpected content and uncertainty after an ambiguous cut. A committed public plan or authenticated kernel premise independently establishes exposure even after reply loss. Clean exposure and exact rework retain their own necessary observations.
- Line 72 explicitly covers independent worker use of Git, plan/context, available kernel queries, tests and verifier actions. A separately requested scalar W1 check costs one. A planner's private OID lookup to implement a submit and offline Git restoration add zero.
- Line 23 now matches the committed `precollection-controls/fresh-context-readback.json` SHA-256 `d3f7d3bf51302c3e67f4cd75d46b8fabfcc414b50d40a344181741b7c67939cb`. Line 60 identifies the correct sealed inventories and replay.
- I reran `python3.11 -I -B stage-two-probes/readback.py` from this private directory. Its output again hashed to `b3073f8d4321825621cf2ea9e53f45b65e6417c452f5a94ea82f3d93d71e1710`. It reconstructed all 18 receipts from the original six archives, distinguished successful handoff, physical `EPIPE` and rejected W3 bytes at the W1 receiver, and ran the existing W1 check with 28 passing public tests against the restored Git candidate.

This resolves the open issue recorded in `stage-two.md` SHA-256 `e6d8aac805fc3bfe5ec1c4cae961a8c1fd36780c4e78fbf838e0ada539f57d08` against the original `stage-one.md` SHA-256 `f8e6039046f539a978d97b1ad14bc0d069a689ba3419cb227ec7453a42982c73`.
