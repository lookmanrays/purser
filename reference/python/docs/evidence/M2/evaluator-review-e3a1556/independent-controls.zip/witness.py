"""Qualification-side observations of real Git packs, independent of evaluator code."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from zipfile import ZipFile

CONTROL_ROOT = Path(__file__).resolve().parent
FIXTURE = CONTROL_ROOT / 'experiments/manifests/v1'
DEFINITION = json.loads((FIXTURE / 'manifest.json').read_bytes())['fixture']


def git(repo, args, data=None):
    return subprocess.run(
        ['git', '-C', str(repo), *args], input=data, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, check=True,
    ).stdout


def candidate_tree(repo, oid):
    entries = git(repo, ['ls-tree', '-rz', oid]).split(b'\0')
    result = {}
    for record in entries:
        if record:
            properties, path = record.split(b'\t', 1)
            mode, kind, identity = properties.split()
            result[path.decode()] = (mode.decode(), kind.decode(), identity.decode())
    return result


def public_probe():
    from datetime import datetime, timedelta
    from notify.service import NotificationQueue

    seed = int(sys.argv[2])
    rank0 = seed - 1001
    chosen = ['mail', 'push', 'digest', 'inbox', 'desktop']
    primary = chosen[rank0 % 5]
    other = chosen[(rank0 + 1) % 5]
    event_a, event_b, event_c = [f'{seed}-{letter}' for letter in 'abc']
    attempts = 4 + (rank0 % 4)
    base = 2 + (rank0 % 5)
    start = datetime(2001, 1, 1, 12)
    def probe(events, disabled, n, interval):
        queue = NotificationQueue(start)
        count = queue.enqueue(primary, events, disabled, n, interval)
        truth = [] if primary in disabled else list(dict.fromkeys(events))
        elapsed = list(range((n - 1) * interval + 2))
        times = [interval * k for k in range(n)]
        actual = []
        okay = (count == len(truth) * n)
        for tick in elapsed:
            rows = queue.advance(start + timedelta(seconds=tick))
            values = [[item.event_id, item.channel, int((item.due_at - start).total_seconds())] for item in rows]
            expected = ([[event, primary, tick] for event in truth] if tick in times else [])
            if values != expected:
                okay = False
            if values:
                actual.append([tick, values])
        remaining = len(queue.scheduler.get_jobs())
        return {'pass': okay and not remaining, 'count': count, 'nonempty': actual, 'pending': remaining}

    probes = {
        'W1/preferences': [probe([event_a], ds, 1, 1) for ds in [[], [primary], [other]]],
        'W2/retry': [probe([event_a], [], n, i) for n,i in [(1,base),(attempts,base),(attempts,1)]],
        'W3/delivery': [probe(ids, [], 1, 1) for ids in [[event_a,event_b,event_a,event_c,event_b],[event_c,event_c],[]]],
        'queue/composition': [probe([event_a,event_b,event_a,event_c,event_b], ds, attempts, base) for ds in [[],[primary]]],
    }
    return {key: all(line['pass'] for line in value) for key,value in probes.items()}


def witness_archive(archive):
    with ZipFile(archive) as z:
        def read(ref):
            payload = z.read(ref['path'])
            if len(payload) != ref['bytes'] or hashlib.sha256(payload).hexdigest() != ref['sha256']:
                raise ValueError(f'bad reference {ref}')
            return payload

        results = []
        for name in sorted(z.namelist()):
            if not(name.startswith('runs/') and name.endswith('.json')):
                continue
            raw = json.loads(z.read(name))
            journal = json.loads(read(raw['artifacts']['journal']))
            candidates = json.loads(read(raw['artifacts']['candidates']))
            observed = []
            lookups = {}
            with tempfile.TemporaryDirectory() as directory:
                db = Path(directory, 'git')
                subprocess.run(['git', 'init', '-q', str(db)], check=True)
                for oid,entry in candidates.items():
                    git(db, ['index-pack', '--stdin', '--strict'], read(entry['pack']))
                    assert git(db, ['rev-parse', oid+'^{tree}']).decode().strip() == entry['tree']
                start = DEFINITION['commit_sha1']
                for oid in candidates:
                    names = candidate_tree(db, oid)
                    if start in candidates:
                        orig = candidate_tree(db, start)
                        assert git(db, ['rev-parse', start+'^{tree}']).decode().strip() == DEFINITION['tree_sha1']
                        for file in DEFINITION['files']:
                            assert hashlib.sha256(git(db, ['cat-file', 'blob', f"{start}:{file['path']}"])).hexdigest() == file['sha256']
                        allowed = set(DEFINITION['public_paths'])
                        scope = (all(names.get(p) == orig.get(p) for p in (set(names) | set(orig)) - allowed)
                                 and all(names.get(p, (None,))[0] == '100644' for p in allowed))
                    else:
                        raise ValueError('missing fixture start')
                    git(db,['checkout','-q','--detach',oid])
                    environment = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=str(db))
                    run = subprocess.run(
                        [sys.executable, str(Path(__file__).resolve()), 'probe', str(raw['seed'])],
                        cwd=db, env=environment, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
                    statuses = json.loads(run.stdout)
                    statuses['scope/paths'] = scope
                    legacy = subprocess.run(
                        [sys.executable,'-B','-m','unittest','discover','-s',str(FIXTURE / 'input/tests'), '-p','test_*.py'],
                        cwd=db, env=environment, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                    statuses['legacy/compat'] = legacy.returncode == 0
                    lookups[oid] = statuses
            for event in journal:
                payload = event['payload']
                if event['kind'] == 'public_state':
                    if payload['diagnosis'] or (payload['subject']=='W-notify' and payload['to'] in ('done','closed')):
                        observed.append({k:payload.get(k) for k in ('subject','candidate','from','to','diagnosis')} | {'seq':event['seq']})
            results.append({'run':name, 'replicate':raw['replicate'], 'score':raw['score'], 'validity':raw['validity'],
                            'terminal':raw['terminal'], 'actions':sum(e['kind']=='action' for e in journal), 'cost':raw['cost'],
                            'public_observations': observed, 'independent_git_oracles':lookups})
        return results


if __name__ == '__main__':
    if len(sys.argv)>1 and sys.argv[1]=='probe':
        print(json.dumps(public_probe()))
    else:
        args = argparse.ArgumentParser()
        args.add_argument('archive', type=Path)
        print(json.dumps(witness_archive(args.parse_args().archive), indent=2, sort_keys=True))
