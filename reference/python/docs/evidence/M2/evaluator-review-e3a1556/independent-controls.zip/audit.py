"""Assert independent archive/control expectations and retain compact evidence."""
import hashlib, json, sqlite3, sys
from pathlib import Path
from zipfile import ZipFile
from controls import HERE,CANDIDATE,OUT,PLANS,git,dump,SHA

def digest(data):return hashlib.sha256(data).hexdigest()
def load(path):return json.loads(path.read_bytes())

def audit_all():
 summary={'identity':load(HERE/'identity.json'),'fresh':{},'preserved':{},'damage':{}}
 for path in sorted(OUT.iterdir()):
  name=path.name
  result=load(path/'offline.json')
  assert result['report']==result['independent_git']==0 and digest((path/'raw.zip').read_bytes())==result['sha256']
  report=(path/'report.txt').read_text()
  if name.startswith('damaged-'):
   assert result['verify']!=0
   if 'primary-' in name:
    delta=next(x for x in report.splitlines() if x.startswith('| 1001 |') and ' / ' in x)
    assert delta.count('unavailable')==2
    assert 'Purser used 42 clean steps and the plain loop used 24' in report
    assert '| 1001 | complete | done |' in report
   else:
    assert 'The clean step-overhead comparison is inconclusive.' in report
    assert '| loop | done |' in report and 'unqualified' in next(x for x in report.splitlines() if x.startswith('| loop | done |'))
    assert 'yes' in next(x for x in report.splitlines() if x.startswith('| purser | done |'))
   result['reason']=(path/'verify.txt').read_text().splitlines()[-1]
   summary['damage'][name]=result
   continue
  if name.startswith('preserved'):
   assert result['verify']==int(name.endswith('contradictory-cutoff'))
   if name.endswith('false-close'):assert '| 1002 | infrastructure_invalid | harness_failure | yes | yes | no |' in report
   else:assert 'The clean step-overhead comparison is inconclusive.' in report
   summary['preserved'][name]=result
   continue
  assert result['verify']==0
  result['runs']=[]
  independent={row['run']:row for row in load(path/'independent-git.json')}
  with ZipFile(path/'raw.zip') as z:
   pin=json.loads(z.read('freeze.json'));assert pin['source_commit']==SHA and pin['replicate']==83
   def read(ref):
    val=z.read(ref['path']);assert digest(val)==ref['sha256'] and len(val)==ref['bytes'];return json.loads(val)
   for key,observation in independent.items():
    raw=json.loads(z.read(key)); journal=read(raw['artifacts']['journal']); platform=read(raw['artifacts']['platform'])
    actions=[e['payload'] for e in journal if e['kind']=='action']
    assert [a['attempt'] for a in actions]==list(range(1,raw['cost']['steps']+1))
    assert all(raw['cost'][k]==0 for k in ('model_calls','input_tokens','output_tokens','spend_usd_micros'))
    assert raw['artifacts']['model'] is None
    assert raw['inputs']['worktree_head']==SHA and raw['replicate']==83
    checks=0
    for event in journal:
     if event['kind']=='oracle':
      p=event['payload'];actual=observation['independent_git_oracles'][p['candidate']][p['criterion']]
      assert p['verdict']==('pass' if actual else 'fail')
      checks+=1
    one={'key':key,'terminal':raw['terminal'],'validity':raw['validity'],'raw_score':raw['score'],
         'independent_oracle_agreement':checks, 'steps':raw['cost']['steps'],
         'public_facts':[line for line in report.splitlines() if line.startswith(f"| {raw['seed']} | {raw['validity']} |")]}
    if name in ('sibling','sibling-first-wrong','post-repair'):
     expect={'sibling':(False,True,True,True,0),'sibling-first-wrong':(False,False,False,False,1),'post-repair':(True,True,False,False,0)}[name]
     assert tuple(raw['score'][key] for key in ('false_parent_closure','missing_named','caught','correct_parent_closure','extra_diagnoses'))==expect
     if name.startswith('sibling'):
      records=[json.loads(line) for line in (path/'sibling-evidence.jsonl').read_text().splitlines()]
      fault=next(e['payload'] for e in journal if e['kind']=='fault')
      r=records[0];assert r['oid']!=fault['candidate'] and not r['actual']['W1/preferences']
      submitted=[a for a in actions if a['action']=='submit' and a['subject']=='W3' and a['candidate']==r['oid']]
      assert submitted and submitted[0]['return']['state']=='submitted'
      first=next(e for e in journal if e['kind']=='public_state' and e['payload']['diagnosis'])
      assert (first['payload']['subject'],first['payload']['candidate'],first['payload']['diagnosis'])==('W3',r['oid'],r['public_release'])
      one['first_diagnosis']={'subject':'W3','candidate':r['oid'],'target_missing':True,'labels':r['public_release'],'fault_origin':fault['candidate']}
     else:
      tables=observation['independent_git_oracles']
      seq=[a['candidate'] for a in actions if a['action']=='submit' and a['subject']=='W1']
      parent=[a['candidate'] for a in actions if a['action']=='submit' and a['subject']=='W-notify'][-1]
      assert len(seq)==2 and not tables[seq[0]]['W1/preferences'] and tables[seq[1]]['W1/preferences'] and not tables[parent]['W1/preferences']
      one.update(original=seq[0],repaired=seq[1],regressed_parent=parent)
    if name=='done':
     trace=read(platform['treatment_trace'])
     assert all(r['state']=='done' for r in trace['plan'].values())
     assert all(observation['independent_git_oracles'][trace['plan']['W-notify']['candidate']].values())
     assert '| loop | done |' in report
    if name=='healthy':
     assert raw['terminal']=='done' and raw['validity']=='complete'
     if raw['track']=='clean':assert raw['cost']['steps']==(24 if raw['arm']=='loop' else 42)
     assert 'Purser used 42 clean steps and the plain loop used 24' in report
    if (path/'barrier.json').exists():
     b=load(path/'barrier.json'); resume=load(path/'resume.json')
     assert resume['child_exit']==-9 and resume['participant_invocations']==1 and resume['resume_count']==2
     assert raw['validity']=='infrastructure_invalid' and raw['score'] is None and platform['cost_basis']=='observed_lower_bound'
     a=actions[-1]; assert a['attempt']==b['attempt'] and a['subject']==b['subject'] and a['actor']==b['actor'] and a['candidate']==b['candidate'] and 'return' not in a
     assert a['before']==b['before'] and a['after']==platform['final_public']
     before,after=(read(a[k]['view']) for k in ('before','after'))
     oid=b['candidate'];work=b['work'];self_work=a['subject']
     recovered=[e['payload'] for e in journal if e['kind']=='public_state' and e['payload'].get('source_action')==a['attempt']]
     actual_trace=read(platform['treatment_trace'])
     if (path/'killed-plan.json').exists():
      disk=load(path/'killed-plan.json')
      assert disk==after==actual_trace['plan']
      if name.endswith('after'):
       assert recovered[0]['evidence']['publication']==disk[work]['_publication']
       assert disk[work]['state']=='done' and before[work]['state']=='submitted'
       assert observation['independent_git_oracles'][oid]['scope/paths'] is False
       assert '| 1002 | infrastructure_invalid | harness_failure | yes | yes | no |' in report
      else:
       assert not recovered and after==before
       if 'repeat' in name: assert disk[work]['_publication']['attempt']==a['attempt']-1 and disk[work]['_publication']['candidate']==oid
     else:
      with sqlite3.connect(f"file:{path/'killed.sqlite'}?mode=ro",uri=True) as con:
       persisted=[r[0].decode() for r in con.execute('select body from events order by revision')]
      assert persisted==actual_trace['original_events']
      assert json.loads(persisted[-1])['revision']==a['after']['revision']
      prop=a['proposal'];assert prop['body']==b['proposal']
      hits=[json.loads(s)['data'] for s in persisted if json.loads(s)['type']=='ProposalReceipted' and json.loads(s)['data']['digest']==prop['digest']]
      if name.endswith('after'):
       assert len(hits)==len(recovered)==1
       durable=recovered[0]['evidence']['receipt'];assert durable==b['receipt']
       assert all(durable[k]==hits[0][k] for k in ('proposal_id','digest','actor_id','code','disposition'))
       if 'verifier' in name:assert recovered[0]['diagnosis']==['W2/retry'] and durable['disposition']=='admitted'
       elif 'close-' in name:assert before[work]['state']=='submitted' and after[work]['state']=='closed' and all(observation['independent_git_oracles'][oid].values())
       else:assert recovered[0]['diagnosis']==['W1/preferences'] and durable['code']=='closure_blocked'
      else:
       assert not hits and not recovered and before==after
       if 'repeat' in name:
        prior=actions[-2];assert prior['proposal']['digest']!=prop['digest'] and prior['candidate']==oid and prior['actor']==a['actor'] and prior['return']['receipt']['code']=='closure_blocked'
     one.update(interrupted_attempt=a['attempt'],actor=a['actor'],work=work,candidate=oid,
                before_state=before[work]['state'],after_state=after[work]['state'],
                recovered=[{'from':v['from'],'to':v['to'],'diagnosis':v['diagnosis'],'source_action':v['source_action']} for v in recovered])
    result['runs'].append(one)
  summary['fresh'][name]=result
 assert set(summary['fresh'])==set(PLANS)
 summary['fresh_participant_count']=sum(len(r['runs']) for r in summary['fresh'].values())
 summary['sigkill_controls']=sum((d/'resume.json').exists() for d in OUT.iterdir())
 summary['fresh_independent_oracle_comparisons']=sum(row['independent_oracle_agreement'] for r in summary['fresh'].values() for row in r['runs'])
 return summary
if __name__=='__main__':
 summary=audit_all(); dump(HERE/'qualification.json',summary)
 print({k:summary[k] for k in ('fresh_participant_count','sigkill_controls','fresh_independent_oracle_comparisons')})
