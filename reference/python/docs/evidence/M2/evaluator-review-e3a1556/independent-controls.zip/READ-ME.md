# Independent scripted E1 qualification

**PASS** for the trusted local M2 scripted evaluator at `e3a155633058cd20274ce5e9cfaca224b41f5b5b`, compared with `163badfb67311ad6049b41faacd2a7f1a029d18b`. The independent code review found zero material issues (P1/P2/P3 all zero). This reviewer used a private clone, authored controls from the immutable v1 protocol, and independently exercised the queue and Git objects. The registration-only private checkpoint is `c7108b342f797f166661531abd16f272b8ca604c`. All fresh controls used nonstudy replicate 83 and zero model calls, tokens and spend. The controlled participant responses and process deaths are fixture conditions. These observations qualify the evaluator and do not establish the study outcome, the separate feature gate, real-model isolation or production behavior.

The environment used Darwin 25.5.0, Python 3.11.15, SQLite 3.53.1 and Git 2.50.1. The review followed the changed producer, capture, intervention binding, score, recovery, offline validation and report, through the public Plan file or original SQLite event bytes, Git pack and consumer. Normal publication and input staging remained executable under the supported local filesystem. Identity and raw artifact digests are in `qualification.json`.

## Findings from the controlled attempts

- The 19 fresh attempts include 10 real SIGKILLs. Each killed process released one participant. Two subsequent calls through the collector preserved that single invocation. The incomplete records kept null raw scores and lower-bound time.
- A clean plan, Purser and equal-verifier control took 24, 42 and 42 steps. The plan’s persisted `done` alias and `closed` both produced genuine all-criteria closures. Normal primary neighbors also retained paired measurements.
- After an unchanged W1 fault, W3 submitted a distinct descendant still failing W1/preferences. Its first explicit W1 diagnosis counted. A wrong first W2 label followed by W1 kept missing-named and caught false, with one extra. A different run genuinely repaired W1, later regressed it and closed the faulty descendant. Both the adverse closure and the loss of caught credit survived offline verification.
- Plan commit-before-reply produced the adverse `submitted → done` on the exact scope-failing candidate. Its before-write counterpart had no closure. SQLite before/after admission produced zero/one genuine `WorkClosed` event at the successful parent boundary. Before/after rejected closure and admitted failing verifier controls distinguished no current result from the exact durable receipt and its released diagnosis. The earlier same-subject, same-candidate, same-actor plan/SQLite decisions were not assigned to the interrupted later attempt.
- The independent checker restored every candidate from its retained Git pack and checked the start hashes. It compared 234 archived criterion verdicts with its own queue probes, immutable public tests and whole-tree/mode comparison. Both offline public commands accepted all 15 fresh coherent archives, including incomplete ones. Six independently damaged archives produced a report with a discrepancy and a failing strict verifier. Missing or contradictory clean endpoints withheld the overhead comparison. Contradictory or missing primary terminal evidence withheld paired cost, with the healthy clean comparison retained.
- Replaying the two original independent negative controls preserved the adverse `done` and disqualified the contradictory cutoff. Twenty-four selected candidate tests also passed, including the registered intervention overlays and changed Git mode/byte controls, real collector concurrency, atomic publication recovery, count/clock boundaries, and source-specific outcomes.

A local scripted participant and trusted archive writer are assumed. No model-authored code, hostile process containment, deployed service or study replicate 2 was exercised here.

## Reproduction

The outer private working directory contains scripts, the independently authored pre-candidate plan, the pin, raw witnesses, and `qualification.json`. Each fresh case’s directory under `cases/` has `raw.zip`, both offline outputs, independent Git truth and the collector transcript. Killed cases also retain the last durable progress, Plan bytes or SQLite backup at process death, external barrier observation, and resume counts. The compact retention bundle carries representative raw archives, all case summaries, source proofs from the ten crashes, and the private checkpoint. The baseline Git repository already carries the inherited negative controls at the comparison base.

For a fresh reproduction put the four Python scripts next to a local clone named `candidate`. Recreate the frozen protocol directory alongside the clone before running the controls. For example, in that fresh directory execute the following commands. The private pin commit created by a new reproduction may have a different commit timestamp. Measured clocks naturally differ.

```sh
git -C candidate checkout --detach e3a155633058cd20274ce5e9cfaca224b41f5b5b
git -C candidate archive 163badfb67311ad6049b41faacd2a7f1a029d18b experiments/manifests/v1 docs/evidence/M2/evaluator-review-3785d19 | tar -xf -
python3.11 -B controls.py init
for c in healthy done sibling sibling-first-wrong post-repair; do
  python3.11 -B controls.py worker "$c"
  python3.11 -B offline.py run "$c"
done
for c in plan-before plan-after sqlite-before sqlite-after sqlite-verifier-before sqlite-verifier-after sqlite-close-before sqlite-close-after sqlite-repeat-before plan-repeat-before; do
  python3.11 -B controls.py kill "$c"
  python3.11 -B offline.py run "$c"
done
python3.11 -B offline.py conflict damaged-conflicting-terminal
python3.11 -B offline.py missing damaged-missing-terminal
python3.11 -B offline.py missing-after damaged-missing-parent-endpoint
python3.11 -B offline.py clock-endpoint damaged-missing-participant-exit
python3.11 -B offline.py primary-conflict damaged-primary-clock-conflict
python3.11 -B offline.py primary-missing damaged-primary-missing-terminal
for c in done-false-close contradictory-cutoff; do
  mkdir -p "cases/preserved-$c"
  cp "docs/evidence/M2/evaluator-review-3785d19/$c.zip" "cases/preserved-$c/raw.zip"
  python3.11 -B offline.py run "preserved-$c"
done
python3.11 -B audit.py
(cd candidate && python3.11 -B -m unittest -v tests.test_e1_outcomes tests.test_e1_intervention tests.test_e1_collection tests.test_e1_accounting.ExitAccounting)
```

A case uses the real `suite.collect_cases` on one or more preselected private keys and reloads the committed registration. Entry to each selected trial goes through `run.attempt`. Full study scheduling and execution are outside these controls. The recorded public offline commands are `python3.11 -B -m experiments.e1 report CASE` and `python3.11 -B -m experiments.e1 verify CASE`. The independent checker command is `python3.11 -B witness.py CASE/raw.zip`.
