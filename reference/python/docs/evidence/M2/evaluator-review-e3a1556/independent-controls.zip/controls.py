"""Private protocol controls for the exact scripted evaluator; never run as a study."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import sqlite3
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
CANDIDATE = HERE / 'candidate'
OUT = HERE / 'cases'
PIN_DIR = CANDIDATE / 'private-qualification-only'
SHA = 'e3a155633058cd20274ce5e9cfaca224b41f5b5b'
PLANS = {
 'healthy': [('clean',1001,1,'loop'), ('clean',1001,1,'purser'),('clean',1001,1,'loop_equal_verifier'),('primary',1001,1,'purser'),('primary',1001,1,'loop')],
 'done': [('clean',1001,1,'loop')],
 'sibling': [('primary',1003,3,'loop')],
 'sibling-first-wrong': [('primary',1003,3,'loop')],
 'post-repair': [('primary',1003,3,'loop')],
 'plan-before': [('primary',1002,2,'loop')],
 'plan-after': [('primary',1002,2,'loop')],
 'sqlite-before': [('primary',1003,3,'purser')],
 'sqlite-after': [('primary',1003,3,'purser')],
 'sqlite-close-before': [('clean',1001,1,'purser')],
 'sqlite-close-after': [('clean',1001,1,'purser')],
 'sqlite-repeat-before': [('primary',1003,3,'purser')],
 'plan-repeat-before': [('primary',1003,3,'loop')],
 'sqlite-verifier-before': [('primary',1001,1,'purser')],
 'sqlite-verifier-after': [('primary',1001,1,'purser')],
}
sys.path.insert(0,str(CANDIDATE))
from experiments.e1 import suite, run, arms, purser_arm
from experiments.e1 import report

def git(*args):
 return subprocess.run(['git','-C',str(CANDIDATE),*args],capture_output=True,text=True,check=True).stdout.strip()

def dump(path,obj):
 path.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')

def init():
 assert git('rev-parse','HEAD')==SHA
 assert not git('status','--porcelain')
 PIN_DIR.mkdir()
 suite.freeze_series(PIN_DIR,replicate=83,reason='Private independent nonstudy qualification under the scripted protocol')
 assert json.loads((PIN_DIR/'freeze.json').read_text())['source_commit']==SHA
 git('add','private-qualification-only/freeze.json')
 git('-c','user.name=Private Qualifier','-c','user.email=qualifier@example.invalid','commit','-qm','Retain private nonstudy qualifier pin')
 OUT.mkdir()
 dump(HERE/'identity.json',{'candidate':SHA,'comparison_base':'163badfb67311ad6049b41faacd2a7f1a029d18b','candidate_parent':git('rev-parse',SHA+'^'),'private_pin_commit':git('rev-parse','HEAD'),'python':sys.version,'git':git('--version'),'sqlite':sqlite3.sqlite_version,'kernel':os.uname().release,'pin_sha256':hashlib.sha256((PIN_DIR/'freeze.json').read_bytes()).hexdigest()})
 for case in PLANS:
  dest=OUT/case
  dest.mkdir()
  shutil.copyfile(PIN_DIR/'freeze.json',dest/'freeze.json')

def worker(case,resume=False):
 units=PLANS[case]
 dest=OUT/case
 checked, registration=suite.committed_registration(PIN_DIR)
 assert SHA==checked['source_commit'] and checked['replicate']==83
 real_attempt=run.attempt
 def counted(*args,**kwargs):
  with (dest/'starts.txt').open('a') as counts:
   print(args[3:6], file=counts, flush=True)
  if resume: raise AssertionError('resumed participant twice')
  return real_attempt(*args,**kwargs)
 def pause(when, work, rows=None, proposal=None, receipt=None):
  track,seed,rank,arm=units[0]
  stage=dest/f'.attempt-{track}-{seed}-{arm}'
  progress=json.loads((stage/'progress.json').read_text())
  last=[e['payload'] for e in progress['rows'] if e['kind']=='action'][-1]
  assert 'return' not in last
  proof={'when':when,'work':work,'subject':last['subject'],'actor':last['actor'],'attempt':last['attempt'],'candidate':last['candidate'],'proposal':proposal,'receipt':receipt,'before':last.get('before')}
  if rows is not None: proof['public_row']=rows[work]
  if arm=='purser':
   with sqlite3.connect(f"file:{stage/'trial/kernel.sqlite'}?mode=ro",uri=True) as db:
    proof['sqlite_tail']=[json.loads(row[0]) for row in db.execute('SELECT body FROM events ORDER BY revision DESC LIMIT 2')]
  dump(dest/'barrier.json',proof)
  while True:
   time.sleep(0.1)
 if 'repeat' in case:
  real_call=run.Driver.call
  def repeat(driver, action, work, actor, inputs, operation, oid=None):
   answer=real_call(driver,action,work,actor,inputs,operation,oid)
   if (actor,work)==('closure','W1'):
    real_call(driver,action,work,actor,inputs,operation,oid)
   return answer
  run.Driver.call=repeat
 if case=='done':
  original=arms.Plan.update
  def done(plan,work,**fields):
   if fields.get('state')=='closed':fields['state']='done'
   return original(plan,work,**fields)
  arms.Plan.update=done
 elif case.startswith('sibling'):
  check=run.self_review
  implement=run.implement
  count=0
  def controlled_review(repo,oid,root,work):
   nonlocal count
   value=check(repo,oid,root,work)
   if work=='W1': value['missing']=[]
   if work=='W3':
    count+=1
    raw=subprocess.run([sys.executable,str(HERE/'witness.py'),'probe','1003'],cwd=root,env=dict(os.environ,PYTHONPATH=str(root),PYTHONDONTWRITEBYTECODE='1'),check=True,capture_output=True,text=True)
    real=json.loads(raw.stdout)
    assert not real['W1/preferences'] and real['W3/delivery']
    if count==1: value['missing']=['W2/retry'] if case=='sibling-first-wrong' else ['W1/preferences']
    if count==2 and case=='sibling-first-wrong': value['missing']=['W1/preferences']
    with (dest/'sibling-evidence.jsonl').open('a') as f:
     print(json.dumps({'ordinal':count,'public_release':value['missing'],'oid':oid,'actual':real}),file=f)
   return value
  def edit(root,work):
   implement(root,work)
   if work=='W2':
    implement(root,'W1')
  run.self_review,run.implement=controlled_review,edit
 elif case=='post-repair':
  implement=run.implement
  def regress(root,work):
   implement(root,work)
   if work=='W2':
    (root/'notify/preferences.py').write_bytes((HERE/'experiments/manifests/v1/input/notify/preferences.py').read_bytes())
  run.implement=regress
 elif case.startswith('plan-'):
  original=arms.Plan.update
  closes=0
  def intercepted(plan,work,**fields):
   nonlocal closes
   if 'repeat' in case and plan.invocation and plan.invocation['actor']=='closure' and work=='W1':
    closes+=1
    if closes==2: pause('before next same-candidate plan decision',work,plan.read())

   if (plan.invocation and plan.invocation['actor']=='closure' and work=='W-notify'):
    if case=='plan-before':
     pause('before plan durable declaration',work,plan.read())
    fields['state']='done'
    original(plan,work,**fields)
    pause('after plan durable declaration before reply',work,plan.read())
   return original(plan,work,**fields)
  arms.Plan.update=intercepted
 elif case.startswith('sqlite-'):
  admit=purser_arm.admit
  closes=0
  def intercepted(store,binding,proposal,**kwargs):
   nonlocal closes
   role,op=binding['role'],proposal['ops'][0]
   wanted=(role=='verifier' and op.get('verdict')=='fail') if 'verifier' in case else (role=='closure' and op.get('id')=='W1')
   if 'close-' in case: wanted=role=='closure' and op.get('id')=='W-notify'
   if 'repeat' in case and wanted:
    closes+=1
    wanted=closes==2
   if wanted:
    work='W-notify' if 'close-' in case else 'W2' if 'verifier' in case else 'W1'
    if case.endswith('before'):pause('before sqlite commit',work,proposal=proposal)
    result=admit(store,binding,proposal,**kwargs)
    pause('after sqlite commit before reply',work,proposal=proposal,receipt=result)
   return admit(store,binding,proposal,**kwargs)
  purser_arm.admit=intercepted
 suite.collect_cases(dest,checked,registration,units,counted)

def kill_resume(case):
 dest=OUT/case
 proc=subprocess.Popen([sys.executable,__file__,'worker',case],cwd=CANDIDATE,stdout=(dest/'before.log').open('w'),stderr=subprocess.STDOUT)
 deadline=time.monotonic()+85
 while not (dest/'barrier.json').exists():
  if proc.poll() is not None: raise RuntimeError(f'child exited {proc.returncode}, {case}')
  if time.monotonic()>deadline:proc.kill();raise RuntimeError('unreached death barrier')
  time.sleep(.05)
 os.kill(proc.pid,signal.SIGKILL)
 assert proc.wait()==-signal.SIGKILL
 units=PLANS[case]
 t,s,r,a=units[0]
 stage=dest/f'.attempt-{t}-{s}-{a}'
 shutil.copyfile(stage/'progress.json',dest/'killed-progress.json')
 work=stage/'trial'
 if (work/'plan.json').exists():shutil.copyfile(work/'plan.json',dest/'killed-plan.json')
 if (work/'kernel.sqlite').exists():
  with sqlite3.connect(f"file:{work/'kernel.sqlite'}?mode=ro",uri=True) as src,sqlite3.connect(dest/'killed.sqlite') as dst:src.backup(dst)
 starts=(dest/'starts.txt').read_bytes()
 worker(case,resume=True)
 worker(case,resume=True)
 assert starts==(dest/'starts.txt').read_bytes()
 dump(dest/'resume.json',{'signal':'SIGKILL','child_exit':proc.returncode,'participant_invocations':len(starts.splitlines()),'resume_count':2,'archive_sha256':hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest()})

if __name__=='__main__':
 args=argparse.ArgumentParser();args.add_argument('cmd',choices=['init','worker','kill']);args.add_argument('case',nargs='?',choices=list(PLANS)); parsed=args.parse_args()
 if parsed.cmd=='init':init()
 elif parsed.cmd=='kill':kill_resume(parsed.case)
 else:worker(parsed.case)
