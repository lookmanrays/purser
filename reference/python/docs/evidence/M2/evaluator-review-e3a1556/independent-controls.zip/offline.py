"""Construct case-local loss/conflict and run both public offline consumers."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile
from controls import CANDIDATE, OUT, HERE, dump

def canonical(data):
 return (json.dumps(data,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n').encode()
def mutate(name,mode):
 source=OUT/'healthy/raw.zip'
 dest=OUT/name;dest.mkdir(exist_ok=True)
 with zipfile.ZipFile(source) as inp,zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as out:
  members={info.filename:inp.read(info.filename) for info in inp.infolist()}
  primary=mode.startswith('primary-')
  mode=mode.removeprefix('primary-')
  raw_key='runs/primary/1001/purser.json' if primary else 'runs/clean/1001/loop.json'
  raw=json.loads(members[raw_key])
  def change(kind,func):
   object=json.loads(members[raw['artifacts'][kind]['path']]);func(object)
   payload=canonical(object); digest=hashlib.sha256(payload).hexdigest(); path=f'objects/{digest}.json'
   raw['artifacts'][kind]={'bytes':len(payload),'path':path,'sha256':digest};members[path]=payload
  if mode=='conflict':
   change('platform',lambda x:x.__setitem__('budget_reason','time_limit'))
  elif mode=='missing':
   change('journal',lambda x:x.pop())
  elif mode=='missing-after':
   def no_endpoint(rows):
    last=[e['payload'] for e in rows if e['kind']=='action'][-1]
    last.pop('after')
   change('journal',no_endpoint)
  elif mode=='clock-endpoint':
   change('platform',lambda x:x.pop('participant_exit'))
  else:raise AssertionError(mode)
  members[raw_key]=canonical(raw)
  for path,payload in members.items():
   member=zipfile.ZipInfo(path,date_time=(1980,1,1,0,0,0));member.compress_type=zipfile.ZIP_DEFLATED
   out.writestr(member,payload)
  (dest/'freeze.json').write_bytes(members['freeze.json'])
def offline(name):
 dest=OUT/name
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
 evidence={}
 for command in ('report','verify'):
  with (dest/(command+'.txt')).open('w') as output:
   done=subprocess.run([sys.executable,'-B','-m','experiments.e1',command,str(dest)],cwd=CANDIDATE,env=env,stdout=output,stderr=subprocess.STDOUT)
  evidence[command]=done.returncode
 witness=subprocess.run([sys.executable,'-B',str(HERE/'witness.py'),str(dest/'raw.zip')],cwd=HERE,capture_output=True,text=True,env=env)
 if witness.returncode==0: (dest/'independent-git.json').write_text(witness.stdout)
 else:(dest/'independent-git-error.txt').write_text(witness.stderr)
 evidence['independent_git']=witness.returncode
 evidence['sha256']=hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest()
 dump(dest/'offline.json',evidence)
 if evidence['report'] or evidence['independent_git']:raise RuntimeError(evidence)
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('kind');p.add_argument('name');a=p.parse_args()
 if a.kind!='run':mutate(a.name,a.kind)
 offline(a.name)
