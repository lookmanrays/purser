"""Preimplementation independent E3 oracle. Its inputs are ordered, observed public/physical facts."""
from itertools import product
import hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
ARMS=('loop','purser','loop_equal_verifier')
KINDS=frozenset(('plan','context','edit','check','submit','observe','decide','effect','reconcile'))
START='55686bd5152e10a53dfdc2c003974ea405a3a075'
TARGET='5828b906ebc2aca8bbaf69c8d50fa8eb1295af7b'
def units():
    for track,seeds in [('primary',range(3001,3021)),('clean',(3001,)),('inconclusive-observation',(3001,))]:
        for seed in seeds:
            j=seed-3001
            shift=(j+3-1)%3
            for arm in ARMS[shift:]+ARMS[:shift]:
                mode={'clean':'acknowledged','inconclusive-observation':'inconclusive'}.get(track,('landed_ack_lost','unlanded_writer_finished')[j%2])
                yield dict(track=track,seed=seed,arm=arm,rank=j+1,fault_slot=mode,semantic_effect='notify-'+str(seed))
def identify(f):
    """Judge information available to the participant at observation delivery, independently of hidden truth."""
    if not (f.get('bound_subject') and f.get('qualified_repo') and f.get('stable_snapshot') and f.get('writer_quiescent') and f.get('protected_retention_intact')):return 'unknown'
    if f.get('receipt')=='matching' and f.get('target_verified') and f.get('tip_consistent_with_evidence'):return 'landed'
    if f.get('receipt')=='absent' and f.get('tip')==START and f.get('no_possible_unrecorded_write'):return 'unlanded'
    return 'unknown'
def cost(events,clock):
    ids={};more=[]
    for i,e in enumerate(events):
        if e['kind']!='action':continue
        assert e['action'] in KINDS and e['invocation']
        if e['invocation'] in ids:
            # Same original public invocation delivered twice. An actual second call has its own occurrence.
            assert e.get('transport_frame_only') and e['action']==ids[e['invocation']][0]
        else:
            assert not e.get('transport_frame_only')
            ids[e['invocation']]=(e['action'],i);more.append((e['invocation'],e['action']))
    if clock is None:return dict(steps=len(ids),elapsed_ns=None,wall_ns=None,offline_ns=None,charged=more)
    start,end=clock['start'],clock['end'];spans=sorted(clock.get('offline',[]))
    assert type(start)==type(end)==int and end>=start
    last=start;pause=0
    for a,b in spans:
        assert last<=a<=b<=end
        pause+=b-a;last=b
    return dict(steps=len(ids),elapsed_ns=end-start-pause,wall_ns=end-start,offline_ns=pause,charged=more)
def sum_known(values):
    return sum(values) if all(v is not None for v in values) else None
def score(case):
    """The wire reader is responsible for native originals and byte/actor attribution, never participant scores."""
    ev=case['events'];price=cost(ev,case['clock']); track=case['track']
    first=case.get('original_writer'); complete=bool(case.get('complete_external_chain'))
    public=[(i,e) for i,e in enumerate(ev) if e['kind']=='public_disposition']
    obs={e['id']:(i,identify(e['facts'])) for i,e in enumerate(ev) if e['kind']=='delivered_observation'}
    paid=[(i,e) for i,e in enumerate(ev) if e['kind']=='action' and e['action']=='effect' and e.get('released_to_writer') and not e.get('transport_frame_only')]
    # Each index is a separate physical publication captured by the authoritative external source. The input
    # binds a task's original private fixture and writer, including later attempts using another transport key.
    pubs=[(i,e) for i,e in enumerate(ev) if e['kind']=='physical_ref_commit' and e.get('belongs_to_semantic_slot') and e['old']!=e['new'] and e['ref']=='refs/heads/notify']
    assert len({e['physical_publication'] for i,e in pubs})==len(pubs)
    count=len(pubs) if complete else None
    original=[e for i,e in pubs if e['writer']==first]
    confirmations=[(i,e) for i,e in enumerate(ev) if e['kind']=='original_writer_exit' and e['writer']==first and e.get('quiescent')]
    truth='landed' if any(e['old']==START and e['new']==TARGET for e in original) else 'unlanded' if complete and confirmations and first is not None else 'unknown'
    cutoff_idx=next((i for i,e in enumerate(ev) if e['kind']=='public_completion'),len(ev))
    retry_at=min((i for i,_ in paid[1:]),default=len(ev))
    first_assertion=next(((i,e) for i,e in public if e['value'] in ['unlanded','landed']),None)
    reported=(first_assertion[1]['value'] if first_assertion else public[-1][1]['value'] if public else 'none')
    facts_before=False
    if first_assertion:
        i,claim=first_assertion
        facts_before=bool(any(eid in obs and obs[eid][0]<i and obs[eid][1]==claim['value'] for eid in claim['attributed_observations']) and i<=min(cutoff_idx,retry_at))
    newauth=[]
    for idx,issue in paid[1:]:
        cut=first_assertion[0] if first_assertion and reported=='unlanded' and facts_before else len(ev)
        auth=next((e for j,e in enumerate(ev) if cut<j<idx and e['kind']=='authorized' and issue['physical_attempt']!=paid[0][1]['physical_attempt'] and e['physical_attempt']==issue['physical_attempt'] and e['semantic']==case['intent'] and e['current_grant']),None)
        if auth is None:newauth.append(issue['physical_attempt'])
    endpoint=any(e['new']==TARGET and e['old']==START for i,e in pubs) and case.get('terminal_success') is True
    resolved=bool(endpoint and price['steps']<=96 and price['elapsed_ns']<=60_000_000_000) if complete and case.get('terminal_observed') and price['elapsed_ns'] is not None else None
    manual=case.get('manual_repair');stuck=case.get('stuck_requires_manual')
    correct=None if truth=='unknown' or not case.get('complete_public_history') else (reported==truth and facts_before and not newauth)
    duplicate=None if count is None else max(0,count-1)
    stress_ok=None
    if track=='inconclusive-observation':
        stress_ok=bool(any(e['value']=='unknown' and e.get('actionable_reason') for i,e in public) and not paid[1:] and not first_assertion) if case.get('complete_public_history') else None
    return dict(original_truth=truth,original_report=reported,justified_in_order=facts_before,correct_reconciliation=correct,effect_count=count,duplicate_count=duplicate,resolved_by_budget=resolved,manual_repair=manual,stuck_requires_manual=stuck,unfresh_retry=newauth,physical_count_lower_bound=len(pubs),stress_held_pending=stress_ok,cost=price)
def aggregate(rows):
    def evaluate_arm(arm):
        rr=[rows.get(('primary',seed,arm)) for seed in range(3001,3021)]
        known=[r for r in rr if r is not None]
        duplicate=sum_known([r['duplicate_count'] if r else None for r in rr])
        correct=sum_known([r['correct_reconciliation'] if r else None for r in rr])
        wrong=any(r['correct_reconciliation'] is False or r['resolved_by_budget'] is False or (r['duplicate_count'] or 0)>0 or r['physical_count_lower_bound']>1 for r in known)
        complete=len(known)==20 and all(r['correct_reconciliation'] is not None and r['resolved_by_budget'] is not None and r['duplicate_count'] is not None for r in known)
        disadv=any((r['duplicate_count'] or 0)>0 or r['physical_count_lower_bound']>1 or r['stuck_requires_manual'] is True for r in known)
        assessed=len(known)==20 and all(r['duplicate_count'] is not None and r['stuck_requires_manual'] is not None for r in known)
        return dict(available=len(known),denominator=20,duplicates=duplicate,correct=correct,absolute=False if wrong else True if complete else None,original_no_advantage=True if disadv else False if assessed else None)
    arms={a:evaluate_arm(a) for a in ARMS}
    pairs={}
    for u in units():
        tr=u['track'];seed=u['seed'];key=(tr,seed);p=rows.get((tr,seed,'purser'))
        if key in pairs:continue
        compare={}
        for arm in ('loop','loop_equal_verifier'):
            b=rows.get((tr,seed,arm))
            compare[arm]={k:p['cost'][k]-b['cost'][k] if p['cost'][k] is not None and b['cost'][k] is not None else None for k in ('steps','elapsed_ns')} if p and b else None
        pairs[key]=compare
    clean=[rows.get(('clean',3001,a)) for a in ('purser','loop')]
    eligible=all(r is not None and r['resolved_by_budget'] is True and r['duplicate_count']==0 for r in clean)
    flag=clean[0]['cost']['steps']>2*clean[1]['cost']['steps'] if eligible else None
    return dict(arms=arms,clean_overhead=flag,paired_costs={str(k[0])+'/'+str(k[1]):v for k,v in pairs.items()})
