"""Independent adapter for original E3 public calls, native witnesses and Git packs."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
import e3_reference as frozen

START, TARGET=frozen.START, frozen.TARGET
BRANCH='refs/heads/notify'
PATHS=['notify/delivery.py','notify/preferences.py','notify/retry.py']
TREES={START:'2afea0fdd3478d29447a40bde8007266c468c72b',TARGET:'a0766bda2c15fcf78c6fd1704892c9d6d9af1286'}
def canonical(v): return json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()
def sha(v): return hashlib.sha256(v).hexdigest()
def tagged(tag,v): return sha(('purser/'+tag+'/v1\0').encode()+canonical(v))
def rows(text):return [tuple(x.split('\t',1)) for x in text.splitlines()]
def exactly_one(seq):
    seq=list(seq)
    assert len(seq)==1,seq
    return seq[0]

class ByteSource:
    def __init__(self,root):
        self.root=Path(root)
        self.z=zipfile.ZipFile(root) if self.root.is_file() else None
        if self.z: assert len(self.z.namelist())==len(set(self.z.namelist()))
        self.known=set()
        self.packs={}
    def read(self,name): return self.z.read(name) if self.z else (self.root/name).read_bytes()
    def bytes(self,r):
        assert set(r)=={'sha256','path','bytes'} and r['path'].startswith('objects/'+r['sha256']+'.')
        b=self.read(r['path']);assert len(b)==r['bytes'] and sha(b)==r['sha256']
        self.known.add(r['path'])
        return b
    def j(self,r):return json.loads(self.bytes(r))
    def objects(self,mapping):
        assert set(mapping)==set(TREES),set(mapping)
        for oid,s in mapping.items():
            assert s['start']==START and s['tree']==TREES[oid] and s['parent']==(None if oid==START else START)
            pack=self.bytes(s['pack']);key=(oid,sha(pack))
            if key in self.packs:continue
            with tempfile.TemporaryDirectory(prefix='m4-read-native-') as raw:
                repo=Path(raw)
                def git(*args,data=None):
                    p=subprocess.run(['git','--git-dir='+str(repo),*args],input=data,capture_output=True,env={'PATH':'/usr/bin:/bin','LC_ALL':'C','TZ':'UTC'})
                    assert p.returncode==0,(args,p.stderr.decode())
                    return p.stdout
                git('init','--bare','--quiet')
                git('index-pack','--stdin',data=pack)
                git('fsck','--strict','--no-reflogs','--no-progress',oid)
                assert git('rev-parse',oid+'^{tree}').decode().strip()==TREES[oid]
                parents=git('rev-list','--parents','-1',oid).decode().split()
                assert parents==([oid] if oid==START else [oid,START])
                checked={}
                if oid==TARGET:
                    assert sorted(git('diff','--name-only',START,TARGET).decode().splitlines())==PATHS
                    for path,ret in ((PATHS[0],b'return tuple(dict.fromkeys(event_ids))'),(PATHS[1],b'return channel not in disabled'),(PATHS[2],b'return tuple(k * base for k in range(attempts))')):
                        old=git('show',START+':'+path);new=git('show',TARGET+':'+path)
                        assert old.rsplit(b'    return ',1)[0]+b'    '+ret+b'\n'==new,(path,new)
                        mode=git('ls-tree',oid,'--',path).decode().split()[0];assert mode=='100644'
                        checked[path]=sha(new)
                self.packs[key]={'tree':TREES[oid],'parent':s['parent'],'checked_blobs':checked}

def current_time(v):return datetime.fromisoformat(v.replace('Z','+00:00'))
def native(src,ref,binding,receipt):
    f=src.j(ref); assert (f['repository_instance'],f['branch'],f['receipt_ref'])==(binding['repository_instance'],BRANCH,receipt)
    assert f['started_ns']<=f['finished_ns']
    refs=dict(rows(f['refs']))
    history=list(reversed(rows(f['branch_log'])))
    protected=list(reversed(rows(f['receipt_log'])))
    assert history and history[0]==(START,'purser.init '+binding['repository_instance'])
    assert history[-1][0]==refs[BRANCH] and (protected[-1][0] if protected else None)==refs.get(receipt)
    return f,refs,history,protected

def kern(src,ref):
    trace=src.j(ref);evs=[];previous='0'*64
    for index,raw in enumerate(trace['original_events'],1):
        event=json.loads(raw);assert raw.encode()==canonical(event) and event['revision']==index and event['prev_hash']==previous
        checksum=event.pop('hash');assert tagged('event',event)==checksum;event['hash']=checksum;evs.append(event);previous=checksum
    assert previous==trace['snapshot']['head_hash'] and len(evs)==trace['snapshot']['revision']
    arts={k:src.bytes(v) for k,v in trace['kernel_artifacts'].items()}
    assert all(sha(blob)==name for name,blob in arts.items())
    return evs,arts

def make_observable(r,raw_native,shut,att,intent,instance,receipt,is_ack=False):
    _,refs,hist,protected=raw_native
    same=[(oid,msg) for oid,msg in hist[1:] if msg=='purser.effect '+receipt.rsplit('/',1)[1]+' '+att]
    if not is_ack:
        assert (r['attempt'],r['target'],r['expected_old'],r['resource'],r['repository_instance'],r['receipt_ref'],r['repository'],r['intent_digest'])==(att,TARGET,START,BRANCH,instance,receipt,'R-notify',receipt.rsplit('/',1)[1])
        assert r['writer_quiescent']==shut
        if shut:
            assert r['branch_tip']==refs[BRANCH] and r['receipt_target']==refs.get(receipt) and r['history_intact'] is True
            assert r['matching_transitions']==len(same)
        else:
            assert r['state']=='pending' and r['history_intact'] is False
    has=refs.get(receipt)==TARGET and len(same)==1 and protected==same
    data={'bound_subject':True,'qualified_repo':True,'stable_snapshot':bool(shut),
          'writer_quiescent':bool(shut),'protected_retention_intact':bool(shut),'receipt':'matching' if has else 'absent' if receipt not in refs else 'other',
          'target_verified':True,'tip':refs[BRANCH],'tip_consistent_with_evidence':bool(has),'no_possible_unrecorded_write':bool(shut and not same and len(hist)==1 and not protected)}
    if not is_ack:
        public={'confirmed_happened':'landed','confirmed_absent':'unlanded','pending':'unknown'}[r['state']]
        assert frozen.identify(data)==public,(public,data)
    return data

def normalize(src,raw):
    arm,track,seed=(raw[n] for n in ('arm','track','seed'));key=(track,seed,arm)
    unit=exactly_one(u for u in frozen.units() if (u['track'],u['seed'],u['arm'])==key)
    assert raw['experiment']=='E3' and raw['mode']=='scripted' and raw['artifacts']['model'] is None
    assert {k:v for k,v in raw['cost'].items() if k not in ('steps','elapsed_ns')}==dict(model_calls=0,input_tokens=0,output_tokens=0,spend_usd_micros=0)
    plat=src.j(raw['artifacts']['platform']);j=src.j(raw['artifacts']['journal']);e=plat['e3']
    for item in plat['referenced_files']: src.bytes(item)
    src.objects(src.j(raw['artifacts']['candidates']))
    intent=e['intent'];packet=src.j(e['task']);bind=e['binding'];receipt=e['receipt_ref'];ix=tagged('effect',intent)
    assert intent==packet['intent'] and receipt==packet['receipt_ref']=='refs/purser/receipts/'+ix
    assert (intent['repository'],intent['resource'],intent['target']['digest'],intent['expected_old']['digest'],intent['effect'])==('R-notify',BRANCH,TARGET,START,unit['semantic_effect'])
    assert (bind['initial_oid'],bind['repository'],bind['resource'])==(START,'R-notify',BRANCH)
    grant=packet['grant'];assert grant['paths']==PATHS and grant['id']==intent['grant'] and grant['work']==intent['work']=='W-notify'
    for name in ('assignment','slot','resource','repository','generation'):assert grant[name]==intent[name]
    assert [row['seq'] for row in j]==list(range(1,1+len(j)))
    internal=[row['payload'] for row in j if row['kind']=='action']
    calls={};chron=[];retained=[];physical={};existing=[]
    def at(ts,rank,kind,**data):chron.append((ts,rank,{'kind':kind,**data}))
    start=src.j(e['release_clock']);end=src.j(e['end_clock']);exitfact=src.j(e['exit'])
    st,en=start['at_ns'],end['at_ns']
    assert st==plat['start_monotonic_ns'] and en==plat['end_monotonic_ns']==exitfact['end_monotonic_ns'] and en>=st
    assert plat['setup']['end_ns']<=st and en<=plat['offline_evidence']['start_ns'] and exitfact==plat['participant_exit']
    terminal=exactly_one(row['payload'] for row in j if row['kind']=='terminal')
    assert terminal['end_reason']==exitfact['reason']==raw['terminal'] and terminal['end_monotonic_ns']==en
    kernel,arts=kern(src,e['kernel']) if e['kernel'] else ([],{})
    assert bool(kernel)==(arm=='purser')
    if arm=='purser':
        g=exactly_one(x for x in kernel if x['type']=='GrantIssued');assert g['actor_id']=='principal:local' and all(g['data'][x]==v for x,v in grant.items())
        bound=exactly_one(x for x in kernel if x['type']=='EffectIntentBound');assert bound['data']['intent']==intent and bound['data']['changed_paths']==PATHS
    prev=st
    for pos,(source,record) in enumerate(zip(e['actions'],internal,strict=True),1):
        req,rep=src.j(source['request']),src.j(source['response']);aid=req['action_id']
        assert req['arm']==arm and req['subject']=='W-notify' and req['candidate']==TARGET
        assert pos==req['attempt'] and req['action_id']==rep['action_id'] and aid not in calls
        assert all(record[k]==v for k,v in req.items()) and all(record[k]==v for k,v in rep.items()) and record['request']==source['request'] and record['response']==source['response']
        assert prev<=req['issued_monotonic_ns']<=rep['finished_monotonic_ns']<=en;prev=rep['finished_monotonic_ns']
        calls[aid]=(req,rep);retained.append([aid,req['action'],req['actor'],req['issued_monotonic_ns'],rep['finished_monotonic_ns']])
        if req['action']!='effect':at(req['issued_monotonic_ns'],1,'action',action=req['action'],invocation=aid)
    assert next(iter(calls.values()))[1]['return']['packet']==packet
    _,init_refs,prior,_=native(src,e['initial_native'],bind,receipt);assert init_refs=={BRANCH:START}
    exclusions={};transition_summary=[];observations=[];decls=[]
    for att,ref in e['writers'].items():
        bundle=src.j(ref);cmd=bundle['command'];aid=cmd['action_id'];q,ret=calls[aid]
        assert cmd['arm']==arm and cmd['intent']==intent and cmd['attempt']==att and q['input']=={'attempt':att,'effect':intent['effect']} and q['action']=='effect'
        ev=bundle['events'];events={x['event']:x for x in ev};assert len(ev)==len(events) and bundle['stderr']==''
        launch,startup,approved=map(events.__getitem__,('launched','started','authorized'))
        pid=launch['writer_pid'];father=launch['recorder_pid']
        assert father==startup['parent_pid'] and startup['writer_pid']==startup['recorder_pid']==pid==approved['recorder_pid'] and pid!=father
        assert q['issued_monotonic_ns']<=launch['at_ns']<=startup['at_ns']<=approved['at_ns']<=ret['finished_monotonic_ns']
        if arm=='purser':
            authority=exactly_one(x for x in kernel if x['type']=='EffectDispatchAuthorized' and x['proposal_id']==aid and x['data']['id']==att)
            assert authority['actor_id']=='broker:git' and authority['data']['effect']==intent['effect']
            assert current_time(authority['data']['authorized_at'])<current_time(grant['expires_at'])
        else:
            gate=events['permission_checked'];assert gate['recorder_pid']==pid and gate['at_ns']<=approved['at_ns']
            assert gate['grant']==grant and gate['preparation']['changed_paths']==PATHS and gate['preparation']['intent_digest']==ix and gate['preparation']['repository_instance']==bind['repository_instance']
            assert gate['authorization']['details']=={'effect':intent['effect'],'attempt':att,'intent_digest':ix,'state':'dispatching'}
        assert (approved['effect'],approved['attempt'])==(intent['effect'],att)
        at(approved['at_ns'],2,'authorized',physical_attempt=att,semantic=intent['effect'],current_grant=True)
        # This is ONE invocation. Preserve the earlier public call timestamp independently;
        # released_to_writer denotes the measured, authorized physical cutoff inside that invocation.
        at(approved['at_ns'],3,'action',action='effect',invocation=aid,physical_attempt=att,released_to_writer=True,public_request_ns=q['issued_monotonic_ns'])
        raw_native=native(src,e['native_snapshots']['after-'+att],bind,receipt)
        n,refs,hist,protected=raw_native;assert hist[:len(prior)]==prior and n['finished_ns']<=ret['finished_monotonic_ns']
        new_history=hist[len(prior):];last=prior[-1][0];snapped=[]
        for i,(oid,msg) in enumerate(new_history):
            assert 'written' in events and events['written']['recorder_pid']==pid and msg=='purser.effect '+ix+' '+att
            assert approved['at_ns']<=events['written']['at_ns']<=n['finished_ns']
            snapped.append({'old':last,'new':oid,'message':msg});at(events['written']['at_ns'],4,'physical_ref_commit',physical_publication=f'{att}/{len(prior)+i}',belongs_to_semantic_slot=True,ref=BRANCH,writer=pid,old=last,new=oid);last=oid
        external=exactly_one(x['payload'] for x in j if x['kind']=='external' and x['payload']['attempt']==att)
        assert (existing or not new_history or prior==[(START,'purser.init '+bind['repository_instance'])])
        assert external['transitions']==snapped and external['writer']==pid and external['action_id']==aid and src.j(external['native'])==n and external['expected_old']==START and external['target']==TARGET
        prior=hist;existing.append(att)
        reaped=events.get('reaped');held=events.get('held_at_return');assert bool(reaped)!=bool(held)
        if reaped:
            assert reaped['writer_pid']==pid and reaped['recorder_pid']==father and reaped['at_ns']<=n['started_ns']
            if reaped['at_ns']<=en:at(reaped['at_ns'],5,'original_writer_exit',writer=pid,quiescent=True)
        else:
            assert held['writer_pid']==pid and events['exit_check']['returncode'] is None and events['teardown_reaped']['at_ns']>en
        assert bool(reaped)==external['writer_quiescent']
        physical[att]=(pid,raw_native,reaped,ret,aid,events)
        transition_summary.extend([{'writer':pid,'attempt':att,**x} for x in snapped])
        if ret['return']['status']=='acknowledged':
            assert events['reply']['public']==ret['return'] and ret['return']['target']==TARGET and ret['return']['receipt_ref']==receipt and ret['return']['effect']==intent['effect'] and ret['return']['attempt']==att and reaped and reaped['returncode']==0
            facts=make_observable({},raw_native,True,att,intent,bind['repository_instance'],receipt,is_ack=True)
            at(ret['finished_monotonic_ns'],1,'delivered_observation',id=aid,facts=facts)
        else:
            assert ret['return']=={'status':'timeout'} and (reaped is None or reaped['returncode']!=0)
    for aid,ref in e['observations'].items():
        req,ret=calls[aid];state=ret['return']['report'];att=req['input']['attempt'];pid,after,reaped,_,_,process=physical[att]
        assert req['action']=='reconcile' and req['input']['delivery']==('explicit' if arm=='loop' else 'automatic') and req['actor']==('executor' if arm=='loop' else 'independent_observer')
        sample=native(src,ref,bind,receipt);t=sample[0];assert req['issued_monotonic_ns']<=t['started_ns']<=t['finished_ns']<=ret['finished_monotonic_ns']
        assert sample[1:]==after[1:]
        facts=make_observable(state,sample,bool(reaped and reaped['at_ns']<=req['issued_monotonic_ns']),att,intent,bind['repository_instance'],receipt)
        if kernel:
            witness=exactly_one(x for x in kernel if x['type']=='GitEffectObserved' and x['proposal_id']==aid)
            assert witness['actor_id']=='observer:git' and witness['data']['attempt']==att and json.loads(arts[witness['data']['artifact_sha256']])==state
            assert ret['return']['receipt']['disposition']=='admitted' and ret['return']['receipt']['actor_id']=='observer:git' and ret['return']['receipt']['details']['state']==state['state']
        at(ret['finished_monotonic_ns'],1,'delivered_observation',id=aid,facts=facts);observations.append([aid,att,req['input']['delivery'],frozen.identify(facts)])
    for declref in e['declarations']:
        d=src.j(declref);q,ret=calls[d['action_id']];assert q['action']=='decide' and d==ret['return'] and all(d[k]==v for k,v in q['input'].items())
        p=exactly_one(x['payload'] for x in j if x['kind']=='public_state' and x['payload']['action_id']==d['action_id'])
        assert p['to']==d['choice'] and p['declaration']==declref and p['original_report']==d['original_report']
        assert q['issued_monotonic_ns']<=d['published_ns']<=ret['finished_monotonic_ns']
        assert calls[d['basis']][1]['finished_monotonic_ns']<=d['published_ns']
        at(d['published_ns'],5,'public_disposition',value=d['report'],attributed_observations=[d['basis']],actionable_reason=bool(d['next_action']),attempt=d['attempt'])
        if d['choice']=='complete':at(d['published_ns'],6,'public_completion')
        decls.append(d)
    final=native(src,e['final_native'],bind,receipt);assert final[2]==prior and final[0]['started_ns']>=en
    assert set(physical)==set(e['writers']) and len([x for x,_ in calls.values() if x['action']=='effect'])==len(physical)
    if len(physical)>1:
        first=decls[0];second=physical['T2'];assert first['attempt']=='T1' and first['published_ns']<=calls[second[4]][0]['issued_monotonic_ns']
    if track=='inconclusive-observation':
        assert final[0]['finished_ns']<=physical['T1'][5]['teardown_reaped']['at_ns'];later=native(src,e['teardown_native'],bind,receipt);assert later[0]['started_ns']>=physical['T1'][5]['teardown_reaped']['at_ns']
    history=[x[2] for x in sorted(chron,key=lambda row:(row[0],row[1]))]
    assert len(history)>0
    done=bool(decls and decls[-1]['choice']=='complete' and exitfact['reason']=='done')
    manual=terminal['human_action'] is not None
    case={'track':track,'events':history,'clock':{'start':st,'end':en},'original_writer':physical['T1'][0],'complete_external_chain':True,'intent':intent['effect'],'terminal_observed':True,'terminal_success':done,'manual_repair':manual,'stuck_requires_manual':track=='primary' and not done and exitfact['reason'] in ('blocked','idle'),'complete_public_history':True}
    score=frozen.score(case)
    assert raw['cost']['steps']==score['cost']['steps'] and raw['cost']['elapsed_ns']==score['cost']['elapsed_ns']
    fault=[(x['payload']['intervention'],x['payload']['released']) for x in j if x['kind']=='fault']
    assert (track=='clean' and not fault) or (len(fault)==1 and fault[0][1]=={'status':'timeout'} and fault[0][0]==('inconclusive-observation' if track=='inconclusive-observation' else unit['fault_slot']))
    return {'key':key,'score':score,'public_calls':retained,'public_observations':observations,'public_decisions':[[d['attempt'],d['original_report'],d['choice'],d['basis'],d['published_ns']] for d in decls],'physical_transitions':transition_summary,'initial':START,'terminal':exitfact,'native_original_boundaries':{'writer':physical['T1'][0],'authorized_ns':physical['T1'][5]['authorized']['at_ns'],'exit_check':physical['T1'][5]['exit_check'],'final_native_finished_ns':final[0]['finished_ns']},'timing':{'start':st,'end':en},'source_digests':{k:v['sha256'] for k,v in raw['artifacts'].items() if v is not None}}
