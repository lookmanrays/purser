"""Verify immutable registration/result identity and compare original E3 data to the preimplementation oracle."""
from read_witness import *
import argparse
from collections import Counter
parser=argparse.ArgumentParser();parser.add_argument('repo',type=Path);parser.add_argument('series');parser.add_argument('registration');parser.add_argument('result');parser.add_argument('freeze_sha');parser.add_argument('raw_sha');parser.add_argument('report_sha');parser.add_argument('out',type=Path);parser.add_argument('--private',action='store_true');args=parser.parse_args()
src=Path(json.loads((HERE/'combined-source.json').read_bytes())['checkout'])
def git(repo,*a):return subprocess.check_output(['git',*a],cwd=repo)
def output(obj):return json.dumps(obj,sort_keys=True,indent=2).encode()+b'\n'
loc=args.repo/args.series; archive=ByteSource(loc/'raw.zip')
freezeb=archive.read('freeze.json'); freeze=json.loads(freezeb)
source=freeze['source_commit'];assert source==json.loads((HERE/'combined-source.json').read_bytes())['candidate']
schedule=list(frozen.units());expected=[[u['track'],u['seed'],u['rank'],u['arm']] for u in schedule];assert freeze['schedule']==expected
keys=['/'+ '/'.join(map(str,(u['track'],u['seed'],u['arm'])))+'.json' for u in schedule]
assert len(set(keys))==66
subprocess.run(['git','merge-base','--is-ancestor',source,args.registration],cwd=args.repo,check=True)
subprocess.run(['git','merge-base','--is-ancestor',args.registration,args.result],cwd=args.repo,check=True)
for n,h in [('freeze.json',args.freeze_sha),('raw.zip',args.raw_sha),('report.md',args.report_sha)]:
 b=(loc/n).read_bytes();assert sha(b)==h and b==git(args.repo,'show',args.result+':'+args.series+'/'+n)
assert git(args.repo,'show',args.registration+':'+args.series+'/freeze.json')==freezeb==(loc/'freeze.json').read_bytes()
dirs=['purser','experiments/e1','experiments/e2','experiments/e3'];ls=git(src,'ls-tree','-r','--name-only',source,'--',*dirs).decode().splitlines();sources={n:sha(git(src,'show',source+':'+n)) for n in ls if n.endswith('.py')};assert freeze['source_files']==sources
closure=sha(canonical(sources));entry=lambda label:sha(canonical({'entrypoint':label,'source_sha256':closure}))
for k,v in {'scorer_sha256':'experiments.e3.report.derive_case','fault_driver_sha256':'experiments.e3.supervisor.Supervisor.dispatch','executor_sha256':'experiments.e3.participant.Participant.execute','controller_sha256':'experiments.e3.suite.collect_units'}.items():assert freeze[k]==entry(v)
assert freeze['treatments']=={a:entry('experiments.e3.trial.attempt/'+a) for a in frozen.ARMS}
for name,k in [('manifest.json','manifest_sha256'),('protocol.md','protocol_sha256'),('raw.schema.json','raw_schema_sha256')]:
 b=git(src,'show',source+':experiments/manifests/v1/'+name);assert sha(b)==freeze[k] and b==git(src,'show','4460381e44f3dd42d22848bf6d82fea9a817a833:experiments/manifests/v1/'+name)
if args.private:
 prereg=json.loads(git(args.repo,'show',args.registration+':'+args.series+'/private-units.json'));assert prereg['replicate']==freeze['replicate'] and prereg['reason']==freeze['replication_reason'];selected=prereg['units']
 assert selected==[x for x in expected if x[0]!='primary' or x[1] in (3001,3002)] and freeze['replicate']==2
else:
 selected=expected;assert freeze['replicate']==1 and freeze['replication_reason'] is None
paths=list(archive.z.namelist())
wanted=['/'+ '/'.join(map(str,(t,s,a)))+'.json' for t,s,rank,a in selected]
assert [n for n in paths if n.startswith('started/')]==['started'+k for k in wanted]
assert [n for n in paths if n.startswith('runs/')]==['runs'+k for k in wanted]
answers={};proofs={};timing={};locations=set()
for suff,(track,seed,rank,arm) in zip(wanted,selected,strict=True):
 raw=json.loads(archive.read('runs'+suff)); marker=json.loads(archive.read('started'+suff))
 assert (raw['track'],raw['seed'],raw['arm'],raw['replicate'])==(track,seed,arm,freeze['replicate']) and marker=={'arm':arm,'rank':rank,'seed':seed,'track':track}
 fields=('fixture_tree','fixture_commit','manifest_sha256','protocol_sha256','raw_schema_sha256','scorer_sha256','fault_driver_sha256','executor_sha256')
 assert raw['inputs']=={**{k:freeze[k] for k in fields},'worktree_head':source,'treatment_sha256':freeze['treatments'][arm]}
 pp=archive.j(raw['artifacts']['platform']); off=pp['offline_scoring'];assert pp['end_monotonic_ns']<=off['start_ns']<=off['end_ns']
 initial=archive.j(off['input_platform'])
 assert {k:v for k,v in pp.items() if k not in ('offline_scoring','referenced_files')}=={k:v for k,v in initial.items() if k!='referenced_files'}
 assert pp['referenced_files']==initial['referenced_files']+[off['input_platform']]
 bound=pp['e3']['binding']['repository_instance'];assert bound not in locations;locations.add(bound)
 rec=normalize(archive,raw); assert rec['key']==(track,seed,arm)
 obs=rec['score']
 if track=='primary':assert raw['score']=={k:obs[k] for k in ('original_truth','original_report','effect_count','duplicate_count','correct_reconciliation','manual_repair','resolved_by_budget')};assert (raw['cost']['elapsed_ns']>0)
 else:assert raw['score'] is None
 answers[(track,seed,arm)]=obs
 proofs[suff[1:-5]]=rec;timing[suff[1:-5]]={'before':pp['setup']['end_ns'],'participant':rec['timing'],'scoring':[off['start_ns'],off['end_ns']]}
def yn(v):return '?' if v is None else 'yes' if v is True else 'no' if v is False else str(v)
agg=frozen.aggregate(answers);public=(loc/'report.md').read_text()
# Parse each labelled published comparison, independent of native summary code.
def section(title):
 prefix='## '+title+'\n';return public.split(prefix,1)[1].split('\n## ',1)[0]
def table(title):
 lines=section(title).splitlines();return [tuple(t.strip() for t in l.strip('|').split('|')) for l in lines if l.startswith('|')][2:]
for row in table('Paired public costs'):
 name,*val=row; key=name.replace(' / ','/');expected=[]
 for comparator in ('loop','loop_equal_verifier'):
  pair=agg['paired_costs'][key][comparator]
  expected+=([yn(pair[k]) for k in ('steps','elapsed_ns')] if pair is not None else ['?','?'])
 assert val==expected,(row,expected)
for arm in frozen.ARMS:
 for row in table('Primary coverage · '+arm):
  si,exitc,declared,just,correct,count,duplicate,resolved,stuck,manual,steps,elapsed=row; outcome=answers.get(('primary',int(si),arm))
  if not outcome:
   assert declared=='? / ?' and all(x=='?' for x in (just,correct,count,duplicate,resolved,stuck,manual,steps,elapsed));continue
  assert exitc=='complete / done' and declared.split(' (')[0]==outcome['original_truth']+' / '+outcome['original_report']
  assert [just,correct,count,duplicate,resolved,stuck,manual,steps,elapsed]==[*(yn(outcome[k]) for k in ('justified_in_order','correct_reconciliation','effect_count','duplicate_count','resolved_by_budget','stuck_requires_manual','manual_repair')),yn(outcome['cost']['steps']),yn(outcome['cost']['elapsed_ns'])]
for row in table('Paired primary outcomes'):
 s,*scalars=row;rr=answers.get(('primary',int(s),'purser'))
 expect=[]
 for comparator in ('loop','loop_equal_verifier'):
  cc=answers.get(('primary',int(s),comparator));expect.extend(str(rr[k]-cc[k]) if rr and cc else '?' for k in ('correct_reconciliation','duplicate_count','resolved_by_budget'))
 assert scalars==expect
for row in table('Matched clean control'):
 arm,terminal,exposure,effects,resolved,steps,elapsed=row;out=answers['clean',3001,arm];assert [terminal,exposure,effects,resolved,steps,elapsed]==['done','yes',yn(out['effect_count']),yn(out['resolved_by_budget']),yn(out['cost']['steps']),yn(out['cost']['elapsed_ns'])]
for row in table('Inconclusive-observation stress'):
 arm,terminal,actual,pending,additional,effects,detail,steps,elapsed=row;out=answers['inconclusive-observation',3001,arm]
 assert terminal=='blocked' and actual=='unknown / unknown' and pending==yn(out['stress_held_pending']) and additional=='0' and effects==yn(out['effect_count']) and 'writer_may_still_apply' in detail and (steps,elapsed)==(yn(out['cost']['steps']),yn(out['cost']['elapsed_ns']))
assert 'registered absolute threshold result is **'+yn(agg['arms']['purser']['absolute'])+'**' in public
assert 'original no-advantage predicate is **'+yn(agg['arms']['purser']['original_no_advantage'])+'**' in public
assert 'eligible clean pair: **'+yn(agg['clean_overhead'])+'**' in public
rep={'source':source,'registration':args.registration,'result':args.result,'freeze_sha256':args.freeze_sha,'raw_sha256':args.raw_sha,'report_sha256':args.report_sha,'rows':len(answers),'registered_cells':len(schedule),'distinct_repository_instances':len(locations),'source_files':len(sources),'original_object_refs_checked':len(archive.known),'original_git_packs':{str(k):v for k,v in archive.packs.items()},'public_report_independently_recomputed':True,'projection':agg,'originals':proofs,'case_clocks':timing}
args.out.write_bytes(output(rep))
print(json.dumps({'rows':rep['rows'],'known_sources':rep['original_object_refs_checked'],'source_files':rep['source_files'],'Git_packs':len(archive.packs),'arms':agg['arms'],'sha256':sha(args.out.read_bytes())},sort_keys=True))
