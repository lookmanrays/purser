"""Observe a real collector SIGKILL after the second reporter-preserved external transition."""
from pathlib import Path
import json,os,signal,sys,subprocess,tempfile,hashlib
HERE=Path(__file__).resolve().parent
root=Path(json.loads((HERE/'combined-source.json').read_bytes())['checkout'])
sys.path.insert(0,str(root))
from experiments.e1.artifacts import Artifacts
from experiments.e1.recovery import FileArchive
from experiments.e1.report import GitPacks,Objects
from experiments.e3.fixture import read,write
from experiments.e3.trial import run_participant,recover,failure
from experiments.e3.scoring import reconstruct
from tests.test_e3_runner import pilot_pin
if len(sys.argv)>1:
    d=Path(sys.argv[1])
    def boundary(original):
        write(d/'saved.json',original)
        rows=original['rows']
        if rows and rows[-1]['kind']=='external' and rows[-1]['payload']['attempt']=='T2':
            os.kill(os.getpid(),signal.SIGKILL)
    run_participant(d,Artifacts(FileArchive(d.parent)),pilot_pin(),'loop','primary',3002,2,progress=boundary)
else:
    wt=Path(tempfile.mkdtemp(prefix='purser-m4-real-partial-')).resolve();unit=wt/'case';unit.mkdir()
    p=subprocess.run([sys.executable,'-B',str(Path(__file__).resolve()),str(unit)],cwd=root,env={'PATH':'/usr/bin:/bin','LC_ALL':'C','TZ':'UTC'},capture_output=True)
    assert p.returncode==-signal.SIGKILL and not p.stderr
    assets=Artifacts(FileArchive(wt));saved=recover(unit,assets,'loop',read(unit/'saved.json'),seed=3002,rank=2)
    original=failure(assets,pilot_pin(),'loop','primary',3002,2,reason='observed SIGKILL after T2 native return and before its public response',progress=saved)
    (wt/'independent-native').mkdir()
    facts=reconstruct(original,Objects(assets.archive),GitPacks(wt/'independent-native'))
    emit={k:v for k,v in facts.items() if k in ('original_truth','original_report','justified_in_order','correct_reconciliation','observed_steps','steps','elapsed_ns','elapsed_lower_ns','publications','physical_count_lower_bound','external_complete','public_complete','eligible','diagnostics','manual_repair','terminal','releases')}
    refs=lambda r:json.loads((wt/r['path']).read_bytes())
    platform=refs(original['artifacts']['platform']);e3=platform['e3']
    last=refs(e3['declarations'][0]);t1=refs(e3['native_snapshots']['after-T1']);t2=refs(e3['native_snapshots']['after-T2'])
    assert len(e3['actions'])==6 and last['report']=='unlanded' and e3['actions'][-1]['response'] is None and '5828b906ebc2aca8bbaf69c8d50fa8eb1295af7b' in t2['refs'] and '5828b906ebc2aca8bbaf69c8d50fa8eb1295af7b' not in t1['refs']
    assert emit['original_truth']=='unlanded' and emit['original_report']=='unlanded' and emit['justified_in_order'] is True and emit['physical_count_lower_bound']==1 and emit['observed_steps']==6 and emit['elapsed_ns'] is None and platform['participant_exit'] is None
    out={'source':json.loads((HERE/'combined-source.json').read_bytes())['candidate'],'real_returncode':p.returncode,'actual_public_decision_before_T2':last,'sixth_return':e3['actions'][-1]['response'],'actual_native_T2':t2,'original':emit,'private_physical_original':str(unit)}
    dp=HERE/'genuine-partial-observation.json';dp.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(hashlib.sha256(dp.read_bytes()).hexdigest(),emit['eligible'],emit['diagnostics'])
