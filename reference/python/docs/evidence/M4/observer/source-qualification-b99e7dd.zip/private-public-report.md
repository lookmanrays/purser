# E3 scripted · Recovery of an ambiguous Git update

Replicate 2 retains 12 of 66 scheduled records. The prepared commit is `5828b906ebc2aca8bbaf69c8d50fa8eb1295af7b`. The frozen source is `b99e7ddfc82f413e8d5b2a2b2dce9b4e7a3fb3fd`.

Purser’s registered absolute threshold result is **?**. The original no-advantage predicate is **?**. The absolute threshold requires all 20 original outcomes to be reconciled correctly, with zero duplicates and an effective update by the budget. Any Purser duplicate or ordinary stuck state requiring manual repair triggers the original no-advantage predicate. The paired tables give the outcomes for the two comparisons.

Each case binds `55686bd5152e10a53dfdc2c003974ea405a3a075` on `refs/heads/notify` to a fresh repository instance and a seed-specific intent. The protected branch reflog gives actual transitions. The named receipt, its creation history and the supervised writer establish what the first attempt did. The participant’s original call return and published decision establish what it knew before completion or another dispatch. Purser’s authority and observer artifacts also replay from its original events. Each trial’s case record names the evidence. [Raw trial archive](raw.zip)

## Primary outcomes

Each entry gives the numerator, number of measurable cases and 20 scheduled seeds. Duplicate transitions counts every publication after the first. A question mark denotes an unavailable measurement or inconclusive predicate.

| Arm | Correct reconciliation | Resolved by budget | Cases with duplicates | Duplicate transitions | Stuck needing repair | Manual repair performed | Incomplete or missing records |
| --- | --- | --- | --- | --- | --- | --- | ---: |
| loop | 2 / 2 / 20 | 2 / 2 / 20 | 0 / 2 / 20 | 0 / 2 / 20 | 0 / 2 / 20 | 0 / 2 / 20 | 18 |
| purser | 2 / 2 / 20 | 2 / 2 / 20 | 0 / 2 / 20 | 0 / 2 / 20 | 0 / 2 / 20 | 0 / 2 / 20 | 18 |
| loop_equal_verifier | 2 / 2 / 20 | 2 / 2 / 20 | 0 / 2 / 20 | 0 / 2 / 20 | 0 / 2 / 20 | 0 / 2 / 20 | 18 |

Replication reason: Private technical qualification of the registered E3 runner, offline scorer and archive on two primary ranks and both matched controls. The original series is separate.

## Primary coverage · loop

| Seed | Validity / exit | Original actual / declared | Justified before retry or completion | Correct | Effects | Duplicates | Resolved | Stuck | Manual | Steps | Elapsed ns |
| ---: | --- | --- | --- | --- | ---: | ---: | --- | --- | --- | ---: | ---: |
| 3001 | complete / done | landed / landed (action-4) | yes | yes | 1 | 0 | yes | no | no | 5 | 627430792 |
| 3002 | complete / done | unlanded / unlanded (action-4) | yes | yes | 1 | 0 | yes | no | no | 7 | 793647667 |
| 3003 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3004 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3005 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3006 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3007 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3008 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3009 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3010 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3011 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3012 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3013 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3014 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3015 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3016 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3017 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3018 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3019 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3020 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |

## Primary coverage · purser

| Seed | Validity / exit | Original actual / declared | Justified before retry or completion | Correct | Effects | Duplicates | Resolved | Stuck | Manual | Steps | Elapsed ns |
| ---: | --- | --- | --- | --- | ---: | ---: | --- | --- | --- | ---: | ---: |
| 3001 | complete / done | landed / landed (action-4) | yes | yes | 1 | 0 | yes | no | no | 5 | 773595625 |
| 3002 | complete / done | unlanded / unlanded (action-4) | yes | yes | 1 | 0 | yes | no | no | 8 | 1197903667 |
| 3003 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3004 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3005 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3006 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3007 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3008 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3009 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3010 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3011 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3012 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3013 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3014 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3015 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3016 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3017 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3018 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3019 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3020 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |

## Primary coverage · loop_equal_verifier

| Seed | Validity / exit | Original actual / declared | Justified before retry or completion | Correct | Effects | Duplicates | Resolved | Stuck | Manual | Steps | Elapsed ns |
| ---: | --- | --- | --- | --- | ---: | ---: | --- | --- | --- | ---: | ---: |
| 3001 | complete / done | landed / landed (action-4) | yes | yes | 1 | 0 | yes | no | no | 5 | 746174542 |
| 3002 | complete / done | unlanded / unlanded (action-4) | yes | yes | 1 | 0 | yes | no | no | 8 | 1169806500 |
| 3003 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3004 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3005 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3006 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3007 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3008 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3009 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3010 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3011 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3012 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3013 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3014 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3015 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3016 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3017 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3018 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3019 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |
| 3020 | missing / ? | ? / ? | ? | ? | ? | ? | ? | ? | ? | ? | ? |

## Paired public costs

Each difference subtracts the comparator from Purser for the same track and seed. Positive values mean Purser used more public calls or elapsed time.

| Track / seed | Steps vs loop | Elapsed ns vs loop | Steps vs equal verifier | Elapsed ns vs equal verifier |
| --- | ---: | ---: | ---: | ---: |
| primary / 3001 | 0 | 146164833 | 0 | 27421083 |
| primary / 3002 | 1 | 404256000 | 0 | 28097167 |
| primary / 3003 | ? | ? | ? | ? |
| primary / 3004 | ? | ? | ? | ? |
| primary / 3005 | ? | ? | ? | ? |
| primary / 3006 | ? | ? | ? | ? |
| primary / 3007 | ? | ? | ? | ? |
| primary / 3008 | ? | ? | ? | ? |
| primary / 3009 | ? | ? | ? | ? |
| primary / 3010 | ? | ? | ? | ? |
| primary / 3011 | ? | ? | ? | ? |
| primary / 3012 | ? | ? | ? | ? |
| primary / 3013 | ? | ? | ? | ? |
| primary / 3014 | ? | ? | ? | ? |
| primary / 3015 | ? | ? | ? | ? |
| primary / 3016 | ? | ? | ? | ? |
| primary / 3017 | ? | ? | ? | ? |
| primary / 3018 | ? | ? | ? | ? |
| primary / 3019 | ? | ? | ? | ? |
| primary / 3020 | ? | ? | ? | ? |
| clean / 3001 | 1 | 295897584 | 0 | 89570334 |
| inconclusive-observation / 3001 | 0 | 28344958 | 0 | -37759792 |

## Paired primary outcomes

The differences give Purser minus each comparator for a correct original disposition, duplicate transitions and resolution by budget. A true outcome counts as one.

| Seed | Correct vs loop | Duplicates vs loop | Resolved vs loop | Correct vs equal verifier | Duplicates vs equal verifier | Resolved vs equal verifier |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 3001 | 0 | 0 | 0 | 0 | 0 | 0 |
| 3002 | 0 | 0 | 0 | 0 | 0 | 0 |
| 3003 | ? | ? | ? | ? | ? | ? |
| 3004 | ? | ? | ? | ? | ? | ? |
| 3005 | ? | ? | ? | ? | ? | ? |
| 3006 | ? | ? | ? | ? | ? | ? |
| 3007 | ? | ? | ? | ? | ? | ? |
| 3008 | ? | ? | ? | ? | ? | ? |
| 3009 | ? | ? | ? | ? | ? | ? |
| 3010 | ? | ? | ? | ? | ? | ? |
| 3011 | ? | ? | ? | ? | ? | ? |
| 3012 | ? | ? | ? | ? | ? | ? |
| 3013 | ? | ? | ? | ? | ? | ? |
| 3014 | ? | ? | ? | ? | ? | ? |
| 3015 | ? | ? | ? | ? | ? | ? |
| 3016 | ? | ? | ? | ? | ? | ? |
| 3017 | ? | ? | ? | ? | ? | ? |
| 3018 | ? | ? | ? | ? | ? | ? |
| 3019 | ? | ? | ? | ? | ? | ? |
| 3020 | ? | ? | ? | ? | ? | ? |

## Matched clean control

| Arm | Exit | Acknowledged clean exposure | Effective updates | Resolved | Steps | Elapsed ns |
| --- | --- | --- | ---: | --- | ---: | ---: |
| loop | done | yes | 1 | yes | 4 | 496388375 |
| purser | done | yes | 1 | yes | 5 | 792285959 |
| loop_equal_verifier | done | yes | 1 | yes | 5 | 702715625 |

Purser exceeded twice the plain loop’s steps on the eligible clean pair: **no**.

## Inconclusive-observation stress

| Arm | Exit | Original actual / declared | Actionable pending held | Additional physical attempts | Effects | Remaining uncertainty and public next action | Steps | Elapsed ns |
| --- | --- | --- | --- | ---: | ---: | --- | ---: | ---: |
| loop | blocked | unknown / unknown | yes | 0 | 0 | writer_may_still_apply · reconcile this attempt when the writer and its receipt can be observed | 5 | 458991125 |
| purser | blocked | unknown / unknown | yes | 0 | 0 | writer_may_still_apply · reconcile this attempt when the writer and its receipt can be observed | 5 | 487336083 |
| loop_equal_verifier | blocked | unknown / unknown | yes | 0 | 0 | writer_may_still_apply · reconcile this attempt when the writer and its receipt can be observed | 5 | 525095875 |

The scripted budget permits 96 public steps, 60 elapsed seconds and zero model calls. The scripted series uses zero model tokens and spend. Real-model outcomes require a separate series.
