from pathlib import Path
import json, os, sys, tempfile, time, hashlib
HERE=Path(__file__).resolve().parent
source=json.loads((HERE/'combined-source.json').read_bytes());root=Path(source['checkout']);sys.path.insert(0,str(root));os.chdir(root)
from experiments.e1.artifacts import Artifacts
from experiments.e1.recovery import FileArchive
from experiments.e1.run import _run_arm, utc
from experiments.e3 import fixture
from experiments.e3.actions import Actions, Tools
from experiments.e3.participant import Participant
from experiments.e3.supervisor import Supervisor
from experiments.e3.witness import native
out={}
for arm,signal,tag in [('purser',b'R','genuine-resume'),('loop',b'','ordinary-eof')]:
    space=Path(tempfile.mkdtemp(prefix='m4-e3-held-')).resolve();session=space/'case';session.mkdir()
    assets=Artifacts(FileArchive(space));p,repo=fixture.provision(session,assets,arm,3001,lambda *a:None)
    initial=native(session,repo.binding,p['receipt_ref'],'initial')
    j=Actions(session,assets,arm,None);s=Supervisor(session,repo,p,arm,'inconclusive-observation',3001,1,j,assets)
    try:
        conclusion=_run_arm(Participant(Tools(session,arm,repo,j,s)),j);assert conclusion=='blocked'
        proc=s.children['T1']; assert proc.poll() is None
        decl=next(json.loads(x.read_bytes()) for x in (session/'declarations').glob('*.json'));assert decl['choice']=='pending' and decl['original_report']=='unknown'
        co=repo.observe(p['intent'],'T1');pre=native(session,repo.binding,p['receipt_ref'],'original-end')
        assert co['state']=='pending' and co['writer_quiescent'] is False and pre['refs']==initial['refs'] and decl['published_ns']<=j.end<=pre['started_ns']
        released=time.monotonic_ns();output,err=proc.communicate(input=signal,timeout=10);reaped=time.monotonic_ns()
        assert not err and proc.returncode==(0 if signal else 76)
        later=repo.observe(p['intent'],'T1');post=native(session,repo.binding,p['receipt_ref'],'after-distinct-intervention')
        expect='confirmed_happened' if signal else 'confirmed_absent';assert later['state']==expect and (post['refs']!=pre['refs'])==bool(signal)
        note=json.loads((session/'writers/T1/started.json').read_bytes());assert note['recorder_pid']==proc.pid
        written=None
        if signal:
            written=json.loads((session/'writers/T1/written.json').read_bytes());assert written['recorder_pid']==proc.pid and released<=written['at_ns']<=reaped
        out[tag]={'arm':arm,'pid':proc.pid,'public_declaration':decl,'original_cutoff_ns':j.end,'earlier_native':pre,'earlier_observation':co,'post_cutoff_intervention_ns':released,'confirmed_reaped_ns':reaped,'later_process_return':proc.returncode,'later_observation':later,'later_native':post,'writer_write_if_any':written}
    finally:s.stop()
dest=HERE/'joined-continuation.json';dest.write_text(json.dumps({'source':source['candidate'],'cases':out},sort_keys=True,indent=2)+'\n');print(hashlib.sha256(dest.read_bytes()).hexdigest())
