"""A real Git child survives a killed launching process while its guarded transaction is prepared."""
import json,os,signal,subprocess,sys,tempfile,time
from pathlib import Path
from git_reference import ME,PROJECT,BRANCH,make_source,new_repo,external,records,action_env,pack,readref,digest,canonical
SELF=Path(__file__).resolve()
def wait_file(path,seconds=8):
    deadline=time.monotonic()+seconds
    while time.monotonic()<deadline and not path.exists():time.sleep(.01)
    if not path.exists():raise TimeoutError(str(path))
def hook():
    phase=sys.argv[2];hold=Path(sys.argv[3]);capture=Path(sys.argv[4]);payload=sys.stdin.buffer.read()
    # All native Git hook phases still enter the same protected outside recorder.
    subprocess.run([sys.executable,'-B',str(ME),'hook',phase,str(capture)],input=payload,check=True)
    if phase=='prepared' and os.environ.get('PUR_WITNESS_WRITER')=='T1':
        (hold/'prepared').write_bytes(canonical({'hook_pid':os.getpid(),'parent_git_pid':os.getppid(),'at_ns':time.monotonic_ns()}))
        wait_file(hold/'release')
def parent():
    hold,repo,old,target,receipt=Path(sys.argv[2]),Path(sys.argv[3]),*sys.argv[4:7]
    with (hold/'git-output.txt').open('wb') as out:
        p=subprocess.Popen(['/usr/bin/git','update-ref','--stdin'],cwd=repo,stdin=subprocess.PIPE,stdout=out,stderr=out,env=action_env('T1','notify-3001'))
        (hold/'git-child').write_text(str(p.pid))
        # Deliver the complete unconditional transport transcript to an already authorized Git child once.
        p.stdin.write(pack(repo,old,target,receipt));p.stdin.close()
        p.wait()
def prove():
    top=Path(tempfile.mkdtemp(prefix='purser-m4-orphan-control.',dir='/private/tmp'));h=top/'hold';h.mkdir();oids=make_source(top/'source');repo=top/'trusted.git';outfile=new_repo(top/'source',repo,oids)
    old,target=oids['start'],oids['e3'];receipt='refs/purser/receipts/'+digest(b'predeclared physical child control')
    path=outfile.parent/'reference-transaction'
    path.write_text('#!/bin/sh\nexec '+sys.executable+' -B '+str(SELF)+' hook "$1" '+str(h)+' '+str(outfile)+'\n');path.chmod(0o755)
    p=subprocess.Popen([sys.executable,'-B',str(SELF),'parent',str(h),str(repo),old,target,receipt],start_new_session=True,env=action_env('fixture-parent','notify-3001'),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    try:
        wait_file(h/'prepared');prepared=json.loads((h/'prepared').read_bytes());child=int((h/'git-child').read_text());assert prepared['parent_git_pid']==child
        os.kill(p.pid,signal.SIGKILL);assert p.wait(timeout=4)==-9
        os.kill(child,0);before=dict(parent=p.pid,child=child,parent_returncode=p.returncode,actual_child_alive=True,observed_tip=readref(repo,BRANCH),receipt=readref(repo,receipt),committed=external(outfile),at_ns=time.monotonic_ns())
        assert before['observed_tip']==old and before['receipt'] is None and not before['committed']
        (h/'release').touch();cut=time.monotonic()+7
        while time.monotonic()<cut and (readref(repo,receipt)!=target or len(external(outfile))!=1):time.sleep(.02)
        after=dict(tip=readref(repo,BRANCH),receipt=readref(repo,receipt),committed=external(outfile),at_ns=time.monotonic_ns());assert after['tip']==after['receipt']==target and after['committed'][0]['actor']=='T1'
        data=dict(scope='original real Git subprocess of killed fixture launcher, already received branch update and receipt transaction, no second writer/authorization',prepared=prepared,after_launcher_death=before,after_allowing_existing_prepared_git_to_finish=after,all_hook_records=records(outfile))
        dst=SELF.parent/'original-descendant-proof.json';assert not dst.exists();dst.write_bytes(canonical(data)+b'\n')
        print(dst.name,digest(dst.read_bytes()),p.pid,child,len(after['committed']))
    finally:
        (h/'release').touch(exist_ok=True)
        if p.poll() is None:p.kill();p.wait(timeout=2)
if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='hook':hook()
    elif len(sys.argv)>1 and sys.argv[1]=='parent':parent()
    else:prove()
