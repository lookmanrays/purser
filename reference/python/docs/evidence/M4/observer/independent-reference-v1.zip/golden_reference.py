"""Construct the independent, ordered ten-question oracle from named original actions."""
from pathlib import Path
import json,hashlib
HERE=Path(__file__).resolve().parent
def jsonbytes(x):return (json.dumps(x,sort_keys=True,indent=2,ensure_ascii=False)+'\n').encode()
def cid(x):return {'kind':'git.commit','algorithm':'sha1','digest':x}
def reason(code,*ids):return dict(code=code,refs=sorted(ids))
def operator(action,subject):return {'action':action,'subject':subject}
def build(pending,ids):
    blocked={'W-doc-root':[reason('missing_coverage','W-doc-stale','W-doc-submitted')],'W-doc-stale':[reason('invalidated_support','A-doc','D-doc','Obs-changed-A-doc','W-doc-stale'),reason('missing_evidence','O-doc-stale'),reason('missing_result','W-doc-stale')],'W-doc-submitted':[reason('missing_evidence','O-doc')],'W-notify':[reason('missing_coverage','W2')],'W-root':[reason('missing_coverage','W-notify')],'W-wait':[reason('awaiting_activation',pending)],'W1':[],'W2':[reason('effect_unresolved','F-publish')],'W3':[]}
    works={'W-doc-root':('open',1,None),'W-doc-stale':('stale',1,None),'W-doc-submitted':('submitted',1,cid(ids['start'])),'W-notify':('open',1,None),'W-root':('open',1,None),'W-wait':('open',1,None),'W1':('closed',1,cid(ids['e3'])),'W2':('submitted',2,cid(ids['lifecycle_b'])),'W3':('closed',1,cid(ids['e3']))}
    q01=[dict(commitment=k,principal='principal:local') for k in ['C-doc','C-notify']]
    q02=[dict(work=k,state=v[0],generation=v[1],candidate=v[2]) for k,v in sorted(works.items())]
    q03=[dict(decision='D-doc',state='reconsidering',support=['A-doc']),dict(decision='D-revised',state='effective',support=['A2'])]
    q04=[dict(assumption='A-doc',affected=['D-doc','W-doc-stale']),dict(assumption='A1',affected=['D-original','W2'])]
    grants=[('G-expired','2026-11-18T13:50:00.000000Z','expired'),('G-publish','2026-11-18T14:00:00.000000Z','active'),('G-retired','2026-11-18T15:00:00.000000Z','revoked')]
    q05=[dict(grant=k,commitment='C-notify',grantee='executor:beta',capability='git.commit',resource='refs/heads/purser-demo',expires_at=expires,state=state) for k,expires,state in grants]
    q06=[dict(effect='F-publish',attempt='T1',state='dispatching')]
    criteria=[('O-delivery','W3','E-delivery'),('O-doc','W-doc-submitted',None),('O-doc-stale','W-doc-stale',None),('O-prefs','W1','E-prefs'),('O-retries','W2','E-B')]
    q07=[dict(obligation=k,work=w,version=1,state='passed' if e else 'open',evidence=[e] if e else []) for k,w,e in criteria]
    q08=[dict(work=k,reasons=blocked[k]) for k in sorted(blocked)]
    q09=[dict(commitment=c,root=w,missing=blocked[w]) for c,w in [('C-doc','W-doc-root'),('C-notify','W-root'),('C-wait','W-wait')]]
    q10=sorted([operator('reconcile','F-publish'),operator('observe','V-doc'),operator('principal_approve',pending),operator('reconsider','D-doc'),operator('rework','W-doc-stale')],key=lambda x:(x['action'],x['subject']))
    return dict(q01=q01,q02=q02,q03=q03,q04=q04,q05=q05,q06=q06,q07=q07,q08=q08,q09=q09,q10=q10)
def main():
    original=json.loads((HERE/'accepted-public-input.json').read_bytes())
    ids=json.loads((HERE/'real-git-reference.json').read_bytes())['objects'];assert ids==original['candidate_ids']
    p=original['pending']['details']['approval_id'];m3=original['status']['answers']
    # Old M3 was observed separately. Validate the hand-built rows independent of its exporter.
    legacy=build(p,ids)
    for q in ('q01','q02','q03','q04','q07','q09'):assert legacy[q]==m3[q],q
    for row in legacy['q08']:
        old=next(x for x in m3['q08'] if x['work']==row['work'])
        if row['work']=='W2':assert old['reasons']==[] and row['reasons']==[reason('effect_unresolved','F-publish')]
        else:assert row==old
    assert sorted([x for x in m3['q10'] if x['action']!='evaluate_close'],key=lambda k:(k['action'],k['subject']))==[x for x in legacy['q10'] if x['action']!='reconcile']
    golden=build('$approval_activation_C_wait',ids)
    out={'fixture':'M0 lifecycle 07 with actual Git identities and closed W1/W3, two active commitments plus a separate genuinely pending activation of C-wait. The M4 physical broker is killed after publication before acknowledgment. The fixed time is 1 s before G-publish expiry.','accepted_base':original['public_m3_source'],'fixed_utc':'2026-11-18T13:59:59.000000Z','exclusive_expiry':'2026-11-18T14:00:00.000000Z','initial_intent':{'id':'F-publish','repository':'R-notify','work':'W2','commitment':'C-notify','generation':2,'assignment':'AS-B','capability':'git.commit','slot':'publish','old':ids['start'],'target':ids['lifecycle_b'],'paths':['notify/retry.py'],'resource':'refs/heads/purser-demo'},'object_ids':ids,'independent_full_answers':golden,'derivation':'Rows and answers are independently written from the named facts, including closure, complete work sets, effective versus invalidated decisions, live exclusive expiry and the unique unresolved effect. The old eight-question consumer was exercised with the actual inputs as a separate cross-check. Pending approval ID is independently bound at its original pending proposal receipt. Use the actual completed revision and independently checked event-chain hash. No future product query provides expected answers.','typed_integration_fields':{'q05.resource':'Canonical allowed branch. If the agreed wire nests a repository/branch/path descriptor, project its independently checked canonical branch and independently check original repository and named retry-only allowed paths.','q08.effect_unresolved':'The required reason identifies the blocked logical effect F-publish. If the agreed public reason also names the requirement/attempt, validate those identifiers against the original admitted input, then compare the semantic row.','q10':'Compare the full applicable action/subject set. Purely presentational subject IDs derived by the agreed wire are resolved from original independent actions. Preserve unrecognized semantic additions or missing actions as discrepancies.'},'followups':{'same_revision_at_exclusive_expiry':'G-publish becomes expired; G-retired and G-expired retain their recorded/time-evaluated states. Existing T1 remains unresolved; reconcile survives. An unstarted sibling clone attempted at equality must produce no Git mutation. Use a separate actual wall-clock crossing on a fresh unstarted control.','after_reconciliation':'Independent occurrence and protected object observations bind F-publish. T1 leaves q06. Its reauthorization never appears. W2 becomes eligible for evaluate_close after all its other evidence remains current. Automatic W2 and W-notify can close; W-root then offers principal_accept for the exact derived outcome. C-notify remains active until a valid local controlled human accept. Later genuine branch advance can coexist with the earlier per-intent receipt.','history':'Historical query at the original completed revision and fixed time must reproduce all ten answers after any later expiry, reconciliation or acceptance. Fresh CLI and log-only rebuilt projection must agree. Reading never calls Git, a model, the broker, or a human.'}}
    file=HERE/'continuity-golden-v1.json';raw=jsonbytes(out)
    if file.exists():assert file.read_bytes()==raw
    else:file.write_bytes(raw)
    print(file.name,len(raw),hashlib.sha256(raw).hexdigest())
if __name__=='__main__':main()
