"""Build the original public M0–M3 prefix for the M4 awkward-state independent oracle."""
import hashlib,json,os,subprocess,sys,tempfile
from datetime import datetime,timezone
from pathlib import Path
from git_reference import make_source,candidate,git,canonical,digest
HERE=Path(__file__).resolve().parent
ASOF='2026-11-18T13:59:59.000000Z';EXP='2026-11-18T14:00:00.000000Z'
CLOCK=lambda:datetime(2026,11,18,13,40,tzinfo=timezone.utc)
def trace_where():
    root=Path(tempfile.mkdtemp(prefix='purser-m4-continuity.',dir='/private/tmp'));src=root/'fixture';ids=make_source(src)
    return root,src,ids
class Prefix:
    def __init__(self,root,src,ids):
        from purser.kernel.store import Store
        self.root=root;self.repo=src;self.ids=ids;self.store=Store(root/'cutoff.sqlite3');self.store.initialize()
        self.records=[];self.allowed={};self.n=0
    def proposal(self,c,role,actor,scope,*ops,expected='admitted',proof=None):
        from purser.kernel.gate import admit
        self.n+=1
        p={'v':1,'commitment':c,'proposal_id':'p-gold-'+str(self.n),'base_revision':self.store.snapshot()['revision'],'ops':list(ops),'justification':[]}
        b={'role':role,'actor_id':actor,'principal_id':'principal:local','commitment':None if role=='principal' else c,'assignment':scope}
        if proof:b.update(proof)
        reply=admit(self.store,b,p,clock=CLOCK)
        assert reply['disposition']==expected,(p,reply)
        self.records.append(dict(proposal=p,actor=actor,role=role,bound_subject=scope,receipt=reply))
        return reply
    def local(self,c,*ops,**kwargs): return self.proposal(c,'principal','principal:local',None,*ops,**kwargs)
    def active(self,c,root,accept=True):
        self.local(c,dict(op='commitment.create',id=c,root=root,statement='Controlled independent continuity '+c))
        receipt=self.local(c,dict(op='commitment.request_acceptance',id=c,expires_at='2026-11-19T00:00:00.000000Z'),expected='pending')
        if accept:self.local(c,dict(op='approval.answer',id=receipt['details']['approval_id'],request_digest=receipt['digest'],decision='approve'))
        return receipt
    def create_work(self,c,parent,children):
        self.local(c,*[dict(op='work.create',id=k,parent=parent,title='Local continuity '+k) for k in children])
        self.local(c,dict(op='work.coverage',id=parent,kind='all',k=None))
    def criterion(self,c,work,label):
        ids={'prefs':'O-prefs','retries':'O-retries','delivery':'O-delivery','doc':'O-doc','doc-stale':'O-doc-stale'}
        oid=ids[label]
        definition=('Independently read the submitted original Git bytes at the specific public policy function for '+label+'; require its assigned input/output pair.').encode()
        env=b'Private, controlled M4 continuity Git fixture and released-byte Python 3.11 interpreter.'
        self.allowed[work]=[oid,definition,env,label]
        self.local(c,dict(op='obligation.set',id=oid,work=work,version=1,title='Independent '+label,observer='observer:fixture',verifier='verifier:fixture',definition_sha256=digest(definition),environment_sha256=digest(env)))
    def assign(self,c,work,key,oid,executor='executor:fixture'):
        assignment='AS-'+key;result='Result-'+key;run='V-'+key;criterion=self.allowed[work][0]
        self.local(c,dict(op='work.assign',id=assignment,work=work,executor=executor))
        self.proposal(c,'executor',executor,assignment,dict(op='result.submit',id=result,assignment=assignment,candidate=candidate(oid)))
        self.local(c,dict(op='run.open',id=run,obligation=criterion,result=result))
    def measured(self,key,oid,label):
        paths={'prefs':'preferences','delivery':'delivery','retries':'retry'}
        path='notify/'+paths[label]+'.py'
        raw=git(self.repo,'show',oid+':'+path)
        p=self.root/(key+'-'+paths[label]+'.py')
        p.write_bytes(raw)
        expr={'prefs':"v['allowed']('mail', ['mail']) is False and v['allowed']('push',['mail']) is True",'delivery':"v['select'](['a','a','b','a']) == ('a','b')",'retries':"v['delays'](4,2) == "+("(0,2,4,6)" if key=='A' else "(0,2,4,8)")}[label]
        cmd=[sys.executable,'-I','-B','-c',"import runpy,sys;v=runpy.run_path(sys.argv[1]);print("+expr+")",str(p)]
        run=subprocess.run(cmd,capture_output=True,check=True,env={'PATH':'/usr/bin:/bin','LC_ALL':'C','TZ':'UTC'})
        assert run.stdout==b'True\n'
        return canonical(dict(oid=oid,path=path,source_sha256=digest(raw),expression=expr,stdout=run.stdout.decode(),status=run.returncode))
    def evidence(self,c,work,key,oid):
        obl,definition,env,label=self.allowed[work]
        run='V-'+key;ob='Obs-'+key
        tree={'candidate':candidate(oid),'definition':definition,'environment':env,'artifact':self.measured(key,oid,label)}
        self.proposal(c,'observer','observer:fixture',run,dict(op='observation.record',id=ob,run=run),proof={'witness':tree})
        self.proposal(c,'verifier','verifier:fixture',run,dict(op='evidence.record',id='E-'+key,verdict='pass',observation=ob,run=run))
    def decision(self,c,a,d,replacement=None):
        self.local(c,dict(op='assumption.create',id=a,statement=a+' holds',observer='observer:premise'))
        self.local(c,dict(op='decision.record',id=d,choice='revised' if replacement else 'original',alternatives=['original','revised'],rationale='Controlled local premise '+a,support=[a],triggers=[a],supersedes=replacement))
    def invalidate(self,c,a):
        self.proposal(c,'observer','observer:premise',a,dict(op='assumption.observe',id='Obs-changed-'+a,assumption=a,finding='contradicts'),proof={'premise':{'artifact':('Independently retained fixture observation of '+a+' contradiction').encode()}})
    def run(self):
        c='C-notify';dc='C-doc';ids=self.ids
        self.active(c,'W-root')
        self.create_work(c,'W-root',['W-notify'])
        self.create_work(c,'W-notify',['W1','W2','W3'])
        self.decision(c,'A1','D-original');self.local(c,dict(op='dependency.add',id='W2',support='D-original'))
        for work,label in [('W1','prefs'),('W2','retries'),('W3','delivery')]:self.criterion(c,work,label)
        for work,key in [('W1','prefs'),('W3','delivery')]:
            self.assign(c,work,key,ids['e3']);self.evidence(c,work,key,ids['e3'])
            self.proposal(c,'closure','closure:fixture',None,dict(op='work.close',id=work))
        self.assign(c,'W2','A',ids['lifecycle_a'],'executor:alpha')
        self.local(c,dict(op='decision.opine',id='Opinion-A1',decision='D-original',opinion='A different schedule sounds desirable.'))
        self.pre_opinion=self.store.snapshot()['revision']
        self.invalidate(c,'A1');self.pre_replace=self.store.snapshot()['revision']
        self.decision(c,'A2','D-revised','D-original')
        self.assign(c,'W2','B',ids['lifecycle_b'],'executor:beta');self.evidence(c,'W2','A',ids['lifecycle_a']);self.pre_current=self.store.snapshot()['revision']
        self.evidence(c,'W2','B',ids['lifecycle_b'])
        self.active(dc,'W-doc-root'); self.create_work(dc,'W-doc-root',['W-doc-stale','W-doc-submitted'])
        self.decision(dc,'A-doc','D-doc'); self.local(dc,dict(op='dependency.add',id='W-doc-stale',support='D-doc'))
        for work,label in [('W-doc-submitted','doc'),('W-doc-stale','doc-stale')]:self.criterion(dc,work,label)
        self.assign(dc,'W-doc-submitted','doc',ids['start'])
        self.local(dc,dict(op='work.assign',id='AS-doc-stale',work='W-doc-stale',executor='executor:doc'))
        self.invalidate(dc,'A-doc')
        self.human_pending=self.active('C-wait','W-wait',accept=False)
        return self
def public_status(root,db):
    args=[sys.executable,'-B','-m','purser','--db',str(db),'status','--as-of',ASOF]
    p=subprocess.run(args,capture_output=True,check=True,cwd=root,env={'PATH':'/usr/bin:/bin','LC_ALL':'C','TZ':'UTC'})
    return json.loads(p.stdout)
if __name__=='__main__':
    runroot=Path((HERE/'accepted-runtime-private-path.txt').read_text().strip())
    sys.path.insert(0,str(runroot))
    root,src,ids=trace_where();seed=Prefix(root,src,ids).run();snap=seed.store.snapshot();st=public_status(runroot,seed.store.path)
    # These are M3 public control observations. M4 and the complete independent 10-question golden are separate.
    result={'public_m3_source':'d865971fa3da20d0b82fa7bc56ca1b24c080270b','actual_public_records':seed.records,'heads':{'last_effective_opinion':seed.pre_opinion,'invalidated':seed.pre_replace,'late_old_evidence':seed.pre_current,'original_prefix':snap['revision']},'pending':seed.human_pending,'candidate_ids':ids,'status':st}
    dest=HERE/'accepted-public-input.json'
    assert not dest.exists()
    dest.write_bytes(canonical(result)+b'\n')
    (HERE/'prefix-private-directory.txt').write_text(str(root)+'\n')
    print('public_fixture',root,'head',snap['revision'],snap['head_hash'],'capture',digest(dest.read_bytes()))
