"""Known facts and independently hand-scored positive/adverse/undefined controls, prior to producer output."""
import copy,hashlib,json,subprocess
from pathlib import Path
from e3_reference import *
from git_reference import canonical,digest,PROJECT,M0
raw=json.loads((HERE/'real-git-reference.json').read_bytes());negative=json.loads((HERE/'git-counterexamples.json').read_bytes())
def action(a,inv=None,**kw):return dict(kind='action',action=a,invocation=inv or a,**kw)
def physical(rows):
    return [dict(kind='physical_ref_commit',old=r['old'],new=r['new'],ref=r['ref'],writer=r['actor'],belongs_to_semantic_slot=r['logical'].startswith('notify-'),physical_publication=r['time_ns']) for r in rows]
def observe(id,raw):
    receipt='absent' if raw['observed_receipt_target'] is None else 'matching' if raw['observed_receipt_target']==raw['target'] else 'wrong'
    return dict(kind='delivered_observation',id=id,facts=dict(bound_subject=raw['expected_receipt_binding'],qualified_repo=True,stable_snapshot=True,writer_quiescent=raw['writer_quiescent'],protected_retention_intact=raw['protected_retention_intact'],receipt=receipt,target_verified=True,tip_consistent_with_evidence=receipt=='matching',tip=raw['tip'],no_possible_unrecorded_write=raw['all_writes_in_boundary'] and not any(e['logical']==raw['logical'] for e in raw['actual_transitions'])))
def declare(value,obs=(),reason=None):return dict(kind='public_disposition',value=value,attributed_observations=list(obs),actionable_reason=reason)
def issue(t):return action('effect',t,physical_attempt=t,released_to_writer=True)
def auth(t):return dict(kind='authorized',physical_attempt=t,semantic='notify-3001',current_grant=True)
end={'kind':'public_completion'}
quit={'kind':'original_writer_exit','writer':'T1','quiescent':True}
def case(events,**kw):
    return dict(dict(track='primary',intent='notify-3001',original_writer='T1',terminal_success=True,complete_external_chain=True,complete_public_history=True,terminal_observed=True,manual_repair=False,stuck_requires_manual=False,clock={'start':1,'end':1_234_567_892,'offline':[(20,28)]},events=events),**kw)
land=raw['cases']['landed'];absent=raw['cases']['unlanded'];live=raw['cases']['uncertain'];obs_l=observe('obs-l',land['after_legitimate_advance']);obs_u=observe('obs-u',absent['before_retry']);obs_x=observe('obs-x',live['still_live_original']['observation'])
L=physical(land['actual_counted_transitions']);U=physical(absent['actual_counted_transitions'])
assert len(L)==2 and len(U)==1
lcase=case([issue('T1'),L[0],quit,action('reconcile'),L[1],obs_l,declare('landed',['obs-l']),end])
ucase=case([issue('T1'),quit,action('reconcile'),obs_u,declare('unlanded',['obs-u']),auth('T2'),issue('T2'),U[0],end])
cases={}
def control(name,s,fields):
    got=score(s)
    for k,v in fields.items():assert got[k]==v,(name,k,got[k],v)
    cases[name]=dict(expected=fields,observed=got)
control('lost_ack_then_legitimate_different_writer_advance',lcase,dict(original_truth='landed',original_report='landed',effect_count=1,duplicate_count=0,correct_reconciliation=True,resolved_by_budget=True))
control('known_absence_original_3002_worked_example',ucase,dict(original_truth='unlanded',original_report='unlanded',effect_count=1,duplicate_count=0,correct_reconciliation=True,manual_repair=False,resolved_by_budget=True))
published=json.loads(subprocess.check_output(['git','show',M0+':experiments/manifests/v1/worked-examples.json'],cwd=PROJECT))
m0=next(x['expected_score'] for x in published['cases'] if x['experiment']=='E3')
assert {k:score(ucase)[k] for k in m0}==m0
wrong=copy.deepcopy(ucase);wrong['events'][4]=declare('landed',['obs-u'])
control('right_final_tip_wrong_original',wrong,dict(original_truth='unlanded',original_report='landed',correct_reconciliation=False,effect_count=1,resolved_by_budget=True))
late=copy.deepcopy(ucase);ev=late['events'];ev[3:7]=[auth('T2'),issue('T2'),obs_u,declare('unlanded',['obs-u'])]
control('true_declaration_after_new_physical_attempt',late,dict(correct_reconciliation=False,effect_count=1,justified_in_order=False,unfresh_retry=['T2']))
pre=copy.deepcopy(ucase);ev=pre['events'];ev[3:6]=[auth('T2'),obs_u,declare('unlanded',['obs-u'])]
control('fresh_id_with_only_early_authorization',pre,dict(correct_reconciliation=False,effect_count=1,unfresh_retry=['T2']))
guard=copy.deepcopy(lcase);guard['events'].insert(-1,action('effect','rejected-proposal',released_to_writer=False))
control('rejected_duplicate_request_zero_new_transition',guard,dict(correct_reconciliation=True,effect_count=1,duplicate_count=0))
dup=copy.deepcopy(lcase);dup['events']=[issue('T1'),quit,obs_l,declare('landed',['obs-l']),auth('T2'),issue('T2'),*physical(negative['two_real_applications']['all_effects']),end]
control('two_actual_publications_another_transport_same_intent',dup,dict(effect_count=2,duplicate_count=1,correct_reconciliation=False))
for k in ['tip_without_receipt','wrong_receipt']:
    obs=observe('obs-x',negative[k]['facts']);assert identify(obs['facts'])=='unknown'
    control(k,case([issue('T1'),quit,obs,declare('landed',['obs-x']),end]),dict(effect_count=0,correct_reconciliation=False,resolved_by_budget=False))
stress=case([issue('T1'),obs_x,declare('unknown',['obs-x'],'Earlier writer is still able to publish. Resume observation when it exits.')],track='inconclusive-observation',terminal_success=False)
control('live_writer_honest_stress',stress,dict(original_truth='unknown',original_report='unknown',correct_reconciliation=None,stress_held_pending=True,effect_count=0))
bad_stress=copy.deepcopy(stress);bad_stress['events'].append(issue('T2'))
control('pending_label_with_real_retry_in_stress',bad_stress,dict(stress_held_pending=False,effect_count=0))
stuck=case([issue('T1'),quit,obs_u,declare('unknown')],terminal_success=False,stuck_requires_manual=True,manual_repair=False)
control('ordinary_resolvable_idle_needs_repair_but_none_performed',stuck,dict(correct_reconciliation=False,stuck_requires_manual=True,manual_repair=False,resolved_by_budget=False))
unknown=copy.deepcopy(lcase);unknown['complete_public_history']=False;unknown['complete_external_chain']=False;unknown['clock']=None
control('missing_independent_coverage',unknown,dict(correct_reconciliation=None,effect_count=None,resolved_by_budget=None))
frames=copy.deepcopy(lcase);frames['events'].insert(1,dict(kind='action',action='effect',invocation='T1',transport_frame_only=True))
assert score(frames)['cost']['steps']==score(lcase)['cost']['steps']==2 and score(frames)['cost']['elapsed_ns']==1_234_567_883
controls={}
gold={('primary',s,a):score(lcase if s%2 else ucase) for a in ARMS for s in range(3001,3021)}
for a in ARMS:gold[('clean',3001,a)]=score(lcase)
def csum(name,changes,expect):
    tab=dict(gold);tab.update(changes);x=aggregate(tab)
    fact=x['arms']['purser'];got=(fact['absolute'],fact['original_no_advantage'],x['clean_overhead'])
    assert got==expect,(name,got,expect);controls[name]=dict(absolute=expect[0],original_no_advantage=expect[1],clean_overhead=expect[2])
csum('twenty_correct_zero_duplicates',{},(True,False,False))
csum('wrong_original_with_one_effect_and_no_stuck',{('primary',3002,'purser'):score(wrong)},(False,False,False))
csum('actual_duplicate',{('primary',3001,'purser'):score(dup)},(False,True,False))
csum('manual_needed_in_ordinary',{('primary',3002,'purser'):score(stuck)},(False,True,False))
csum('unknown_coverage',{('primary',3001,'purser'):None},(None,None,False))
csum('known_duplicate_even_with_other_unit_missing',{('primary',3001,'purser'):score(dup),('primary',3002,'purser'):None},(False,True,False))
def priced(n):
    r=score(lcase);r['cost']['steps']=n;return r
csum('clean_exactly_double',{('clean',3001,'purser'):priced(4),('clean',3001,'loop'):priced(2)},(True,False,False))
csum('clean_strictly_over_double',{('clean',3001,'purser'):priced(5),('clean',3001,'loop'):priced(2)},(True,False,True))
csum('failed_clean_ineligible',{('clean',3001,'purser'):score(stuck)},(True,False,None))
schedule=list(units());assert len(schedule)==66 and len({(v['track'],v['seed'],v['arm']) for v in schedule})==66
assert [r['arm'] for r in schedule[:3]]==['loop_equal_verifier','loop','purser'] and sum(v['fault_slot']=='landed_ack_lost' for v in schedule)==30 and sum(v['fault_slot']=='unlanded_writer_finished' for v in schedule)==30
output=dict(schema='independent_reference_controls_v1',source='accepted M0 contracts and directly observed private physical cases; synthetic chronology and arithmetic are explicitly hand controls',per_case=cases,aggregate_facts=controls,schedule=schedule,budgets={'scripted':{'steps':96,'active_elapsed_ns':60_000_000_000,'model_calls':0,'tokens':0,'spend':0},'separate_M5_model':{'steps':96,'elapsed_s':900,'model_calls':8,'input_tokens':64000,'output_tokens':12000,'needs_named_monetary_authority':True}},scientific='Absolute and the original no-advantage are independent, not complements. Report all arm counts with observed/20, and primary Purser-minus-baseline paired costs for both comparisons, one separate matched clean and one distinct unresolved stress seed each. Real-mode outcomes are outside the scripted series.')
p=HERE/'e3-reference-controls.json';raw=canonical(output)+b'\n'
if p.exists():assert p.read_bytes()==raw
else:p.write_bytes(raw)
print('e3_original_controls',len(cases),'aggregate',len(controls),'units',len(schedule),'sha256',digest(raw))
