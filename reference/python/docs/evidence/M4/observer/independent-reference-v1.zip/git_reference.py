"""Independently build the two frozen fixture populations and witness local reference transactions."""
import hashlib,json,os,signal,subprocess,sys,tempfile,time
from collections import Counter
from pathlib import Path
ME=Path(__file__).resolve()
M0='4460381e44f3dd42d22848bf6d82fea9a817a833'
BASE='d865971fa3da20d0b82fa7bc56ca1b24c080270b'
PROJECT=Path('/Users/lookman/Projects/purser')
SOURCE='experiments/manifests/v1/'
BRANCH='refs/heads/notify'
SHA='0'*40
def run(args,cwd,inputs=None,env=None,check=True):
    return subprocess.run(args,input=inputs,cwd=cwd,env=env or {'PATH':'/usr/bin:/bin','LC_ALL':'C','TZ':'UTC','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null'},stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=check)
def gg(cwd,*args,inputs=None,env=None,check=True):
    return run(['/usr/bin/git',*args],cwd,inputs,env,check)
def git(cwd,*args,**kw):return gg(cwd,*args,**kw).stdout
def show(path):return git(PROJECT,'show',M0+':'+SOURCE+path)
def canonical(obj):return json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def digest(raw):return hashlib.sha256(raw).hexdigest()
def tag_intent(obj):return digest(b'purser/effect/v1'+bytes([0])+canonical(obj))
def candidate(oid):return {'kind':'git.commit','algorithm':'sha1','digest':oid}
def writer_identity():
    return {**{'PATH':'/usr/bin:/bin','LC_ALL':'C','TZ':'UTC','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null'},**{k:'Purser fixture' for k in ['GIT_AUTHOR_NAME','GIT_COMMITTER_NAME']},**{k:'fixture@example.invalid' for k in ['GIT_AUTHOR_EMAIL','GIT_COMMITTER_EMAIL']},**{k:'2000-01-01T00:00:00+0000' for k in ['GIT_AUTHOR_DATE','GIT_COMMITTER_DATE']}}
def make_source(folder):
    manifest=json.loads(show('manifest.json'));spec=manifest['fixture']
    folder.mkdir();git(folder,'init','--quiet','--object-format=sha1')
    original={}
    for row in spec['files']:
        raw=show('input/'+row['path']);assert digest(raw)==row['sha256']
        path=folder/row['path'];path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw);path.chmod(0o644)
        original[row['path']]=raw
    def tree():
        git(folder,'add','--all');return git(folder,'write-tree').decode().strip()
    def commit(obj,msg,parent=None):
        extra=['-p',parent] if parent else []
        return git(folder,'commit-tree',obj,*extra,inputs=msg.encode(),env=writer_identity()).decode().strip()
    def change(path,last_line):
        file=folder/path
        lines=original[path].splitlines(keepends=True)
        assert lines[-1].startswith(b'    return ') and lines[-1].endswith(b'\n')
        file.write_bytes(b''.join(lines[:-1])+b'    return '+last_line.encode()+b'\n')
    t0=tree();old=commit(t0,spec['git']['commit_message']);assert old==spec['commit_sha1'] and t0==spec['tree_sha1']
    retry='notify/retry.py'
    change(retry,'tuple(k * base for k in range(attempts))');a=commit(tree(),'Continuity fixture original retry\n',old)
    change(retry,'tuple(0 if k == 0 else base * 2 ** (k - 1) for k in range(attempts))');b=commit(tree(),'Continuity fixture revised retry\n',old)
    change(retry,'tuple(k * base for k in range(attempts))');change('notify/preferences.py','channel not in disabled');change('notify/delivery.py','tuple(dict.fromkeys(event_ids))')
    t=tree();fixed=commit(t,manifest['experiments']['E3']['prepared_candidate']['commit_message'],old)
    later=commit(t,'Independent later legitimate branch advance\n',fixed)
    assert fixed==manifest['experiments']['E3']['prepared_candidate']['commit_sha1'] and t==manifest['experiments']['E3']['prepared_candidate']['tree_sha1']
    for oid,paths in [(a,[retry]),(b,[retry]),(fixed,sorted(spec['public_paths']))]:
        got=git(folder,'diff-tree','-r','--no-commit-id','--name-only',old,oid).decode().splitlines();assert sorted(got)==paths
    for oid in [old,a,b,fixed,later]:git(folder,'update-ref','refs/heads/export/'+oid,oid)
    return dict(start=old,initial_tree=t0,lifecycle_a=a,lifecycle_b=b,e3=fixed,prepared_tree=t,later=later)
def new_repo(source,dest,oids):
    dest.mkdir()
    git(dest,'init','--bare','--quiet','--object-format=sha1')
    git(dest,'fetch','--quiet','--no-tags',str(source),'+refs/heads/export/*:refs/hidden/input/*')
    git(dest,'update-ref',BRANCH,oids['start'])
    git(dest,'config','core.logAllRefUpdates','always')
    hooks=dest.parent/(dest.name+'-outside-witness');hooks.mkdir()
    git(dest,'config','core.hooksPath',str(hooks))
    hook=hooks/'reference-transaction'
    hook.write_text('#!/bin/sh\nexec '+sys.executable+' -B '+str(ME)+' hook "$1" '+str(hooks/'transactions.ndjson')+'\n');hook.chmod(0o755)
    return hooks/'transactions.ndjson'
def hook():
    # The controller binds a writer to a logical effect before release. Git provides actual ref transition data.
    rec={'phase':sys.argv[2],'time_ns':time.monotonic_ns(),'actor':os.environ.get('PUR_WITNESS_WRITER'),'logical_intent':os.environ.get('PUR_WITNESS_INTENT'),'refs':[]}
    for line in sys.stdin:
        old,new,ref=line.split();rec['refs'].append({'old':old,'new':new,'ref':ref})
    with Path(sys.argv[3]).open('ab') as f:
        f.write(canonical(rec)+b'\n');f.flush();os.fsync(f.fileno())
def readref(repo,ref):
    p=gg(repo,'show-ref','--verify','--hash',ref,check=False)
    return p.stdout.decode().strip() if p.returncode==0 else None
def pack(repo,old,new,receipt):
    return f'start\nupdate {BRANCH} {new} {old}\ncreate {receipt} {new}\nprepare\ncommit\n'.encode()
def action_env(writer,intent):
    return {**writer_identity(),'PUR_WITNESS_WRITER':writer,'PUR_WITNESS_INTENT':intent}
def actor():
    repo,mode,old,target,receipt,writer,intent=sys.argv[2:9]
    print('ready',flush=True)
    if mode in ('hold-before','survivor'):sys.stdin.readline()
    if mode=='hold-before':return
    ret=gg(repo,'update-ref','--stdin',inputs=pack(repo,old,target,receipt),env=action_env(writer,intent),check=False)
    print(json.dumps({'actual_rc':ret.returncode,'stdout':ret.stdout.decode().splitlines(),'stderr':ret.stderr.decode().splitlines()}),flush=True)
    if mode=='hold-after':sys.stdin.readline()
def start(repo,mode,old,target,receipt,writer,intent):
    p=subprocess.Popen([sys.executable,'-B',str(ME),'actor',str(repo),mode,old,target,receipt,writer,intent],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,text=True,env=action_env(writer,intent))
    assert p.stdout.readline().strip()=='ready'
    return p
def stop(p):
    os.killpg(p.pid,signal.SIGKILL); code=p.wait(timeout=5)
    try:os.killpg(p.pid,0);dead=False
    except ProcessLookupError:dead=True
    assert code==-9 and dead
    return {'original_pid':p.pid,'returncode':code,'process_group_absent':dead,'observed_ns':time.monotonic_ns()}
def records(hookfile):
    return [json.loads(line) for line in hookfile.read_bytes().splitlines()] if hookfile.exists() else []
def external(hookfile):
    return [dict(actor=e['actor'],logical=e['logical_intent'],time_ns=e['time_ns'],ref=r['ref'],old=r['old'],new=r['new']) for e in records(hookfile) if e['phase']=='committed' for r in e['refs'] if r['ref']==BRANCH and r['old']!=r['new']]
def fact(path,intent,receipt,objects,hookfile,writer_still_alive,retention=True):
    return dict(repository=str(path.name),logical=intent,receipt_ref=receipt,observed_receipt_target=readref(path,receipt),tip=readref(path,BRANCH),expected_old=objects['start'],target=objects['e3'],writer_quiescent=not writer_still_alive,protected_retention_intact=retention,expected_receipt_binding=True,all_writes_in_boundary=True,actual_transitions=external(hookfile))
def conclusion(obs):
    if not obs['expected_receipt_binding'] or not obs['writer_quiescent'] or not obs['protected_retention_intact']:return 'pending'
    if obs['observed_receipt_target']==obs['target'] and obs['all_writes_in_boundary']:return 'landed'
    if obs['observed_receipt_target'] is None and obs['tip']==obs['expected_old'] and obs['all_writes_in_boundary'] and all(x['logical']!=obs['logical'] for x in obs['actual_transitions']):return 'unlanded'
    return 'pending'
def physical():
    root=Path(tempfile.mkdtemp(prefix='purser-m4-git-reference.',dir='/private/tmp'));source=root/'source';ids=make_source(source)
    result={'scope':'Preimplementation physical reference, independent of all M4 worker sources and official experiment. Controller owns these private Git refs and captures all committed transitions under this fixture.','objects':ids,'cases':{}}
    for idx,kind in enumerate(['landed','unlanded','uncertain'],1):
        repo=root/kind;hf=new_repo(source,repo,ids);logical='notify-'+str(3000+idx)
        intent=dict(repository='R-notify',commitment='C-notify',work='W-notify',generation=1,assignment='AS-control',slot='publish',effect=logical,capability='git.commit',resource=BRANCH,expected_old=candidate(ids['start']),target=candidate(ids['e3']),purpose='Publish the prepared notification change.',grant='G-study')
        receipt='refs/purser/receipts/'+tag_intent(intent)
        case={'fixture_intent':intent,'predeclared_receipt':receipt,'attempts':[]}
        if kind=='landed':
            proc=start(repo,'hold-after',ids['start'],ids['e3'],receipt,'T1',logical)
            original=json.loads(proc.stdout.readline());assert original['actual_rc']==0
            case['original_writer_killed_before_caller_ack']=stop(proc)
            boundary=fact(repo,logical,receipt,ids,hf,False);assert conclusion(boundary)=='landed'
            case['before_advance']=boundary
            admin=gg(repo,'update-ref',BRANCH,ids['later'],ids['e3'],env=action_env('separate-writer','other-legitimate-intent'));assert admin.returncode==0
            advanced=fact(repo,logical,receipt,ids,hf,False);assert conclusion(advanced)=='landed' and advanced['tip']==ids['later']
            case['after_legitimate_advance']=advanced
            repeat=gg(repo,'update-ref','--stdin',inputs=pack(repo,ids['start'],ids['e3'],receipt),env=action_env('readback-control',logical),check=False);assert repeat.returncode!=0
            case['guarded_conflict']={'returncode':repeat.returncode,'same_intent_transitions':sum(e['logical']==logical for e in external(hf))}
        elif kind=='unlanded':
            proc=start(repo,'hold-before',ids['start'],ids['e3'],receipt,'T1',logical);case['original_killed_and_reaped']=stop(proc)
            obs=fact(repo,logical,receipt,ids,hf,False);assert conclusion(obs)=='unlanded'
            case['before_retry']=obs
            p=start(repo,'normal',ids['start'],ids['e3'],receipt,'T2',logical);res=json.loads(p.stdout.readline());assert p.wait(timeout=5)==res['actual_rc']==0
            case['separate_reference_retry']=dict(writer='T2',k='physical control, without product authorization claims',result=res)
            case['after_physical_retry']=fact(repo,logical,receipt,ids,hf,False)
        else:
            p=start(repo,'survivor',ids['start'],ids['e3'],receipt,'T1',logical);assert p.poll() is None
            obs=fact(repo,logical,receipt,ids,hf,True);assert conclusion(obs)=='pending' and not obs['actual_transitions']
            case['still_live_original']=dict(pid=p.pid,returncode_at_observation=p.poll(),observation=obs)
            p.stdin.write('continue\n');p.stdin.flush();assert json.loads(p.stdout.readline())['actual_rc']==0 and p.wait(timeout=5)==0
            case['same_writer_later_landed']=fact(repo,logical,receipt,ids,hf,False)
            assert len(external(hf))==1 and external(hf)[0]['actor']=='T1'
        case['actual_transactions']=records(hf);case['actual_counted_transitions']=external(hf)
        assert sum(row['logical']==logical for row in external(hf))==1
        result['cases'][kind]=case
    dest=ME.parent/'real-git-reference.json'
    if dest.exists():raise RuntimeError('Original physical reference already exists; preserve it.')
    dest.write_bytes(canonical(result)+b'\n')
    print('git_commit_targets',json.dumps(ids,sort_keys=True));print('physical_reference',str(dest),digest(dest.read_bytes()))
if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='hook':hook()
    elif len(sys.argv)>1 and sys.argv[1]=='actor':actor()
    else:physical()
