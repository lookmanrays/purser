"""Additional independently constructed local Git histories. These are controls outside the registered series."""
from pathlib import Path
import json,tempfile
from git_reference import *
root=Path(tempfile.mkdtemp(prefix='purser-m4-git-negative.',dir='/private/tmp'));src=root/'source';obj=make_source(src);old,target=obj['start'],obj['e3'];result={}
a=BRANCH;logical='notify-3001'
for variant in ['tip_without_receipt','wrong_receipt','two_real_applications']:
    repo=root/variant;hf=new_repo(src,repo,obj);ref='refs/purser/receipts/'+digest(b'original-unmodified-intent')
    if variant=='tip_without_receipt':
        gg(repo,'update-ref',a,target,old,env=action_env('external-other','other-logical'))
        f=fact(repo,logical,ref,obj,hf,False);assert conclusion(f)=='pending' and f['tip']==target and f['observed_receipt_target'] is None
    elif variant=='wrong_receipt':
        gg(repo,'update-ref',ref,old,'0'*40,env=action_env('foreign-control','foreign-input'))
        f=fact(repo,logical,ref,obj,hf,False);assert f['observed_receipt_target']==old and conclusion(f)=='pending'
    else:
        gg(repo,'update-ref','--stdin',inputs=pack(repo,old,target,ref),env=action_env('T1',logical))
        gg(repo,'update-ref',a,old,target,env=action_env('independent-fixture-rewind','fixture-rewind'))
        other='refs/purser/receipts/'+digest(b'different-transport-id-same-fixture-operation')
        gg(repo,'update-ref','--stdin',inputs=pack(repo,old,target,other),env=action_env('T2-other-transport',logical))
        f=fact(repo,logical,ref,obj,hf,False);observed=[x for x in external(hf) if x['logical']==logical];assert len(observed)==2 and observed[0]['old']==observed[1]['old']==old and observed[0]['new']==observed[1]['new']==target and observed[0]['time_ns']!=observed[1]['time_ns']
    result[variant]=dict(facts=f,transactions=records(hf),all_effects=external(hf))
p=ME.parent/'git-counterexamples.json';assert not p.exists();p.write_bytes(canonical(result)+b'\n');print(p.name,digest(p.read_bytes()))
