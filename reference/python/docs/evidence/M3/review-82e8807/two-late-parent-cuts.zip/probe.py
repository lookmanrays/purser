"""Exercise a case-local late crash with the same publication witness on both public state formats."""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
from unittest.mock import patch
from zipfile import ZipFile

def shab(data):
    return sha256(data).hexdigest()

def save(file, value):
    file.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n")

def git(directory, *args):
    return subprocess.check_output(["git", *args], cwd=directory, text=True).strip()

def worker(repo, arm):
    sys.path.insert(0, str(repo))
    from experiments.e2 import policy, suite
    from experiments.e1.capture import position
    cls = policy.KernelArm if arm == "purser" else policy.PlanArm
    decide = cls.decide
    def after_close(self, work, audit):
        reply = decide(self, work, audit)
        if work == "W-notify":
            rows, head = self.public_view()
            state, candidate = position(rows[work])
            if state in ("closed", "done"):
                save(repo.parent/(arm+"-close.json"), {"arm":arm,"head":head,"public":rows,"candidate":candidate,"pid":os.getpid()})
                os.kill(os.getpid(), signal.SIGKILL)
        return reply
    with patch.object(cls, "decide", after_close):
        suite.collect_units(repo/("private-"+arm), [("primary",2001,1,arm)])

def run_case(repo, arm):
    sys.path.insert(0, str(repo))
    from experiments.e2 import suite, trial
    folder=repo/("private-"+arm)
    args=[sys.executable,"-I","-B",str(Path(__file__).resolve()),str(repo.parent),"--worker",arm]
    child=subprocess.run(args,capture_output=True,timeout=190)
    assert child.returncode == -signal.SIGKILL, (arm,child.returncode,child.stderr[-1300:])
    hand=json.loads((repo.parent/(arm+"-close.json")).read_bytes())
    attempt=folder/(".attempt-primary-2001-"+arm)
    (attempt/"trial").rename(repo.parent/("withheld-"+arm))
    calls=0
    def no_new_calls(*args,**kwargs):
        nonlocal calls
        calls += 1
        raise AssertionError("a started case was dispatched again")
    with patch.object(trial,"attempt",no_new_calls):
        unit=[("primary",2001,1,arm)]
        suite.collect_units(folder,unit)
        digest=shab((folder/"raw.zip").read_bytes())
        suite.collect_units(folder,unit)
        assert digest==shab((folder/"raw.zip").read_bytes()) and calls==0
    result={"arm":arm,"original_commit_at_physical_parent_close":hand["candidate"],"public_head_at_physical_parent_close":hand["head"],"process_exit":child.returncode,"redispatches":calls,"same_on_second_reopen":True,"raw_sha256":digest,"freeze_sha256":shab((folder/"freeze.json").read_bytes())}
    with ZipFile(folder/"raw.zip") as z:
        def object_json(ref):
            data=z.read(ref["path"])
            assert len(data)==ref["bytes"] and shab(data)==ref["sha256"]
            return json.loads(data)
        record=json.loads(z.read("runs/primary/2001/"+arm+".json")); platform=object_json(record["artifacts"]["platform"])
        ck=platform["checkpoint_measurement"]; source=object_json(ck["submission_source"])
        raw_journal=object_json(record["artifacts"]["journal"])
        result.update(raw_status=record["terminal"],raw_steps=record["cost"]["steps"],raw_score=record["score"],terminal_trace_present=bool(platform.get("treatment_trace")),participant_exit=platform.get("participant_exit"),checkpoint_candidate=ck["candidate"],checkpoint_ref=ck["checkpoint"],checkpoint_submission_attempt=ck["submission_attempt"],checkpoint_source_sha256=ck["submission_source"]["sha256"],checkpoint_source_fields=sorted(source),checkpoint_prefix_units=len(source.get("original_events",source.get("plan_versions",[]))),retained_worker_fault_records=sum(1 for row in raw_journal if row["kind"]=="fault"),protected_rows=sum(1 for row in raw_journal if row["kind"]=="oracle"))
    for action in ("report","verify"):
        read=subprocess.run([sys.executable,"-B","-m","experiments.e2",action,str(folder)],cwd=repo,capture_output=True,timeout=250)
        (repo.parent/f"{arm}.{action}.out").write_bytes(read.stdout)
        (repo.parent/f"{arm}.{action}.err").write_bytes(read.stderr)
        result[action+"_exit"]=read.returncode
        if read.stderr:
            result[action+"_last_message"]=read.stderr.decode(errors="replace").splitlines()[-1]
    save(repo.parent/(arm+"-result.json"),result)
    print(json.dumps(result),flush=True)

def main():
    cmd=argparse.ArgumentParser(); cmd.add_argument("root",type=Path); cmd.add_argument("--source",default="/Users/lookman/Projects/purser"); cmd.add_argument("--commit",default="82e880734539bbd8d2af2b0b44fbdcff2b4062f3");cmd.add_argument("--first-replicate",type=int,default=313);cmd.add_argument("--worker");a=cmd.parse_args()
    root=a.root.resolve(); repo=root/"repo"
    if a.worker:
        worker(repo,a.worker);return
    assert a.first_replicate>1
    root.mkdir(exist_ok=True)
    git(root,"clone","-q","--local","--no-checkout",a.source,str(repo))
    git(repo,"checkout","--quiet","--detach",a.commit)
    assert git(repo,"rev-parse","HEAD")==a.commit
    sys.path.insert(0,str(repo)); from experiments.e2 import suite
    arms=["purser","loop_equal_verifier"]
    paths=[]
    for i,arm in enumerate(arms):
        f=repo/("private-"+arm)
        suite.freeze_series(f,replicate=a.first_replicate+i,reason="Private late parent-publication recovery control with disposable trial set aside")
        assert json.loads((f/"freeze.json").read_bytes())["source_commit"]==a.commit
        paths.append(str((f/"freeze.json").relative_to(repo)))
    git(repo,"add","--",*paths)
    git(repo,"-c","user.name=Purser independent architect","-c","user.email=architect@purser.invalid","commit","-qm","Register two private late-parent publication cuts")
    git(repo,"bundle","create",str(root/"registration.bundle"),"HEAD","^"+a.commit)
    save(root/"registration.json",{"source":a.commit,"registration":git(repo,"rev-parse","HEAD"),"arms":arms,"replicates":[a.first_replicate,a.first_replicate+1],"script_sha256":shab(Path(__file__).read_bytes())})
    for arm in arms:run_case(repo,arm)
if __name__=="__main__": main()
