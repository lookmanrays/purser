"""Independently read the old public checkpoint in the two late-parent crash archives."""
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import tempfile
from zipfile import ZipFile

base = Path(__file__).resolve().parent
repo = base / "repo"
spec = importlib.util.spec_from_file_location("continuity", repo / "docs/evidence/M3/series_continuity.py")
continuity = importlib.util.module_from_spec(spec)
spec.loader.exec_module(continuity)
out = {}
for arm in ("purser", "loop_equal_verifier"):
    raw = repo / ("private-" + arm) / "raw.zip"
    with ZipFile(raw) as z:
        def load(ref):
            data = z.read(ref["path"])
            assert sha256(data).hexdigest() == ref["sha256"] and len(data) == ref["bytes"]
            return json.loads(data)

        record = json.loads(z.read("runs/primary/2001/" + arm + ".json"))
        platform = load(record["artifacts"]["platform"])
        ck = platform["checkpoint_measurement"]
        prefix = load(ck["submission_source"])
        view = load(ck["checkpoint"]["view"])
        if arm == "purser":
            original = [e.encode("utf-8") for e in prefix["original_events"]]
            events = [json.loads(e) for e in original]
            tip = events[-1]
            wanted = {v for e in events for k, v in e["data"].items() if k.endswith("_sha256") and isinstance(v, str)}
            blobs = {n.split("/")[-1].split(".")[0]: z.read(n) for n in z.namelist()
                     if n.startswith("objects/") and n.split("/")[-1].split(".")[0] in wanted}
            assert all(sha256(v).hexdigest() == k for k, v in blobs.items())
            with tempfile.TemporaryDirectory() as scratch:
                db = continuity.restore(Path(scratch) / "prefix", original, blobs)
                status = continuity.public_state(db, tip["revision"], tip["at"])["status"]
            assert status["head_hash"] == ck["checkpoint"]["head_hash"]
            work = {r["work"]: r for r in status["answers"]["q02"]}
            assert all(work.get(k) == v for k, v in view.items())
            original_decision, = [x["data"] for x in events if x["type"] == "DecisionRecorded"
                                  and x["data"]["id"] == "D-retry-linear"]
            assert original_decision["choice"] == "linear" and original_decision["support"] == ["A1"]
            assert any(d["decision"] == original_decision["id"] and d["state"] == "effective"
                       for d in status["answers"]["q03"])
            result = {"method":"cold CLI replay of original event bytes","revisions":len(events),
                      "authenticated_prefix_head":status["head_hash"],"referenced_witnesses_present":sorted(blobs),
                      "referenced_witnesses_unavailable":sorted(wanted - blobs.keys()),
                      "recorded_choice":original_decision["choice"],"visible_decisions":status["answers"]["q03"]}
        else:
            previous = None
            steps = []
            for number, ref in enumerate(prefix["plan_versions"], 1):
                work = load(ref)
                meta = work["W-notify"]["_e2_plan_version"]
                assert meta["number"] == number and meta["previous"] == previous
                previous = ref["sha256"]
                steps.append([number, previous, meta["attempt"]])
            assert previous == ck["checkpoint"]["plan_sha256"] and work == view == prefix["plan"]
            assert work["W2"]["retry_choice"] == "linear" and work["W2"]["premise"] is None
            result = {"method":"ordered original plan bytes, including hashes and predecessors","publications":steps,
                      "recorded_choice":work["W2"]["retry_choice"]}
        states = {w:{"state":work[w]["state"],"candidate":(work[w]["candidate"].get("digest")
                    if isinstance(work[w]["candidate"],dict) else work[w]["candidate"])} for w in ("W1","W2","W3")}
        assert [states[w]["state"] for w in ("W1","W2","W3")] == ["closed","submitted","closed"]
        assert states["W2"]["candidate"] == ck["candidate"]
        out[arm] = dict(result, raw_sha256=sha256(raw.read_bytes()).hexdigest(), old_subjects=states,
                        checkpoint_source=ck["submission_source"]["sha256"])
dest = base / "prefix-readback.json"
dest.write_text(json.dumps(out, sort_keys=True, indent=2) + "\n")
print(sha256(dest.read_bytes()).hexdigest())
