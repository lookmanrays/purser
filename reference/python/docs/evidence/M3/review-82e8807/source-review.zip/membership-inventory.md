# E2 independent exact-source review

**NO-GO for official registration.** The reviewed evaluator is 82e880734539bbd8d2af2b0b44fbdcff2b4062f3. The accepted Purser product tree is c2d2e50c748324fc0b4fe697ccf490efc47c15f9. I compared the evaluator to the original M0 protocol, the reconciled design with SHA-256 dd24d464d6da9d8ba589873e48652366c6141ea449bfa6066854e361c41be19f, and the independently frozen estimator with manifest a514c3505f0d6236148f475a029ac26305a13e8ef3d279a5dd7eeb9875a9ad04.

## Two distinct questions a reader must answer

The answer to **which commit this participant actually produced or exposed** can come from a case-local original. Examples include a specific installed working Git HEAD, an original plan or SQLite publication naming the exact candidate, a genuinely case-bound candidate-map entry, and the verified unique target of a full pack retained by this attempt before pooling. On the normal private collector, the case also retains references to its packs in both the seal list and its own referenced-files list. A pack's SHA-256, length, ancestry and unique target permit a check of its correspondence to the proposed OID. An identifiable disagreement should remain attached to that source.

The answer to **whether bytes exist for an already identified commit** can come from a verified full pack in this case, a descendant's pack, or equivalent bytes in another case's pack. A full pack can contain genuine ancestors that this participant never separately produced or exposed. The shared ZIP inventories content across participants. A protected report can provide historical measurements even after the Git bytes disappear. Neither reachability nor a positive independent replay resolves a case-identity disagreement.

| Evidence in this receipt or archive | Membership evidence | Content evidence |
| --- | --- | --- |
| Hash-linked original plan or SQLite publication that names an OID | Establishes that the participant publicly used that candidate at that boundary | Git objects must still be obtained |
| Pack captured inside this attempt with an independently verified unique tip | Identifies the sealed tip | Supplies objects for matching observed ancestors |
| Genuine case-bound map entry | Can identify its exact named commit. Check the record against the retained case references and available provenance | The map's pack can supply independently verified tree and parent bytes |
| Broken length, missing object, or conflicting OID-to-tip correspondence in a seal | Retain the claim and discrepancy. The observed contradiction cannot authenticate the asserted identity | An independently known OID may still be retrievable |
| Case-specific referenced pack or detached original | Corroborates the case membership warranted by its original and concrete verified target | Useful when a sibling field is partial or missing |
| Global pool, unrelated case or bare reachable ancestor | Supplies no case association on its own | Can supply content matching an independently named exact OID |
| Protected report or measured Git behavior | Records a judgment about its candidate and seed. A pooled object alone cannot establish the participant history | Historical result and independent replay remain separately attributable |

Uncertainty arises when a self-consistent candidate map is the sole surviving case-bound witness and independent case references have actually been lost. The accepted design permits a genuine case-bound entry. A reader cannot distinguish two incompatible origins from identical surviving bytes. Archive evidence should identify the level of support and any conflict. The reproducible cases below retain other case artifacts that do distinguish the two actual participants.

## Candidate membership and measurement

Both real plain-loop participants started under private registration 97 at commit 0636ee6b1803791d85ec7294d0d7358a964888f7. Seed 2002 included a harmless source comment in its allowed retry implementation, giving it two unique real commits. Both participants finished and returned their original public plans. I verified each original case pack with fresh Git index-pack and fsck, established the unique tip independently, compared each case's own captured OIDs with its original public submissions, and reexecuted eight registered criteria per OID and seed from actual Git objects.

| Original participant | Five observed case OIDs |
| --- | --- |
| 2001 | 55686bd5152e10a53dfdc2c003974ea405a3a075, 6dcb12a91c06f00fc75c5e68b6145a727f3749a7, af70fa43920a23d5e30dd6b4f5502084da6f9e6b, 7df4a199e2ada1caafe78f5acec2f99b06f44771, a5cd7dfec079a2b38d8b673c47d736ce3161f22a |
| 2002 | 55686bd5152e10a53dfdc2c003974ea405a3a075, 6dcb12a91c06f00fc75c5e68b6145a727f3749a7, af70fa43920a23d5e30dd6b4f5502084da6f9e6b, 7a5f37408cf2d0d17a5fe30390e55a42ce1e8ac1, 1a3550e0ed9c92cd004e96848a34a4fb1f2ac8f4 |

Each case had 40 protected slots. The 2002 donor retained all 40 with exactly the original values and provenance across all 18 controls. The table reports what the public cold Markdown consumer attributed to 2001.

| Change to the 2001 archive | Genuine rows present | Current grades matching independent execution | Incorrect donor rows added |
| --- | ---: | ---: | ---: |
| Genuine input, or one foreign map entry against intact scope | 40 | 40 | 0 |
| False donor assertion bound to a readable recipient pack with a different tip | 40 | 40 | 0 |
| Same one false seal with the recipient pack length off by one | 40 | 40 | **8** |
| Case seal inventory absent, otherwise genuine | 40 | 40 | 0 |
| Same absent inventory plus one donor-only map entry | 40 | 40 | **8** |
| Remove just the genuine START seal entry with its original map, separate referenced pack, objects and eight reports intact | **32** | **32** | 0 |
| Remove just the final candidate's seal with its original public submission intact | 40 | 40 | 0 |
| Remove map entry, remove entire map, false tree on a true OID, or substitute a donor pack for the genuine final seal | 40 | 40 | 0 |
| Remove all available content for the genuine final OID, preserving original case identity and reports | 40 | 32, with eight historical-only | 0 |
| Only original submissions identify four commits, two shared Git histories still available and two exclusive histories removed | 32 | 16, with 16 historical-only | 0 |

In the malformed seal case, candidate_evidence.py lines 211–215 add an unverified OID to the membership set after its pack reference failed. Lines 247–260 then retrieve the donor's content from the global pool. The donor's eight public 2001 grades are real executions against the wrong case membership. Native strict verification rejects this disputed archive and records 88 reexecuted criteria across the two cases. The ordinary cold report still publishes the false association. With the seal length corrected, strict checks 80 and the ordinary report adds zero donor slots.

Inventory presence changes the rule at candidate_evidence.py lines 191–205 and 224–242. A missing field enables the permissive map branch including the donor-only map entry. A partially present field can suppress the genuine independently named, case-referenced START pack. Both discrepancies alter which candidate's eight registered slots appear.

## Ordering and eligibility

A separate control changed one leaf of the work request on attempt 29, after the real observation was delivered. That request physically issued after delivery. Its journal entry is sequence 39. The entire platform artifact, original plan history, five candidate packs, 17 charged pre-intervention actions, all records through the actual receipt at sequence 23, and all 40 healthy protected slots are byte-identical. The original W2 candidate had passed the linear obligation. Its pre-notice plan hash is 395c9b555417b9d4201f1db174f5e66e5efd494840a773a95c9694f7fc6aecad. The actual delivered plan hash is 0c837132f22e0de202de234afb8d7ca065bd45d4988e5fad098c667665883c92.

The first-consumer row changes from checkpoint reached, continuous retention, zero reopenings, zero bad closures, 13 rework and final pass to six unknown fields. The separate observed-facts text retains some candidate and public facts. public_history.py line 180 writes a run-wide work coverage flag. Line 703 consumes that flag as an input to pre-intervention exposure. The corrupted late request and affected exact cost estimates deserve their own dispute. The independent observation already recorded at the earlier boundary remains demonstrable. The source also applies global coverage to the private pause check, despite the changed request being physically outside that interval.

## Ordinary and closure qualification

Private registration 91 committed at 2f4b3dd74b4b79ac33ec8937a9f341a13b794df0 before twelve sessions. They covered all three treatments, two primary seeds, and all clean and stress arms. The independent reader matched 456 protected reports, 25 public fixed-probe pairs, all 100 written report cells it examined, and every issued raw outcome. Native strict reexecuted 80 unique seed–candidate–criterion combinations and accepted the private archive.

Five further privately registered controls exercised common public action boundaries. Two W3 reopenings produced two transitions and one distinct ID. A parent closing on the prior Git candidate after W2 had closed correctly produced one real parent failure and 18 rework actions. A refused parent closure produced zero failures and 17 rework actions. A transient incorrect W2 closure preceding the repair produced one W2 failure and 16 rework actions. A single original plan publication reopened W1 and W3 together. The consumer retained two records on the same original digest and a lower bound of two. The deliberately uncharged additional publications caused an explicit dispute in that control. Its exact cohort totals remain ineligible.

The assessment covers private local SQLite/plan, Git, original raw ZIP, native cold report and strict verify on Python 3.11.15 with LC_ALL=C and TZ=UTC. The project assigned live process-kill cuts and shared E1 regression separately. The original M0 thresholds and accepted Purser product tree retain their identities. These private observations yield no registered 66-case experimental outcome.

The independent machine-readable proof is independent-qualification.json with SHA-256 9a710e84627d2f3eb40b62c13ba8d3b82dc289cf57a604f83a8e34607619adb7. It includes every changed ZIP and report digest, chronological prefix and post-change clock values, per-case OIDs, raw closure witnesses, strict errors and donor readback.
