"""A premise observation is a public Observation, but is not one of a verification run's observations."""
import json
from pathlib import Path
import sys
from kernel_witness import Witness,assumption,observe,observe_binding,role

source,dest=[Path(v).resolve() for v in sys.argv[1:]]
sys.path.insert(0,str(source))
dest.mkdir(parents=True)
w=Witness(source,dest)
w.start()
w.tree()
w.eligible("Held")
w.send(assumption("A-shared"))
w.send(observe("Premise-confirm","A-shared","confirms"),observe_binding("A-shared"))
before=w.base()
op={"op":"evidence.record","id":"E-cross-kind","run":"V-Held","observation":"Premise-confirm","verdict":"pass"}
try:
    result=w.send(op,role("verifier",assignment="V-Held"),admitted=False)
    answer={"receipt":result}
except Exception as e:
    answer={"exception":type(e).__name__,"text":str(e)}
after=w.base()
answer.update(before=before,after=after,source=w.oids[0],op=op)
(dest/"observed.json").write_text(json.dumps(answer,indent=2)+"\n")
print(json.dumps(answer))
