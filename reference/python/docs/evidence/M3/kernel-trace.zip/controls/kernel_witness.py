"""Independent M3 product witness. Use an exact local detached candidate checkout."""
from contextlib import contextmanager
from datetime import datetime
import argparse
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import time

SCOPE="C-notify"
FIXED=datetime.fromisoformat("2026-11-18T12:01:00+00:00")
STAMP="2026-11-18T12:01:00.000000Z"
DEFINITION=b"Independent Git object exists and is readable as a commit."
ENV=b"Local Git object store, scoped read only."
OWNER={"actor_id":"principal:local","principal_id":"principal:local","role":"principal","commitment":None,"assignment":None}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def dump(path,value):
    path.write_text(json.dumps(value,indent=2,sort_keys=True)+"\n")


def role(name, actor=None, assignment=None, **extra):
    return {**OWNER,"actor_id":actor or name+":private", "role":name,
            "commitment":SCOPE,"assignment":assignment,**extra}


def mark(path,stage):
    with path.open("a") as file:
        file.write(json.dumps([stage,time.monotonic_ns(),os.getpid()])+"\n")
        file.flush()


def wait_file(path,stage,seconds=12):
    start=time.monotonic()
    while time.monotonic()-start<seconds:
        if path.exists() and any(json.loads(s)[0]==stage for s in path.read_text().splitlines() if s):
            return
        time.sleep(.005)
    raise RuntimeError(f"{path} did not reach {stage}")


def actual_graph(snapshot, start):
    """Close over *only* dependent arrows on each turn. Structural children are not dependencies."""
    pending=[start]
    seen=set()
    edges=snapshot["projection"]["edges"]
    while pending:
        current=pending.pop()
        if current in seen:
            continue
        seen.add(current)
        pending.extend(e["from_id"] for e in edges if e["kind"]=="depends_on" and e["to_id"]==current)
    return sorted(seen-{start})


class Witness:
    def __init__(self,source,run):
        from purser.kernel.store import Store
        self.source=source
        self.directory=run
        self.db=run/"live.db"
        self.store=Store(self.db)
        self.counter=0
        self.receipts=[]
        self.reads=[]
        self.events={}
        self.oids=[self.git("rev-parse","HEAD"),self.git("rev-parse","HEAD^1")]
        self.ids=[{"kind":"git.commit","algorithm":"sha1","digest":oid} for oid in self.oids]
        self.clock=FIXED

    def git(self,*args):
        return subprocess.check_output(["git","-C",str(self.source),*args]).decode().strip()

    def cli(self,*args):
        env={k:v for k,v in os.environ.items() if k in ("PATH","HOME","TMPDIR")}
        env.update(TZ="UTC", LC_ALL="C", PYTHONDONTWRITEBYTECODE="1")
        p=subprocess.run([sys.executable,"-B","-m","purser","--db",str(self.db),*args],
                         cwd=self.source,env=env,capture_output=True)
        raw=json.loads(p.stdout)
        self.reads.append({"argv":args,"returncode":p.returncode,"answer":raw})
        return raw

    def snap(self,rev=None):
        return self.store.snapshot(revision=rev)

    def base(self):
        return self.snap()["revision"]

    def records(self,rev=None):
        return {r["id"]:r for r in self.snap(rev)["projection"]["records"]}

    def event_rows(self):
        with sqlite3.connect(self.db) as db:
            return [json.loads(row[0]) for row in db.execute("select body from events order by revision")]

    def proposal(self, ops, base=None, token=None):
        self.counter+=1
        return {"v":1,"proposal_id":token or ("private-" + str(self.counter)), "commitment":SCOPE,
                "base_revision":self.base() if base is None else base,"ops":ops if isinstance(ops,list) else [ops],"justification":[]}

    def send(self,ops, binding=OWNER, base=None, admitted=True,token=None):
        from purser.kernel.gate import admit
        p=self.proposal(ops,base,token)
        receipt=admit(self.store,binding,p,clock=lambda:self.clock)
        self.receipts.append({"ops":p["ops"],"base":p["base_revision"],"receipt":receipt})
        if admitted is not None:
            assert receipt["disposition"]==("admitted" if admitted else "rejected"),(p,receipt)
        return receipt

    def start(self):
        from purser.kernel.gate import admit
        wire=json.loads((self.source/"docs/contracts/wire-v1.json").read_bytes())
        self.store.initialize()
        for p,at in zip(wire["proposals"],wire["clock_by_batch"]):
            admit(self.store,wire["binding"],p,clock=lambda:datetime.fromisoformat(at))
        assert self.snap()==wire["expected"]["snapshot_at_8"]

    def tree(self):
        nodes=[("P-all","W-root"),("P-any","W-root"),("W2","P-all"),("Sibling","P-all"),
               ("Held","W2"),("Safe","P-any"),("Zaffected","P-any"),("Independent","W-root"),("Waiting","W-root")]
        self.send([{"op":"work.create","id":s,"parent":p,"title":s} for s,p in nodes])
        self.send([{"op":"work.coverage","id":s,"kind":k,"k":None} for s,k in
                   (("W-root","all"),("P-all","all"),("P-any","any"),("W2","all"))])
        self.send([{"op":"obligation.set","id":"O-"+s,"work":s,"version":1,"title":"Read the exact immutable Git commit",
                    "observer":"observer:private","verifier":"verifier:private","definition_sha256":sha(DEFINITION),"environment_sha256":sha(ENV)}
                   for s in ("W2","Sibling","Held","Safe","Zaffected","Independent","Waiting")])

    def assign(self,subject,tag):
        return self.send({"op":"work.assign","id":"AS-"+tag,"work":subject,"executor":"executor:private"})

    def result(self,subject,tag,index=0):
        return self.send({"op":"result.submit","id":"R-"+tag,"assignment":"AS-"+tag,"candidate":self.ids[index]},
                         role("executor",assignment="AS-"+tag))

    def open(self,subject,tag, label=None):
        return self.send({"op":"run.open","id":"V-"+(label or tag),"obligation":"O-"+subject,"result":"R-"+tag})

    def measure(self,tag,index=0):
        oid=self.oids[index]
        assert self.git("cat-file","-t",oid) == "commit"
        ptr={"candidate":self.ids[index],"definition":DEFINITION,"environment":ENV,
             "artifact":subprocess.check_output(["git","-C",self.source,"cat-file","commit",oid])}
        return self.send({"op":"observation.record","id":"Obs-"+tag,"run":"V-"+tag},
                         role("observer",assignment="V-"+tag,witness=ptr))

    def verify(self,tag):
        return self.send({"op":"evidence.record","id":"E-"+tag,"run":"V-"+tag,"observation":"Obs-"+tag,"verdict":"pass"},
                         role("verifier",assignment="V-"+tag))

    def eligible(self,subject,tag=None,index=0):
        tag=tag or subject
        self.assign(subject,tag)
        self.result(subject,tag,index)
        self.open(subject,tag)
        self.measure(tag,index)
        self.verify(tag)

    def close(self,subject,**options):
        return self.send({"op":"work.close","id":subject},role("closure"),**options)

    def checks(self,name,revision):
        status=self.cli("status","--revision",str(revision),"--as-of",STAMP)
        frontier=self.cli("frontier","--revision",str(revision),"--as-of",STAMP)
        assert frontier["actions"]==status["answers"]["q10"]
        why={key:self.cli("why",key,"--revision",str(revision),"--as-of",STAMP) for key in
             ("A1","D-old","W2","Held","Sibling","P-all","P-any")}
        self.events[name]={"revision":revision,"q03":status["answers"]["q03"],"q04":status["answers"]["q04"],
                           "frontier":frontier["actions"],"why":why}
        return status["answers"],why

    def save(self,more):
        dump(self.directory/"product.json",{"source":self.oids[0],"receipts":self.receipts,"reads":self.reads,"checkpoints":self.events,"more":more})
        with sqlite3.connect(self.db) as db:
            data=b"\n".join(r[0] for r in db.execute("select body from events order by revision"))+b"\n"
        (self.directory/"original-events.jsonl").write_bytes(data)


def assumption(key):
    return {"op":"assumption.create","id":key,"statement":"Controlled externally measured premise "+key,"observer":"observer:premise"}


def record(key,support,triggers,choice="linear",supersedes=None):
    return {"op":"decision.record","id":key,"choice":choice,"alternatives":["linear","exponential"],
            "rationale":"Independent decision witness","support":support,"triggers":triggers,"supersedes":supersedes}


def link(subject,support):
    return {"op":"dependency.add","id":subject,"support":support}


def observe(key,assumption_key,finding):
    return {"op":"assumption.observe","id":key,"assumption":assumption_key,"finding":finding}


def observe_binding(assumption_key):
    return role("observer","observer:premise",assignment=assumption_key,premise={"artifact":("Independently observed premise change for "+assumption_key).encode()})


def contender(source,db,operation,base,token,log,release,hold):
    from purser.kernel.gate import admit
    from purser.kernel.store import Store
    class TimedStore(Store):
        @contextmanager
        def _connection(self,*,write=False):
            with super()._connection(write=write) as connection:
                if write:
                    def traced(statement):
                        if statement=="BEGIN IMMEDIATE":
                            mark(log,"sqlite-begin-immediate")
                    connection.set_trace_callback(traced)
                yield connection
    def clock():
        mark(log,"owns-write-lock")
        if hold:
            wait_file(release,"release")
        return FIXED
    d=json.loads(operation)
    kind=d["op"]
    binding=role("closure") if kind=="work.close" else observe_binding("A1")
    proposal={"v":1,"proposal_id":token,"commitment":SCOPE,"base_revision":base,"ops":[d],"justification":[]}
    receipt=admit(TimedStore(db),binding,proposal,clock=clock)
    mark(log,"committed")
    print(json.dumps(receipt))


def race(w,first,second):
    common=w.base()
    events=w.directory
    l1=events/"first.lock"
    l2=events/"second.lock"
    release=events/"go"
    def launch(op,token,log,hold):
        return subprocess.Popen([sys.executable,"-B",__file__,"contest",str(w.source),str(w.db),
                                 json.dumps(op),str(common),token,str(log),str(release),str(int(hold))],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    a=launch(first,"race-first",l1,True)
    wait_file(l1,"owns-write-lock")
    b=launch(second,"race-second",l2,False)
    wait_file(l2,"sqlite-begin-immediate")
    assert "owns-write-lock" not in l2.read_text()
    mark(release,"release")
    out1,err1=a.communicate(timeout=20)
    out2,err2=b.communicate(timeout=20)
    assert a.returncode==0 and b.returncode==0,(out1,err1,out2,err2)
    t1=json.loads(out1)
    t2=json.loads(out2)
    traces=[[json.loads(line) for line in f.read_text().splitlines()] for f in (l1,l2,release)]
    return {"common":common,"first":t1,"second":t2,"timing":traces}


if __name__=="__main__":
    if sys.argv[1]=="contest":
        _,_,source,db,op,rev,token,log,release,hold=sys.argv
        sys.path.insert(0,source)
        contender(Path(source),Path(db),op,int(rev),token,Path(log),Path(release),bool(int(hold)))
    else:
        raise SystemExit("Use the independent scenario driver, product_controls.py")
