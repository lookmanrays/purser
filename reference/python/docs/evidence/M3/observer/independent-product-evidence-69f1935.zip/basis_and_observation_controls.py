"""Independent controls added to qualify the publicly specified defects on a replacement candidate."""
from fixture import *
out=HERE/'additional-defects';out.mkdir();results={}
def query(db,work):return cli(db,'why',work,'--as-of',ASN)
def evidence(db,w):return next(v for v in cli(db,'status','--as-of',ASN)['answers']['q07'] if v['work']==w)
def counts(db,id):return sum(e['type']=='WorkClosed' and e['data']['id']==id for e in map(json.loads,rows(db)))
def outcome(db,w):return query(db,w)['support']['outcome']
# Stored type Observation covers run evidence and premise observations. Only the former can support an EvidenceRecord.
db=fork(HERE/'mixed-evidence-verified/prepared.sqlite',out/'premise-observation.sqlite')
before=rows(db);proposal=req(db,{'op':'evidence.record','id':'E-wrong-type','run':'V-W9-old','observation':'Obs-A1-confirm','verdict':'pass'},bind('verifier',VE,'V-W9-old'))
runner=subprocess.run([sys.executable,'-B',str(HERE/'fixture.py'),'send',str(db)],env=ENV,input=enc(wire(proposal)),capture_output=True)
after=rows(db)
if runner.returncode==0:rec=json.loads(runner.stdout);good=rec['disposition']=='rejected' and len(after)==len(before)+1 and json.loads(after[-1])['type']=='ProposalReceipted'
else:good=False;rec=None
# Well-formed, run-bound but wrong run ID has a typed negative and no introduced evidence.
valid_wrong=op(db,{'op':'evidence.record','id':'E-wrong-linked-run','run':'V-W9-old','observation':'Obs-W10-old','verdict':'pass'},bind('verifier',VE,'V-W9-old'),'rejected')
results['observation_subject']={'passes_requirement':good,'initial':len(before),'after_bad':len(after),'exit':runner.returncode,'stderr':runner.stderr.decode(),'receipt':rec,'other_real_run_receipt':valid_wrong}
# The sentinel consumes a structural aggregate R. Close R on eligible W9/W10, bind the sentinel result and evidence to that original support.
db=fork(HERE/'mixed-evidence-verified/prepared.sqlite',out/'direct-work-support.sqlite')
op(db,{'op':'work.close','id':WA},CLOSE);op(db,{'op':'work.close','id':R},CLOSE);old=outcome(db,R)
guard='W-sentinel';tag='guard-old';set_crit(db,guard,1);assign(db,guard,tag);submit(db,guard,tag,G['w3']);openrun(db,guard,tag);witness(db,guard,tag,G['w3'],1)
g_before=query(db,guard);q_before=evidence(db,guard);assert q_before['state']=='passed' and old
# Independent unaffected reference, same existing support outcomes protect a legitimate old result after unrelated opinion.
positive=fork(db,out/'unchanged-support.sqlite');op(positive,{'op':'decision.opine','id':'Opinion-unchanged','decision':D,'opinion':'I prefer a different schedule.'},PL)
same=outcome(positive,R);c=op(positive,{'op':'work.close','id':guard},CLOSE);assert same==old and c['disposition']=='admitted'
# Now change the covered child's decision, cause R to reopen, then requalify R by new B evidence.
inv=prem(db,'Obs-direct-basis-cycle',A);between=query(db,guard);blocked=op(db,{'op':'work.close','id':guard},CLOSE,'rejected')
replacement(db);submit(db,WA,'W9-new',G['revised']);openrun(db,WA,'W9-new');witness(db,WA,'W9-new',G['revised'],2);op(db,{'op':'work.close','id':WA},CLOSE);op(db,{'op':'work.close','id':R},CLOSE)
new=outcome(db,R);assert old!=new and old and new
pre=query(db,guard);q_pre=evidence(db,guard)
previous_close_count=counts(db,guard);trial=op(db,{'op':'work.close','id':guard},CLOSE,None);actual_new=counts(db,guard)-previous_close_count
good=trial['disposition']=='rejected' and actual_new==0
results['changed_support']={'passes_requirement':good,'old_aggregate_outcome':old,'new_aggregate_outcome':new,'original_dependent_evidence':q_before,'reopened_boundary':between,'rejection_while_prerequisite_open':blocked,'requalified_aggregate_current_dependent':pre,'current_old_evidence':q_pre,'attempt_to_close_with_prior_evidence':trial,'new_public_close_events':actual_new,'same_support_positive_control':c}
(out/'independent-results.json').write_bytes(enc(results))
print('observation class',results['observation_subject']['passes_requirement'],runner.returncode,runner.stderr.decode().splitlines()[-1:] if runner.stderr else rec['code'])
print('changed structural support',good,old,new,q_pre['state'],trial['code'],actual_new)
