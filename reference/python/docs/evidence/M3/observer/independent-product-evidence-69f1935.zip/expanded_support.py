from fixture import *
out=HERE/'support-boundaries';out.mkdir()
def why(db,w,r=None):return cli(db,'why',w,'--as-of',ASN,*(['--revision',str(r)] if r else []))
def outcome(db,w):return why(db,w)['support']['outcome']
def support(db,w):return why(db,w)['support']['work_outcomes']
def state(db,w):return why(db,w)['record']['fields']['state']
def q7(db,w):return next(x for x in cli(db,'status','--as-of',ASN)['answers']['q07'] if x['work']==w)
def closure(db,w,expect='admitted'):return op(db,{'op':'work.close','id':w},CLOSE,expect)
def eligibility(db,work,tag):
    set_crit(db,work,1);assign(db,work,tag);submit(db,work,tag,G['w3']);openrun(db,work,tag);witness(db,work,tag,G['w3'],1)
def add(db,w,parent):return op(db,{'op':'work.create','id':w,'parent':parent,'title':w})
def recovered(db,w,tag,old_tag):
    previous=why(db,w)['record']['fields']['generation'];before=support(db,w);assert before['acquired']!=before['current']
    assign(db,w,tag);submit(db,w,tag,G['w3']);openrun(db,w,tag)
    witness(db,w,old_tag,G['w3'],1,seq='-late')
    assert q7(db,w)['evidence']==[] and closure(db,w,'rejected')['code']=='closure_blocked'
    witness(db,w,tag,G['w3'],1);grant=closure(db,w);record=why(db,w)
    assert record['record']['fields']['generation']==previous+1 and record['record']['fields']['state']=='closed'
    live=support(db,w);assert live['acquired']==live['current']==before['current']
    return {'previous':before,'now':live,'late_then_current':q7(db,w),'closed':grant}
def update_w9(db):
    replacement(db);submit(db,WA,'W9-new',G['revised']);openrun(db,WA,'W9-new');witness(db,WA,'W9-new',G['revised'],2);closure(db,WA)
def live_cold(db):
    new=out/(db.stem+'-cold.sqlite');s=cold_cli.copied_events(REPO,db,new)
    assert s==cli(db,'status','--as-of',s['as_of'])
    return [s['revision'],s['head_hash'],s['projection_hash']]
guard='W-sentinel';source=HERE/'mixed-evidence-verified/prepared.sqlite'
single=fork(HERE/'additional-defects/direct-work-support.sqlite',out/'recovered-assignment.sqlite')
results={'same_candidate_fresh_generation':recovered(single,guard,'guard-new','guard-old')}
results['same_candidate_fresh_generation']['cold']=live_cold(single)
# An intermediate purely structural work reads a structural support, and in turn supports a separate assigned consumer.
two=fork(source,out/'two-level.sqlite');v='W-chain-consumer';leaf='W-sentinel-leaf';add(two,leaf,guard);add(two,v,ROOT)
op(two,{'op':'work.coverage','id':guard,'kind':'all','k':None});op(two,{'op':'dependency.add','id':v,'support':guard})
closure(two,WA);closure(two,R);eligibility(two,leaf,'chain-leaf');closure(two,leaf);closure(two,guard)
initial_leaf=why(two,leaf);prior=why(two,guard);old_guard_out=prior['support']['outcome'];old_r=outcome(two,R)
eligibility(two,v,'chain-old');g0=why(two,v);assert q7(two,v)['state']=='passed'
inv=prem(two,'Obs-two-level',A);assert state(two,R)!='closed' and state(two,guard)!='closed'
assert closure(two,v,'rejected')['code']=='closure_blocked'
update_w9(two);closure(two,R);middle=why(two,guard);assert middle['record']['fields']['generation']>prior['record']['fields']['generation']
closure(two,guard);end=why(two,guard);assert end['support']['outcome']!=old_guard_out and outcome(two,R)!=old_r
assert why(two,leaf)['support']==initial_leaf['support']
assert closure(two,v,'rejected')['code']=='closure_blocked' and not q7(two,v)['evidence']
result=recovered(two,v,'chain-new','chain-old')
results['multi_level_fixed_point']={'source_outcome_A':old_r,'source_outcome_B':outcome(two,R),'structural_outcome_A':old_guard_out,'structural_outcome_B':outcome(two,guard),'generation_A':prior['record']['fields']['generation'],'generation_B':middle['record']['fields']['generation'],'downstream':result,'unchanged_leaf_outcome':initial_leaf['support']['outcome'],'cold':live_cold(two)}
# A change to an unselected sibling cannot fence a valid consumer of a selected any/k-of-n basis.
for kind,k in [('any',None),('k_of_n',2)]:
    db=fork(source,out/('retained-'+kind+'.sqlite'));stable='W0-stable';add(db,stable,R);eligibility(db,stable,'stable');closure(db,stable)
    closure(db,WA);op(db,{'op':'work.coverage','id':R,'kind':kind,'k':k});closure(db,R)
    original=why(db,R);selected={v['work'] for v in original['support']['basis']['witnesses']};assert WA not in selected and stable in selected
    eligibility(db,guard,'guard-retain');before=why(db,guard);q=q7(db,guard)
    prem(db,'Obs-retain-'+kind,A);assert state(db,WA)=='stale' and outcome(db,R)==original['support']['outcome']
    assert before['support']==why(db,guard)['support'] and q==q7(db,guard);closure(db,guard);assert state(db,guard)=='closed'
    results['unchanged_'+kind]={'selected':sorted(selected),'reopened_other':WA,'outcome':original['support']['outcome'],'original_evidence':q,'current_evidence':q7(db,guard),'cold':live_cold(db)}
(out/'independent.json').write_bytes(enc(results));print([(k,v['cold'][0]) for k,v in results.items()])
