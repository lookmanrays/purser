import collections,hashlib,json,os,select,sqlite3,subprocess,sys
from fixture import *
out=HERE/'mixed-evidence-verified';out.mkdir();db=fork(HERE/'assigned.sqlite',out/'prepared.sqlite')
def why(db,w,r=None):
    a=['why',w,'--as-of',ASN]
    if r is not None:a+=['--revision',str(r)]
    return cli(db,*a)
def status(db,r=None):
    a=['status','--as-of',ASN]
    if r is not None:a+=['--revision',str(r)]
    return cli(db,*a)
def state(x):return x['record']['fields']['state']
def matches(db,r=None):
    ss=status(db,r);return {q:ss['answers'][q] for q in ('q03','q04','q07','q08','q09','q10')}
def whyset(db,r=None):return {k:why(db,k,r) for k in (WA,WB,D,A,R,'W-sentinel','W-cycle-x','W-cycle-y')}
def cause(db,i):return {'op':'assumption.observe','id':i,'assumption':A,'finding':'contradicts'}
def cbind(key):return bind('observer',OP,A,premise={'artifact':('Independent counterexample to A1 linear; '+key).encode()})
def same_outcome(a,b):assert a['record']==b['record'] and a['support']==b['support'] and a['reasons']==b['reasons']
def source(db):
    return {'head':head(db),'why':whyset(db),'answers':matches(db)}
def compare_cold(db,records):
    dest=db.with_name(db.stem+'-cold.sqlite');replay=cold_cli.copied_events(REPO,db,dest)
    assert replay==cli(db,'status','--as-of',replay['as_of'])
    for rev in sorted(set(records)):
        names=(WA,WB,D,A,R,'W-sentinel','W-cycle-x','W-cycle-y')
        x=cold_cli.sample(REPO,db,rev,ASN,names);y=cold_cli.sample(REPO,dest,rev,ASN,names);cold_cli.compare(x,y)
    return {'revision':replay['revision'],'head_hash':replay['head_hash'],'projection_hash':replay['projection_hash'],'historical_revisions':sorted(set(records))}
class Wait:
    def __init__(self,db,r):
        self.p=subprocess.Popen([sys.executable,'-B',str(HERE/'fixture.py'),'wait',str(db)],env=ENV,cwd=HERE,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,bufsize=0)
        self.p.stdin.write(enc(wire(r))+b'\n')
        if not select.select([self.p.stdout],[],[],10)[0]:raise TimeoutError('gated actor before release')
        self.init=json.loads(self.p.stdout.readline())
    def release(self):
        self.p.stdin.write(b'go\n');out,err=self.p.communicate(timeout=12);assert self.p.returncode==0,err;return json.loads(out)
initial=source(db);d0=initial['why'][D]['record'];untouched=initial['why'][WB];w9h=initial['head']
op(db,{'op':'decision.opine','id':'Opinion-W9','decision':D,'opinion':'A different layout could be preferable.'},bind('executor',EX,'AS-W9-old'))
assert why(db,D)['record']==d0
prem(db,'Obs-A1-confirm',A,'confirms');assert why(db,D)['record']==d0
prem(db,'Obs-A-extra','A-nontrigger');assert why(db,D)['record']==d0 and state(why(db,WA))=='assigned'
prem(db,'Obs-wrong',A,b=bind('observer','observer:impostor',A,premise={'artifact':b'Not bound'}),expected='rejected');assert why(db,D)['record']==d0
same_outcome(untouched,why(db,WB))
submit(db,WA,'W9-old',G['linear']);openrun(db,WA,'W9-old');witness(db,WA,'W9-old',G['linear'],1)
prepared=source(db);before=prepared['head'];assert prepared['why'][WA]['support']['outcome'] and prepared['why'][WA]['record']['fields']['candidate']==cand(G['linear'])
cases={}
for label in ('close-first','invalidate-first'):
    dest=fork(db,out/(label+'.sqlite'));ident='Obs-order-'+label
    close=Wait(dest,req(dest,{'op':'work.close','id':WA},CLOSE));invalid=Wait(dest,req(dest,cause(dest,ident),cbind(ident)))
    assert close.init['head']==invalid.init['head']==before and close.init['pid']!=invalid.init['pid']
    rclose=None;parent_then=None;firsttry=None
    if label=='close-first':
        rclose=close.release();assert rclose['disposition']=='admitted'
        assert state(why(dest,WA,rclose['revision']))=='closed'
        parent_then=op(dest,{'op':'work.close','id':R},CLOSE);assert state(why(dest,R,parent_then['revision']))=='closed'
        firsttry=invalid.release();ri=firsttry if firsttry['disposition']=='admitted' else apply(dest,req(dest,cause(dest,ident),cbind(ident)))
    else:
        ri=invalid.release();assert ri['disposition']=='admitted';rclose=close.release();assert rclose['disposition']=='rejected'
    ri_revision=ri['revision'];assert state(why(dest,WA,ri_revision))=='stale'
    got=source(dest);by=got['why'];q=got['answers']
    impact=next(x['affected'] for x in q['q04'] if x['assumption']==A)
    assert sorted(impact)==sorted([D,WA,'W-cycle-x','W-cycle-y']),(label,impact)
    assert next(x['state'] for x in q['q03'] if x['decision']==D)=='reconsidering'
    same_outcome(untouched,by[WB]);assert state(by['W-sentinel'])=='open' and 'W-sentinel' not in impact and R not in impact
    assert [a for a in q['q10'] if a['subject']==D and a['action']=='reconsider']
    assert [a for a in q['q10'] if a['subject']==WA and a['action']=='rework']
    assert state(by[R])!='closed'
    ev=next(e for e in map(json.loads,rows(dest)) if e['type']=='PremiseObserved' and e['data']['id']==ident)
    cw=by[WA]['support']['causes'];rootcause=next(c for c in cw if c['observation']==ident)
    assert rootcause['assumption']==A and rootcause['revision']==ev['revision']
    edges={(e['from_id'],e['to_id']) for e in rootcause['edges']};assert {(WA,D),(D,A)}<=edges
    for wid in (D,WA,'W-cycle-x','W-cycle-y'):
        assert by[wid]['record']['changed']==ev['revision']
    rcnow=op(dest,{'op':'work.close','id':WA},CLOSE,'rejected');assert rcnow['code']=='closure_blocked'
    lateentry=op(dest,{'op':'assignment.dispatch','id':'AS-W9-old'},bind('executor',EX,'AS-W9-old'),'rejected')
    # The earlier old qualified result stays in history, while any current close now names the changed cause.
    assert why(dest,WA,before)['record']==prepared['why'][WA]['record']
    prior=why(dest,WA,ri_revision);replacement(dest);submit(dest,WA,'W9-new',G['revised']);openrun(dest,WA,'W9-new')
    witness(dest,WA,'W9-old',G['linear'],1,seq='-late')
    blocked=op(dest,{'op':'work.close','id':WA},CLOSE,'rejected');assert blocked['code']=='closure_blocked'
    q7=next(x for x in matches(dest)['q07'] if x['obligation']=='O-W9')
    assert q7['version']==2 and 'E-W9-old-late' not in q7['evidence'] and q7['state']!='passed'
    witness(dest,WA,'W9-new',G['revised'],2);success=op(dest,{'op':'work.close','id':WA},CLOSE);new=source(dest)
    assert state(new['why'][WA])=='closed' and new['why'][WA]['record']['fields']['candidate']==cand(G['revised'])
    assert new['why'][WA]['support']['outcome']!=prepared['why'][WA]['support']['outcome']
    assert new['why'][WA]['support']['basis']['decisions']==[{'id':'D-revised','revision':why(dest,'D-revised')['record']['changed']}]
    assert new['why'][D]['record']['fields']['state']=='superseded'
    assert why(dest,WA,ri_revision)==prior
    same_outcome(untouched,new['why'][WB])
    cold=compare_cold(dest,[w9h,before,ri_revision,success['revision'],rclose['revision']])
    cases[label]={'writer_processes':[close.init,invalid.init],'prepared':before,'close':rclose,'parent_close':parent_then,'initial_invalidation_after_close':firsttry,'invalidation':ri,'new_close_attempt_with_stale_support':rcnow,'stale_dispatch':lateentry,'why_at_invalidation':by,'continuity_at_invalidation':q,'late_evidence_gate':blocked,'current_why':new['why'],'cold':cold}
(out/'disposition.json').write_bytes(enc({'scope':'independent M3 graph and ordering component','original':initial,'prepared':prepared,'orderings':cases}))
print([(k,v['invalidation']['revision'],v['cold']) for k,v in cases.items()])
