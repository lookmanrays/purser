import hashlib,json,os,select,signal,subprocess,sys,time
from pathlib import Path
from fixture import *
out=HERE/'release-evidence';out.mkdir();proof=out/'callback-witness.jsonl'
class Foreground:
    def __init__(self,db,name,oid=None):
        self.label=name;self.buffer=b'';self.marks=[]
        self.p=subprocess.Popen([sys.executable,'-B',str(BASE/'local-release-supplement/driver_witness.py'),'--repo',str(REPO),'--db',str(db),'--label',name,'--actor',EX,'--candidate',oid or G['linear'],'--witness',str(proof)],cwd=HERE,env=ENV,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,bufsize=0)
        self.first=self.until('snapshot')
    def until(self,what):
        end=time.monotonic()+15
        while True:
            if b'\n' not in self.buffer:
                if not select.select([self.p.stdout],[],[],max(end-time.monotonic(),0))[0]:raise TimeoutError((self.label,what))
                b=os.read(self.p.stdout.fileno(),65536)
                if not b:raise ValueError((self.label,self.p.poll(),self.p.stderr.read()))
                self.buffer+=b
            while b'\n' in self.buffer:
                line,self.buffer=self.buffer.split(b'\n',1);e=json.loads(line);self.marks.append(e)
                if e['kind']==what:return e
                if e['kind']=='actual-callback-entry' and what=='tick-finished':
                    self.p.kill();self.p.wait(5);raise AssertionError(('unexpected physical callback',self.label,e))
    def go(self):self.p.stdin.write(b'release-snapshot\n')
    def finish(self):self.p.stdin.write(b'return-candidate\n');return self.done()
    def done(self):
        answer=self.until('tick-finished');assert self.p.wait(5)==0;return answer
    def stop(self):self.p.kill();assert self.p.wait(5)==-signal.SIGKILL
def at(db,rev=None):
    args=['status','--as-of',ASN]
    if rev is not None:args+=['--revision',str(rev)]
    return cli(db,*args)
def state(db,rev=None):
    s=at(db,rev);rows={v['work']:v for v in s['answers']['q02']};return {k:rows[k] for k in (WA,WB)}
def entries():
    return [json.loads(x) for x in proof.read_bytes().splitlines()]
def by(label,kind):
    return [v for v in entries() if v['process']==label and v['kind']==kind]
def witness(label,kind):v=by(label,kind);assert len(v)==1,(label,kind,v);return v[0]
def new(name):return fork(HERE/'assigned.sqlite',out/(name+'.sqlite'))
def ref(db,tag):return prem(db,'Observation-'+tag,A)
def assert_stale(db):
    s=state(db);assert s[WA]['state']=='stale' and s[WB]['state']=='closed',s
res={}
# Same real snapshot at each driver, with admitted ordering from actual callbacks and DB reads.
db=new('D1');p=Foreground(db,'D1-P');q=Foreground(db,'D1-Q');assert p.first['head_hash']==q.first['head_hash'];base=p.first['revision']
p.go();entered=p.until('actual-callback-entry');inv=ref(db,'D1');assert entered['revision']<inv['revision'];q.go();qdone=q.done();pdone=p.finish();assert not by('D1-Q','actual-callback-entry') and len(by('D1-P','actual-callback-entry'))==1
assert qdone['answer']['receipt']['disposition']=='rejected' and pdone['answer']['receipt']['disposition']=='rejected'
slot=witness('D1-P','dispatch-gate');assert slot['receipt']['disposition']=='admitted' and slot['receipt']['revision']==entered['revision']
bad=witness('D1-Q','dispatch-gate');assert bad['receipt']['disposition']=='rejected' and bad['proposal']['proposal_id']!=slot['proposal']['proposal_id']
assert_stale(db);assert not [e for e in map(json.loads,rows(db)) if e['type']=='ResultSubmitted' and e['data']['work']==WA]
res['D1']={'base':base,'entered':entered['revision'],'invalidation':inv['revision'],'head':head(db),'P':pdone['answer'],'Q':qdone['answer']}
# Same authenticated gate bytes replayed on new process, plus a distinct request at the now-invalid head.
before=rows(db);marks=len(entries())
replay=apply(db,{'binding':slot['binding'],'proposal':slot['proposal']})
assert replay==slot['receipt'] and rows(db)==before and len(entries())==marks
fresh=Foreground(db,'D2-fresh');fresh.go();fr=fresh.done();assert not by('D2-fresh','actual-callback-entry')
obsolete=op(db,{'op':'assignment.dispatch','id':'AS-W9-old'},bind('executor',EX,'AS-W9-old'),'rejected')
res['D2']={'exact_original':replay,'event_count_before':len(before),'event_count_after_identical_replay':len(before),'fresh':fr['answer'],'differently_identified_request':obsolete}
# Both stale readers and a genuine newly started reader are now prohibited.
db3=new('D3');x=Foreground(db3,'D3-P');y=Foreground(db3,'D3-Q');assert x.first['head_hash']==y.first['head_hash']
i3=ref(db3,'D3');x.go();y.go();f3=[x.done(),y.done()];z=Foreground(db3,'D3-R');z.go();f3.append(z.done())
assert all(not by('D3-'+k,'actual-callback-entry') for k in ('P','Q','R'));assert_stale(db3)
res['D3']={'invalidation':i3,'outcomes':[v['answer'] for v in f3]}
# Real completed old result remains visible at the former immutable batch only.
db4=new('D4');x=Foreground(db4,'D4-P');x.go();e4=x.until('actual-callback-entry');r4=x.finish();rn=r4['answer']['receipt']['revision'];assert state(db4,rn)[WA]['candidate']==cand(G['linear'])
i4=ref(db4,'D4');assert_stale(db4);z=Foreground(db4,'D4-restart');z.go();z.done();assert not by('D4-restart','actual-callback-entry')
assert state(db4,rn)[WA]['state']=='submitted'
res['D4']={'callback':e4,'result':r4['answer'],'invalidation':i4,'before':state(db4,rn),'after':state(db4)}
# Killing in the actual callback retains prior release but creates no result.
db5=new('D5');x=Foreground(db5,'D5-killed');x.go();e5=x.until('actual-callback-entry');x.stop();s1=witness('D5-killed','dispatch-gate')
assert state(db5)[WA]['candidate'] is None
z=Foreground(db5,'D5-restart');z.go();e5b=z.until('actual-callback-entry');r5=z.finish();s2=witness('D5-restart','dispatch-gate')
assert s1['receipt']['digest']!=s2['receipt']['digest'] and s1['proposal']['proposal_id']!=s2['proposal']['proposal_id'] and s2['receipt']['revision']>s1['receipt']['revision']
assert r5['answer']['receipt']['disposition']=='admitted' and state(db5)[WA]['candidate']==cand(G['linear'])
assert len([e for e in map(json.loads,rows(db5)) if e['type']=='ResultSubmitted' and e['data']['work']==WA])==1
z=Foreground(db5,'D5-post');z.go();z.done();assert not by('D5-post','actual-callback-entry')
res['D5']={'death':-signal.SIGKILL,'first_release':s1['receipt'],'second_release':s2['receipt'],'result':r5['answer']}
# Same D1 database: replacement work progresses, while old authenticated retry stays historical.
replacement(db);z=Foreground(db,'D6-revised',G['revised']);z.go();e6=z.until('actual-callback-entry');r6=z.finish()
assert e6['assignment']=='AS-W9-new' and e6['generation']==2 and state(db)[WA]['candidate']==cand(G['revised'])
before=rows(db);r=apply(db,{'binding':slot['binding'],'proposal':slot['proposal']});assert r==slot['receipt'] and before==rows(db)
res['D6']={'callback':e6,'result':r6['answer'],'current':state(db),'old_replay':r}
(out/'disposition.json').write_bytes(enc({'scope':'independent M3 physical callback controls','cases':res,'physical_entries':[v for v in entries() if v['kind']=='actual-callback-entry'],'cases_passed':len(res)}))
print('observed six controls',[(v['process'],v['revision']) for v in entries() if v['kind']=='actual-callback-entry'],flush=True)
