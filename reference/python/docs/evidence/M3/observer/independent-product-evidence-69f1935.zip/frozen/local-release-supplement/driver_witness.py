"""One foreground driver process. Barriers only delay a verified SQLite read and a genuine callback."""
import argparse,hashlib,json,os,sqlite3,sys
from pathlib import Path
def append(path,value):
    data=(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode()
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
    try:
        if os.write(fd,data)!=len(data):raise OSError('incomplete private witness')
        os.fsync(fd)
    finally:os.close(fd)
def send(value):print(json.dumps(value,sort_keys=True),flush=True)
def wait(expected):
    got=sys.stdin.readline().strip()
    if got!=expected:raise RuntimeError(('wrong test barrier',expected,got))
def main():
    p=argparse.ArgumentParser()
    for k in ('repo','db','label','actor','candidate','witness'):p.add_argument('--'+k,required=True)
    args=p.parse_args();db=Path(args.db).resolve();sys.path.insert(0,str(Path(args.repo).resolve()))
    from purser import driver
    from purser.kernel.store import Store
    def audit(kind,**data):
        payload={'kind':kind,'process':args.label,'pid':os.getpid(),**data};append(args.witness,payload);send(payload)
    def mark():
        st=Store(db).snapshot();return {'revision':st['revision'],'head_hash':st['head_hash']}
    c=sqlite3.connect(db.as_uri()+'?mode=ro',uri=True)
    try:jm=c.execute('pragma journal_mode').fetchone()[0]
    finally:c.close()
    if jm!='wal':raise ValueError('fixture must be a real WAL database')
    class ReadBarrier(Store):
        first=True
        def snapshot(self,*a,**kw):
            snapshot=super().snapshot(*a,**kw)
            if self.first:
                self.first=False
                audit('snapshot',revision=snapshot['revision'],head_hash=snapshot['head_hash'],journal_mode=jm)
                wait('release-snapshot')
            return snapshot
    # Record an unmodified normal gate call and its unmodified result. The callback counter is separate.
    if hasattr(driver,'admit'):
        real=driver.admit
        def recording(store,binding,proposal,**kwargs):
            result=real(store,binding,proposal,**kwargs)
            names=[op['op'] for op in proposal['ops']]
            if names==['assignment.dispatch']:
                audit('dispatch-gate',binding=binding,proposal=proposal,receipt=result)
            elif names==['result.submit']:audit('submit-gate',proposal_id=proposal['proposal_id'],receipt=result)
            return result
        driver.admit=recording
    def callback(ctx):
        oid=args.candidate
        audit('actual-callback-entry',assignment=ctx['assignment']['id'],work=ctx['work']['id'],generation=ctx['work']['generation'],candidate=oid,**mark())
        wait('return-candidate')
        audit('actual-callback-return',**mark())
        return {'kind':'git.commit','algorithm':'sha1','digest':oid}
    result=driver.tick(ReadBarrier(db),{args.actor:callback})
    audit('tick-finished',answer=result,**mark())
if __name__=='__main__':main()
