"""Independent actual API setup. Process requests contain the original role and wire, no mocked gate."""
import base64,hashlib,json,os,sqlite3,subprocess,sys,uuid
from datetime import datetime,timezone
from pathlib import Path
HERE=Path(__file__).resolve().parent;BASE=HERE.parent;REPO=Path('/Users/lookman/.codex/worktrees/purser-delivery/review')
sys.path.insert(0,str(REPO));sys.path.insert(1,str(BASE))
from purser.kernel.store import Store
from purser.kernel.gate import admit
from queue_reference import measure
import cold_cli
ENV={'PATH':'/usr/bin:/bin','TZ':'UTC','LC_ALL':'C'};ASN='2026-11-18T23:30:00.000000Z'
NOW=datetime(2026,11,18,17,tzinfo=timezone.utc);C='C-m3-local';ROOT='W-root';R='W-covered';WA='W9';WB='W10';A='A1';D='D-original';OP='observer:premise';OE='observer:queue';VE='verifier:queue';EX='executor:private'
G=json.loads((BASE/'hand-git-proofs.json').read_bytes())['candidates']
def cand(oid):return {'digest':oid,'kind':'git.commit','algorithm':'sha1'}
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def wire(v):
    if isinstance(v,bytes):return {'__fixture_raw__':base64.b64encode(v).decode()}
    if isinstance(v,dict):return {k:wire(s) for k,s in v.items()}
    if isinstance(v,list):return list(map(wire,v))
    return v
def unwire(v):
    if isinstance(v,dict):
        if set(v)=={'__fixture_raw__'}:return base64.b64decode(v['__fixture_raw__'])
        return {k:unwire(s) for k,s in v.items()}
    if isinstance(v,list):return list(map(unwire,v))
    return v
def bind(role='planner',actor='planner:private',assignment=None,**proof):
    return dict(role=role,actor_id=actor,principal_id='principal:local',commitment=None if role=='principal' else C,assignment=assignment,**proof)
OWNER=bind('principal','principal:local');PL=bind();CLOSE=bind('closure','closure:independent')
def material(name,version=1):
    return (('Independent protected queue '+('W2 revised' if name==WA and version==2 else 'W2 linear' if name==WA else 'W1 preferences')+' v'+str(version)+'; scope exact fixture Git object').encode(),
            (BASE/'m3-environment-v1.json').read_bytes())
def req(db,ops,b=PL,base=None,pid=None):
    return dict(binding=b,proposal={'v':1,'commitment':C,'base_revision':head(db) if base is None else base,'proposal_id':pid or 'ind-'+uuid.uuid4().hex,'justification':[],'ops':ops if isinstance(ops,list) else [ops]})
def apply(db,r,expected='admitted'):
    out=subprocess.run([sys.executable,'-B',str(Path(__file__).resolve()),'send',str(db)],input=enc(wire(r)),env=ENV,cwd=HERE,capture_output=True,timeout=15)
    if out.returncode:raise RuntimeError((out.stderr,out.stdout))
    got=json.loads(out.stdout)
    if expected is not None:assert got['disposition']==expected,(r['proposal'],got,expected)
    return got
def op(db,op,b=PL,expected='admitted',**kw):return apply(db,req(db,op,b,**kw),expected)
def head(db):return Store(db).snapshot()['revision']
def cli(db,*a):return cold_cli.ok(cold_cli.run(REPO,db,*a))
def rows(db):
    c=sqlite3.connect(Path(db).resolve().as_uri()+'?mode=ro',uri=True)
    try:return [r[0] for r in c.execute('select body from events order by revision')]
    finally:c.close()
def fork(src,path):
    assert not path.exists();cold_cli.copied_events(REPO,src,path);return path
def prem(db,key,aid,what='contradicts',b=None,**kw):
    if b is None:b=bind('observer',OP,aid,premise={'artifact':('Independent protected observation: '+aid+' '+what+' '+key).encode()})
    return op(db,{'op':'assumption.observe','id':key,'assumption':aid,'finding':what},b,**kw)
def decision(id,choice,support,triggers,prev=None):return {'op':'decision.record','id':id,'choice':choice,'alternatives':['linear','exponential'],'rationale':'Independent documented fixture basis','support':support,'triggers':triggers,'supersedes':prev}
def set_crit(db,w,version):
    defn,env=material(w,version)
    return op(db,{'op':'obligation.set','id':'O-'+w,'work':w,'version':version,'title':('W2/retry' if w==WA else 'W1/preferences'),'observer':OE,'verifier':VE,'definition_sha256':sha(defn),'environment_sha256':sha(env)},OWNER)
def assign(db,w,tag):return op(db,{'op':'work.assign','id':'AS-'+tag,'work':w,'executor':EX})
def submit(db,w,tag,oid):
    return op(db,{'op':'result.submit','id':'R-'+tag,'assignment':'AS-'+tag,'candidate':cand(oid)},bind('executor',EX,'AS-'+tag))
def openrun(db,w,tag,result=None):return op(db,{'op':'run.open','id':'V-'+tag,'obligation':'O-'+w,'result':result or 'R-'+tag})
def witness(db,w,tag,oid,version,seq=''):
    lab='W2/retry' if w==WA else 'W1/preferences';phase='revised' if w==WA and version==2 else 'linear'
    data=measure(BASE/'hand-git',oid,2001,phase);passed=data['criteria'][lab]
    defn,env=material(w,version);rid='V-'+tag;ob='Obs-'+tag+seq;ev='E-'+tag+seq
    artifact=enc({'candidate':oid,'criterion':lab,'phase':phase,'observations':[v for v in data['observations'] if v['criterion']==lab],'verdict':passed})
    op(db,{'op':'observation.record','id':ob,'run':rid},bind('observer',OE,rid,witness={'candidate':cand(oid),'definition':defn,'environment':env,'artifact':artifact}))
    return op(db,{'op':'evidence.record','id':ev,'run':rid,'observation':ob,'verdict':'pass' if passed else 'fail'},bind('verifier',VE,rid))
def replacement(db):
    op(db,decision('D-revised','exponential',['A-new'],['A-new'],D))
    set_crit(db,WA,2)
    assign(db,WA,'W9-new')
def fresh(db):
    cli(db,'init')
    op(db,{'op':'commitment.create','id':C,'root':ROOT,'statement':'Independent candidate-bound private M3 graph'},OWNER)
    hold=op(db,{'op':'commitment.request_acceptance','id':C,'expires_at':'2030-01-01T00:00:00.000000Z'},OWNER,'pending')
    op(db,{'op':'approval.answer','id':hold['details']['approval_id'],'request_digest':hold['digest'],'decision':'approve'},OWNER)
    op(db,[{'op':'work.create','id':w,'parent':parent,'title':w} for w,parent in ((R,ROOT),(WA,R),(WB,R),('W-cycle-x',ROOT),('W-cycle-y',ROOT),('W-sentinel',ROOT))])
    op(db,[{'op':'work.coverage','id':w,'kind':'all','k':None} for w in (ROOT,R)])
    op(db,[{'op':'assumption.create','id':a,'statement':'Controlled '+a,'observer':OP} for a in (A,'A-nontrigger','A-other','A-new')])
    op(db,decision(D,'linear',[A,'A-nontrigger'],[A]))
    op(db,[{'op':'dependency.add','id':w,'support':support} for w,support in ((WA,D),(WB,'A-other'),('W-cycle-x',WA),('W-cycle-y','W-cycle-x'),('W-cycle-x','W-cycle-y'),('W-sentinel',R))])
    for work in (WA,WB):set_crit(db,work,1);assign(db,work,work+'-old')
    submit(db,WB,'W10-old',G['linear']);openrun(db,WB,'W10-old');witness(db,WB,'W10-old',G['linear'],1)
    op(db,{'op':'work.close','id':WB},CLOSE)
def worker():
    mode,db=sys.argv[1:3]
    r=unwire(json.loads(sys.stdin.readline()))
    if mode=='wait':
        ready={'pid':os.getpid(),'head':head(db),'proposal_id':r['proposal']['proposal_id']};print(json.dumps(ready),flush=True)
        assert sys.stdin.readline().strip()=='go'
    rec=admit(Store(db),r['binding'],r['proposal'],clock=lambda:NOW)
    print(json.dumps(rec,sort_keys=True))
if __name__=='__main__':
    if len(sys.argv)>1:worker()
    else:
        p=HERE/'assigned.sqlite';fresh(p);print('assigned',head(p),cli(p,'frontier','--as-of',ASN))
