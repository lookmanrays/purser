"""Exercise the ordinary E2 archive entrypoints using one private rank on each of three tracks."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import zipfile

source = Path("/Users/lookman/.codex/worktrees/purser-delivery/m3-e2-fresh")
out = Path(__file__).resolve().parent
pin = sys.argv[1]
if not re.fullmatch("[0-9a-f]{40}", pin):
    raise ValueError("supply the full local candidate commit")
working = out / pin
working.mkdir()
repo = working / "source"
data = repo / "private-e2-91"
env = {"PATH": os.defpath, "TZ": "UTC", "LC_ALL": "C", "PYTHONDONTWRITEBYTECODE": "1",
       "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": os.devnull, "GIT_ALLOW_PROTOCOL": "file",
       "GIT_TERMINAL_PROMPT": "0"}

def run(cwd, argv):
    return subprocess.check_output(argv, env=env, cwd=cwd)

def git(cwd, *argv):
    return run(cwd, ["git", *argv])

def python(*argv):
    return run(repo, [sys.executable, "-B", *argv])

def artifact(path):
    blob = path.read_bytes()
    return {"sha256": hashlib.sha256(blob).hexdigest(), "bytes": len(blob)}

git(source, "clone", "--quiet", "--shared", "--no-checkout", "--", str(source), str(repo))
git(repo, "checkout", "--quiet", "--detach", pin)
assert git(repo,"rev-parse","HEAD").decode().strip() == pin
python("-m", "experiments.e2", "freeze", str(data), "--replicate", "91", "--reason",
       "Private readback qualification on the first seed and both controls in each arm")
freeze = json.loads((data/"freeze.json").read_bytes())
assert freeze["source_commit"] == pin and freeze["replicate"] == 91
git(repo, "add", "--", str(data.relative_to(repo)/"freeze.json"))
git(repo, "-c", "user.name=Purser local qualification", "-c", "user.email=qualification@example.invalid",
    "-c", "commit.gpgsign=false", "commit", "--quiet", "-m", "Pin private E2 qualification for nine local observations")
registration = git(repo, "rev-parse", "HEAD").decode().strip()
print("private preregistration", registration, "source", pin, flush=True)
python("-c", """
import sys
from pathlib import Path
from experiments.e2.suite import collect_units, schedule
units = [unit for unit in schedule() if unit[1] == 2001]
assert len(units) == 9 and all(unit[2] == 1 for unit in units)
collect_units(Path(sys.argv[1]), units)
""", str(data))
print("private collection returned", flush=True)
archive_copy = working / "archive-only"
archive_copy.mkdir()
(archive_copy/"raw.zip").write_bytes((data/"raw.zip").read_bytes())
report = python("-m", "experiments.e2", "report", str(archive_copy))
(working/"report.md").write_bytes(report)
assert "9 of 66 registered records" in report.decode()
assert "57 are missing" in report.decode()
assert "overhead flag is **no**" in report.decode()
assert report == python("-m", "experiments.e2", "report", str(data))
print("native report reproduced byte-identically with and without detached freeze", flush=True)
verification = json.loads(python("-m", "experiments.e2", "verify", str(archive_copy)))
assert verification["records"] == verification["started"] == 9
assert verification["replicate"] == 91 and verification["registered"] == 66 and verification["missing_registered"] == 57
print("native strict verify", verification, flush=True)
readback = json.loads(python("-c", """
import json,sys
from pathlib import Path
from experiments.e2.report import inspect_series
cases,stats=inspect_series(Path(sys.argv[1]))
print(json.dumps([{"track":t,"seed":s,"arm":a,"terminal":c.raw["terminal"],"validity":c.raw["validity"],
                  "steps":c.raw["cost"]["steps"],"calls":c.raw["cost"]["model_calls"],"issues":c.issues,
                  "unavailable":c.unavailable,"healthy_clean":c.healthy_clean,
                  **{k:c.facts.get(k) for k in ("rework_steps","intervention_reached","unaffected_both_retained",
                    "stale_at_delivery","new_bad_closure","final_pass","final_candidate","final_criteria",
                    "clock_pause_quiescent","exclusion_accounted","witnessed_elapsed_ns","cohort_eligible",
                    "prior_changed_exposure","clean_exposure","physical_exit","step_comparable","elapsed_comparable")}}
                 for (t,s,a),c in cases.items()],sort_keys=True))
""",str(archive_copy)))
expected={"primary":{"loop":(30,13),"purser":(48,25),"loop_equal_verifier":(48,25)},
          "clean":{"loop":(24,None),"purser":(42,None),"loop_equal_verifier":(42,None)},
          "closed-affected":{"loop":(32,13),"purser":(53,25),"loop_equal_verifier":(53,25)}}
with zipfile.ZipFile(data/"raw.zip") as archive:
    assert archive.read("freeze.json") == (data/"freeze.json").read_bytes()
    members = archive.namelist()
    assert len(members)==len(set(members))
    starts = [name[8:] for name in members if name.startswith("started/")]
    records = [name[5:] for name in members if name.startswith("runs/")]
    assert set(starts) == set(records) and len(starts)==9
for case in readback:
    track,arm=case["track"],case["arm"]
    assert not case["issues"] and not case["unavailable"], (track,arm,case)
    assert case["terminal"]=="done" and case["validity"]=="complete" and case["calls"]==0
    assert (case["steps"],case["rework_steps"]) == expected[track][arm], case
    assert case["final_pass"] and len(case["final_criteria"])==6 and set(case["final_criteria"].values())=={"pass"}
    assert case["physical_exit"] and case["step_comparable"] and case["elapsed_comparable"] and case["cohort_eligible"]
    if track=="clean":
        assert case["clean_exposure"] is True and case["healthy_clean"]
    else:
        assert case["intervention_reached"] and case["unaffected_both_retained"]
        assert case["prior_changed_exposure"] is False and case["new_bad_closure"] is False
        assert case["stale_at_delivery"] is (track=="closed-affected" and arm!="purser")
record={"source":pin,"private_registration_commit":registration,"freeze":artifact(data/"freeze.json"),
        "raw":artifact(data/"raw.zip"),"report":artifact(working/"report.md"),"verified":verification,"cases":readback}
(working/"readback.json").write_text(json.dumps(record,sort_keys=True,indent=2)+"\n")
print(json.dumps({k:v for k,v in record.items() if k!="cases"},sort_keys=True))
print("readback",str(working/"readback.json"),flush=True)
