"""Stop with an initialized sealed fixture immediately before actual participant release."""
import hashlib
import json
import os
import signal
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from unittest.mock import patch

out = Path(__file__).resolve().parent
source = out / 'source'
sys.path.insert(0, str(source))
from experiments.e1.artifacts import START
from experiments.e1.report import Objects, GitPacks
from experiments.e2 import clock, suite, trial, measure
from experiments.e2.report import inspect_series

pin = '0ad579f7a39f033b2efe59a6f8f3d04ac1dabef0'
series = source / 'private-qualification' / 'sealed-before-release'
unit = [('primary', 2001, 1, 'loop')]
if sys.argv[1:] == ['worker']:
    def stop(journal):
        assert not journal.released and START in journal.candidates and journal.steps == 0
        os.kill(os.getpid(), signal.SIGKILL)
    with patch.object(clock.ParticipantClock, 'release', stop):
        suite.collect_units(series, unit)
else:
    assert suite.repo('rev-parse','HEAD').decode().strip() == pin
    suite.freeze_series(series, replicate=119, reason='Private controlled stop after sealing the starting fixture and before release')
    subprocess.run(['git','add','--',str(series.relative_to(source)/'freeze.json')],cwd=source,check=True)
    subprocess.run(['git','-c','user.name=Local qualification','-c','user.email=qualification@example.invalid',
                    '-c','commit.gpgsign=false','commit','--quiet','-m','Register private stopped-before-release control'],cwd=source,check=True)
    proc = subprocess.run([sys.executable,'-B', __file__,'worker'])
    assert proc.returncode == -signal.SIGKILL
    progress = json.loads((series/'.attempt-primary-2001-loop/progress.json').read_bytes())
    assert START in progress['candidates'] and progress['cost_basis'] == 'before_release'
    (out/'sealed-before-release-progress.json').write_text(json.dumps(progress, sort_keys=True,indent=2)+'\n')
    with patch.object(trial, 'attempt', side_effect=AssertionError('redispatch')):
        suite.collect_units(series,unit)
        suite.collect_units(series,unit)
    with zipfile.ZipFile(series/'raw.zip') as archive:
        raw = json.loads(archive.read('runs/primary/2001/loop.json'))
        obj = Objects(archive)
        rows = obj.item(raw['artifacts']['journal'])
        candidates = obj.item(raw['artifacts']['candidates'])
        with tempfile.TemporaryDirectory() as temp:
            repo = GitPacks(Path(temp)).restore(START,candidates[START],obj)
            expected = []
            from experiments.e1.artifacts import extract_tree
            from experiments.e1.scorer import LABELS
            with extract_tree(repo,START) as tree:
                for ver,labels in ((measure.OLD,LABELS),(measure.NEW,measure.REVISED)):
                    expected.extend((label,ver,report['verdict']) for label,report in
                                    measure.check(repo,START,Path(tree),2001,1,ver,labels).items())
        actual = [e['payload'] for e in rows if e['kind']=='oracle']
        result = {'source':pin,'registration':suite.repo('rev-parse','HEAD').decode().strip(),'worker_returncode':proc.returncode,
                  'stage_candidates':list(progress['candidates']), 'retained_candidates':list(candidates),
                  'basis':progress['cost_basis'],'steps':raw['cost']['steps'],'terminal':raw['terminal'],
                  'independent_sealed_fixture':expected,'archived_oracles':actual,
                  'raw':str(series/'raw.zip'),'raw_sha256':hashlib.sha256((series/'raw.zip').read_bytes()).hexdigest()}
        path=out/'sealed-before-release-result.json'
        path.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
        print(path)
        print(json.dumps(result,sort_keys=True))
