# Private E2 stopped worker control

The source commit is 0ad579f7a39f033b2efe59a6f8f3d04ac1dabef0. Private replicate 119 covers the primary loop arm at seed 2001, rank 1. The separate private registration commit is d95cff6d0c5f86632bb41a2a4ff31aff397a421f. The protocol, product and study code come from the source pin.

In an isolated local clone, the control registered its private freeze, started the normal collect_units process, and delivered SIGKILL immediately before the real journal's release. At that point setup had written and fsynced progress containing the sealed starting fixture. No public action had started. The parent confirmed the worker's negative SIGKILL process status and the durable progress, then reopened the same case twice through collect_units. The final raw records before_release, zero participant costs and no exit. The archived kernel-independent Git pack contains the exact initial tree. Eight independently reexecuted observations have six failures and two passes. The native reader shows all six last-candidate criteria as unknown. The native strict command verifies the Git pack and reports zero candidate/version reexecutions. The private collector's record contains zero oracle events.

The early return at experiments/e2/trial.py line 147 skips all surviving candidate data whenever cost_basis is before_release. The failure concerns independent measurement of an existing sealed Git candidate. The physical participant exit and release are unavailable by construction. The collector's zero elapsed time, zero actions, original interruption and unchanged archive on two additional read-only reopens are directly confirmed in cold-readback.json. The six old criteria are W1/preferences, W2/retry, W3/delivery, scope/paths, legacy/compat and queue/composition. Each changed-task variant of W2/retry and queue/composition was also graded. Each original measured report and its grade are in independent-oracles.

## Reproduce the original worker stop

These commands use a new empty private directory containing copies of sealed_before_release.py, readback.py and source-and-registration.bundle. They create one isolated local private registration commit. No credentials, remote provider or network transport is required.

```sh
git init -q source
git -C source fetch ../source-and-registration.bundle HEAD
git -C source checkout -q --detach 0ad579f7a39f033b2efe59a6f8f3d04ac1dabef0
python3.11 -B sealed_before_release.py
python3.11 -B readback.py
```

## Verify the original evidence read-only at the product boundary

Extract the evidence zip in a new directory. Use the original private registration and byte-identical raw archive. readback.py writes its audit outside the retained study source. The script also reopens the original collection twice with an asserted zero dispatch count and checks that its SHA-256 remains identical.

```sh
git init -q source
git -C source fetch ../source-and-registration.bundle HEAD
git -C source checkout -q --detach d95cff6d0c5f86632bb41a2a4ff31aff397a421f
cp original/raw.zip source/private-qualification/sealed-before-release/
python3.11 -B readback.py
```

The original registration bytes are also included in original/freeze.json. The full unmodified archive, including original start marker, raw case, sealed Git object and every staged reference, is in original/raw.zip.

## Other working-copy controls

Before the immutable pin was supplied, 13 actual local qualification/withholding controls exercised the two registered timing tracks and all three arms. All six faulty old W2 behaviors withheld ingress, all four plain-loop faulty W1/W3 behaviors withheld ingress, and all three valid old checkpoints followed by real W1 reopen recorded exactly one withheld stale-head delivery. A separate earliest setup interruption had no sealed candidates or issued actions. An interruption during protected scoring retained four candidates, 17 attempts, 32 postmortem measurements and one completed admission criterion. After physical closure, the two stopped-worker tests (no disposable trial; only the redundant bare store missing) each recovered five candidates and 40 independent observations. Two real SIGALRM runs observed an active in-flight cutoff at 60.002919917 physical seconds and a quiescent 60.256256042-second interval charged 0.000808375 active seconds. Six checkpoint/clock/recovery and four original-history unit tests covered real pre-witness Purser history and missing admitted witness bytes, and eight E1 collection/E2 plan tests passed. These are development observations on the evolving integrated working copy. The post-pin control ended candidate qualification on the observed recoverable START omission before the planned immutable repeats of those other controls. No official study registration or collection took place.
