"""Independent readback of a stopped E2 worker's archived starting pack."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


archive_path, reference_path = map(Path, sys.argv[1:])
with zipfile.ZipFile(archive_path) as archive:
    names = archive.namelist()
    assert len(names) == len(set(names)) and archive.testzip() is None
    for name in names:
        if name.startswith("objects/"):
            assert digest(archive.read(name)) == Path(name).stem
    starts = sorted(n for n in names if n.startswith("started/"))
    raws = sorted(n for n in names if n.startswith("runs/"))
    assert len(starts) == len(raws) == 1
    raw = json.loads(archive.read(raws[0]))
    def read(ref):
        value = archive.read(ref["path"])
        assert len(value) == ref["bytes"] and digest(value) == ref["sha256"]
        return value
    registration = json.loads(archive.read("freeze.json"))
    candidates = json.loads(read(raw["artifacts"]["candidates"]))
    oid, = candidates
    entry = candidates[oid]
    packet = read(entry["pack"])
    events = json.loads(read(raw["artifacts"]["journal"]))
    platform = json.loads(read(raw["artifacts"]["platform"]))
    assert not any(row["kind"] in ("oracle", "action", "fault") for row in events)
    assert raw["terminal"] == "harness_failure" and raw["validity"] == "infrastructure_invalid"
    assert platform.get("participant_exit") is None and all(i == 0 for i in raw["cost"].values())
with tempfile.TemporaryDirectory(prefix="purser-fresh-original-start-") as temp:
    repo = Path(temp) / "objects.git"
    def git(*args, input=None):
        return subprocess.run(["git", *args], input=input, check=True, capture_output=True).stdout
    git("init", "-q", "--bare", str(repo))
    git("-C", str(repo), "index-pack", "--stdin", "--strict", input=packet)
    assert git("-C", str(repo), "rev-parse", oid + "^{tree}").decode().strip() == entry["tree"]
    phases = {}
    for phase in ("linear", "revised"):
        measurement = json.loads(subprocess.check_output([sys.executable, "-I", "-B", str(reference_path),
                                 str(repo), oid, str(raw["seed"]), phase]))
        assert measurement["candidate"] == oid and measurement["tree"] == entry["tree"]
        phases[phase] = measurement
    results = {label + "/v1": grade for label, grade in phases["linear"]["criteria"].items()}
    results.update({k + "/v2": phases["revised"]["criteria"][k] for k in ("W2/retry", "queue/composition")})
assert len(results) == 8 and sum(results.values()) == 2
print(json.dumps({"source": registration["source_commit"], "archive_sha256": digest(archive_path.read_bytes()),
                  "archive_members_verified": len(names), "starts": len(starts), "raw_cases": len(raws),
                  "participant_cost": raw["cost"], "raw_terminal": raw["terminal"], "raw_score": raw["score"],
                  "physical_participant_exit": platform.get("participant_exit"),
                  "journal_kinds": [e["kind"] for e in events], "recorded_oracles": 0,
                  "seed": raw["seed"], "replicate": raw["replicate"], "candidate": oid, "tree": entry["tree"],
                  "pack_sha256": digest(packet), "pack_bytes": len(packet), "oracle_program_sha256": digest(reference_path.read_bytes()),
                  "independent_grades": results, "legacy_suite": phases["linear"]["legacy"]}, indent=2, sort_keys=True))
