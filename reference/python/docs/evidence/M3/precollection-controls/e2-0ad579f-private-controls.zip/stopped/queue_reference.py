"""Protected, independent E2 notification measurement from the frozen M0 protocol."""
import hashlib,json,os,subprocess,sys,tempfile
from datetime import datetime,timedelta
from pathlib import Path
START='55686bd5152e10a53dfdc2c003974ea405a3a075'
TREE='2afea0fdd3478d29447a40bde8007266c468c72b'
ALLOWED={'notify/preferences.py','notify/retry.py','notify/delivery.py'}
EPOCH=datetime(2001,1,1,12)
LABEL=['W1/preferences','W2/retry','W3/delivery','scope/paths','legacy/compat','queue/composition']
ENV={'PATH':'/usr/bin:/bin','LC_ALL':'C','TZ':'UTC','GIT_CONFIG_GLOBAL':os.devnull,'GIT_CONFIG_NOSYSTEM':'1'}
def canonical(v):
    return json.dumps(v,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode()
def git(root,*args,data=None):
    return subprocess.check_output(['git','-C',str(root),*args],input=data,stderr=subprocess.PIPE,env=ENV)
def files(repo,oid):
    if len(oid)!=40 or any(c not in '0123456789abcdef' for c in oid):raise ValueError('immutable Git commit required')
    assert git(repo,'cat-file','-t',oid).strip()==b'commit'
    out={}
    for row in git(repo,'ls-tree','-r','-z',oid).split(b'\0'):
        if not row:continue
        meta,path=row.split(b'\t',1);mode,kind,blob=meta.decode().split();name=path.decode()
        if Path(name).is_absolute() or any(p in ('','.','..') for p in name.split('/')):raise ValueError('invalid fixture path')
        out[name]=(mode,kind,blob)
    return out
def extract(root,repo,source):
    for name,(mode,kind,blob) in source.items():
        if kind!='blob' or mode not in ('100644','100755'):raise ValueError('unavailable regular-file measurement')
        p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(git(repo,'cat-file','blob',blob))
def offsets(phase,n,base):
    if phase=='linear':return [k*base for k in range(n)]
    if phase=='revised':return [0]+[base*(2**(k-1)) for k in range(1,n)]
    raise ValueError(phase)
def inputs(seed,phase):
    j=seed-2001
    if not 0<=j<20:raise ValueError('registered E2 seed required')
    channels=['mail','push','digest','inbox','desktop'];ch,alt=channels[j%5],channels[(j+1)%5]
    a,b,c=[f'{seed}-{x}' for x in 'abc'];n,base=4+j%4,2+j%5;cases=[]
    def add(label,ids,disabled,count,delay,single=False):
        due=offsets(phase,count,delay)
        times=[0,1] if single else sorted({0,*due,*(t-1 for t in due if t>0),due[-1]+1})
        ids2=list(dict.fromkeys(ids)) if ch not in disabled else []
        expected=[];last=-1
        for t in times:
            expected.append([[x,ch,off*1000000] for off in due if last<off<=t for x in ids2]);last=t
        spec={'channel':ch,'ids':ids,'disabled':disabled,'attempts':count,'base':delay,'times':times}
        cases.append((label,spec,{'count':len(ids2)*count,'batches':expected,'pending':0}))
    for disabled in ([],[ch],[alt]):add(LABEL[0],[a],disabled,1,base,True)
    for count,delay in ((1,base),(n,base),(n,1)):add(LABEL[1],[a],[],count,delay)
    for ids in ([a,b,a,c,b],[c,c],[]):add(LABEL[2],ids,[],1,base,True)
    for disabled in ([],[ch]):add(LABEL[5],[a,b,a,c,b],disabled,n,base)
    return cases
def typed(value,t):
    if type(value) is t:return value
    return {'type':type(value).__name__,'repr':repr(value)}
def child(args):
    mode,root,tests=args;sys.path.insert(0,root)
    if mode=='legacy':
        import unittest
        suite=unittest.defaultTestLoader.discover(tests);result=unittest.TestResult();suite.run(result)
        print(json.dumps({'count':result.testsRun,'errors':len(result.errors),'fails':len(result.failures),'skips': len(result.skipped)}));return
    cases=json.load(sys.stdin)
    try:from notify.service import NotificationQueue
    except Exception as e:
        print(json.dumps([{'candidate_import_error':type(e).__name__}]*len(cases)));return
    found=[]
    for spec in cases:
        try:
            q=NotificationQueue(EPOCH);cnt=q.enqueue(spec['channel'],spec['ids'],disabled=spec['disabled'],attempts=spec['attempts'],base=spec['base']);batches=[]
            for t in spec['times']:
                group=[]
                for item in q.advance(EPOCH+timedelta(seconds=t)):
                    due=typed(item.due_at,datetime)
                    if isinstance(due,datetime) and due.tzinfo is None:
                        d=due-EPOCH;due=(d.days*86400+d.seconds)*1000000+d.microseconds
                    elif isinstance(due,datetime):due={'aware_datetime':str(due)}
                    group.append([typed(item.event_id,str),typed(item.channel,str),due])
                batches.append(group)
            found.append({'count':typed(cnt,int),'batches':batches,'pending':len(q.scheduler.get_jobs())})
        except Exception as e:found.append({'candidate_queue_error':type(e).__name__})
    print(json.dumps(found))
def measure(repo,oid,seed,phase):
    assert git(repo,'rev-parse',START+'^{tree}').decode().strip()==TREE
    first,now=files(repo,START),files(repo,oid);changed=sorted(k for k in first.keys()|now.keys() if first.get(k)!=now.get(k))
    checks={LABEL[3]:set(changed)<=ALLOWED and all(now.get(k,())[0:2]==('100644','blob') for k in ALLOWED)}
    cases=inputs(seed,phase)
    with tempfile.TemporaryDirectory(prefix='purser-e2-independent-queue-') as folder:
        tmp=Path(folder);root=tmp/'candidate';tests=tmp/'trust';extract(root,repo,now);extract(tests,repo,{k:v for k,v in first.items() if k.startswith('tests/')})
        def invoke(mode,specs=None):
            return json.loads(subprocess.check_output([sys.executable,'-I','-B',str(Path(__file__).resolve()),'child',mode,str(root),str(tests/'tests')],input=canonical(specs),env=ENV,cwd=tmp,stderr=subprocess.PIPE,timeout=15))
        found=invoke('queue',[v[1] for v in cases]);legacy=invoke('legacy')
        if type(found) is not list or len(found)!=len(cases):raise ValueError('protected measurement unavailable')
        observations=[]
        for (label,spec,expect),observed in zip(cases,found):
            passed=canonical(expect)==canonical(observed)
            checks[label]=checks.get(label,True) and passed
            observations.append({'criterion':label,'input':spec,'expected':expect,'observed':observed})
        checks[LABEL[4]]=legacy=={'count':28,'errors':0,'fails':0,'skips':0}
    return {'candidate':oid,'tree':git(repo,'rev-parse',oid+'^{tree}').decode().strip(),'seed':seed,'phase':phase,'criteria':checks,'changed':changed,'legacy':legacy,'observations':observations}
if __name__=='__main__':
    if sys.argv[1]=='child':child(sys.argv[2:])
    else:print(json.dumps(measure(Path(sys.argv[1]),sys.argv[2],int(sys.argv[3]),sys.argv[4]),sort_keys=True))
