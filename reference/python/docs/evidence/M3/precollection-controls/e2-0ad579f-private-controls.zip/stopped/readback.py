"""Reopen the original twice, run the native readers and direct-grade every surviving START criterion."""
import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from unittest.mock import patch

out = Path(__file__).resolve().parent
source = out / 'source'
sys.path.insert(0, str(source))
from experiments.e1.artifacts import START, REGISTRATION, extract_tree
from experiments.e1.report import Objects, GitPacks
from experiments.e1.scorer import LABELS
from experiments.e2 import suite, measure, trial
from experiments.e2.report import inspect_series

pin = '0ad579f7a39f033b2efe59a6f8f3d04ac1dabef0'
case = str(Path('private-qualification') / 'sealed-before-release')
series = source / case
raw_path = series / 'raw.zip'
digest = lambda value: hashlib.sha256(value).hexdigest()
def save(name, value):
    (out / name).write_text(json.dumps(value, sort_keys=True, indent=2)+'\n')
def run(*args):
    return subprocess.check_output(args,cwd=source)
assert run('git','rev-parse', 'HEAD^').decode().strip() == pin
frozen = json.loads(run('git','show','HEAD:' + case + '/freeze.json'))
assert frozen['source_commit'] == pin
original = json.loads((out/'sealed-before-release-result.json').read_bytes())
before = digest(raw_path.read_bytes())
assert before == original['raw_sha256']
with patch.object(trial,'attempt',side_effect=AssertionError('second release')) as runner:
    unit=[('primary',2001,1,'loop')]
    suite.collect_units(series,unit)
    suite.collect_units(series,unit)
    assert runner.call_count == 0
after = digest(raw_path.read_bytes())
assert before == after
reports = out / 'independent-oracles'
reports.mkdir(exist_ok=True)
native = {}
for op, dest in [('report','native-report.md'),('verify','native-verify.json')]:
    answer = run(sys.executable,'-B','-m','experiments.e2',op,case)
    (out/dest).write_bytes(answer)
    if op=='verify': native = json.loads(answer)
assert native['git_packs'] == native['started'] == native['records'] == 1
assert native['reexecuted_seed_candidate_versions'] == 0
cases,stats = inspect_series(series)
cold, = cases.values()
assert cold.facts['last_observed_candidate'] == START and cold.facts['last_observed_source']=='sealed_starting_fixture'
assert set(cold.facts['last_observed_criteria'].values()) == {None}
save('native-cold-facts.json',{'basis':cold.basis,'facts':cold.facts,'issues':cold.issues,'unavailable':cold.unavailable,'stats':stats})
with zipfile.ZipFile(raw_path) as archive:
    assert archive.read('freeze.json') == (series/'freeze.json').read_bytes()
    row = json.loads(archive.read('runs/primary/2001/loop.json'))
    obj = Objects(archive)
    events=obj.item(row['artifacts']['journal'])
    platform=obj.item(row['artifacts']['platform'])
    candidates=obj.item(row['artifacts']['candidates'])
    assert row['inputs']['worktree_head'] == pin and row['replicate'] == frozen['replicate'] == 119
    assert row['cost']['steps'] == row['cost']['elapsed_ns'] == 0
    assert platform['participant_exit'] is None and not platform['clock_stopped']
    assert platform['failure'] == 'InterruptedError: collector exited before recording the complete trial'
    assert not any(e['kind'] in ('fault','action','oracle') for e in events)
    assert list(candidates)==[START]
    assert sum(n.startswith('started/') for n in archive.namelist())==1
    assert sum(n.startswith('runs/') for n in archive.namelist())==1
    assert len(set(archive.namelist()))==len(archive.namelist())
    with tempfile.TemporaryDirectory() as temp:
        repo=GitPacks(Path(temp)).restore(START,candidates[START],obj)
        observed=[]
        with extract_tree(repo, START) as tree:
            for version, labels in ((measure.OLD,LABELS),(measure.NEW,measure.REVISED)):
                for label in labels:
                    report=measure.check(repo,START,Path(tree),2001,1,version,[label])[label]
                    grade=measure.grade(report,START,label,2001,1,version)
                    assert grade==report['verdict']
                    name=f"{label.replace('/', '-')}-v{version}.json"
                    save('independent-oracles/'+name,report)
                    observed.append([label,version,grade])
        assert observed==original['independent_sealed_fixture']
    progress=json.loads((out/'sealed-before-release-progress.json').read_bytes())
    assert progress['cost_basis']=='before_release' and candidates==progress['candidates']
    record={'source':pin,'experiments_tree':run('git','rev-parse','HEAD:experiments').decode().strip(),
            'product_tree':run('git','rev-parse','HEAD:purser').decode().strip(),'registration':run('git','rev-parse','HEAD').decode().strip(),
            'private_replicate':119,'seed':2001,'rank':1,'arm':'loop','track':'primary','killed_before_release':original['worker_returncode'],
            'start':START,'retained_pack':candidates[START],'issued_actions':0,'before_release_cost':row['cost'],
            'participant_exit':platform['participant_exit'],'raw_recovery_reason':platform['failure'],'raw_members':len(archive.namelist()),
            'native_recorded_oracles':0,'native_versions_reexecuted':native['reexecuted_seed_candidate_versions'],
            'independently_reexecuted':observed,'double_reopen_calls':runner.call_count,
            'archive_digest_unchanged_across_reopens':before,'private_freeze_sha256':digest(archive.read('freeze.json'))}
    save('cold-readback.json',record)
    print(json.dumps(record, sort_keys=True))
