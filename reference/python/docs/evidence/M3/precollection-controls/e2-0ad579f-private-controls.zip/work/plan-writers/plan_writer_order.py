"""Observe a real competing plan writer between preparation and physical head replacement."""
import json
import multiprocessing
import os
from pathlib import Path
import sys
import time

def main(source,directory):
    sys.path.insert(0,str(source))
    from experiments.e2 import policy
    directory.mkdir(parents=True)
    participant=directory/"participant";participant.mkdir()
    writer=policy.PlanArm(participant)
    writer.update("W1",state="closed");writer.update("W2",state="closed")
    initial=writer.public_view()
    ctx=multiprocessing.get_context("fork")
    first_wait=ctx.Event();second_begun=ctx.Event();release=ctx.Event()
    def go(which,work):
        entered=False
        actual=os.replace
        traffic=[]
        def replace(src,dst,*a,**kw):
            nonlocal entered
            target=Path(dst)
            traffic.append(str(target))
            if which=="first" and not entered and target.resolve()==writer.file.resolve():
                entered=True
                first_wait.set()
                if not release.wait(10):
                    raise RuntimeError("timeout while holding real first publication")
            return actual(src,dst,*a,**kw)
        os.replace=replace
        if which=="second":second_begun.set()
        ret=writer.update(work,state="open")
        rows,identity=writer.public_view()
        (directory/(which+".json")).write_text(json.dumps({"ret":ret,"W1":rows['W1']['state'],"W2":rows['W2']['state'],"identity":identity,"destinations":traffic},indent=2)+"\n")
    p1=ctx.Process(target=go,args=("first","W1"));p1.start()
    armed=first_wait.wait(5)
    if not armed:
        release.set();p1.join();raise RuntimeError("this version's active plan head moved; inspect actual publication path before repeating")
    p2=ctx.Process(target=go,args=("second","W2"));p2.start();assert second_begun.wait(4)
    p2.join(.5)
    at_gap,mid_id=writer.public_view()
    second_published=(directory/"second.json").exists()
    release.set()
    p1.join(8);p2.join(8)
    assert p1.exitcode==p2.exitcode==0,(p1.exitcode,p2.exitcode)
    end,end_id=writer.public_view()
    pick=lambda rows:{s:rows[s]["state"] for s in ("W1","W2")}
    result={"source":__import__("subprocess").check_output(["git","-C",str(source),"rev-parse","HEAD"]).decode().strip(),
            "initial":pick(initial[0]),"initial_id":initial[1],"second_finished_before_first_publish":second_published,
            "observed_before_first_release":pick(at_gap),"observed_predecessor":mid_id,"final":pick(end),"final_id":end_id,
            "first":json.loads((directory/"first.json").read_bytes()),"second":json.loads((directory/"second.json").read_bytes())}
    (directory/"result.json").write_text(json.dumps(result,indent=2,sort_keys=True)+"\n");print(json.dumps(result))
if __name__=="__main__":
    main(*[Path(p).resolve() for p in sys.argv[1:]])
