"""Read a sealed nine-case private E2 archive and exercise three archive-only controls."""
import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import zipfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()


def referenced(members, ref):
    payload = members[ref["path"]]
    assert len(payload) == ref["bytes"] and digest(payload) == ref["sha256"], ref
    return json.loads(payload)


def put(members, value):
    payload = canonical(value)
    hashed = digest(payload)
    path = f"objects/{hashed}.json"
    members[path] = payload
    return {"bytes": len(payload), "sha256": hashed, "path": path}


def update_platform(members, raw, platform, trace):
    old = platform["treatment_trace"]
    del members[old["path"]]
    new = put(members, trace) if trace is not None else None
    platform["treatment_trace"] = new
    platform["referenced_files"] = [ref for ref in platform["referenced_files"] if ref != old]
    if new is not None:
        platform["referenced_files"].append(new)
    raw["artifacts"]["platform"] = put(members, platform)
    return {"original": old, "retained_prefix": new}


def cross_work_receipt(members, raw, platform):
    journal = referenced(members, raw["artifacts"]["journal"])
    closes = {row["payload"]["subject"]: row["payload"] for row in journal
              if row["kind"] == "action" and row["payload"]["actor"] == "closure"}
    victim, other = closes["W2"], closes["W3"]
    actual, earlier = victim["return"]["receipt"], other["return"]["receipt"]
    assert actual["proposal_id"] != earlier["proposal_id"]
    trace = referenced(members, platform["treatment_trace"])
    original = list(map(json.loads, trace["original_events"]))
    original_closures = {}
    for work, item in (("W2", actual), ("W3", earlier)):
        original_receipt = next(event for event in original
                                if event["type"] == "ProposalReceipted" and event["revision"] == item["revision"])
        assert {**original_receipt["data"], "revision": original_receipt["revision"]} == item
        certified = next(event for event in original if event["type"] == "WorkClosed" and event["data"]["id"] == work
                         and event["proposal_id"] == item["proposal_id"] and event["batch_start"] == original_receipt["batch_start"])
        original_closures[work] = {"work_revision": certified["revision"], "receipt": item,
                                   "batch_head": original_receipt["hash"]}
    witness = referenced(members, victim["response_evidence"])
    victim["return"]["receipt"] = earlier
    witness["return"] = victim["return"]
    victim["response_evidence"] = put(members, witness)
    raw["artifacts"]["journal"] = put(members, journal)
    return {"target_attempt": victim["attempt"], "copied_attempt": other["attempt"], "originals": original_closures}


def partial_original(members, raw, platform):
    trace = referenced(members, platform["treatment_trace"])
    stream = list(map(json.loads, trace["original_events"]))
    physical = next(event for event in stream if event["type"] == "PremiseObserved")
    cut = physical["batch_start"] + physical["batch_size"] - 1
    receipt = stream[cut - 1]
    assert receipt["type"] == "ProposalReceipted" and receipt["data"]["disposition"] == "admitted"
    assert cut < len(stream)
    trace["original_events"] = trace["original_events"][:cut]
    identities = update_platform(members, raw, platform, trace)
    return {**identities, "original_events": len(stream), "surviving_events": cut, "committed_notice": physical,
            "surviving_head": receipt["hash"], "original_head": stream[-1]["hash"]}


FIELDS = ("intervention_reached", "unaffected_both_retained", "reopened_subjects", "affected_invalid_closure",
          "closure_observations", "rework_observed", "rework_steps", "charged_attempts_observed", "final_candidate",
          "final_pass", "last_observed_candidate", "last_observed_pass", "cohort_eligible", "clean_exposure",
          "physical_exit", "complete_action_sequence", "complete_public_history", "receipt_complete",
          "witnessed_elapsed_ns", "step_comparable", "elapsed_comparable")


def facts(case):
    return {key: case.facts.get(key) for key in FIELDS}


def run(args):
    source, archive, out = args.source.resolve(), args.archive.resolve(), args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    sys.path.insert(0, str(source))
    from experiments.e2.report import inspect_series
    observed = {}
    executed = []
    def command(argv, cwd, name):
        result = subprocess.run(argv, cwd=cwd, capture_output=True)
        (out / (name + ".stdout")).write_bytes(result.stdout)
        (out / (name + ".stderr")).write_bytes(result.stderr)
        executed.append({"command": shlex.join(argv), "cwd": str(cwd), "exit": result.returncode,
                         "stdout": name + ".stdout", "stderr": name + ".stderr"})
        return result
    with zipfile.ZipFile(archive) as zipped:
        assert zipped.testzip() is None
        members = {n: zipped.read(n) for n in zipped.namelist()}
    registration = json.loads(members["freeze.json"])
    pin = registration["source_commit"]
    assert pin == args.candidate and registration["replicate"] > 1
    fixture = subprocess.check_output(["git", "rev-parse", pin + ":experiments/manifests/v1"], cwd=source, text=True).strip()
    product = subprocess.check_output(["git", "rev-parse", pin + ":purser"], cwd=source, text=True).strip()
    tree = subprocess.check_output(["git", "rev-parse", pin + "^{tree}"], cwd=source, text=True).strip()
    assert fixture == "f1d8dd89981771249389b0b713aa389eca98c1fd" and product == "c2d2e50c748324fc0b4fe697ccf490efc47c15f9"
    baseline = out / "input"
    baseline.mkdir(exist_ok=True)
    shutil.copyfile(archive, baseline / "raw.zip")
    original, _ = inspect_series(baseline)
    assert len(original) == 9 and all(not case.issues for case in original.values())
    raw_sha = digest(archive.read_bytes())
    for scenario, track, alter in (
        ("wrong-closure-receipt", "primary", cross_work_receipt),
        ("missing-original-kernel", "clean", lambda m, r, p: update_platform(m, r, p, None)),
        ("partial-original-kernel", "primary", partial_original),
    ):
        folder = out / scenario
        folder.mkdir(exist_ok=True)
        derived = dict(members)
        key = track, 2001, "purser"
        run_path = f"runs/{track}/2001/purser.json"
        raw = json.loads(derived[run_path])
        platform = referenced(derived, raw["artifacts"]["platform"])
        change = alter(derived, raw, platform)
        derived[run_path] = canonical(raw)
        path = folder / "raw.zip"
        with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as z:
            for name, data in derived.items():
                entry = zipfile.ZipInfo(name, (2000, 1, 1, 0, 0, 0))
                z.writestr(entry, data, compress_type=zipfile.ZIP_DEFLATED)
        with zipfile.ZipFile(path) as z:
            assert z.testzip() is None
        native = [sys.executable, "-B", "-m", "experiments.e2"]
        report = command(native+["report", str(folder)], source, scenario+"-report")
        strict = command(native+["verify", str(folder)], source, scenario+"-verify")
        assert report.returncode == 0 and strict.returncode != 0
        cases, _ = inspect_series(folder)
        target, healthy = cases[key], original[key]
        unchanged = ["/".join(map(str,k)) for k,v in original.items() if k != key and asdict(v) == asdict(cases[k])]
        assert len(unchanged) == 8
        fail = strict.stderr.decode().splitlines()[-1]
        assert "/".join(map(str,key)) in fail and target.issues
        f = facts(target)
        assert f["physical_exit"] and f["final_pass"] and f["last_observed_pass"]
        assert f["charged_attempts_observed"] == (42 if track == "clean" else 48)
        if scenario == "wrong-closure-receipt":
            assert "return receipt differs from the original bound proposal" in fail
            assert change["originals"]["W2"]["receipt"]["proposal_id"] in fail
            assert f["complete_public_history"] and not f["receipt_complete"]
            assert f["closure_observations"] == healthy.facts["closure_observations"]
            assert f["rework_steps"] == 25 and f["unaffected_both_retained"]
        elif scenario == "missing-original-kernel":
            assert f["complete_public_history"] is False and f["clean_exposure"] is None and not target.healthy_clean
            assert not target.comparable_steps and f["elapsed_comparable"]
            assert b"overhead flag is **?**" in report.stdout
        else:
            assert not f["complete_public_history"] and not target.comparable_steps and f["rework_steps"] is None
            assert f["clean_exposure"] is False and f["unaffected_both_retained"] is None
        observed[scenario] = {"derived_archive_sha256": digest(path.read_bytes()), "alteration": change,
                              "strict_error": fail, "issues": list(target.issues), "unavailable": list(target.unavailable),
                              "unchanged_neighbors": unchanged, "facts": f, "original_facts": facts(healthy)}
    assert raw_sha == digest(archive.read_bytes())
    result = {"candidate_sha": pin, "source_tree": tree, "product_tree": product, "v1_tree": fixture,
              "input_archive": str(archive), "input_sha256": raw_sha, "registration_sha256": digest(members["freeze.json"]),
              "private_replicate": registration["replicate"], "scope": "archive-only trusted scripted fixture",
              "commands": executed, "observations": observed}
    (out/"result.json").write_text(json.dumps(result, indent=2, sort_keys=True)+"\n")
    print(json.dumps({"candidate": pin, "input_sha256":raw_sha, "controls": list(observed), "results":str(out/"result.json")}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("archive", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("candidate")
    run(parser.parse_args())
