# M3-B evidence-only handoff after RemediationFailure

Technical source `1baf2ddc88e187e1ee33e89c2a08f186f48db17c` failed independent source qualification. Implementation stopped and the official E2 series has zero starts. The two independently reproduced failures are in `findings/`.

Run the ordinary report and verifier on `findings/implicit-git-history/primary/implicit`. The report assigns 48 slots to seed 2001 and 40 to seed 2002. The verifier rejects after probing 88 slots. Its matched `explicit` directory uses the exact same donor chain and produces 40 slots for each case.

Each `findings/plan-missing-v10/` subdirectory with `baseline`, `missing` and `restored` records a separate comparison. `reviewer` holds the reviewer's original plain case, `primary` an independently registered plain case, and `equal-reviewer` the equal-verifier case missing version 12. The standalone Python scripts read the actual stored Git or captured operation and context before comparing native reports.

Each run retains its own committed registration. The case-level historical read uses the original producers' raw bytes and keeps their source pins. Open each nested control archive for its manifest and retained registration.

From a checkout at the exact source, execute the normal consumers on the extracted fresh cutoff directory.

```sh
python3.11 -B -m experiments.e2 report /path/to/packet/cutoff/data
python3.11 -B -m experiments.e2 verify /path/to/packet/cutoff/data
```

The historical cases span independently registered producer versions. Rerun the cross-version proof in a writable extraction of this packet. The script records both normal derivation and independent Git reexecution for each case.

```sh
python3.11 -I -B /path/to/packet/primary/originals.py /path/to/exact-source /path/to/packet/historical
```

The three crash controls also compare each recovered plan digest or original SQLite event with a separately withheld physical store. The independent Git matrix records membership, replay and historical reports per seed. The Python test logs, historical E1 report hashes and accepted M2 and M3-A replay identities are under `primary/`.
