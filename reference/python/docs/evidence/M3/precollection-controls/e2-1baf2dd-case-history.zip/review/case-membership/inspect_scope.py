from pathlib import Path
from unittest.mock import patch
import hashlib,json,sys,zipfile
b=Path(__file__).resolve().parent;repo=b/'inspect-repo';sys.path.insert(0,str(repo))
from experiments.e2 import suite,policy
from experiments.e2.driver import Driver
from experiments.e1.artifacts import START,git
d=repo/'docs/private-origin-inspection';mode=sys.argv[1]
def enc(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def sha(x):return hashlib.sha256(x).hexdigest()
if mode=='freeze':
    suite.freeze_series(d,replicate=117,reason='Private case-origin crosscheck on a genuine default Git history and an explicit HEAD query, sharing a ZIP with a distinct participant.')
if mode=='collect':
    execute=Driver.execute;sub=Driver.submit_work;edit=policy.edit
    def before(worker):
        if worker.seed==2001:
            reads=[]
            for oid in (None,START):
                git_reply=worker.tools.inspect('git_history','W-notify',candidate=oid)
                reads.append({'explicit_oid':oid,'reply':git_reply})
            (b/'outputs/private-inspect-independent-returns.json').write_bytes(enc(reads)+b'\n')
        return execute(worker)
    def donor(worker,work):
        if worker.seed==2001 or work!='W2':return sub(worker,work)
        def alt(directory,work,phase):
            v=edit(directory,work,phase);p=Path(directory)/'notify/retry.py';p.write_text(p.read_text()+'\n# Local reader-control comparison case.\n');return v
        with patch.object(policy,'edit',alt):return sub(worker,work)
    with patch.object(Driver,'execute',before),patch.object(Driver,'submit_work',donor):
        suite.collect_units(d,[('primary',2001,1,'loop'),('primary',2002,2,'loop')])
if mode=='derive':
    for name in ['implicit-impossible','explicit-impossible','implicit-genuine-donor']:
        out=b/'inspection-disputes'/name;out.mkdir(exist_ok=True,parents=True)
        with zipfile.ZipFile(d/'raw.zip') as a:
            def get(ref):return json.loads(a.read(ref['path']))
            obj={}; path='runs/primary/2001/loop.json';r=json.loads(a.read(path));j=get(r['artifacts']['journal'])
            s=json.loads(a.read('runs/primary/2002/loop.json'));donor=get(s['artifacts']['candidates']);pb=get(s['artifacts']['platform']);foreign=pb['exit_candidate']['head']
            def put(x):
                data=enc(x);oid=sha(data);p='objects/'+oid+'.json';obj[p]=data;return dict(path=p,sha256=oid,bytes=len(data))
            action=[row['payload'] for row in j if row.get('kind')=='action' and row['payload'].get('input',{}).get('tool')=='git_history'][1 if name.startswith('explicit') else 0]
            assert action['delivery']['state']=='received' and get(action['delivery']['payload'])==action['return']=={'value':[START]}
            original=action['delivery']['payload'];pack=[foreign,START]
            if name=='implicit-genuine-donor':
                pack=[]
                while foreign is not None:
                    pack.append(foreign);foreign=donor[foreign]['parent']
                assert pack[-1]==START and len(pack)>2
            ref=put({'value':pack});action['delivery']['payload']=ref;action['delivery']['sha256']=ref['sha256']
            r['artifacts']['journal']=put(j);obj[path]=enc(r)
            with zipfile.ZipFile(out/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as rep:
                for p in a.namelist():rep.writestr(p,obj.pop(p,a.read(p)))
                for p,data in obj.items():rep.writestr(p,data)
            (out/'identity.json').write_bytes(enc({'case':name,'attempt':action['attempt'],'work_started':action['work_started'],'only_changed_physical_source':'receiver reference and its duplicated SHA','genuine_retained_response':action['response_evidence'],'original':original,'replacement':ref,'donor_chain':pack})+b'\n')
