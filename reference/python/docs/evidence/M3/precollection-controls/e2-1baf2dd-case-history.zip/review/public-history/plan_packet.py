"""Reconstruct a missing original plan using only the damaged case's surviving public bytes."""
from copy import deepcopy
import hashlib,json
from pathlib import Path
import sys
from zipfile import ZipFile,ZIP_DEFLATED

damaged,restored,evidence=map(lambda x:Path(x).resolve(),sys.argv[1:])
canon=lambda obj:json.dumps(obj,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(",",":")).encode()
sha=lambda b:hashlib.sha256(b).hexdigest()
with ZipFile(damaged) as z:
    names=z.namelist()
    def obj(ref):
        data=z.read(ref["path"])
        assert len(data)==ref["bytes"] and sha(data)==ref["sha256"]
        return json.loads(data)
    raw_path,=[name for name in names if name.startswith("runs/")]
    row=json.loads(z.read(raw_path))
    journal=obj(row["artifacts"]["journal"])
    actions={e["payload"]["attempt"]:e["payload"] for e in journal if e["kind"]=="action"}
    reassign,read_n,submit_n,parent_n,previous_generation=(19,20,23,28,9) if row["arm"]=="loop" else (25,26,29,37,11)
    a,receiver,submit=actions[reassign],actions[read_n],actions[submit_n]
    assert a["work_started"]==a["work_request"] and a["work_request"]["method"]=="assign_again"
    assert a["subject"]==a["port_input"]["work"]==a["port_input"]["assign"]=="W2"
    assert a["actor"]=="planner" and a["port_return"]==a["return"]=={"state":"open"}
    assert a["finished_monotonic_ns"] < receiver["issued_monotonic_ns"]
    post=a["port_after"]["view"]
    assert post["path"] not in names and a["after"]==a["port_after"]==receiver["context_source"]==submit["port_before"]
    pre=obj(a["port_before"]["view"]); following=obj(submit["port_after"]["view"])
    tag=pre["W-notify"]["_e2_plan_version"]; assert tag["number"]==previous_generation
    next_tag=following["W-notify"]["_e2_plan_version"]
    assert next_tag["number"]==previous_generation+2 and next_tag["previous"]==post["sha256"]
    delivery=receiver["delivery"]; packet=obj(delivery["payload"])
    assert delivery["subject"]==packet["work"]["id"]=="W2" and delivery["state"]=="received" and delivery["attempt"]==read_n
    assert receiver["issued_monotonic_ns"]<=delivery["observed_monotonic_ns"]<=receiver["finished_monotonic_ns"]
    assert packet==obj(receiver["prepared_context"])==receiver["port_return"] and packet["state"]=="open"
    def reconstruct_packet(w2):
        picture=deepcopy(pre)
        picture["W2"]={**w2,"_publication":{"actor":a["actor"],"attempt":a["attempt"],"subject":a["subject"],"candidate":w2["candidate"],"diagnosis":[]}}
        picture["W-notify"]["_e2_plan_version"]={"attempt":a["attempt"],"number":tag["number"]+1,"previous":a["port_before"]["plan_sha256"]}
        return canon(picture)
    contents=reconstruct_packet(packet)
    assert (len(contents),sha(contents))==(post["bytes"],post["sha256"])
    assert sha(contents)==receiver["context_source"]["plan_sha256"]==next_tag["previous"]
    alternative=reconstruct_packet(dict(packet,retry_choice="linear"))
    assert sha(alternative)!=post["sha256"]
    parent=actions[parent_n]; prev_parent=obj(parent["port_before"]["view"]); parent_head=obj(parent["port_after"]["view"])
    actual=parent_head["W-notify"]["_publication"]
    assert actual=={"attempt":parent_n,"subject":"W-notify","actor":"executor","candidate":parent["candidate"],"diagnosis":[]}
    assert parent_head["W-notify"]["_e2_plan_version"]["previous"]==parent["port_before"]["plan_sha256"]
    assert [prev_parent["W-notify"]["state"],parent_head["W-notify"]["state"]]==["open","submitted"]
    other=[v for v in actions.values() if v["action"]=="submit" and v["attempt"]!=parent_n]
    assert all(v["finished_monotonic_ns"]<parent["issued_monotonic_ns"] for v in other)
    restored.parent.mkdir(exist_ok=True,parents=True)
    with ZipFile(restored,"x",ZIP_DEFLATED) as add:
        for name in names:add.writestr(name,z.read(name))
        add.writestr(post["path"],contents)
    output=dict(damaged_sha256=sha(damaged.read_bytes()),restored_sha256=sha(restored.read_bytes()),
                only_added=post,prior_head=a["port_before"]["plan_sha256"],next_head=submit["port_after"]["plan_sha256"],
                context_packet=delivery["payload"],received_ns=delivery["observed_monotonic_ns"],counterfactual_hash=sha(alternative),
                parent_subject=actual,parent_head=parent["port_after"]["plan_sha256"],parent_issued_ns=parent["issued_monotonic_ns"],
                previous_submissions=[(v["attempt"],v["subject"],v["finished_monotonic_ns"]) for v in other])
    evidence.write_text(json.dumps(output,sort_keys=True,indent=2)+"\n")
