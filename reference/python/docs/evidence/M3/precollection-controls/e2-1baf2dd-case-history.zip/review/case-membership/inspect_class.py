from pathlib import Path
from unittest.mock import patch
import hashlib,json,sys
b=Path(__file__).resolve().parent;repo=b/'class-repo';sys.path.insert(0,str(repo))
from experiments.e2 import suite,policy
from experiments.e2.driver import Driver
from experiments.e1.artifacts import START,git
from experiments.e1.executor import PARENT,PATHS
root=repo/'docs/inspection-method-class';mode=sys.argv[1]
def enc(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def sha(x):return hashlib.sha256(x).hexdigest()
if mode=='freeze':
 suite.freeze_series(root,replicate=118,reason='Private independent method-class inventory of genuine current and explicit Git operations and first participant readbacks.')
if mode=='collect':
 old=Driver.submit_work;edit=policy.edit;seen=set()
 def exercise(d):
  head=d.candidates.head;gitdir=d.candidates.archive;assert head!=START
  results=[]
  for operation in ('git','git_diff','git_history'):
   for work in (PARENT,'W1'):
    for selector in (None,START):
     oid=selector or head;path=[] if work==PARENT else [PATHS[work]]
     if operation=='git_history':native=git(gitdir,'log','--format=%H',oid,'--',*path).decode().splitlines()
     elif operation=='git_diff':native=git(gitdir,'diff','--no-ext-diff',START,oid,'--',*path).decode()
     elif path:native=git(gitdir,'cat-file','blob',f'{oid}:{path[0]}').decode()
     else:native=git(gitdir,'ls-tree','-r',oid).decode()
     result=d.tools.inspect(operation,work,candidate=selector)
     assert result==native
     results.append({'operation':operation,'work':work,'requested':selector,'physical_case_head':head,'expected_target':oid,'sha256_of_canonical_value':sha(enc(result)),'returned_history':result if operation=='git_history' else None})
  for scenario in ('different-return','lost-outer-ack','no-receipt','absent-candidate'):
   actual=[]
   def receiver(value,w):
    actual.append(value)
    if scenario!='no-receipt':w.received(PARENT,value)
    if scenario=='lost-outer-ack':raise RuntimeError('outer acknowledgment lost after physical receipt')
    return {'summary':'read returned to performing worker'}
   foreign='1a3550e0ed9c92cd004e96848a34a4fb1f2ac8f4'
   try: result=d.tools.inspect('git_history',PARENT,candidate=foreign if scenario=='absent-candidate' else None,receiver=receiver)
   except (ValueError,RuntimeError) as err:result={'observed_exception':str(err)}
   results.append({'scenario':scenario,'physical_case_head':head,'first_consumer_input':actual,'outward_return':result})
  (b/'outputs/class-boundary.json').write_bytes(enc(results)+b'\n')
 def sub(d,work):
  if d.seed==2001 and work=='W2' and not seen:
   seen.add(work);exercise(d)
  if d.seed!=2002 or work!='W2':return old(d,work)
  def changed(wk,name,phase):
   v=edit(wk,name,phase);p=Path(wk)/'notify/retry.py';p.write_text(p.read_text()+'\n# Local reader-control comparison case.\n');return v
  with patch.object(policy,'edit',changed):return old(d,work)
 with patch.object(Driver,'submit_work',sub):suite.collect_units(root,[('primary',2001,1,'loop'),('primary',2002,2,'loop')])
