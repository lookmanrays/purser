"""Independent private readback of known, controlled E2 fixture archives. No Purser imports."""

import argparse
import hashlib
import io
import json
import os
import subprocess
import sys
import tarfile
import tempfile
import unittest
import zipfile
from datetime import datetime, timedelta
from pathlib import Path


START = "55686bd5152e10a53dfdc2c003974ea405a3a075"
START_TREE = "2afea0fdd3478d29447a40bde8007266c468c72b"
CODE = Path(__file__).resolve()
PROJECT = Path("/Users/lookman/.codex/worktrees/purser-delivery/m3-case-history")
INPUTS = Path("/Users/lookman/.local/state/purser/development/m3-case-history/original-inputs")
DISPUTES = Path("/private/tmp/purser-m3-review.MbIBfSlC/m3-source-82/disputes")
CHECKPOINT_FIELDS = ("before", "after", "port_before", "port_after", "checkpoint", "pre_issue_head",
                     "context_source", "required_before")
PERMITTED = {"notify/preferences.py", "notify/retry.py", "notify/delivery.py"}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def read(z, ref):
    data = z.read(ref["path"])
    assert ref["bytes"] == len(data) and digest(data) == ref["sha256"], ref
    assert Path(ref["path"]).stem == ref["sha256"]
    return data


def item(z, ref):
    return json.loads(read(z, ref))


def git(path, *args, data=None):
    env = {k: v for k, v in os.environ.items() if not k.startswith("GIT_")}
    env.update(GIT_CONFIG_NOSYSTEM="1", GIT_CONFIG_GLOBAL=os.devnull)
    return subprocess.run(["git", *args], cwd=path, env=env, input=data, capture_output=True,
                          check=True, timeout=30).stdout


def observed_queue(root, seed):
    sys.path.insert(0, str(root))
    from notify.service import NotificationQueue

    start = datetime(2001, 1, 1, 12)
    j = seed - 2001
    channels = ("mail", "push", "digest", "inbox", "desktop")
    main, alternate = channels[j % 5], channels[(j + 1) % 5]
    base, attempts = 2 + j % 5, 4 + j % 4
    a, b, c = [f"{seed}-{x}" for x in "abc"]
    batch = [a, b, a, c, b]
    definitions = {
        "W1/preferences": [([a], 1, base, dis) for dis in ([], [main], [alternate])],
        "W2/retry": [([a], 1, base, []), ([a], attempts, base, []), ([a], attempts, 1, [])],
        "W3/delivery": [(ids, 1, base, []) for ids in (batch, [c, c], [])],
        "queue/composition": [(batch, attempts, base, dis) for dis in ([], [main])],
    }
    results = {}
    for label, inputs in definitions.items():
        for version in (1, 2) if label in ("W2/retry", "queue/composition") else (1,):
            checks = []
            for ids, tries, interval, dis in inputs:
                delays = [0] + [(k if version == 1 else 2 ** (k - 1)) * interval for k in range(1, tries)]
                ticks = sorted({0, max(delays) + 1, *delays, *(d - 1 for d in delays if d)})
                q = NotificationQueue(start)
                count = q.enqueue(main, ids, disabled=dis, attempts=tries, base=interval)
                observed = []
                expected = []
                previous = -1
                for tick in ticks:
                    rows = q.advance(start + timedelta(seconds=tick))
                    observed.append([[r.event_id, r.channel, int((r.due_at - start).total_seconds() * 1_000_000)]
                                     for r in rows])
                    expected.append([[eid, main, delay * 1_000_000] for delay in delays if previous < delay <= tick
                                     for eid in dict.fromkeys(ids) if main not in dis])
                    previous = tick
                checks.append(dict(input=dict(ids=ids, channel=main, base=interval, attempts=tries, disabled=dis, times=ticks),
                                   expected=dict(samples=expected, enqueued=sum(map(len, expected)), pending=0),
                                   observed=dict(samples=observed, enqueued=count, pending=len(q.scheduler.get_jobs()))))
            results[f"{version}:{label}"] = checks
    frozen_tests = PROJECT / "experiments/manifests/v1/input/tests"
    tests = unittest.defaultTestLoader.discover(str(frozen_tests))
    answer = unittest.TestResult()
    tests.run(answer)
    actual = {"tests": answer.testsRun, "errors": [str(case) for case, _ in answer.errors],
              "failures": [str(case) for case, _ in answer.failures], "skipped": list(answer.skipped)}
    results["1:legacy/compat"] = [{"observed": actual, "expected": {"tests": 28, "failures": [], "errors": [], "skipped": []}}]
    return results


def unpack(z, ref, target, pack_cache):
    body = read(z, ref)
    key = digest(body)
    if key in pack_cache:
        return pack_cache[key]
    directory = target / key
    directory.mkdir()
    git(directory, "init", "--quiet", "--bare", "--object-format=sha1")
    git(directory, "index-pack", "--strict", "--stdin", data=body)
    git(directory, "fsck", "--full", "--no-dangling", "--no-progress")
    lines = git(directory, "cat-file", "--batch-all-objects", "--batch-check=%(objectname) %(objecttype)").decode().splitlines()
    commits = {line.split()[0] for line in lines if line.endswith(" commit")}
    links = {}
    for oid in commits:
        tree, *parents = git(directory, "show", "--no-patch", "--format=%T %P", oid).decode().split()
        links[oid] = (tree, parents)
    assert links[START] == (START_TREE, [])
    assert all(len(parents) == 1 and parents[0] in links for oid, (_, parents) in links.items() if oid != START)
    tips = commits - {pid for _, parents in links.values() for pid in parents}
    tip, = tips
    assert len(git(directory, "rev-list", tip).splitlines()) == len(commits)
    pack_cache[key] = directory, tip, links
    return pack_cache[key]


def get_reports(z, seed, mapping, journal, target, packs, reports):
    checked = {}
    candidates = {row["payload"]["candidate"] for row in journal if row["kind"] == "oracle"}
    for oid in sorted(candidates):
        ent = mapping[oid]
        repo, tip, links = unpack(z, ent["pack"], target, packs)
        assert tip == oid and ent["start"] == START
        tree, parents = links[oid]
        assert ent["tree"] == tree and ent["parent"] == (parents[0] if parents else None)
        ck = oid, seed
        if ck not in reports:
            with tempfile.TemporaryDirectory() as unpacked:
                root = Path(unpacked)
                payload = git(repo, "archive", "--format=tar", oid)
                with tarfile.open(fileobj=io.BytesIO(payload)) as tar:
                    tar.extractall(root, filter="data")
                output = subprocess.check_output([sys.executable, "-B", "-I", str(CODE), "--queue", str(root), str(seed)])
                data = json.loads(output)
            diff = git(repo, "diff", "--no-renames", "--raw", "-z", START, oid).split(b"\0")[:-1]
            changes, bad = [], []
            for header, path in zip(diff[::2], diff[1::2], strict=True):
                old, new, _, _, status = header.decode().lstrip(":").split()
                change = dict(path=path.decode(), old_mode=old, new_mode=new, status=status)
                changes.append(change)
                if change["path"] not in PERMITTED or old != "100644" or new != old or status != "M":
                    bad.append(change)
            data["1:scope/paths"] = [dict(all_changes=changes, expected=[], observed=bad)]
            reports[ck] = data
        actual = reports[ck]
        grades = {}
        for event in journal:
            if event["kind"] != "oracle" or event["payload"]["candidate"] != oid:
                continue
            claim = event["payload"]
            report = item(z, claim["evidence"])
            assert [report[k] for k in ("candidate", "criterion", "version")] == [oid, claim["criterion"], claim["version"]]
            key = f"{claim['version']}:{claim['criterion']}"
            assert key not in grades and report["cases"] == actual[key], (seed, oid, key)
            grade = "pass" if all(c["observed"] == c["expected"] for c in actual[key]) else "fail"
            assert claim["verdict"] == claim["observed"] == report["verdict"] == grade
            grades[key] = grade
        assert set(grades) == set(actual) and len(grades) == 8
        checked[oid] = grades
    return checked


def chronology(z, raw, plat, journal, checked, target, packs, entries):
    pause = plat["checkpoint_measurement"]
    early = item(z, pause["submission_source"])
    first_refs = early["plan_versions"]
    assert early["plan"] == item(z, first_refs[-1]) and first_refs[-1] == pause["checkpoint"]["view"]
    points = {}
    def remember(ref):
        rows = item(z, ref)
        stamp = rows["W-notify"]["_e2_plan_version"]
        pair = ref["sha256"], rows
        assert points.setdefault(stamp["number"], pair) == pair
    for ref in first_refs:
        remember(ref)
    for row in journal:
        for field in CHECKPOINT_FIELDS:
            point = row["payload"].get(field)
            if point:
                assert point["plan_sha256"] == point["view"]["sha256"]
                remember(point["view"])
    assert sorted(points) == list(range(1, 15))
    assert points[1][1]["W-notify"]["_e2_plan_version"]["previous"] is None
    for i in range(2, 15):
        assert points[i][1]["W-notify"]["_e2_plan_version"]["previous"] == points[i-1][0]
    assert all(points[i][1]["W2"].get("premise") is None and
               points[i][1]["W2"]["retry_choice"] == "linear" for i in range(2, 8))
    actions = {r["payload"]["attempt"]: r["payload"] for r in journal if r["kind"] == "action"}
    assert list(actions) == list(range(1, 31))
    for number, p in actions.items():
        assert p["work_request"] == p["work_started"] and p["parent_attempt"] is None
        for name in ("candidate", "input", "actor", "subject", "action"):
            assert p["work_request"][name] == p[name]
        assert p["action_id"] == f"action-{number}" and p["arm"] == "loop"
        if "response_evidence" in p:
            assert item(z, p["response_evidence"]) == {k:p[k] for k in ("attempt", "actor", "subject", "candidate", "return")}
        if "delivery" in p:
            receipt = p["delivery"]
            packet = item(z, receipt["payload"])
            assert receipt["attempt"] == number and receipt["subject"] == p["subject"] and receipt["state"] == "received"
            assert p["issued_monotonic_ns"] <= receipt["observed_monotonic_ns"] <= p["finished_monotonic_ns"]
            assert receipt["sha256"] == p["prepared_context"]["sha256"] == digest(encoded(packet))
            row = item(z, p["context_source"]["view"])[p["subject"]]
            assert packet == {k:v for k,v in row.items() if k not in ("_publication","_e2_plan_version")}
    before, after = points[7], points[8]
    w2 = before[1]["W2"]["candidate"]
    assert before[0] == pause["checkpoint"]["plan_sha256"] and w2 == pause["candidate"]
    submissions = []
    for i in range(2, 15):
        head, rows = points[i]
        for work, fields in rows.items():
            marker = fields.get("_publication")
            if not marker or marker == points[i-1][1][work].get("_publication") or marker["actor"] != "executor":
                continue
            idx = marker["attempt"]
            action = actions[idx]
            assert action["port_method"] == action["work_request"]["method"] == "submit"
            assert action["actor"] == marker["actor"] and action["subject"] == marker["subject"] == work
            assert action["candidate"] == action["port_input"]["candidate"] == marker["candidate"] == fields["candidate"]
            assert fields["state"] == "submitted" and action["port_after"]["plan_sha256"] == head
            assert action["port_before"]["plan_sha256"] == points[i-1][0]
            submissions.append(dict(version=i, head=head, attempt=idx, work=work, candidate=fields["candidate"]))
    assert [s["attempt"] for s in submissions] == [5, 11, 17, 23, 28]
    assert pause["submission_attempt"] == 17 and submissions[2]["candidate"] == w2
    checks = {}
    for check in pause["checks"]:
        protected = item(z, check["evidence"])
        label, oid = check["criterion"], check["candidate"]
        rows = [e["payload"] for e in journal if e["kind"] == "oracle" and (e["payload"]["candidate"],e["payload"]["criterion"],e["payload"]["version"]) == (oid,label,1)]
        singleton, = rows
        assert check["evidence"] == singleton["evidence"] and checked[oid]["1:"+label] == protected["verdict"] == "pass"
        checks[oid, label] = True
    assert len(checks) == 5
    for work, label, path in (("W1", "W1/preferences", "notify/preferences.py"), ("W3", "W3/delivery", "notify/delivery.py")):
        orig = before[1][work]["candidate"]
        assert before[1][work]["state"] == "closed" and (orig, label) in checks and (w2,label) in checks
        repo = unpack(z, entries[w2]["pack"], target, packs)[0]
        old = git(repo, "ls-tree", orig, "--", path)
        assert old and old == git(repo, "ls-tree", w2, "--", path)
    assert (w2,"W2/retry") in checks and before[1]["W2"]["state"] == "submitted"
    fault, = [r["payload"] for r in journal if r["kind"] == "fault"]
    assert fault["seed"] == 2001 and fault["subject"] == "W2" and fault["actor"] == "fixture_observer"
    assert fault["released"]["retry_schedule"] == "exponential"
    assert fault["before"] == fault["required_before"] == pause["checkpoint"]
    assert fault["attempt"] == fault["observation_id"] == after[1]["W2"]["_publication"]["attempt"] == "Obs-A1-changed"
    assert after[1]["W2"]["_publication"]["actor"] == "fixture_observer"
    assert fault["released_sha256"] == digest(encoded(after[1]["W2"]["premise"]))
    assert after[0] == fault["after"]["plan_sha256"] and after[1]["W2"]["premise"] == fault["released"]
    assert points[7][1]["W2"]["premise"] is None
    left, right = pause["start_monotonic_ns"], pause["end_monotonic_ns"]
    assert all(actions[i]["finished_monotonic_ns"] <= left for i in range(1,18))
    assert left < right <= fault["issued_monotonic_ns"] <= fault["finished_monotonic_ns"]
    assert all(actions[i]["issued_monotonic_ns"] >= fault["finished_monotonic_ns"] for i in range(18,31))
    assert [i for i in actions if "finished_monotonic_ns" not in actions[i]] == [30]
    for idx in range(1,18):
        assert b"exponential" not in encoded([actions[idx]["input"],actions[idx].get("port_input"),actions[idx].get("return")])
    assert all(actions[i]["action"] in ("plan","context","edit","check","submit","observe","decide")
               and actions[i]["subject"] in ("W-notify","W1","W2","W3") for i in range(18,31))
    assert all(rows[s]["state"] == "closed" for i,(_,rows) in points.items() if i>=8 for s in ("W1","W3"))
    endpoints = []
    for i in range(8,15):
        for subject in ("W2","W-notify"):
            row = points[i][1][subject]
            prev = points[i-1][1][subject]
            if row["state"] == "closed" and prev["state"] != "closed":
                assert row["candidate"] == submissions[-1]["candidate"]
                assert checked[row["candidate"]]["2:W2/retry"] == "pass"
                endpoints.append(dict(version=i,subject=subject,head=points[i][0],candidate=row["candidate"]))
    assert [r["version"] for r in endpoints] == [12,14]
    elapsed = plat["end_monotonic_ns"]-plat["start_monotonic_ns"]-(right-left)
    assert elapsed == raw["cost"]["elapsed_ns"] == 3357076250 and plat["cost_basis"] == "observed_lower_bound"
    assert raw["terminal"] == "harness_failure" and raw["validity"] == "infrastructure_invalid" and raw["score"] is None
    assert not any(plat.get(k) for k in ("final_public","participant_exit","clock_stopped","exit_candidate","treatment_trace"))
    return dict(prefix_versions=len(first_refs), ordered_plan_versions=len(points), pause_checks=len(checks),
                native_public_submissions=submissions, closed_after_premise=endpoints,
                stale_closure_at_delivery=False, witnessed_reopenings=0, prior_changed_exposure=False,
                checkpoint_qualified=True, registered_intervention_reached=True,
                latest_witnessed_submission=submissions[-1], latest_revised_criteria_all_pass=True,
                rework_lower_bound=13, action_lower_bound=30, scoring_pause_ns=right-left,
                lower_bound_active_ns=elapsed, exact_rework=None, exact_steps=None, final_pass=None,
                complete_history=None, exact_reopenings=None, continuous_retention=None, invalid_closure_ever=None,
                final_candidate=None, participant_exit=None)


def main():
    if len(sys.argv) == 4 and sys.argv[1] == "--queue":
        return observed_queue(Path(sys.argv[2]), int(sys.argv[3]))
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--disputes", type=Path, default=DISPUTES)
    parser.add_argument("--inputs", type=Path, default=INPUTS)
    args = parser.parse_args()
    selected = {"late-parent":args.inputs/"late-parent-trial.zip",
                "added-readable":args.inputs/"conflicting-seal.zip","added-mismatched-length":args.inputs/"damaged-seal.zip",
                "omitted-start":args.disputes/"partial_no_start/raw.zip","omitted-final":args.disputes/"partial_no_final/raw.zip"}
    result = {}
    packs, measurements = {}, {}
    with tempfile.TemporaryDirectory() as store:
        for key, path in selected.items():
            dest = result[key] = {"raw_sha256": digest(path.read_bytes()), "cases": {}}
            with zipfile.ZipFile(path) as z:
                for name in [n for n in z.namelist() if n.startswith("runs/")]:
                    raw = json.loads(z.read(name))
                    arts = raw["artifacts"]
                    seed = raw["seed"]
                    platform, journal, entries = [item(z, arts[k]) for k in ("platform","journal","candidates")]
                    assert all(i==r["seq"] for i,r in enumerate(journal,1))
                    checked = get_reports(z, seed, entries, journal, Path(store), packs, measurements)
                    case_packs = [unpack(z, p, Path(store), packs)[1] for p in platform["referenced_files"] if p["path"].endswith(".pack")]
                    assert set(entries) == set(checked) == set(case_packs) and len(case_packs) == 5
                    defects, valid_seals = [], set()
                    for claim in platform["case_git_packs"]:
                        ref, oid = claim["pack"], claim["candidate"]
                        disk = z.read(ref["path"])
                        if len(disk) != ref["bytes"] or digest(disk) != ref["sha256"]:
                            defects.append(dict(kind="seal_reference_disagrees_with_original", oid=oid,
                                                declared_bytes=ref["bytes"], actual_bytes=len(disk)))
                            continue
                        tip = unpack(z, ref, Path(store), packs)[1]
                        if tip != oid:
                            defects.append(dict(kind="seal_names_different_tip", oid=oid, original_tip=tip))
                            continue
                        valid_seals.add(tip)
                    missing = sorted(set(entries)-valid_seals)
                    result[key]["cases"][seed] = {"candidate_oids": sorted(entries), "protected_observations": 8*len(checked),
                                                   "original_grades": checked, "seal_discrepancies": defects, "omitted_seals": missing}
                    if key == "late-parent":
                        dest["chronology"] = chronology(z, raw, platform, journal, checked, Path(store), packs, entries)
            if key != "late-parent":
                a,b = dest["cases"][2001], dest["cases"][2002]
                assert not b["seal_discrepancies"] and not b["omitted_seals"]
                if key.startswith("added"):
                    collision, = a["seal_discrepancies"]
                    assert collision["oid"] in b["candidate_oids"] and collision["oid"] not in a["candidate_oids"]
                    assert not a["omitted_seals"]
                else:
                    omitted, = a["omitted_seals"]
                    assert (omitted == START) == (key == "omitted-start")
                    assert not a["seal_discrepancies"]
    return result


if __name__ == "__main__":
    print(json.dumps(main(), indent=2, sort_keys=True))
