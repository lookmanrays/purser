"""Recompute pinned kernel batches in a disposable DB and compare each surviving original public head."""
import hashlib
import io
import json
import sqlite3
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path

PROJECT = Path("/Users/lookman/.codex/worktrees/purser-delivery/m3-case-history")
sys.path.insert(0, str(PROJECT))
from purser.kernel.artifacts import Artifacts
from purser.kernel.gate import admit
from purser.kernel.store import Store
from purser.kernel.wire import canonical, digest
from purser.kernel.workview import WorkView

PACKET = Path("/Users/lookman/Projects/purser/docs/evidence/M3/review-82e8807/two-late-parent-cuts.zip")
EXPECTED = "3555caed4d9f888776ef8f6cdb97ddd0e15997279699829ed38d87ef656a306d"
WORK = {"W1","W2","W3","W-notify"}


def obj(z, ref):
    raw = z.read(ref["path"])
    assert len(raw) == ref["bytes"] and hashlib.sha256(raw).hexdigest() == ref["sha256"]
    return raw


def item(z, ref):
    return json.loads(obj(z, ref))


def rows(snapshot):
    return {r["work"]:r for r in WorkView(snapshot["projection"]).answers()["q02"] if r["work"] in WORK}


def rebuild_prefix(directory, source):
    store=Store(directory/"ledger.sqlite3")
    store.initialize()
    with sqlite3.connect(store.path) as db:
        db.executemany("INSERT INTO events(revision,body) VALUES (?,?)",[(i,row.encode()) for i,row in enumerate(source["original_events"],1)])
    store.replay()
    assert store.snapshot() == source["snapshot"]
    return store


def verify(z, negative=False):
    raw=json.loads(z.read("runs/primary/2001/purser.json"))
    art=raw["artifacts"]
    plat, journal = item(z, art["platform"]),item(z,art["journal"])
    pause=plat["checkpoint_measurement"]
    source=item(z, pause["submission_source"])
    defs={item(z, ref)["criterion"]:obj(z, ref) for ref in plat["definition_artifacts"]}
    env=obj(z,plat["environment_artifact"])
    with tempfile.TemporaryDirectory() as tmp:
        store=rebuild_prefix(Path(tmp),source)
        artifacts=Artifacts(store.path)
        for value in [*defs.values(), env]:
            artifacts.put(value)
        for row in journal[:pause["preceding_events"]]:
            p=row["payload"]
            if p.get("port_method") == "observe":
                raw_observation = canonical(p["port_input"]["observation"])
                assert raw_observation == obj(z,p["return"]["witness"])
                artifacts.put(raw_observation)
        verified=[]
        for row in journal[pause["preceding_events"]:]:
            event=row["payload"]
            if row["kind"] not in ("action","fault") or not event.get("proposal"):
                continue
            req=event["proposal"]
            actor,body=req["actor_id"],req["body"]
            assert body["proposal_id"]==req["proposal_id"]
            assert req["digest"]==digest("proposal", {"actor_id":actor,"proposal":body})
            assert event.get("requests",[req]) == [req]
            snap=store.snapshot()
            before=event.get("port_before",event.get("before"))
            assert (snap["revision"],snap["head_hash"]) == (before["revision"],before["head_hash"]) and rows(snap)==item(z,before["view"])
            op,=body["ops"]
            role=actor.partition(":")[0]
            binding={"role":role,"actor_id":actor,"principal_id":"principal:local","commitment":"C-notify","assignment":None}
            if op["op"]=="assumption.observe":
                assert row["kind"]=="fault" and before==event["required_before"]==pause["checkpoint"]
                assert hashlib.sha256(canonical(event["released"])).hexdigest()==event["released_sha256"]
                binding.update(assignment=op["assumption"],premise={"artifact":canonical(dict(event["released"],seed=2099) if negative else event["released"])})
            elif op["op"]=="result.submit":
                binding["assignment"]=op["assignment"]
            elif op["op"] in ("evidence.record","observation.record"):
                binding["assignment"]=op["run"]
                if op["op"]=="observation.record":
                    observed=event["port_input"]["observation"]
                    oid={"kind":"git.commit","algorithm":"sha1","digest":event["candidate"]}
                    binding["witness"]={"candidate":oid,"definition":defs[event["port_input"]["criterion"]],
                                        "environment":env,"artifact":canonical(observed)}
            reply=admit(store,binding,body,clock=lambda:datetime(2026,1,1,tzinfo=timezone.utc))
            assert reply["disposition"]=="admitted"
            if row["kind"]=="fault":
                recorded=event["return"]
            else:
                recorded=event["port_return"]
                if "receipt" in recorded:
                    recorded=recorded["receipt"]
            assert recorded==reply, (op,recorded,reply)
            if "response_evidence" in event:
                assert item(z,event["response_evidence"]) == {k:event[k] for k in ("attempt","actor","subject","candidate","return")}
            after=event.get("port_after",event.get("after"))
            snap=store.snapshot()
            same_view=rows(snap)==item(z,after["view"])
            same_head=(snap["revision"],snap["head_hash"])==(after["revision"],after["head_hash"])
            if negative:
                assert row["kind"]=="fault" and same_view and not same_head
                return dict(receipt_equal=True,projected_public_rows_equal=same_view,after_revision=snap["revision"],
                            recorded_head=after["head_hash"],counterfactual_head=snap["head_hash"])
            assert same_view and same_head, (op,snap["head_hash"],after)
            verified.append(dict(attempt=event["attempt"],operation=op["op"],proposal=body["proposal_id"],
                                 from_revision=before["revision"],through_revision=after["revision"],post_head=after["head_hash"]))
        assert len(verified)==19 and snap["revision"]==94
        assert rows(snap)["W-notify"]["state"]=="closed" and plat.get("final_public") is None and plat.get("participant_exit") is None
        with sqlite3.connect(store.path) as db:
            suffix=[json.loads(body)for body, in db.execute("SELECT body FROM events WHERE revision>56 ORDER BY revision")]
        assert len(suffix)==38
        return {"original_prefix_revision":source["snapshot"]["revision"], "matched_suffix_batches":verified,
                "matched_suffix_events":len(suffix), "last_witnessed_rows":rows(snap),
                "premise_event":next(e for e in suffix if e["type"]=="PremiseObserved"),
                "last_witnessed_submission":next(v for v in reversed(verified) if v["operation"]=="result.submit")}


def equal(z):
    raw=json.loads(z.read("runs/primary/2001/loop_equal_verifier.json"))
    art=raw["artifacts"];plat=item(z,art["platform"]); journal=item(z,art["journal"])
    pause=plat["checkpoint_measurement"]; source=item(z,pause["submission_source"])
    versions={}
    def add(ref):
        rows=item(z,ref);stamp=rows["W-notify"]["_e2_plan_version"];v=stamp["number"]
        assert versions.setdefault(v,(ref["sha256"],rows))==(ref["sha256"],rows)
    for ref in source["plan_versions"]:
        add(ref)
    for row in journal:
        for name in ("checkpoint","before","after","port_after","port_before","required_before","context_source"):
            ck=row["payload"].get(name)
            if ck:
                assert ck["plan_sha256"]==ck["view"]["sha256"]
                add(ck["view"])
    assert len(versions)==20
    for i,(head,rows) in sorted(versions.items()):
        assert rows["W-notify"]["_e2_plan_version"]["previous"]==(versions[i-1][0] if i>1 else None)
    latest=versions[16];assert latest[1]["W-notify"]["_publication"]["attempt"]==37
    assert latest[1]["W-notify"]["state"]=="submitted" and versions[20][1]["W-notify"]["state"]=="closed"
    assert versions[20][1]["W-notify"]["_publication"]["attempt"]==48
    return {"original_prefix_length":len(source["plan_versions"]), "linked_versions":len(versions),
            "latest_submission": {"version":16,"head":latest[0],"candidate":latest[1]["W-notify"]["candidate"],"attempt":37}}


if __name__=="__main__":
    assert hashlib.sha256(PACKET.read_bytes()).hexdigest()==EXPECTED
    with zipfile.ZipFile(PACKET) as packet:
        def archive(name):
            return zipfile.ZipFile(io.BytesIO(packet.read(f"repo/private-{name}/raw.zip")))
        with archive("purser") as z:
            result={"purser":verify(z),"changed_premise_body_only":verify(z,negative=True)}
        with archive("loop_equal_verifier")as z:
            result["equal"]=equal(z)
    print(json.dumps(result,sort_keys=True,indent=2))
