# Scripted E2 results

Twenty matched primary ranks were registered. Count columns show the total and the number of seeds with an observed value. Missing binary outcomes can range from zero to one. Thresholds use those bounds. A question mark marks an unavailable measurement.

| Arm | Complete | Incomplete | Invalid or missing | Checkpoint reached | Both retained | Invalid affected closure | Rework steps / measured | Final pass | Total steps / measured |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| loop | 0 | 0 | 20 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 |
| purser | 0 | 0 | 20 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 |
| loop_equal_verifier | 0 | 0 | 20 | 1/1 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 |

## Frozen thresholds

Each comparison uses the original rules. The half-cost test compares summed rework across all 20 ranks. The no-advantage predicate is true when Purser rework is equal or greater, or its final pass count is lower.

| Purser compared with | Both retained ≥18 | 2 × Purser rework ≤ comparator | Final passes ≥ comparator | E2 passes | No advantage | Rework ratio |
| --- | --- | --- | --- | --- | --- | ---: |
| loop | inconclusive | inconclusive | inconclusive | inconclusive | inconclusive | inconclusive |
| loop_equal_verifier | inconclusive | inconclusive | inconclusive | inconclusive | inconclusive | inconclusive |

## Paired primary results

Each signed difference is Purser minus its comparator. Columns within each cell give retention, bad affected closure, rework steps, final pass, total steps and elapsed seconds. Zero is a tie.

| Seed | Purser − plain loop | Purser − equal verifier |
| ---: | --- | --- |
| 2001 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2002 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2003 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2004 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2005 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2006 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2007 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2008 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2009 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2010 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2011 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2012 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2013 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2014 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2015 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2016 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2017 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2018 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2019 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |
| 2020 | ? / ? / ? / ? / ? / ? | ? / ? / ? / ? / ? / ? |

## Primary coverage · loop

| Seed | Validity / exit | Reached | Both retained | Reopen transitions | Invalid affected closure | Rework | Final pass | Steps | Elapsed s |
| ---: | --- | --- | --- | ---: | --- | ---: | --- | ---: | ---: |
| 2001 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2002 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2003 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2004 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2005 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2006 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2007 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2008 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2009 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2010 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2011 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2012 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2013 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2014 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2015 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2016 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2017 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2018 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2019 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2020 | missing | ? | ? | ? | ? | ? | ? | ? | ? |

## Primary coverage · purser

| Seed | Validity / exit | Reached | Both retained | Reopen transitions | Invalid affected closure | Rework | Final pass | Steps | Elapsed s |
| ---: | --- | --- | --- | ---: | --- | ---: | --- | ---: | ---: |
| 2001 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2002 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2003 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2004 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2005 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2006 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2007 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2008 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2009 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2010 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2011 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2012 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2013 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2014 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2015 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2016 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2017 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2018 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2019 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2020 | missing | ? | ? | ? | ? | ? | ? | ? | ? |

## Primary coverage · loop_equal_verifier

| Seed | Validity / exit | Reached | Both retained | Reopen transitions | Invalid affected closure | Rework | Final pass | Steps | Elapsed s |
| ---: | --- | --- | --- | ---: | --- | ---: | --- | ---: | ---: |
| 2001 | infrastructure_invalid / harness_failure | yes | ? | ? | ? | ≥25 (total ?) | ? | 48 observed (total ?) | ≥2.037 |
| 2002 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2003 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2004 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2005 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2006 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2007 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2008 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2009 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2010 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2011 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2012 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2013 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2014 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2015 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2016 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2017 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2018 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2019 | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| 2020 | missing | ? | ? | ? | ? | ? | ? | ? | ? |

## Clean control · A1 retained

| Arm | Exit | Clean exposure | Final pass | Steps | Elapsed s |
| --- | --- | --- | --- | ---: | ---: |
| loop | missing | ? | ? | ? | ? |
| purser | missing | ? | ? | ? | ? |
| loop_equal_verifier | missing | ? | ? | ? | ? |

The twice-baseline clean overhead flag is **?**.

## Already-closed affected stress control

At delivery the affected W2 was already closed under the old schedule. The two bad-closure columns distinguish a stale closure still visible at delivery from a new bad closure asserted later.

| Arm | Exit | Old W2 candidate at delivery | Both siblings retained | Stale at delivery | New bad closure | Rework | Final pass | Steps | Elapsed s |
| --- | --- | --- | --- | --- | --- | ---: | --- | ---: | ---: |
| loop | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| purser | missing | ? | ? | ? | ? | ? | ? | ? | ? |
| loop_equal_verifier | missing | ? | ? | ? | ? | ? | ? | ? | ? |

## Observed sibling reopenings

An incomplete history gives a lower bound on the number of transitions.

| Case | Transitions observed | Distinct siblings observed reopening | Exact eligible total |
| --- | ---: | --- | ---: |
| primary / 2001 / loop_equal_verifier | 0 | — | ? |

## Public reopening and closure evidence

Each reopening identifies the previously closed candidate. Each closure grades revised retry on the candidate declared by that subject.

| Case | Plan digest or kernel revision / hash | Public action | Subject | Public observation | Git candidate | Revised retry passes |
| --- | --- | --- | --- | --- | --- | --- |
| primary / 2001 / loop_equal_verifier | `627bacd82e71860a7f1887613cdc0a1b4f422db5da5dbb8e2331a8193d5ec978` | 34 | W2 | closed | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | yes |
| primary / 2001 / loop_equal_verifier | `0409f2998df8906c4cf91448385b04a5366f3831f698863762a88b70862865a9` | 48 | W-notify | closed | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | yes |

## Unavailable or disputed observations

- primary / 2001 / loop_equal_verifier — original participant trace unavailable · final public checkpoint lacks an identical original participant head
  Observed facts — old W2 submission yes, old checkpoint qualified yes, premise delivered yes, prior changed exposure no, scoring interval quiescent yes, scoring exclusion accounted yes, witnessed participant exit no, clean exposure no, both siblings continuously retained ?, invalid affected closure ?, stale closure at receipt no, new invalid affected closure ?, final Git criteria pass ?.
  From delivery through `0409f2998df8906c4cf91448385b04a5366f3831f698863762a88b70862865a9`, both retained yes, reopenings 0, invalid affected closure no.
  Last measured candidate `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` (last_witnessed_public_submission, W-notify submission 37, publication a3a30d4f1960517d6aa5cfd7671096fba16b254811732a3e809dbb2adfecc976), registered criteria pass yes. W1/preferences pass, W2/retry pass, W3/delivery pass, scope/paths pass, legacy/compat pass, queue/composition pass.

## Protected Git observations

| Case | Candidate | Criterion | Version | Retained verdict | Available grade | Grade source | Original journal row | Independent replay |
| --- | --- | --- | ---: | --- | --- | --- | --- | --- |
| primary / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W1/preferences | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `55686bd5152e10a53dfdc2c003974ea405a3a075` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W1/preferences | 1 | pass | pass | case_stage | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W3/delivery | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `6dcb12a91c06f00fc75c5e68b6145a727f3749a7` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W1/preferences | 1 | pass | pass | case_stage | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 1 | pass | pass | case_stage | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W3/delivery | 1 | pass | pass | case_stage | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `7df4a199e2ada1caafe78f5acec2f99b06f44771` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W3/delivery | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | W2/retry | 2 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `a5cd7dfec079a2b38d8b673c47d736ce3161f22a` | queue/composition | 2 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W1/preferences | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W3/delivery | 1 | pass | pass | case_stage | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | scope/paths | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | legacy/compat | 1 | pass | pass | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 1 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | W2/retry | 2 | fail | fail | journal | recorded | unrequested |
| primary / 2001 / loop_equal_verifier | `af70fa43920a23d5e30dd6b4f5502084da6f9e6b` | queue/composition | 2 | fail | fail | journal | recorded | unrequested |

The scripted protocol permits zero model calls, tokens and spend.
