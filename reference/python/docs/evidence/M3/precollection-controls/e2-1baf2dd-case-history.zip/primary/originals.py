"""Recompute the five historical controls with their immutable producer metadata and a named candidate reader."""
import hashlib, io, json, subprocess, sys, tempfile, zipfile
from pathlib import Path

here = Path(__file__).resolve().parent
state = here.parent
work = Path(sys.argv[1]).resolve()
source = '1baf2ddc88e187e1ee33e89c2a08f186f48db17c'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()==source
sys.path.insert(0,str(work))
from experiments.e1.report import Objects, GitPacks
from experiments.e1.artifacts import REGISTRATION
from experiments.e2.report import inspect_case
from experiments.e2.summary import render_summary, value

extra = Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else None
more = extra/'two-late-parent-cuts.zip' if extra else Path('/Users/lookman/Projects/purser/docs/evidence/M3/review-82e8807/two-late-parent-cuts.zip')
def sha(data): return hashlib.sha256(data).hexdigest()
assert sha(more.read_bytes()) == '3555caed4d9f888776ef8f6cdb97ddd0e15997279699829ed38d87ef656a306d'
originals = extra if extra else state/'original-inputs'
scenarios = [('interrupted-loop',originals/'late-parent-trial.zip',None),
             ('interrupted-purser',more,'repo/private-purser/raw.zip'),
             ('interrupted-equal',more,'repo/private-loop_equal_verifier/raw.zip'),
             ('late-identity',originals/'late-action-29.zip' if extra else Path('/private/tmp/purser-m3-review.MbIBfSlC/m3-source-82/disputes/late_action_identity_only/raw.zip'),None),
             ('cutoff',originals/'actual-limit-no-exit-checkout.zip','original/raw.zip')]
schema = json.loads((REGISTRATION/'raw.schema.json').read_bytes())
results={}
for label,path,member in scenarios:
    data = path.read_bytes()
    archive_hash = sha(data)
    if member:
        with zipfile.ZipFile(io.BytesIO(data)) as envelope: data = envelope.read(member)
    result = dict(source_reader=source,archive_sha256=archive_hash,inner_raw_sha256=sha(data),cases={})
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        freeze=json.loads(archive.read('freeze.json')); result['producer']=freeze['source_commit']
        for strict in (False,True):
            lane='reexecute' if strict else 'normal'
            with tempfile.TemporaryDirectory() as temp:
                objects=Objects(archive); packs=GitPacks(Path(temp)); measurements={}; cases={}
                for name in [n for n in archive.namelist() if n.startswith('runs/')]:
                    r=json.loads(archive.read(name));rank=json.loads(archive.read(name.replace('runs/','started/',1)))['rank']
                    case=inspect_case(r,schema,objects,packs,rank,rerun=strict,measurements=measurements,producer_files=freeze['source_files'])
                    cases[r['track'],r['seed'],r['arm']]=case
                    f=case.facts
                    counts=[len(rows) for rows in f['protected_slots'].values()]
                    assert counts == [8]*(4 if label=='cutoff' else 5)
                    if strict:
                        assert all(slot['replay']=='matched' for rows in f['protected_slots'].values() for slot in rows)
                    assert f['checkpoint_qualified'] is f['intervention_reached'] is f['old_submission_observed'] is f['premise_delivered'] is True
                    assert f['prior_changed_exposure'] is False
                    assert not case.issues or label=='late-identity' and r['seed']==2001
                    if label.startswith('interrupted-'):
                        plain=r['arm']=='loop'
                        assert f['physical_exit'] is f['complete_public_history'] is False
                        assert all(f[k] is None for k in ('final_pass','rework_steps','unaffected_reopened','affected_invalid_closure','unaffected_both_retained'))
                        assert f['charged_attempts_observed']==(30 if plain else 48) and f['rework_observed']==(13 if plain else 25)
                        assert f['last_observed_subject']=='W-notify' and f['last_observed_attempt']==(28 if plain else 37)
                        assert f['last_observed_pass'] is True and (f['observed_interval']['both_retained'],f['observed_interval']['reopened'],f['observed_interval']['invalid_closure'])==(True,0,False)
                        assert [(x['subject'],x['source_action'],x['revised_pass']) for x in f['closure_observations']]==[('W2',25 if plain else 34,True),('W-notify',30 if plain else 48,True)]
                        assert not case.comparable_steps and not case.comparable_elapsed
                        if plain: assert f['active_lower_ns']==3357076250
                        if r['arm']=='purser': assert f['kernel_recovery']=={'original_prefix_revision':56,'recovered_through_revision':94}
                    elif label=='cutoff':
                        assert r['terminal']=='harness_failure' and f['work_cutoff'] and f['final_pass'] is None
                        assert [value(case,k) for k in ('steps','rework_steps','elapsed_ns')]==[96,79,2326257916]
                    else:
                        assert case.comparable_steps and case.comparable_elapsed and f['final_pass'] is True
                        assert [value(case,k) for k in ('steps','rework_steps')]==[30,13]
                        if r['seed']==2001:
                            assert len(case.issues)==1 and 'attempt 29 work identity' in case.issues[0]
                            assert value(case,'elapsed_ns')==1986411209
                    selected={k:f.get(k) for k in ('checkpoint_qualified','prior_changed_exposure','intervention_reached','charged_attempts_observed','rework_observed','rework_steps','observed_interval','closure_observations','last_observed_attempt','last_observed_subject','last_observed_publication','last_observed_candidate','last_observed_pass','complete_public_history','physical_exit','work_cutoff','active_lower_ns','final_pass','kernel_recovery')}
                    result['cases'].setdefault(name,{})[lane]={'issues':case.issues,'unavailable':case.unavailable,'protected_slots':sum(counts),'step_comparable':case.comparable_steps,'elapsed_comparable':case.comparable_elapsed,'observed':selected}
                (here/f'{label}-{lane}.md').write_text(render_summary(cases))
                if strict: assert sum(len(v) for v in measurements.values())==(32 if label=='cutoff' else 40)*len(cases)
    results[label]=result
    (here/'historical-originals.json').write_text(json.dumps(results,indent=2,sort_keys=True)+'\n')
    print(label,result['inner_raw_sha256'],flush=True)
