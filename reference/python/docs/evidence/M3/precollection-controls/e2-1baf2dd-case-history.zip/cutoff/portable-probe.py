"""Preserve a real step-limit receipt while withholding the disposable final Git checkout."""
from pathlib import Path
from hashlib import sha256
from unittest.mock import patch
from zipfile import ZipFile
import argparse,json,subprocess,sys

def main():
    p=argparse.ArgumentParser();p.add_argument('repo');p.add_argument('commit');p.add_argument('output',type=Path);p.add_argument('--replicate',type=int,default=325);a=p.parse_args()
    assert a.replicate>1
    d=a.output.resolve();d.mkdir(exist_ok=True);repo=d/'source'
    def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
    subprocess.run(['git','clone','-q','--local','--no-checkout',a.repo,str(repo)],check=True)
    git('checkout','-q','--detach',a.commit)
    assert git('rev-parse','HEAD')==a.commit
    sys.path.insert(0,str(repo))
    from experiments.e2 import suite,trial,policy
    from experiments.e1.run import Cutoff
    folder=repo/'private-physical-cutoff'
    suite.freeze_series(folder,replicate=a.replicate,reason='Private genuine operation limit followed by loss of the disposable final Git checkout')
    git('add','--','private-physical-cutoff/freeze.json');git('-c','user.name=Purser architect','-c','user.email=architect@purser.invalid','commit','-qm','Register private operation-limit evidence control')
    git('bundle','create',str(d/'registration.bundle'),'HEAD','^'+a.commit)
    words={};prev=policy.PlanArm.revise;retain=trial.retain
    def saturate(arm,message):
        prev(arm,message);budget=arm.work_actions.driver.j
        words['at_start']=budget.steps
        for i in range(100):
            try:arm.context('W1')
            except Cutoff as exc:
                words['at_cutoff']=budget.steps;words['reason']=str(exc);raise
        raise ValueError('registered physical cutoff was not reached')
    def withhold(directory,assets,arm,progress,*args,**kwargs):
        if 'real_exit' not in words:
            e=progress['platform']['participant_exit'];assert e['reason']=='step_limit'
            words['real_exit']=e
            (directory/'worker').rename(d/'withheld-exiting-worktree')
        return retain(directory,assets,arm,progress,*args,**kwargs)
    with patch.object(policy.PlanArm,'revise',saturate),patch.object(trial,'retain',withhold):
        suite.collect_units(folder,[('primary',2001,1,'loop')])
    assert words['at_cutoff']==96 and words['real_exit']['reason']=='step_limit'
    rawpath=folder/'raw.zip'
    with ZipFile(rawpath) as z:
        def obj(ref):
            b=z.read(ref['path']);assert sha256(b).hexdigest()==ref['sha256'] and len(b)==ref['bytes'];return json.loads(b)
        row=json.loads(z.read('runs/primary/2001/loop.json'));plat=obj(row['artifacts']['platform']);j=obj(row['artifacts']['journal'])
        fault=next(i for i,r in enumerate(j) if r['kind']=='fault')
        acts=[(i,r['payload']['attempt']) for i,r in enumerate(j) if r['kind']=='action']
        assert [n for i,n in acts]==list(range(1,97))
        assert row['cost']['steps']==96 and not plat.get('exit_candidate')
        words.update(source=a.commit,prereg=git('rev-parse','HEAD'),raw_sha256=sha256(rawpath.read_bytes()).hexdigest(),first_after_fault=sum(1 for i,_ in acts if i<fault)+1,charged_post_fault=sum(1 for i,_ in acts if i>fault),raw_terminal=row['terminal'],raw_score=row['score'],retained_participant_exit=plat.get('participant_exit'),elapsed_ns=row['cost']['elapsed_ns'],cutoff_basis=plat['cost_basis'],final_checkout=plat.get('exit_candidate'),final_public_retained=bool(plat.get('treatment_trace')))
    for k in ('report','verify'):
        x=subprocess.run([sys.executable,'-B','-m','experiments.e2',k,str(folder)],capture_output=True,cwd=repo,timeout=170)
        (d/(k+'.out')).write_bytes(x.stdout);(d/(k+'.err')).write_bytes(x.stderr)
        words[k+'_returncode']=x.returncode
        if k=='report':
            section=x.stdout.decode().split('## Primary coverage · loop\n')[1].split('##')[0];words['native_coverage']=next(s for s in section.splitlines() if s.startswith('| 2001 |'))
        if x.stderr:words[k+'_last_message']=x.stderr.decode(errors='replace').splitlines()[-1]
    (d/'witness.json').write_text(json.dumps(words,sort_keys=True,indent=2)+'\n')
    print(json.dumps(words))
if __name__=='__main__':main()
