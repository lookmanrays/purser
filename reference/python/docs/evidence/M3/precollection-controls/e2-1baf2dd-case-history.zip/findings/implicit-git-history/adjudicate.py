"""Compare the physical Git read and response, original case packs, and independently observed receiver claims."""
from copy import deepcopy
from pathlib import Path
import hashlib,json,subprocess,sys,tempfile,zipfile

work,baseline,changed,output=map(lambda x:Path(x).resolve(),sys.argv[1:])
cid='1baf2ddc88e187e1ee33e89c2a08f186f48db17c'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()==cid
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda v:json.dumps(v,ensure_ascii=False,allow_nan=False,separators=(',',':'),sort_keys=True).encode()
def blob(z,ref):
    data=z.read(ref['path']);assert len(data)==ref['bytes'] and sha(data)==ref['sha256'];return data
def get(z,ref):return json.loads(blob(z,ref))
def raw(z,seed):return json.loads(z.read(f'runs/primary/{seed}/loop.json'))
def action(j,n):return next(e['payload'] for e in j if e['kind']=='action' and e['payload']['attempt']==n)
def ref(data):
    h=sha(data);return {'path':'objects/'+h+'.json','sha256':h,'bytes':len(data)}
def git(d,*args,**kwargs):return subprocess.run(['git','-C',str(d),*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,**kwargs)
output.mkdir(parents=True,exist_ok=True)
for name,f in [('baseline',baseline),('implicit',changed)]:
    d=output/name;d.mkdir();(d/'raw.zip').write_bytes(f.read_bytes())
with zipfile.ZipFile(baseline) as orig,zipfile.ZipFile(changed) as replaced:
    assert orig.read('freeze.json')==replaced.read('freeze.json') and raw(orig,2002)==raw(replaced,2002)
    recipient=raw(orig,2001);altered=raw(replaced,2001)
    j=get(orig,recipient['artifacts']['journal']);modified=get(replaced,altered['artifacts']['journal'])
    original_row=action(j,1);changed_row=action(modified,1);explicit=action(j,2)
    assert original_row['input']=={'tool':'git_history','work':'W-notify'} and original_row['candidate'] is None
    assert changed_row['work_request']==original_row['work_request']==original_row['work_started'] and original_row['work_request']['method']=='inspect'
    returned=get(orig,original_row['response_evidence'])['return']
    assert returned==original_row['return']==get(orig,original_row['delivery']['payload'])==get(replaced,changed_row['response_evidence'])['return']
    fixture,=returned['value']
    assert explicit['candidate']==fixture and explicit['return']==returned
    other=get(replaced,changed_row['delivery']['payload'])
    foreign=other['value'][0]
    assert len(other['value'])>2 and other['value'][-1]==fixture and changed_row['delivery']['sha256']==changed_row['delivery']['payload']['sha256']
    clean_j=deepcopy(modified)
    for k in ('payload','sha256'):action(clean_j,1)['delivery'][k]=original_row['delivery'][k]
    assert clean_j==j
    clean_raw=deepcopy(altered);clean_raw['artifacts']['journal']=recipient['artifacts']['journal'];assert clean_raw==recipient
    physical={}
    with tempfile.TemporaryDirectory() as tmp:
        for seed in (2001,2002):
            p=get(orig,raw(orig,seed)['artifacts']['platform']);db=Path(tmp)/str(seed);db.mkdir()
            git(db,'init','-q','--bare',check=True)
            for pack in p['case_git_packs']:git(db,'index-pack','--stdin',input=blob(orig,pack['pack']),check=True)
            git(db,'fsck','--full','--no-dangling',check=True)
            present=git(db,'cat-file','-e',foreign+'^{commit}').returncode==0
            physical[str(seed)]={'sealed_tips':sorted(s['candidate'] for s in p['case_git_packs']),'has_donor_tip':present}
            if present:assert git(db,'rev-list',foreign,check=True).stdout.decode().splitlines()==other['value']
    assert not physical['2001']['has_donor_tip'] and physical['2002']['has_donor_tip']
    # Matched negative uses exactly the same donor packet, this time on the explicitly pinned query.
    two=deepcopy(j);d=action(two,2)['delivery'];d.update(payload=changed_row['delivery']['payload'],sha256=changed_row['delivery']['sha256'])
    jr=ref(encode(two));r2=deepcopy(recipient);r2['artifacts']['journal']=jr
    new={'runs/primary/2001/loop.json':encode(r2),jr['path']:encode(two),d['payload']['path']:encode(other)}
    d=output/'explicit';d.mkdir()
    with zipfile.ZipFile(d/'raw.zip','x',zipfile.ZIP_DEFLATED) as z:
        for info in orig.infolist():z.writestr(info,new.pop(info.filename,orig.read(info.filename)))
        for n,b in new.items():z.writestr(n,b)
sys.path.insert(0,str(work))
from experiments.e2.report import inspect_series
results={}
for label,want in [('baseline',80),('implicit',88),('explicit',80)]:
    d=output/label
    cases, stats=inspect_series(d,rerun=True)
    assert stats['reexecuted_seed_candidate_criteria']==want
    detail={}
    for seed in (2001,2002):
        c=cases['primary',seed,'loop'];slots=c.facts['protected_slots']
        detail[str(seed)]={'slots':sum(len(x) for x in slots.values()),'donor_rows':[{k:s[k] for k in ('criterion','version','verdict','replay','original')} for s in slots.get(foreign,[])],'issues':c.issues}
    assert detail['2002']['slots']==40 and detail['2001']['slots']==(48 if label=='implicit' else 40)
    assert (len(detail['2001']['donor_rows'])==8)==(label=='implicit')
    commands={}
    for command in ('report','verify'):
        p=subprocess.run([sys.executable,'-B','-m','experiments.e2',command,str(d)],cwd=work,capture_output=True)
        (d/(command+'.out')).write_bytes(p.stdout);(d/(command+'.err')).write_bytes(p.stderr)
        assert p.returncode==(1 if command=='verify' and label!='baseline' else 0)
        commands[command]={'exit':p.returncode,'stdout_sha256':sha(p.stdout),'last_stderr':p.stderr.decode().splitlines()[-1][:320] if p.stderr else None}
    results[label]={'raw_sha256':sha((d/'raw.zip').read_bytes()),'measured':want,'cases':detail,'native':commands}
report={'source':cid,'validated_return':returned,'original_response_digest':original_row['response_evidence']['sha256'],'damaged_receiver':other,'actual_git':physical,'results':results}
(output/'independent.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(foreign,fixture,[(k,v['measured'],v['cases']['2001']['slots'],v['cases']['2002']['slots']) for k,v in results.items()])
