"""Reconstruct the missing plan object from the remaining physical case records before opening its withheld copy."""
from pathlib import Path
from copy import deepcopy
import argparse,hashlib,json,subprocess,sys,zipfile
p=argparse.ArgumentParser(); p.add_argument('repo',type=Path);p.add_argument('original',type=Path);p.add_argument('output',type=Path);p.add_argument('--damaged',type=Path);a=p.parse_args()
cid='1baf2ddc88e187e1ee33e89c2a08f186f48db17c'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=a.repo,text=True).strip()==cid
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,allow_nan=False,separators=(',',':')).encode()
def read(z,ref):
    data=z.read(ref['path'])
    assert (len(data),sha(data))==(ref['bytes'],ref['sha256'])
    return json.loads(data)
def run(z):
    name,=[n for n in z.namelist() if n.startswith('runs/')]
    raw=json.loads(z.read(name))
    return raw,read(z,raw['artifacts']['journal'])
def write_derived(src,dest,missing,addition=None):
    with zipfile.ZipFile(src) as old, zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED) as new:
        for info in old.infolist():
            if info.filename!=missing: new.writestr(info,old.read(info.filename))
        if addition is not None: new.writestr(missing,addition)
root=a.output;root.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(a.original) as a0:
    trial,j=run(a0); plain=trial['arm']=='loop'
    version,assign,ctx,w2,parent,total=((10,19,20,23,28,30) if plain else (12,25,26,29,37,48))
    action={e['payload']['attempt']:e['payload'] for e in j if e['kind']=='action'}
    missing=action[assign]['port_after']['view']['path']
base,damaged,restored=(root/name for name in ('baseline','missing','restored'))
for d in (base,damaged,restored):d.mkdir()
(base/'raw.zip').write_bytes(a.original.read_bytes())
if a.damaged: (damaged/'raw.zip').write_bytes(a.damaged.read_bytes())
else: write_derived(a.original,damaged/'raw.zip',missing)
with zipfile.ZipFile(damaged/'raw.zip') as z:
    assert missing not in z.namelist()
    raw,j=run(z);a0={e['payload']['attempt']:e['payload'] for e in j if e['kind']=='action'}
    assignment,context,submit=a0[assign],a0[ctx],a0[parent]
    assert assignment['work_request']==assignment['work_started'] and assignment['work_request']['method']=='assign_again'
    assert assignment['subject']==assignment['input']['assign']==assignment['port_input']['assign']=='W2'
    assert assignment['actor']=='planner' and assignment['port_return']==assignment['return']=={'state':'open'}
    checkpoint=assignment['port_before']; prior=read(z,checkpoint['view'])
    assert sha(encode(prior))==checkpoint['plan_sha256']
    assert prior['W-notify']['_e2_plan_version']['number']==version-1
    expected=deepcopy(prior); row=expected['W2']
    row.update(state='open',candidate=None,verified={})
    row['_publication']={'attempt':assign,'actor':'planner','subject':'W2','candidate':None,'diagnosis':[]}
    expected['W-notify']['_e2_plan_version']={'number':version,'previous':checkpoint['plan_sha256'],'attempt':assign}
    data=encode(expected); reconstructed=sha(data)
    packet=read(z,context['delivery']['payload'])
    assert context['delivery']['state']=='received' and context['delivery']['subject']=='W2'
    assert packet==read(z,context['prepared_context'])==context['return']
    assert {k:v for k,v in expected['W2'].items() if k!='_publication'}==packet
    v11=read(z,a0[w2]['port_after']['view'])
    hashes={'original_assigned_post_head':assignment['port_after']['plan_sha256'],'received_context_source':context['context_source']['plan_sha256'],'next_head_previous':v11['W-notify']['_e2_plan_version']['previous']}
    assert set(hashes.values())=={reconstructed} and missing=='objects/'+reconstructed+'.json'
    earlier=read(z,submit['port_before']['view']);later=read(z,submit['port_after']['view']); stamp=later['W-notify']['_e2_plan_version']
    assert earlier['W-notify']['_e2_plan_version']['number']==(12 if plain else 15) and stamp=={'number':(13 if plain else 16),'previous':sha(encode(earlier)),'attempt':parent}
    assert submit['port_method']=='submit' and submit['subject']=='W-notify' and submit['port_return']==submit['return']=={'state':'submitted'}
    assert later['W-notify']['candidate']==submit['candidate']==submit['port_input']['candidate'] and later['W-notify']['_publication']['attempt']==parent
    assert set(a0)==set(range(1,total+1)) and all(a0[i]['finished_monotonic_ns']<a0[i+1]['issued_monotonic_ns'] for i in range(1,total))
    asserting={'hash':reconstructed,'length':len(data),'anchors':hashes,'received_w2_packet':sha(encode(packet)),'parent_before':sha(encode(earlier)),'parent_after':sha(encode(later)),'parent_submission':{'attempt':parent,'candidate':submit['candidate'],'previous_all_physical_calls_completed':True}}
with zipfile.ZipFile(a.original) as z, zipfile.ZipFile(damaged/'raw.zip') as other:
    assert set(z.namelist())-set(other.namelist())=={missing} and not set(other.namelist())-set(z.namelist())
    assert all(z.read(n)==other.read(n) for n in other.namelist())
    assert z.read(missing)==data
write_derived(damaged/'raw.zip',restored/'raw.zip',missing,data)
sys.path.insert(0,str(a.repo.resolve()))
from experiments.e2.report import inspect_series
results={}
for directory in (base,damaged,restored):
    case=next(iter(inspect_series(directory)[0].values()))
    facts=case.facts
    outcomes={}
    for command in ('report','verify'):
        p=subprocess.run([sys.executable,'-B','-m','experiments.e2',command,str(directory)],cwd=a.repo,capture_output=True)
        (directory/(command+'.out')).write_bytes(p.stdout);(directory/(command+'.err')).write_bytes(p.stderr)
        outcomes[command]={'exit':p.returncode,'stdout_sha256':sha(p.stdout),'stderr':p.stderr.decode()[-190:]}
    results[directory.name]={'source':cid,'raw_sha256':sha((directory/'raw.zip').read_bytes()),'issues':case.issues,'unavailable':case.unavailable,
        'facts':{k:facts.get(k) for k in ('intervention_reached','last_observed_candidate','last_observed_subject','last_observed_attempt','last_observed_publication','last_observed_pass','rework_observed','charged_attempts_observed','final_pass','complete_public_history','observed_interval','closure_observations')},'native':outcomes}
assert results['missing']['facts']['last_observed_candidate'] is None and results['missing']['native']['report']['exit']==0
for label in ('baseline','restored'):
    assert results[label]['facts']['last_observed_attempt']==parent and results[label]['facts']['last_observed_pass'] is True
    assert results[label]['native']['verify']['exit']==0
assert results['baseline']['facts']==results['restored']['facts']
result={'candidate':cid,'reconstruction':asserting,'cases':results}
(root/'independent.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(reconstructed,[(k,v['native']['verify']['exit'],v['facts']['last_observed_attempt'],v['facts']['observed_interval']['through']) for k,v in results.items()])
