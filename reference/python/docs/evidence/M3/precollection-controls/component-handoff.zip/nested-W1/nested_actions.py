"""Independent compound-participant W1 control with refusal and intermediate durable states."""
from copy import copy
import json
from pathlib import Path
import sys
import tempfile
import zipfile

def run(source,target,arm,rep):
    from experiments.e1.artifacts import Artifacts,extract_tree
    from experiments.e1.recovery import FileArchive
    from experiments.e1.suite import publish
    from experiments.e2 import policy,suite,trial
    from experiments.e2.report import inspect_series
    folder=target/arm;stage=folder/"stage";base=folder/"participant"
    folder.mkdir(parents=True);stage.mkdir();base.mkdir()
    suite.freeze_series(folder,replicate=rep,reason="Independent compound call W1 qualification; separate local receipt-bound adapter")
    reg=(folder/"freeze.json").read_bytes();pin=json.loads(reg)
    stored=FileArchive(stage)
    adapter=policy.KernelArm if arm=="purser" else policy.PlanArm
    original=adapter.revise
    emitted=[]
    def side(self,notice):
        response=original(self,notice)
        other=copy(self)
        if arm=="purser":
            other.on_proposal=None
            other.count=10_000
            other.assignments=dict(self.assignments)
            other.results=dict(self.results)
            other.runs=dict(self.runs)
            other.observations=dict(self.observations)
            other.receipts=[]
        else:
            other.invocation=None
        def call(label,f):
            ret=f()
            rows,identity=other.public_view()
            emitted.append({"label":label,"return":ret,"state":rows["W1"]["state"],"identity":identity})
            return ret
        prior=other.public_view()[0]["W1"]["candidate"]
        oid=prior["digest"] if isinstance(prior,dict) else prior
        call("plan",lambda:other.assign_again("W1"))
        if arm=="purser":
            call("decide rejected",lambda:other.decide("W1",{"missing":[]}))
        else:
            call("decide refused",lambda:other.decide("W1",{"missing":["W1/preferences"]}))
        call("submit",lambda:other.submit("W1",oid))
        if arm=="purser":
            label="W1/preferences"
            call("plan run",lambda:other.opening("W1",label))
            repo=base/"private-objects"
            with extract_tree(repo,oid) as checkout:
                observed=policy.inspect(repo,oid,Path(checkout),label,policy.LINEAR)
            call("observe",lambda:other.observe("W1",label,observed))
            call("decide verdict",lambda:other.verify("W1",label,dict(observed,verdict="pass")))
        call("decide close",lambda:other.decide("W1",{"missing":[]}))
        return response
    adapter.revise=side
    try:
        raw=trial.attempt(base,Artifacts(stored),pin,arm,"primary",2001,1)
    finally:
        adapter.revise=original
    publish(folder/"raw.zip",reg,set(),"primary/2001/"+arm,{"track":"primary","rank":1,"seed":2001,"arm":arm},stored,raw)
    cases,_=inspect_series(folder);case=cases["primary",2001,arm]
    with zipfile.ZipFile(folder/"raw.zip") as z:
        plat=json.loads(z.read(raw["artifacts"]["platform"]["path"]))
        trace=json.loads(z.read(plat["treatment_trace"]["path"]))
        if arm=="purser":
            bound=[json.loads(r) for r in trace["original_events"] if json.loads(r)["proposal_id"].startswith("P-1000")]
        else:
            bound=[]
    witness={"source":pin["source_commit"],"arm":arm,"emitted":emitted,"actual_extra_calls":len(emitted),
             "observed_states":[e["state"] for e in emitted],"nested_receipts":[r for r in bound if r["type"]=="ProposalReceipted"],
             "scored_siblings":case.facts["unaffected_both_retained"],"scored_reopened":case.facts["unaffected_reopened"],
             "scored_rework":case.facts["rework_steps"],"scored_steps":raw["cost"]["steps"],"scope":"private",
             "issues":case.issues,"terminal":raw["terminal"],"score":raw["score"]}
    (folder/"result.json").write_text(json.dumps(witness,indent=2,sort_keys=True)+"\n")
    print(json.dumps({k:v for k,v in witness.items() if k not in ("emitted","nested_receipts","score")}),flush=True)
    return witness

if __name__=="__main__":
    source=Path(sys.argv[1]).resolve(); target=Path(sys.argv[2]).resolve();sys.path.insert(0,str(source));target.mkdir(parents=True)
    out=[run(source,target,arm,rep) for arm,rep in (("loop",812),("purser",813))]
    (target/"summary.json").write_text(json.dumps(out,indent=2,sort_keys=True)+"\n")
