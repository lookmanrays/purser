"""Challenge the last permitted work attempt with independently bound, real plan and gate calls."""
from copy import copy
import json
from pathlib import Path
import sys
import zipfile
from unittest.mock import patch

source,destination=[Path(v).resolve() for v in sys.argv[1:]]
sys.path.insert(0,str(source))
from experiments.e1.artifacts import Artifacts
from experiments.e1.recovery import FileArchive
from experiments.e1.suite import publish
from experiments.e2 import policy,suite,trial

def run(arm,rep):
    where=destination/arm;where.mkdir(parents=True)
    participant=where/"participant"; participant.mkdir()
    stage=where/"stage";stage.mkdir();storage=FileArchive(stage)
    suite.freeze_series(where,replicate=rep,reason="Independent nested attempted work at the 96-step cutoff")
    reg=(where/"freeze.json").read_bytes();pin=json.loads(reg)
    cls=policy.KernelArm if arm=="purser" else policy.PlanArm
    original=cls.revise
    trace=[]
    def exhaust(self,*args,**kwargs):
        output=original(self,*args,**kwargs)
        other=copy(self)
        if arm=="purser":
            other.count=15000;other.on_proposal=None;other.assignments=dict(self.assignments);other.receipts=[]
        else:other.invocation=None
        for i in range(100):
            step={"private_ordinal":i+1}
            trace.append(step)
            step["before"]=other.public_view()[1]
            try:
                step["reply"]=other.assign_again("W1")
            except BaseException as exc:
                step["exception"]=type(exc).__name__+" "+str(exc);raise
            finally:
                step["after"]=other.public_view()[1]
        return output
    with patch.object(cls,"revise",exhaust):
        raw=trial.attempt(participant,Artifacts(storage),pin,arm,"primary",2001,1)
    publish(where/"raw.zip",reg,set(),"primary/2001/"+arm,{"rank":1,"seed":2001,"track":"primary","arm":arm},storage,raw)
    with zipfile.ZipFile(where/"raw.zip") as z:
        obj=lambda ref:json.loads(z.read(ref["path"]))
        p=obj(raw["artifacts"]["platform"]);j=obj(raw["artifacts"]["journal"]);t=obj(p["treatment_trace"])
        prior=[]
        for e in j:
            if e["kind"]=="action":
                prior.append(e["payload"]["attempt"])
                if "adopt" in (e["payload"].get("input") or {}):break
        assert prior
        seen=sum('reply' in r for r in trace)
        canonical=[]
        if arm=="purser":
            canonical=[json.loads(s)["revision"] for s in t["original_events"] if json.loads(s)["type"]=="ProposalReceipted" and int(json.loads(s)["proposal_id"].split("-")[1])>15000]
            assert len(canonical)>=seen
        result={"source":pin["source_commit"],"arm":arm,"prior_inclusive":prior[-1],"extra_successfully_returned":seen,
                "extra_entered":len(trace),"last_error":trace[-1].get("exception") if trace else None,
                "counted_steps":raw["cost"]["steps"],"terminal":raw["terminal"],"canonical_extra_receipt_revisions":canonical,
                "before_after":trace,"score":raw["score"]}
    (where/"result.json").write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
    print(arm,seen,raw["cost"]["steps"],raw["terminal"],flush=True);return result
destination.mkdir(parents=True)
res=[run(a,rep) for a,rep in (("loop",825),("purser",826))]
(destination/"summary.json").write_text(json.dumps(res,indent=2,sort_keys=True)+"\n")
