"""A missing pre-change view does not disprove a witnessed stress intervention."""
import json
from pathlib import Path
import sys
import zipfile
from negative_archives import put,canonical
source,healthy,out=[Path(s).resolve() for s in sys.argv[1:]]
sys.path.insert(0,str(source))
from experiments.e2.report import inspect_series
out.mkdir(parents=True)
rawname="runs/closed-affected/2001/purser.json"
with zipfile.ZipFile(healthy/"raw.zip") as z:
    raw=json.loads(z.read(rawname))
    journal=json.loads(z.read(raw["artifacts"]["journal"]["path"]))
    p=next(r["payload"] for r in journal if r["kind"]=="fault")
    previous=next(r["payload"]["after"] for r in reversed(journal[:next(i for i,r in enumerate(journal) if r["kind"]=="fault")]) if r["kind"]=="action")
    assert previous==p["before"]
    original=p["before"]["view"].copy()
    p["before"]=dict(p["before"],view={"path":"objects/"+"f"*64+".json","sha256":"f"*64,"bytes":original["bytes"]})
    writes={}
    raw["artifacts"]["journal"]=put(writes,journal)
    writes[rawname]=canonical(raw)
    with zipfile.ZipFile(out/"raw.zip","x",compression=zipfile.ZIP_DEFLATED) as z2:
        for s in z.namelist():
            z2.writestr(s,writes.pop(s) if s in writes else z.read(s))
        for s,data in writes.items():
            z2.writestr(s,data)
cases,_=inspect_series(out)
case=cases["closed-affected",2001,"purser"]
result={"source":__import__("subprocess").check_output(["git","-C",str(source),"rev-parse","HEAD"]).decode().strip(),
        "admitted_premise":True,"unmodified_previous_public":previous,"intentionally_unavailable":p["before"]["view"],
        "independently_known_visible_W2":"closed","intervention_reached":case.facts["intervention_reached"],
        "cost_lower_bound":case.facts["rework_observed"],"issues":case.issues}
(out/"result.json").write_text(json.dumps(result,indent=2)+"\n");print(json.dumps(result),flush=True)
