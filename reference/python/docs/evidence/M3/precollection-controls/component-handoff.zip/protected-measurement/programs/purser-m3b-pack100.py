import json,os,subprocess,sys,tempfile,shutil,signal
from pathlib import Path
source=Path.cwd()
scratch=Path(tempfile.mkdtemp(prefix="purser-m3b-pack100-")); print(scratch,flush=True)
repo=scratch/'repo'
def run(*args,wd=repo,ok=True):
    return subprocess.run(args,cwd=wd,env={**os.environ,"TZ":"UTC","LC_ALL":"C","PYTHONDONTWRITEBYTECODE":"1"},check=ok)
run('git','clone','--quiet','--local',str(source),str(repo),wd=scratch)
run('git','checkout','--quiet','--detach','1243dde2d23f9dc67986d78ea2d60099bff2b7c4')
for name in ("experiments/e2","experiments/e1","tests/test_e2.py"):
    target=repo/name
    if (source/name).is_dir():
        shutil.copytree(source/name,target,dirs_exist_ok=True,ignore=shutil.ignore_patterns("__pycache__"))
    else:
        shutil.copy2(source/name,target)
run('git','add','--','experiments/e1','experiments/e2','tests/test_e2.py')
run('git','commit','--quiet','-m','Private E2 pack-only recovery control')
run('python3.11','-B','-m','experiments.e2','freeze','private-pack-only','--replicate','100','--reason','Real process kill and recovery without bare store')
run('git','add','--','private-pack-only/freeze.json')
run('git','commit','--quiet','-m','Register off-study E2 pack recovery')
script=scratch/"pack_recovery.py"
shutil.copy2('/private/tmp/purser-e2-assurance-E6chNl/pack_recovery.py',script)
assert run('python3.11','-B',str(script),'die',ok=False).returncode==-signal.SIGKILL
# The external control expected a historical recovery_issues list even if now clean.
proc=run('python3.11','-B',str(script),'recover',ok=False)
run('python3.11','-B','-c',"""from pathlib import Path
from experiments.e2.report import inspect_series
from experiments.e1.artifacts import read_artifact
import zipfile,json
d=Path('private-pack-only')
cases,stats=inspect_series(d,strict=True,rerun=True); case=next(iter(cases.values()))
with zipfile.ZipFile(d/'raw.zip') as z:
 r=json.loads(z.read('runs/primary/2001/loop.json')); j=json.loads(read_artifact(z,r['artifacts']['journal']))
 n=sum(e['kind']=='oracle' for e in j)
print(stats,n,case.basis,case.facts['last_observed_source'],case.facts['last_observed_pass'],case.issues)
assert n>0 and case.facts['last_observed_pass'] is True and not case.issues
""")
