import os,tempfile,sys,subprocess,signal,zipfile,json
from pathlib import Path
from experiments.e1.artifacts import FIXTURE,REGISTRATION,encoded
from experiments.e1.suite import collect_cases
from experiments.e1.report import Objects,GitPacks
from experiments.e2 import trial,checkpoint
from experiments.e2.report import inspect_case
if len(sys.argv)>1: dest=Path(sys.argv[1]);child=True
else:dest=Path(tempfile.mkdtemp(prefix='purser-e2b-kill-during-eligibility-'));child=False
arm='loop';track='primary';seed=2001;rank=1
pin={k:'0'*64 for k in ('manifest_sha256','protocol_sha256','raw_schema_sha256','scorer_sha256','fault_driver_sha256','executor_sha256')}
pin.update(fixture_tree=FIXTURE['tree_sha1'],fixture_commit=FIXTURE['commit_sha1'],source_commit='0'*40,treatments={arm:'0'*64},replicate=98)
def collect():collect_cases(dest,pin,encoded(pin),[(track,seed,rank,arm)],trial.attempt,recover=trial.recover,failure=trial.failure)
if child:
    original=checkpoint.measure.check
    def killed(*args):
        result=original(*args)
        if args[-1]==['W2/retry']:os.kill(os.getpid(),signal.SIGKILL)
        return result
    checkpoint.measure.check=killed
    collect()
else:
    print(dest,flush=True)
    r=subprocess.run([sys.executable,'-B',__file__,str(dest)])
    assert r.returncode==-signal.SIGKILL
    collect();collect()
    with zipfile.ZipFile(dest/'raw.zip') as z:
        assert len([n for n in z.namelist() if n.startswith('started/')])==1
        raw=json.loads(z.read('runs/primary/2001/loop.json'))
        obj=Objects(z);platform=obj.item(raw['artifacts']['platform']);j=obj.item(raw['artifacts']['journal']);p=platform['checkpoint_measurement']
        test=inspect_case(raw,json.loads((REGISTRATION/'raw.schema.json').read_text()),obj,GitPacks(dest),1,rerun=True,measurements={})
        print(raw['terminal'],raw['cost'],p['qualified'],p['end_monotonic_ns'],len(p['checks']),test.basis,test.facts['rework_steps'],test.facts['final_pass'],test.issues)
        assert raw['terminal']=='harness_failure' and test.basis=='observed_lower_bound' and p['end_monotonic_ns'] is None and not test.issues
