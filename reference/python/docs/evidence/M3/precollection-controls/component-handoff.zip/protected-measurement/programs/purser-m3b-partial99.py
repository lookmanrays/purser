import json,os,subprocess,sys,tempfile,shutil
from pathlib import Path
source=Path.cwd()
scratch=Path(tempfile.mkdtemp(prefix="purser-m3b-provisional99-"))
print(scratch,flush=True)
repo=scratch/'repo'
def run(*args,wd=repo):
    subprocess.run(args,cwd=wd,env={**os.environ,"TZ":"UTC","LC_ALL":"C","PYTHONDONTWRITEBYTECODE":"1"},check=True)
run('git','clone','--quiet','--local',str(source),str(repo),wd=scratch)
run('git','checkout','--quiet','--detach','1243dde2d23f9dc67986d78ea2d60099bff2b7c4')
for name in ("experiments/e2","experiments/e1","tests/test_e2.py"):
    target=repo/name
    if (source/name).is_dir():
        shutil.copytree(source/name,target,dirs_exist_ok=True,ignore=shutil.ignore_patterns("__pycache__"))
    else:
        shutil.copy2(source/name,target)
run('git','add','--','experiments/e1','experiments/e2','tests/test_e2.py')
run('git','commit','--quiet','-m','Private M3-B cutoff and partial input controls on revised A')
run('python3.11','-B','-m','experiments.e2','freeze','private-99','--replicate','99','--reason','Private M3-B checkpoint and partial release qualification')
run('git','add','--','private-99/freeze.json')
run('git','commit','--quiet','-m','Register private 99')
run('python3.11','-B','-c','from pathlib import Path;from experiments.e2.suite import collect_units,schedule;collect_units(Path("private-99"),[u for u in schedule() if u[0]=="closed-affected" and u[3]=="purser"])')
run('python3.11','-B','-m','experiments.e2','verify','private-99')
script='/private/tmp/purser-m3-independent-CQF3Qwl5/partial_stress.py'
run('python3.11','-B',script,str(repo),str(repo/'private-99'),str(scratch/'partial'))
print((scratch/'partial/result.json').read_text())
