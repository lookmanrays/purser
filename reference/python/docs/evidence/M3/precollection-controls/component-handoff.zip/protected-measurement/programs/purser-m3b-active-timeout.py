import os,sys,time
from unittest.mock import patch
sys.path.insert(0,'/tmp')
from pathlib import Path
from types import ModuleType
s=Path('/tmp/purser-m3b-live-eligibility-tests.py').read_text().split('if sys.argv[-1]=="slow":')[0]
ns={};exec(s,ns)
raw,platform,events,case=ns['run']('active-timeout','primary',patch.object(ns['policy'].PlanArm,'revise',lambda *args:time.sleep(100)))
assert raw['terminal']=='time_limit' and raw['cost']['elapsed_ns']>=60_000_000_000 and case.facts['rework_steps']==1 and not case.issues
