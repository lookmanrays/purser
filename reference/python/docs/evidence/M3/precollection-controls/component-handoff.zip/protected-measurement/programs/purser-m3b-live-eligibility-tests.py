import json,tempfile,sys,time
from pathlib import Path
from unittest.mock import patch
from experiments.e1.artifacts import Artifacts,FIXTURE,REGISTRATION
from experiments.e1.recovery import FileArchive
from experiments.e1.report import Objects,GitPacks
from experiments.e1.measurement import MeasurementUnavailable
from experiments.e2 import policy,measure,checkpoint,clock
from experiments.e2.trial import attempt
from experiments.e2.report import inspect_case
root=Path(tempfile.mkdtemp(prefix="purser-private-checkpoint-98-"));print(root,flush=True)
orig=policy.edit
def run(name,track,setup):
    parent=root/name;parent.mkdir();work=parent/"work";work.mkdir();assets=Artifacts(FileArchive(parent))
    pin={k:'0'*64 for k in ('manifest_sha256','protocol_sha256','raw_schema_sha256','scorer_sha256','fault_driver_sha256','executor_sha256')}
    pin.update(fixture_tree=FIXTURE['tree_sha1'],fixture_commit=FIXTURE['commit_sha1'],source_commit='0'*40,treatments={'loop':'0'*64},replicate=98)
    with setup:
        raw=attempt(work,assets,pin,'loop',track,2001,1)
    (parent/"raw.json").write_text(json.dumps(raw))
    objs=Objects(assets.archive);plat=objs.item(raw["artifacts"]["platform"]);j=objs.item(raw["artifacts"]["journal"])
    p=plat["checkpoint_measurement"]; actual=plat["end_monotonic_ns"]-plat["start_monotonic_ns"]; active=raw['cost']['elapsed_ns']
    print(name,raw["terminal"],raw["cost"]["steps"],p["qualified"],"phys",round(actual/1e9,3),"active",round(active/1e9,3),"pause",round((p["end_monotonic_ns"]-p["start_monotonic_ns"])/1e9,3),"fault",sum(x["kind"]=="fault" for x in j),flush=True)
    packs=parent/'packs';packs.mkdir()
    result=inspect_case(raw,json.loads((REGISTRATION/"raw.schema.json").read_text()),objs,GitPacks(packs),1,rerun=True,measurements={})
    print("issues",result.issues,"reached",result.facts['intervention_reached'],"final",result.facts['final_pass'],flush=True)
    assert actual-active==p["end_monotonic_ns"]-p["start_monotonic_ns"]
    return raw,plat,j,result
def bad(which):
    def edit(w,subject,phase):
        orig(w,subject,phase)
        if phase!=policy.LINEAR or subject!=which:return
        loc=w/policy.PATHS[subject];src=loc.read_text()
        if subject=="W2":src=src.replace("k * base", "k * (base if base == 3 else base + 1)")
        elif subject=="W1":src=src.replace("channel not in disabled",'channel == "mail" or channel not in disabled')
        else:src=src.replace("tuple(dict.fromkeys(event_ids))",'tuple(event_ids) if any(s.startswith("2001") for s in event_ids) else tuple(dict.fromkeys(event_ids))')
        loc.write_text(src)
    return patch.object(policy,'edit',edit)
if sys.argv[-1]=="slow":
    live=checkpoint.measure
    class Slow:
        OLD=1
        @staticmethod
        def check(*args):
            if not hasattr(Slow,"waited"):
                Slow.waited=True;time.sleep(61)
            return live.check(*args)
    raw,pl,j,r=run("time-pause", "primary",patch.object(checkpoint,'measure',Slow))
    assert raw["terminal"]=="done" and r.facts["rework_steps"]==13 and r.issues==()
else:
    for subject in ("W2","W1","W3"):
        for track in ("primary","closed-affected"):
            raw,pl,j,r=run(subject+track,track,bad(subject))
            assert raw["terminal"]=="blocked" and not any(e["kind"]=="fault" for e in j) and r.facts["rework_steps"] is None and r.issues==()
    live=checkpoint.measure
    class Unavailable:
        OLD=1
        @staticmethod
        def check(*args):
            if args[-1]==["W2/retry"]:raise MeasurementUnavailable("private admission probe unavailable")
            return live.check(*args)
    raw,pl,j,r=run("unavailable","primary",patch.object(checkpoint,'measure',Unavailable))
    assert raw["terminal"]=="harness_failure" and not any(e["kind"]=="fault" for e in j)
