"""Observe native branch and offline case report after a real loopback HTTP failure."""
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import subprocess
import sys
import threading

repo = Path(sys.argv[1]).resolve()
destination = Path(sys.argv[2]).resolve()
sys.path.insert(0, str(repo))
from tests.test_model_study import enroll, cli
from experiments.e1.artifacts import encoded, sha
from experiments.model_study.collector import case_path
from experiments.model_study.report import inspect

unit = ('E3', 'primary', 3013, 'loop')
destination.mkdir(exist_ok=False)
calls = []

class Service(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_POST(self):
        body = self.rfile.read(int(self.headers['Content-Length']))
        index = len(calls) + 1
        request = json.loads(body)
        if index == 1:
            observation = json.loads(json.loads(request['messages'][1]['content'])['observation'])
            intent = observation[0]['intent']
            command = {'action': 'dispatch', 'arguments': {'effect': intent['effect'], 'target': intent['target']['digest']}}
            status = 200
            reply = {'model': request['model'], 'choices': [{'index': 0, 'finish_reason': 'stop', 'message': {'role': 'assistant', 'content': encoded(command).decode()}}], 'usage': {'prompt_tokens': 19, 'completion_tokens': 7}}
        else:
            status = 429
            reply = {'error': {'message': 'local qualification service rate limit'}, 'usage': {'prompt_tokens': 17, 'completion_tokens': 0}}
        outgoing = encoded(reply)
        (destination / f'{index}-request.json').write_bytes(body)
        (destination / f'{index}-response.json').write_bytes(outgoing)
        calls.append((status, sha(body), sha(outgoing)))
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(outgoing)))
        self.end_headers()
        self.wfile.write(outgoing)

server = ThreadingHTTPServer(('127.0.0.1', 0), Service)
worker = threading.Thread(target=server.serve_forever, daemon=True)
worker.start()
try:
    series = enroll(destination, server.server_port, observer='unavailable')
    unit_s = '/'.join(map(str, unit))
    cli('collect', series, '--unit', unit_s)
    cli('collect', series, '--unit', unit_s)
finally:
    server.shutdown()
    server.server_close()
    worker.join()

saved_report = cli('report', series)
(destination / 'report.md').write_text(saved_report)
case = case_path(series, unit)
gitlog = subprocess.check_output(['git', '--git-dir', str(case / 'trial/canonical.git'), 'reflog', 'show', '--format=%H%x09%gs', 'refs/heads/notify'], text=True).splitlines()
raw = json.loads((case/'raw.json').read_bytes())
_, cases = inspect(series)
rec = cases[unit]
header = None
for line in saved_report.splitlines():
    if line.startswith('| Track | Seed | Arm | Validity'):
        header = [part.strip() for part in line.strip('|').split('|')]
    if line.startswith('| primary | 3013 | loop |'):
        fields = dict(zip(header, [part.strip() for part in line.strip('|').split('|')], strict=True))
        break
else:
    raise ValueError('No scheduled individual')
result = {'source': subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(), 'wire': calls, 'original_reflog': gitlog, 'raw_validity': raw['validity'], 'raw_terminal': raw['terminal'], 'raw_score': raw['score'], 'facts': {key: rec['facts'].get(key) for key in ('eligible', 'original_truth', 'original_report', 'effect_count', 'duplicate_count', 'correct_reconciliation', 'resolved_by_budget', 'justified_in_order', 'uncertainty_remaining')}, 'rendered_case': fields, 'exact_cost': rec['cost'].exact, 'errors': rec['errors']}
data=encoded(result)
(destination/'result.json').write_bytes(data)
print(json.dumps(result, indent=2))
print('result sha256',sha(data))
