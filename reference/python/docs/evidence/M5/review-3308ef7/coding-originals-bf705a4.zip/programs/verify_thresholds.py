from collections import Counter
from pathlib import Path
import json,sys
from private_cli import launch,save,sha
repo=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();sys.path.insert(0,str(repo))
from experiments.model_study.registration import schedule
from experiments.model_study.report import predicates,inspect,render
from experiments.model_costs import ModelCaseCost
spec=json.loads((Path(__file__).resolve().parents[1]/'expected-matrix-v1.json').read_bytes())
units=list(schedule());assert len(units)==len(set(units))==195
totals={key:sum(u[0]==key for u in units) for key in ('E1','E2','E3')};assert totals=={'E1':63,'E2':66,'E3':66}
for name,target in spec['experiments'].items():
    normal=sorted({u[2] for u in units if u[:2]==(name,'primary')})
    assert normal==target['seeds']
    assert {u[3] for u in units if u[0]==name}==set(spec['arms_in_manifest_order'])
    assert len([u for u in units if u[:2]==(name,'clean') and u[2]==target['clean']])==3
    if 'stress' in target and target['stress']:
        assert len([u for u in units if u[:2]==(name,target['stress']['id']) and u[2]==target['stress']['seed']])==3
def trial(arm,i,exp):
    if exp=='E1':return dict(false_parent_closure=False,missing_named=i<19,caught=i<19)
    if exp=='E2':return dict(unaffected_both_retained=i<18,rework_steps=2 if arm=='purser' else 4,final_pass=i<17)
    return dict(duplicate_count=0,correct_reconciliation=True,resolved_by_budget=True,stuck_requires_manual=False)
def fixture():
    ans={}
    for u in units:
        e,t,seed,a=u
        if t!='primary':continue
        i=spec['experiments'][e]['seeds'].index(seed)
        ans[u]={'facts':dict(eligible=True,**trial(a,i,e)),'cost':ModelCaseCost('complete',{})}
    return ans
result={}
def validate(label,cases,want):
    got=predicates(cases)
    for k,v in want.items():assert got[k]==v,(label,k,got,want)
    result[label]=got
p=fixture();validate('at inclusive cutoffs',p,{'E1':(True,True),'E2':(True,False),'E3':(True,False)})
p=fixture();p['E1','primary',1001,'purser']['facts']['false_parent_closure']=True
p['E1','primary',1001,'loop']['facts']['caught']=False
p['E2','primary',2001,'purser']['facts']['unaffected_both_retained']=False
p['E3','primary',3001,'purser']['facts']['duplicate_count']=1
validate('one wrong outcome against each denominator',p,{'E1':(False,False),'E2':(False,False),'E3':(False,True)})
p=fixture()
for u in p:
 if u[0]=='E2':p[u]['facts']['rework_steps']=0
validate('both zero rework',p,{'E2':(True,True)})
p=fixture();p['E2','primary',2001,'purser']['facts']['final_pass']=False
p['E3','primary',3001,'purser']['facts'].update(stuck_requires_manual=True,resolved_by_budget=False)
validate('fewer passing finals or stuck',p,{'E2':(False,True),'E3':(False,True)})
p=fixture();del p['E1','primary',1001,'purser'];del p['E2','primary',2001,'purser'];del p['E3','primary',3001,'purser']
validate('one missing otherwise-favorable original',p,{'E1':(None,True),'E2':(None,None),'E3':(None,None)})
blank=launch(repo,'report').stdout
assert b'0 of 195 original real-model observations' in blank and b'0 / 0 / 0 / 195' in blank
save(out,{'basis':'offline hand-scored synthetic truth and authentic no-series public CLI, no model observations','registered_counts':totals,
         'physical_coverage_by_track':dict(Counter(u[1] for u in units)),'unregistered_cli_sha256':sha(blank),'native_predicate_readouts':result})
