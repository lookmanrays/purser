"""Counterfactual cold evidence loss and authentic cross-case substitution; originals stay immutable."""
from pathlib import Path
import hashlib,json,os,shutil,sys
from private_cli import encode,launch,save,sha
from cold_independent import get,ref
repo=Path(sys.argv[1]).resolve();run=Path(sys.argv[2]).resolve();lab=Path(sys.argv[3]).resolve()
lab.mkdir();sys.path.insert(0,str(repo))
from experiments.model_study.report import inspect,field
unit=('E2','primary',2001,'loop')
orig=run/'e2-double-reopen/series';donor=run/'e2-stale-stress/series'
rel=Path('cases/E2/primary/2001/loop');drel=Path('cases/E2/closed-affected/2001/loop');droot=donor/drel
r0=get(orig/rel/'raw.json'); p0=ref(orig/rel,r0['artifacts']['platform']); j=ref(orig/rel,r0['artifacts']['journal'])
dr=get(droot/'raw.json');dp=ref(droot,dr['artifacts']['platform'])
last=next(r['payload'] for r in reversed(j) if r['kind']=='oracle' and r['payload']['version']==2 and r['payload']['criterion']=='queue/composition')
assert last['verdict']=='fail' # linear recipient against new requirement
expected_obj=last['evidence']
receipt_group=ref(orig/rel,last['probe_receipts'])
measured=next(x for x in reversed(receipt_group) if ref(orig/rel,x)['phase']=='measured' and ref(orig/rel,x)['mode']=='queue')
assert ref(orig/rel,measured)['candidate']==last['candidate']
def prepare(label):
    series=lab/label;shutil.copytree(orig,series,copy_function=os.link)
    return series,series/rel
def replace(path,data):
    path.unlink(missing_ok=True);path.write_bytes(data)
def put(root,value):
    wire=encode(value);digest=sha(wire);ref={'path':'objects/'+digest+'.json','sha256':digest,'bytes':len(wire)}
    f=root/ref['path']
    if f.exists():assert f.read_bytes()==wire
    else:f.write_bytes(wire)
    return ref
def reading(series):
    output1=launch(repo,'report',series).stdout;output2=launch(repo,'report',series).stdout;assert output1==output2
    (lab/(series.name+'-report.md')).write_bytes(output1)
    _,cs=inspect(series);r=cs[unit];f=r['facts']
    return {'terminal':r['terminal'],'validity':r['cost'].validity,'errors':r['errors'],'report_sha256':sha(output1),
        'returned':{k:field(cs,unit,k) for k in ('intervention_reached','eligible','unaffected_reopened','unaffected_both_retained','affected_invalid_closure','final_pass','steps','model_calls','input_tokens','output_tokens')},
        'final_criteria':f.get('final_criteria'),'confirmed_send':f.get('first_model_exposure'),'reopen_observations':f.get('reopen_observations')}
out={}
series,root=prepare('only-report-absent')
assert sha((root/expected_obj['path']).read_bytes())==expected_obj['sha256'];(root/expected_obj['path']).unlink()
out['only-report-absent']=reading(series)
a=out['only-report-absent'];assert a['validity']=='infrastructure_invalid' and a['returned']['intervention_reached'] and a['returned']['unaffected_reopened']==2 and a['final_criteria']['queue/composition']=='fail' and expected_obj['sha256'] in str(a['errors']),a
series,root=prepare('report-and-actual-output-absent')
for f in (expected_obj,measured):(root/f['path']).unlink()
out['report-and-actual-output-absent']=reading(series)
a=out['report-and-actual-output-absent'];assert a['validity']=='infrastructure_invalid' and a['returned']['intervention_reached'] and a['returned']['unaffected_reopened']==2 and a['final_criteria']['queue/composition'] is None and a['returned']['final_pass'] is None and a['returned']['model_calls']==8,a
series,root=prepare('alien-measured-object-at-home-address')
foreign=next(row['receipt'] for row in reversed(dp['isolation_receipts']) if row['group']['use']=='protected' and row['group']['selector']['version']==2 and ref(droot,row['receipt'])['phase']=='measured' and ref(droot,row['receipt'])['mode']=='queue' and row['receipt']['sha256']!=measured['sha256'])
alien=ref(droot,foreign,raw=True)
replace(root/measured['path'],alien)
a=out['alien-measured-object-at-home-address']=reading(series)
assert a['validity']=='infrastructure_invalid' and a['returned']['final_pass'] is None and a['final_criteria'] is None and a['returned']['model_calls']==8 and 'object changed after capture' in str(a['errors']).lower(),a
series,root=prepare('authentic-alien-wrapper')
meta=ref(root,r0['artifacts']['platform'])
pair=next((row,other) for row in meta['isolation_receipts'] for other in dp['isolation_receipts']
          if row["group"]["use"]==other["group"]["use"]=="protected" and row["group"]["candidate"]==other["group"]["candidate"]
          and row["group"]["selector"]==other["group"]["selector"] and row["group"]["unit"]!=other["group"]["unit"])
prior,other=pair
home={'unit':prior['group']['unit'],'registration':prior['group']['registration_sha256'],'candidate':prior['group']['candidate']}
away={'unit':other['group']['unit'],'registration':other['group']['registration_sha256'],'candidate':other['group']['candidate']}
prior['group']=other['group']
r=get(root/'raw.json');r['artifacts']['platform']=put(root,meta);replace(root/'raw.json',encode(r))
a=out['authentic-alien-wrapper']=reading(series)
assert a['validity']=='infrastructure_invalid' and a['returned']['intervention_reached'] is None and a['final_criteria'] is None and 'another case' in str(a['errors']),a
assert not any(sha((orig/rel/f['path']).read_bytes())!=f['sha256'] for f in (expected_obj,measured))
save(lab/'independent.json',{'source':(run/'source.txt').read_text().strip(),'original_raw':sha((orig/rel/'raw.json').read_bytes()),'foreign_raw':sha((droot/'raw.json').read_bytes()),'actual_ownership':home,'different_actual_ownership':away,'original_final_report':expected_obj,'original_bounded_output':measured,'foreign_bounded_output':foreign,'readbacks':out})
print(sha((lab/'independent.json').read_bytes()),list(out),flush=True)
