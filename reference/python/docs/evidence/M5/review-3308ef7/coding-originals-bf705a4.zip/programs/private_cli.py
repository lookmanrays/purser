"""Independent canned decisions for the public M5 study CLI. All service traffic is loopback."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import threading
import time
from dataclasses import asdict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = Path(__file__).resolve().parent
ARCHIVES = HERE.parents[1] / "isolator-feasibility"
ENV = {"PATH": "/usr/bin:/bin", "TZ": "UTC", "LC_ALL": "C", "PYTHONDONTWRITEBYTECODE": "1"}
MODEL = "local-independent-counted-responder"
MODULES = {
  "preferences": '"""Fixture preference policy."""\n\ndef allowed(channel, disabled):\n    return channel not in set(disabled)\n',
  "delivery": '"""Fixture ordered delivery policy."""\n\ndef select(event_ids):\n    seen = set()\n    answer = []\n    for item in event_ids:\n        if item not in seen:\n            seen.add(item)\n            answer.append(item)\n    return tuple(answer)\n',
  "linear": '"""Fixture old retry policy."""\n\ndef delays(attempts, base):\n    return tuple(step * base for step in range(attempts))\n',
  "revised": '"""Fixture revised retry policy."""\n\ndef delays(attempts, base):\n    return tuple(0 if step == 0 else base * (1 << (step - 1)) for step in range(attempts))\n',
}

def sha(b):
    return hashlib.sha256(b).hexdigest()

def encode(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()

def save(path, value):
    path.write_bytes(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2).encode() + b"\n")

def act(name, **arguments):
    return {"action": name, "arguments": arguments}

def choose(mode, turn, menu, view):
    if mode == "early":
        return act("stop", reason="I have not yet edited a public candidate.")
    if mode == "defer":
        return act("defer", reason="I need additional observation.", next_action="inspect")
    if turn in (1, 2, 3):
        pick = ("preferences", "delivery", "linear")[turn - 1]
        path = "notify/" + ("retry" if pick == "linear" else pick) + ".py"
        disposition = "submit" if mode.startswith("E2") and mode != "E2-stale-stress" and turn == 3 else "request_close"
        return act("edit", path=path, source=MODULES[pick], disposition=disposition)
    if mode == "E1-repair" and turn == 4:
        outside = [c["path"] for c in view["git_changes"] if c["path"].startswith("notes/")]
        if len(outside) != 1:
            raise AssertionError(("no single public extra path", outside))
        return act("remove", path=outside[0], disposition="request_close")
    if mode == "E1-bad":
        if turn == 4:
            return act("close", work="W-notify")
        if turn == 5:
            return act("diagnose", work="W-notify", obligations="scope/paths")
    if mode == "E2-reopens":
        if not view.get("notice"): raise AssertionError("notice not yet seen")
        if turn in (4, 6): return act("reopen", work="W3")
        if turn in (5, 7): return act("close", work="W3")
        return act("stop", reason="Two observed interruptions of the same sibling completed.")
    if mode == "E2-stale-stress":
        if not view.get("notice"): raise AssertionError("closed-affected notice not yet seen")
        return act("stop", reason="Retain the initially closed stale item on the public plan.")
    if mode.startswith("E2"):
        if turn == 4:
            if not view.get("notice") or "revise_retry" not in menu:
                raise AssertionError(("missing publicly observed notice", view.get("notice"), list(menu)))
            if mode in ("E2-repair", "E2-interrupt", "E2-unrelated"):
                return act("revise_retry", path="notify/retry.py", source=MODULES["revised"], disposition="request_close")
            return act("close", work="W2")
        if mode=="E2-unrelated" and turn==5:
            return act("edit", path="notify/preferences.py", source=MODULES["preferences"].replace("channel not in set(disabled)", "True"), disposition="request_close")
        if turn == 5 or (mode=="E2-unrelated" and turn==6):
            return act("close", work="W-notify")
    return act("stop", reason="The original controlled public actions have completed.")

class Service(ThreadingHTTPServer):
    daemon_threads = True

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_):
        return
    def do_POST(self):
        s = self.server
        try:
            body = self.rfile.read(int(self.headers["Content-Length"]))
            request = json.loads(body)
            participant = json.loads(request["messages"][1]["content"])
            mode, label, out = s.mode
            n = len(s.calls[label]) + 1
            decision = choose(mode, n, participant["actions"], json.loads(participant["observation"]))
            forbidden = [b"/Users/lookman/", b"skipped_retry_check", b"outside_scope", b"unchanged_module",
                         b"authority_sha256", b"observer_intervals", b"private-objects", b"registration_sha256"]
            leaked = [p.decode() for p in forbidden if p in body]
            rec = {"turn": n, "request_sha256": sha(body), "response": decision, "leaks": leaked, "route": self.path}
            s.calls[label].append(rec)
            (out / f"{n}.request.json").write_bytes(body)
            save(out / "posts.json", s.calls[label])
            if mode == "E2-interrupt" and n == 4:
                s.arrived.set()
                if not s.release.wait(90):
                    raise TimeoutError("reviewer did not release local response")
            response = {"model": request["model"], "choices": [{"index": 0, "finish_reason": "stop",
                        "message": {"role": "assistant", "content": encode(decision).decode()}}],
                        "usage": {"prompt_tokens": 23 + n, "completion_tokens": 7}}
            wire = encode(response)
            (out / f"{n}.response.json").write_bytes(wire)
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(wire)))
            self.end_headers()
            self.wfile.write(wire)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as error:
            s.errors.append(repr(error))
            self.send_error(500)

def command(repo, *args):
    return [sys.executable, "-B", "-m", "experiments.model_study", *map(str, args)]

def launch(repo, *args, check=True, timeout=900):
    run = subprocess.run(command(repo, *args), cwd=repo, env=ENV, capture_output=True, timeout=timeout)
    if check and run.returncode:
        raise RuntimeError((args, run.returncode, run.stderr.decode(errors="replace")[-4000:]))
    return run

def create_enrollment(repo, work, name, port, budget_name=None):
    from purser.adapters.model import LocalEndpoint
    from experiments.model_budget import ModelBudget, SpendingAuthority
    folder = work / name
    folder.mkdir()
    end = LocalEndpoint(port, MODEL, sha((HERE / "private_cli.py").read_bytes()), 6000,
        provider="Independent local canned fixture", provider_version="1", model_revision="synthetic-reference-1")
    policy = SpendingAuthority(sha(b"Reviewer local private zero-charge disposable qualification"),end.service_sha256,0,0,0)
    budget = work / ((budget_name or name) + ".sqlite3")
    ModelBudget.enroll(budget, policy)
    conditions = {"service": end.profile(), "authority": asdict(policy),
                  "observer": {"status":"qualified", "basis":"independent local WASI guest replay"},
                  "data": "synthetic-notification-and-arm-public-context"}
    (folder/"conditions.json").write_bytes(encode(conditions))
    series = folder/"series"
    launch(repo,"freeze",series,"--conditions",folder/"conditions.json","--budget",budget,"--population","canned_control")
    return series

def play(repo, work, s, series, unit, mode, label, *, qualify=True):
    labeldir = work/"wire"/label
    labeldir.mkdir(parents=True)
    s.mode = (mode, label, labeldir)
    s.calls[label]=[]
    args = ["collect",series,"--unit",unit]
    if qualify: args += ["--wasi-archives",ARCHIVES]
    if mode == "E2-interrupt":
        out = (labeldir/"collector.out").open("wb")
        err = (labeldir/"collector.err").open("wb")
        p = subprocess.Popen(command(repo,*args),cwd=repo,env=ENV,stdout=out,stderr=err,start_new_session=True)
        started = time.monotonic()
        while not s.arrived.wait(.25):
            if p.poll() is not None or time.monotonic()-started>720:
                raise RuntimeError(("physical fourth turn unavailable",p.poll(),s.errors))
        os.killpg(p.pid,signal.SIGKILL)
        exitcode = p.wait(timeout=30)
        s.release.set()
        out.close();err.close()
        if exitcode != -signal.SIGKILL: raise RuntimeError(("unexpected process status",exitcode))
        save(labeldir/"cut.json",{"actual_pid":p.pid,"signal":"SIGKILL","returncode":exitcode,"physical_posts_at_cut":len(s.calls[label])})
        restart = launch(repo,*args)
        (labeldir/"restart.err").write_bytes(restart.stderr)
    else:
        completed = launch(repo,*args)
        (labeldir/"collector.err").write_bytes(completed.stderr)
    case = series/"cases"/Path(unit)
    raw = case/"raw.json"
    before = sha(raw.read_bytes()) if raw.is_file() else None
    count = len(s.calls[label])
    launch(repo,*args)
    after = sha(raw.read_bytes()) if raw.is_file() else None
    if (after!=before or len(s.calls[label])!=count or s.errors or any(r["leaks"] for r in s.calls[label])):
        raise RuntimeError((unit,mode,s.errors,s.calls[label]))
    result = {"case": str(case), "index": label, "mode": mode, "raw_sha256": before, "observed_posts": count,
              "repeat_posts":len(s.calls[label])-count}
    print(label,mode,"posts",count,"raw",before,flush=True)
    return result

def main():
    args=argparse.ArgumentParser()
    args.add_argument("repo",type=Path);args.add_argument("out",type=Path)
    args.add_argument("--phase",choices=["prepare","full"],required=True)
    opt=args.parse_args();repo=opt.repo.resolve();work=opt.out.resolve()
    sys.path.insert(0,str(repo));work.mkdir(exist_ok=False)
    source=subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo).decode().strip()
    (work/"source.txt").write_text(source+"\n")
    empty=launch(repo,"report").stdout
    (work/"empty.md").write_bytes(empty)
    assert b"0 of 195 original" in empty and b"0 / 0 / 0 / 195" in empty
    if opt.phase=="prepare":
        save(work/"preparation.json",{"public_cli_read":True,"start_coverage":195,"reference":sha((HERE/"control.json").read_bytes()),
             "canned_module_sha256":{k:sha(v.encode()) for k,v in MODULES.items()},"standalone_choices":True})
        return
    service=Service(("127.0.0.1",0),Handler);service.calls={};service.errors=[];service.arrived=threading.Event();service.release=threading.Event()
    thread=threading.Thread(target=service.serve_forever,daemon=True);thread.start()
    results=[]
    try:
        enrolled={name:create_enrollment(repo,work,name,service.server_port) for name in ("comparison","repair","early","interrupted","transition","stress","unrelated")}
        choices=[("transition","E2/primary/2001/loop","E2-reopens","e2-double-reopen"),
            ("stress","E2/closed-affected/2001/loop","E2-stale-stress","e2-stale-stress"),
            ("unrelated","E2/primary/2001/loop","E2-unrelated","e2-unrelated-parent"),
            ("comparison","E1/primary/1002/purser","E1-bad","e1-purser"),
            ("comparison","E1/primary/1002/loop_equal_verifier","E1-bad","e1-equal"),
            ("comparison","E1/primary/1002/loop","E1-bad","e1-plain"),
            ("repair","E1/primary/1002/loop","E1-repair","e1-repaired"),
            ("comparison","E2/primary/2001/loop","E2-bad","e2-obsolete"),
            ("repair","E2/primary/2001/loop","E2-repair","e2-revised"),
            ("early","E2/primary/2001/loop","early","e2-unexposed"),
            ("interrupted","E2/primary/2001/loop","E2-interrupt","e2-interrupted")]
        for series,unit,mode,label in choices:
            result=play(repo,work,service,enrolled[series],unit,mode,label)
            results.append(result)
            save(work/"controls.json",results)
        for name,series in enrolled.items():
            first=launch(repo,"report",series).stdout
            assert first == launch(repo,"report",series).stdout and b"0 of 195 original" in first
            (work/(name+".md")).write_bytes(first)
    finally:
        service.release.set();service.shutdown();service.server_close();thread.join()

if __name__=="__main__":
    main()
