"""Exercise and compare a native landed E3 branch with its publicly displayed late HTTP failure."""
import json,subprocess,sys,threading
from pathlib import Path
import private_cli
from private_cli import Service,Handler,create_enrollment,play,save,sha,launch,encode
from e3_join import choose
class RateLimited(Handler):
    def do_POST(self):
        s=self.server;_,label,out=s.mode
        if len(s.calls[label])!=1: return super().do_POST()
        wire=self.rfile.read(int(self.headers["Content-Length"]));req=json.loads(wire)
        (out/"2.request.json").write_bytes(wire)
        obj={"model":req['model'],"error":{"message":"Local counting fixture returns an explicit rate limit.","type":"rate_limit"},"usage":{"prompt_tokens":31,"completion_tokens":0}}
        msg=encode(obj);(out/"2.response.json").write_bytes(msg)
        s.calls[label].append({'turn':2,'request_sha256':sha(wire),'response':obj,'http_status':429,'route':self.path,'leaks':[]})
        save(out/'posts.json',s.calls[label])
        self.send_response(429);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(msg)));self.end_headers()
        self.wfile.write(msg)
def main():
    repo=Path(sys.argv[1]).resolve();work=Path(sys.argv[2]).resolve();work.mkdir();sys.path.insert(0,str(repo));private_cli.choose=choose
    from experiments.model_study.report import inspect,field
    s=Service(("127.0.0.1",0),RateLimited);s.errors=[];s.calls={};s.release=threading.Event();s.arrived=threading.Event()
    t=threading.Thread(target=s.serve_forever,daemon=True);t.start()
    try:
        series=create_enrollment(repo,work,'registered',s.server_port);unit=('E3','primary',3013,'loop')
        row=play(repo,work,s,series,'E3/primary/3013/loop','read','late-429',qualify=False)
        physical=Path(row['case'])/'trial'/'canonical.git'
        reflog=subprocess.check_output(['git','--git-dir',str(physical),'reflog','show','--format=%H%x09%gs','refs/heads/notify']).decode().splitlines()
        effect=[s for s in reflog if '\tpurser.effect ' in s];assert len(effect)==1
        stdout=launch(repo,'report',series).stdout;assert stdout==launch(repo,'report',series).stdout
        (work/'report.md').write_bytes(stdout)
        text=stdout.decode().split('## E3\n',1)[1]
        table=next(s for s in text.splitlines() if s.startswith('| primary | 3013 | loop | '))
        header=next(s for s in text.splitlines() if s.startswith('| Track | Seed | Arm | Validity / terminal |'))
        keys=[v.strip() for v in header.strip('|').split('|')];vals=[v.strip() for v in table.strip('|').split('|')]
        visible=dict(zip(keys,vals,strict=True))
        _,cases=inspect(series);c=cases[unit];f=c['facts'];physical_n=row['observed_posts']
        assert physical_n==2 and c['cost'].exact['model_calls']==2 and c['cost'].exact['input_tokens']==55 and c['cost'].exact['output_tokens']==7 and c['cost'].exact['spend_usd_micros']==0
        assert row['repeat_posts']==0 and c['cost'].validity=='infrastructure_invalid' and f['effect_count']==1 and f['duplicate_count']==0 and f['original_truth']=='landed' and f['eligible']
        raw=json.loads((Path(row['case'])/'raw.json').read_bytes())
        assert raw['score'] is None
        diff={k:[f[k],visible[k]] for k in ('effect_count','duplicate_count','original_truth','eligible') if visible[k]!={True:'yes',False:'no'}.get(f[k],str(f[k]))}
        # Use explicitly typed displays; Python booleans compare equal to 0/1.
        matched=all(visible[k]==v for k,v in {'effect_count':'1','duplicate_count':'0','original_truth':'landed','eligible':'yes'}.items())
        record={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),'unit':unit,'row':row,'confirmed_reflog':effect,
            'raw_score':raw['score'],'native_fields':{k:f.get(k) for k in ('effect_count','duplicate_count','original_truth','eligible','correct_reconciliation','original_report','resolved_by_budget','stuck_requires_manual')},
            'costs':c['cost'].exact,'public':visible,'errors':c['errors'],'public_matches_observed_fields':matched,'report_sha256':sha(stdout)}
        save(work/'independent.json',record);print(sha((work/'independent.json').read_bytes()),'matches',matched)
    finally:s.release.set();s.shutdown();s.server_close();t.join()
if __name__=='__main__':main()
