import sys,threading,subprocess,json
from pathlib import Path
import private_cli
from private_cli import Service,Handler,create_enrollment,play,save,launch,sha
def choose(mode,turn,menu,h):
    intent=h[0]["intent"]
    if "dispatch" in menu: return {"action":"dispatch","arguments":{"effect":intent["effect"],"target":intent["target"]["digest"]}}
    last=[r for r in h if r["action"]=="effect"][-1]; attempt=last["attempt"]
    receipts=[r for r in h if r["action"]=="reconcile" and r["attempt"]==attempt]
    if not receipts and last["acknowledgment"]["status"]=="timeout":return {"action":"inspect","arguments":{"attempt":attempt}}
    use=(receipts or [last])[-1]
    observed=use["observation"]["state"] if receipts else "confirmed_happened"
    reported={"confirmed_happened":"landed","confirmed_absent":"unlanded","pending":"unknown"}[observed]
    reason=use["observation"]["reason"] if receipts else "guarded_write_acknowledged"
    if mode=="wrong" and attempt=="T1":
        assert observed=="confirmed_absent";reported="landed";reason="I deliberately close despite the explicitly absent first transaction."
    first=next((x["declaration"]["original_report"] for x in h if x["action"]=="decide"),reported)
    name={"landed":"complete","unlanded":"retry","unknown":"pending"}[reported]
    args={"attempt":attempt,"report":reported,"original_report":first,"reason":reason,"basis":use["source"]}
    if name!="complete":args["next_action"]="Get a fresh authorization for the eligible branch."
    return {"action":name,"arguments":args}
def main():
    repo=Path(sys.argv[1]).resolve();work=Path(sys.argv[2]).resolve();work.mkdir();sys.path.insert(0,str(repo)); private_cli.choose=choose
    from experiments.model_study.report import inspect
    s=Service(("127.0.0.1",0),Handler); s.errors=[];s.calls={};s.release=threading.Event();s.arrived=threading.Event()
    t=threading.Thread(target=s.serve_forever,daemon=True);t.start();allresults={}
    try:
        for label in ("read","wrong"):
            series=create_enrollment(repo,work,label,s.server_port);row=play(repo,work,s,series,"E3/primary/3008/loop",label,label,qualify=False)
            p=Path(row["case"]);git=p/"trial"/"canonical.git";log=subprocess.check_output(["git","--git-dir",str(git),"reflog","show","--format=%H%x09%gs","refs/heads/notify"]).decode().splitlines()
            effects=[x for x in log if "\tpurser.effect " in x];_,cases=inspect(series)
            c=cases[("E3","primary",3008,"loop")];f=c["facts"];assert f["effect_count"]==len(effects)
            assert c["cost"].exact["model_calls"]==row['observed_posts']
            allresults[label]={**row,"physical_native_events":effects,"facts":{k:f.get(k) for k in ("original_truth","original_report","effect_count","duplicate_count","correct_reconciliation","eligible","final_tip","first_model_exposure")},"exact":c['cost'].exact,"errors":c["errors"]}
            assert (len(effects),f["correct_reconciliation"]) == ((1,True) if label=="read" else (0,False))
            (work/(label+".md")).write_bytes(launch(repo,"report",series).stdout)
        assert all((work/"wire/read"/f"{i}.request.json").read_bytes()==(work/"wire/wrong"/f"{i}.request.json").read_bytes() for i in (1,2,3))
    finally:s.release.set();s.shutdown();s.server_close();t.join()
    save(work/"result.json",allresults);print(sha((work/"result.json").read_bytes()))
if __name__=="__main__":main()
