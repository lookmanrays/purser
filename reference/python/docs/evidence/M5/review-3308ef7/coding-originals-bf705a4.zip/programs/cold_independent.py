"""Read exact original public versions, Git packs and endpoint bytes without the study's score."""
import hashlib,json,subprocess,sys,tempfile
from pathlib import Path
from private_cli import MODULES,save,sha
CLOSED=('closed','done')
COLD_ROWS={}
def get(f):return json.loads(Path(f).read_bytes())
def ref(root,reference,raw=False):
    data=(root/reference["path"]).read_bytes()
    if sha(data)!=reference["sha256"] or len(data)!=reference["bytes"]:raise ValueError("invalid referenced artifact")
    return data if raw else json.loads(data)
def git(root,*args,data=None):
    return subprocess.check_output(["git","--git-dir",str(root),*args],input=data,stderr=subprocess.PIPE)
def pos(row):return (row["state"],row["candidate"] if not isinstance(row["candidate"],dict) else row["candidate"]["digest"])
def independent_plan(case,after_oid):
    physical=case/"trial"/"plan.json";current=physical.read_bytes()
    chain=[]
    while True:
        digest=sha(current);r=json.loads(current);v=r["W-notify"]["_e2_plan_version"]
        assert (case/"trial"/"plan-versions"/digest).read_bytes()==current
        chain.append((digest,v["number"],v["attempt"],r));parent=v["previous"]
        if parent is None: break
        current=(case/"trial"/"plan-versions"/parent).read_bytes()
        assert sha(current)==parent
    chain.reverse();assert [r[1] for r in chain]==list(range(1,len(chain)+1))
    hit=next(i for i,r in enumerate(chain) if r[0]==after_oid)
    after=chain[hit][3];before=chain[hit-1][3]
    reopened=[];closures=[]
    for i in range(hit,len(chain)):
        digest,n,a,rows=chain[i];prior=chain[i-1][3]
        for w in ('W1','W3'):
            if pos(prior[w])[0] in CLOSED and pos(rows[w])[0] not in CLOSED:
                reopened.append({"subject":w,"publication":n,"digest":digest,"prior_candidate":pos(prior[w])[1]})
        for w in ('W2','W-notify'):
            state,oid=pos(rows[w]);previous=pos(prior[w])
            if state in CLOSED and (i==hit or previous!=(state,oid)):
                closures.append({"subject":w,"candidate":oid,"publication":n,"digest":digest,"at_delivery":i==hit})
    return {"publications":len(chain),"before":{k:pos(v) for k,v in before.items()},
        "after":{k:pos(v) for k,v in after.items()},"notice":after["W2"]["premise"],"reopened":reopened,"closures":closures}
def examine(run,label,case,repo):
    raw=get(case/"raw.json");journal=ref(case,raw["artifacts"]["journal"])
    meta=ref(case,raw["artifacts"]["platform"]);candidates=ref(case,raw["artifacts"]["candidates"])
    series=case.parents[4];unit=(raw["experiment"],raw["track"],raw["seed"],raw["arm"])
    # Compare the independent native record with the publicly exposed offline presentation at the same point.
    from experiments.model_study.report import inspect,field
    if series not in COLD_ROWS: COLD_ROWS[series]=inspect(series)[1]
    native=COLD_ROWS[series];case_read=native[unit]
    result={"unit":unit,"actual_posts":len(get(run/"wire"/label/"posts.json")),"source":(run/"source.txt").read_text().strip(),
            "raw_sha256":sha((case/"raw.json").read_bytes()),"terminal":raw["terminal"],"case_validity":case_read["cost"].validity,
            "reader_facts":{k:v for k,v in case_read["facts"].items() if k in ("eligible","intervention_reached","unaffected_both_retained","unaffected_reopened","affected_invalid_closure","checkpoint_candidate","final_candidate","final_parent_closed","final_pass","stale_at_delivery","missing_named","false_parent_closure","correct_parent_closure","caught","rework_steps","collector_invocations","model_receipts","first_model_exposure","observed_steps")},
            "visible_fields":{k:field(native,unit,k) for k in ("eligible","intervention_reached","unaffected_reopened","stale_at_delivery","affected_invalid_closure","false_parent_closure")},
            "report_errors":case_read["errors"],"measured_cost_exact":dict(case_read["cost"].exact),"measured_cost_lower":dict(case_read["cost"].lower_bounds),
            "commit_states":{},"model_choices":[],"closures":[],"public_actors":{},"scope_violations":[]}
    protected={}
    for e in journal:
        p=e["payload"]
        if e["kind"]=="action":
            k=p["actor"];result["public_actors"][k]=result["public_actors"].get(k,0)+1
            if p.get("choice"):result["model_choices"].append([p.get("model_turn"),p["choice"]["action"],p["attempt"]])
        if e["kind"]=="public_state" and p["to"] in CLOSED and (p["from"] not in CLOSED) and p["subject"] in ("W2","W-notify"):
            result["closures"].append({"work":p["subject"],"git":p["candidate"],"seq":e["seq"],"publication":p["checkpoint"].get("plan_sha256") or p["checkpoint"].get("revision")})
        if e["kind"]=="oracle":
            code=(p["candidate"],p["version"],p["criterion"]);o=ref(case,p["evidence"])
            protected[code]={"reported":p["verdict"],"cases":o["cases"]}
    with tempfile.TemporaryDirectory() as t:
        db=Path(t)/"archive.git";subprocess.run(["git","init","--quiet","--bare",str(db)],check=True)
        for oid,entry in candidates.items():
            pack=ref(case,entry["pack"],raw=True)
            git(db,"index-pack","--stdin",data=pack)
            assert git(db,"rev-parse",oid+"^{tree}").decode().strip()==entry["tree"]
            changes=git(db,"diff","--name-only","55686bd5152e10a53dfdc2c003974ea405a3a075",oid).decode().splitlines()
            blobs={name:git(db,"show",oid+":notify/"+name+".py") for name in ("preferences","delivery","retry")}
            retry=next((model for model in ("linear","revised") if blobs["retry"]==MODULES[model].encode()),"other")
            good_pref=blobs["preferences"]==MODULES["preferences"].encode()
            bad_pref=b"    return True\n" in blobs["preferences"]
            good_delivery=blobs["delivery"]==MODULES["delivery"].encode()
            extras=sorted(set(changes)-{"notify/preferences.py","notify/delivery.py","notify/retry.py"})
            result["commit_states"][oid]={"tree":entry["tree"],"extra":extras,"retry":retry,"good_preferences":good_pref,"bad_preferences":bad_pref,
                "good_delivery":good_delivery,"captured_grade":{str(law)+" "+label:v["reported"] for (c,law,label),v in protected.items() if c==oid}}
        if unit[0]=="E2" and unit[3]!="purser":
            fault=next((r["payload"] for r in journal if r["kind"]=="fault"),None)
            if fault:
                orig=independent_plan(case,fault["after"]["plan_sha256"])
                orig["before_plan_sha256"]=fault["before"]["plan_sha256"];orig["after_plan_sha256"]=fault["after"]["plan_sha256"]
                for closure in orig["closures"]:
                    st=result["commit_states"][closure["candidate"]]
                    closure["changed_retry_pass"]=st["retry"]=="revised"
                    if st["retry"]=="other":raise ValueError("this fixture only considers independently known sources")
                orig["stale_at_delivery"]=any(c["at_delivery"] and not c["changed_retry_pass"] for c in orig["closures"])
                orig["new_bad"]=any(not c["at_delivery"] and not c["changed_retry_pass"] for c in orig["closures"])
                orig["any_bad"]=any(not c["changed_retry_pass"] for c in orig["closures"])
                result["physical_plan"]=orig
    if unit[0]=="E1":
        for original in result["closures"]:
            if original["work"]=="W-notify":
                state=result["commit_states"][original["git"]]
                if state["extra"]:result["scope_violations"].append({"closure":original,"physical_paths":state["extra"]})
    return result

def main():
    repo=Path(sys.argv[1]).resolve();run=Path(sys.argv[2]).resolve();sys.path.insert(0,str(repo))
    rows=get(run/"controls.json");take=sys.argv[3:]
    summary={}
    for d in rows:
        label=d["index"]
        if take and label not in take:continue
        out=run/(label+"-independent.json")
        result=examine(run,label,Path(d["case"]),repo);save(out,result)
        summary[label]={"digest":sha(out.read_bytes()),"calls":result["actual_posts"],"terminal":result["terminal"],"errors":result["report_errors"],
            "reader":{k:result["reader_facts"].get(k) for k in ("eligible","unaffected_reopened","stale_at_delivery","affected_invalid_closure","false_parent_closure","final_pass")},
            "witness":{k:result.get("physical_plan",{}).get(k) for k in ("reopened","stale_at_delivery","new_bad","any_bad")}}
    print(json.dumps(summary,sort_keys=True))
if __name__=="__main__": main()
