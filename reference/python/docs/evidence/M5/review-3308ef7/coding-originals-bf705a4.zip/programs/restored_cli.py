"""Rerun the earlier originals unchanged on the exact corrected source."""
import sys,json,subprocess,threading
from pathlib import Path
from private_cli import Service,Handler,create_enrollment,play,save,launch
class LocalLateError(Handler):
    def send_header(self,key,value):
        mode,label,_=self.server.mode
        if label=='after-return-error' and key=="Content-Type" and len(self.server.calls[label])==6:
            value="text/plain"
        return super().send_header(key,value)
def main():
    repo=Path(sys.argv[1]).resolve();work=Path(sys.argv[2]).resolve();work.mkdir()
    sys.path.insert(0,str(repo))
    sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()
    (work/'source.txt').write_text(sha+'\n')
    (work/'empty.md').write_bytes(launch(repo,'report').stdout)
    service=Service(("127.0.0.1",0),LocalLateError);service.calls={};service.errors=[];service.arrived=threading.Event();service.release=threading.Event()
    t=threading.Thread(target=service.serve_forever,daemon=True);t.start()
    rows=[]
    try:
        schedule=[('e2-double-reopen','E2/primary/2001/loop','E2-reopens'),('e2-stale-stress','E2/closed-affected/2001/loop','E2-stale-stress'),
                  ('e2-unrelated-parent','E2/primary/2001/loop','E2-unrelated'),('e2-interrupted','E2/primary/2001/loop','E2-interrupt'),
                  ('after-return-error','E2/primary/2001/loop','E2-reopens'),('e2-obsolete','E2/primary/2001/loop','E2-bad'),('e2-revised','E2/primary/2001/loop','E2-repair'),
                  ('e1-plain','E1/primary/1002/loop','E1-bad')]
        for label,unit,mode in schedule:
            series=create_enrollment(repo,work,label,service.server_port)
            rows.append(play(repo,work,service,series,unit,mode,label))
            save(work/'controls.json',rows)
    finally:
        service.release.set();service.shutdown();service.server_close();t.join()
    print('ORIGINAL_NATIVE_SERIES_SEALED',flush=True)
if __name__=='__main__':main()
