import json
import os
from pathlib import Path
import socket
import sys
import threading
from private_cli import Handler, Service, create_enrollment, launch, save, sha
def get(path):
    return json.loads(path.read_bytes())
def main():
    repo=Path(sys.argv[1]).resolve()
    work=Path(sys.argv[2]).resolve()
    work.mkdir()
    sys.path.insert(0,str(repo))
    from experiments.model_study.report import inspect
    code={}
    with socket.socket() as bound:
        bound.bind(("127.0.0.1",0))
        series=create_enrollment(repo,work,"offline",bound.getsockname()[1])
        args=("collect",series,"--unit","E1/primary/1001/loop","--unit","E3/primary/3001/loop")
        for _ in range(2):launch(repo,*args)
        rendered=launch(repo,"report",series).stdout
        (work/"offline.md").write_bytes(rendered)
        _,cases=inspect(series)
        for unit,case in cases.items():
            root=series/"cases"/unit[0]/unit[1]/str(unit[2])/unit[3]
            raw=get(root/"raw.json")
            jref=raw["artifacts"]["journal"];journal=get(root/jref["path"])
            sref=get(root/"session.json");session=get(root/sref["path"])
            turns=[]
            for t in session["turns"]:
                if t.get("record"):
                    record=get(root/t["record"]["path"])
                    turns.append({"wire_state":record["transport"]["wire_state"],"status":record["transport"]["http_status"],"usage":record["usage"]})
            row={"port_bound_without_listen":bound.getsockname()[1],"unit":unit,"raw_sha256":sha((root/"raw.json").read_bytes()),
                 "registered_population":"canned_control","cost_exact":case["cost"].exact,"cost_lower":case["cost"].lower_bounds,
                 "public_steps":sum(r["kind"]=="action" for r in journal),"public_attempted_model_choices":sum(r["kind"]=="action" and r["payload"]["action"]=="decide" for r in journal),
                 "turns":turns,"first_exposure":case["facts"].get("first_model_exposure"),"validity":case["cost"].validity,"terminal":case["terminal"],"errors":case['errors']}
            assert row["cost_exact"]["model_calls"]==0 and row["first_exposure"] is None,row
            assert row["cost_exact"]["input_tokens"]==0 and row["cost_exact"]["output_tokens"]==0,row
            if unit[0]=="E3":assert len(turns)==1 and turns[0]["wire_state"]=="not_sent" and row["public_attempted_model_choices"]==1,row
            if unit[0]=="E1":assert not turns and "observer" in str(row["errors"]),row
            code[unit[0]]=row
    save(work/"wire-controls.json",code)
    print(json.dumps({k:(v["cost_exact"]["model_calls"],v["public_attempted_model_choices"],v["validity"]) for k,v in code.items()}))
if __name__=="__main__":main()
