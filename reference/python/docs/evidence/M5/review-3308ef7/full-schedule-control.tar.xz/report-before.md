# Notification model study · canned_control

Replicate 1 on `142c9735f52d470686fbe82dfb0a3c83afa1295b`. Service `full-schedule-canned-control`. 195 of 195 scheduled case directories are present.

Registered provider, provider version and model revision — private-loopback-qualification / 1 / no-trained-model.

This report contains **0 of 195 original real-model observations**. The original model criterion is open. Canned and disabled cases exercise the harness.

| Experiment | Absolute threshold | Original no-advantage | Diagnostic absolute / no-advantage |
| --- | --- | --- | --- |
| E1 | ? | ? | ? / ? |
| E2 | ? | ? | ? / ? |
| E3 | yes | no | yes / no |

Thresholds use the 20 primary seeds per arm. E1 requires zero false parent closures and at least 19 named faults. A baseline catching at least 19 establishes the E1 no-advantage predicate. E2 requires 18 retained sibling pairs, at most half the baseline’s total rework and at least its final pass count. Equal or higher rework or a lower pass count establishes E2 no-advantage. E3 requires 20 correct, completed recoveries and zero duplicates. Any duplicate or ordinary stuck case requiring manual repair establishes its separate adverse predicate.

## E1

Primary totals show the sum, measurable count and scheduled count.

| Measure | Plain loop | Purser | Equal verifier |
| --- | ---: | ---: | ---: |
| false_parent_closure | ? / 0 / 20 | ? / 0 / 20 | ? / 0 / 20 |
| missing_named | ? / 0 / 20 | ? / 0 / 20 | ? / 0 / 20 |
| caught | ? / 0 / 20 | ? / 0 / 20 | ? / 0 / 20 |
| correct_parent_closure | ? / 0 / 20 | ? / 0 / 20 | ? / 0 / 20 |
| extra_diagnoses | ? / 0 / 20 | ? / 0 / 20 | ? / 0 / 20 |

### Case measurements

| Track | Seed | Arm | Validity / terminal | false_parent_closure | missing_named | caught | correct_parent_closure | extra_diagnoses | eligible | final_pass | final_parent_closed | steps | elapsed_ns | model_calls | input_tokens | output_tokens | spend_usd_micros |
| --- | ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| primary | 1001 | loop | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 82263708 | 2 | 38 | 14 | 0 |
| primary | 1001 | purser | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 115797917 | 2 | 38 | 14 | 0 |
| primary | 1001 | loop_equal_verifier | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 86907708 | 2 | 38 | 14 | 0 |
| primary | 1002 | purser | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 112117875 | 2 | 38 | 14 | 0 |
| primary | 1002 | loop_equal_verifier | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 79637750 | 2 | 38 | 14 | 0 |
| primary | 1002 | loop | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 90060500 | 2 | 38 | 14 | 0 |
| primary | 1003 | loop_equal_verifier | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 89530459 | 2 | 38 | 14 | 0 |
| primary | 1003 | loop | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 78920333 | 2 | 38 | 14 | 0 |
| primary | 1003 | purser | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 113542875 | 2 | 38 | 14 | 0 |
| primary | 1004 | loop | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 79919000 | 2 | 38 | 14 | 0 |
| primary | 1004 | purser | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 132704833 | 2 | 38 | 14 | 0 |
| primary | 1004 | loop_equal_verifier | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 93344542 | 2 | 38 | 14 | 0 |
| primary | 1005 | purser | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 117377833 | 2 | 38 | 14 | 0 |
| primary | 1005 | loop_equal_verifier | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 97112334 | 2 | 38 | 14 | 0 |
| primary | 1005 | loop | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 83007125 | 2 | 38 | 14 | 0 |
| primary | 1006 | loop_equal_verifier | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 88261375 | 2 | 38 | 14 | 0 |
| primary | 1006 | loop | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 80144667 | 2 | 38 | 14 | 0 |
| primary | 1006 | purser | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 124367875 | 2 | 38 | 14 | 0 |
| primary | 1007 | loop | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 83044708 | 2 | 38 | 14 | 0 |
| primary | 1007 | purser | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 124254917 | 2 | 38 | 14 | 0 |
| primary | 1007 | loop_equal_verifier | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 85116792 | 2 | 38 | 14 | 0 |
| primary | 1008 | purser | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 120555583 | 2 | 38 | 14 | 0 |
| primary | 1008 | loop_equal_verifier | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 97507833 | 2 | 38 | 14 | 0 |
| primary | 1008 | loop | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 103060125 | 2 | 38 | 14 | 0 |
| primary | 1009 | loop_equal_verifier | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 86008542 | 2 | 38 | 14 | 0 |
| primary | 1009 | loop | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 96032291 | 2 | 38 | 14 | 0 |
| primary | 1009 | purser | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 117022542 | 2 | 38 | 14 | 0 |
| primary | 1010 | loop | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 103595167 | 2 | 38 | 14 | 0 |
| primary | 1010 | purser | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 125053834 | 2 | 38 | 14 | 0 |
| primary | 1010 | loop_equal_verifier | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 87533500 | 2 | 38 | 14 | 0 |
| primary | 1011 | purser | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 120051541 | 2 | 38 | 14 | 0 |
| primary | 1011 | loop_equal_verifier | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 89355708 | 2 | 38 | 14 | 0 |
| primary | 1011 | loop | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 87545458 | 2 | 38 | 14 | 0 |
| primary | 1012 | loop_equal_verifier | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 83680916 | 2 | 38 | 14 | 0 |
| primary | 1012 | loop | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 85142709 | 2 | 38 | 14 | 0 |
| primary | 1012 | purser | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 119023916 | 2 | 38 | 14 | 0 |
| primary | 1013 | loop | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 89924000 | 2 | 38 | 14 | 0 |
| primary | 1013 | purser | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 138988250 | 2 | 38 | 14 | 0 |
| primary | 1013 | loop_equal_verifier | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 88756208 | 2 | 38 | 14 | 0 |
| primary | 1014 | purser | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 119498875 | 2 | 38 | 14 | 0 |
| primary | 1014 | loop_equal_verifier | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 100442958 | 2 | 38 | 14 | 0 |
| primary | 1014 | loop | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 85904250 | 2 | 38 | 14 | 0 |
| primary | 1015 | loop_equal_verifier | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 83884625 | 2 | 38 | 14 | 0 |
| primary | 1015 | loop | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 113779625 | 2 | 38 | 14 | 0 |
| primary | 1015 | purser | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 123082709 | 2 | 38 | 14 | 0 |
| primary | 1016 | loop | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 84272542 | 2 | 38 | 14 | 0 |
| primary | 1016 | purser | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 128585167 | 2 | 38 | 14 | 0 |
| primary | 1016 | loop_equal_verifier | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 85263916 | 2 | 38 | 14 | 0 |
| primary | 1017 | purser | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 128489166 | 2 | 38 | 14 | 0 |
| primary | 1017 | loop_equal_verifier | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 104063625 | 2 | 38 | 14 | 0 |
| primary | 1017 | loop | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 84602833 | 2 | 38 | 14 | 0 |
| primary | 1018 | loop_equal_verifier | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 91948583 | 2 | 38 | 14 | 0 |
| primary | 1018 | loop | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 91718209 | 2 | 38 | 14 | 0 |
| primary | 1018 | purser | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 122184166 | 2 | 38 | 14 | 0 |
| primary | 1019 | loop | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 88657791 | 2 | 38 | 14 | 0 |
| primary | 1019 | purser | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 124855917 | 2 | 38 | 14 | 0 |
| primary | 1019 | loop_equal_verifier | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 92783250 | 2 | 38 | 14 | 0 |
| primary | 1020 | purser | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 146264125 | 2 | 38 | 14 | 0 |
| primary | 1020 | loop_equal_verifier | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 85232584 | 2 | 38 | 14 | 0 |
| primary | 1020 | loop | incomplete / blocked | no | ? | ? | no | ? | no | no | no | 8 | 85459208 | 2 | 38 | 14 | 0 |
| clean | 1001 | loop | incomplete / blocked | no | ? | ? | no | ? | yes | no | no | 8 | 84908542 | 2 | 38 | 14 | 0 |
| clean | 1001 | purser | incomplete / blocked | no | ? | ? | no | ? | yes | no | no | 8 | 122000250 | 2 | 38 | 14 | 0 |
| clean | 1001 | loop_equal_verifier | incomplete / blocked | no | ? | ? | no | ? | yes | no | no | 8 | 91738333 | 2 | 38 | 14 | 0 |

### Paired differences

Each cell subtracts that comparator from Purser in this order — false_parent_closure, missing_named, caught, correct_parent_closure, extra_diagnoses, steps, elapsed_ns, model_calls, input_tokens, output_tokens, spend_usd_micros.

| Track / seed | Purser minus plain loop | Purser minus equal verifier |
| --- | --- | --- |
| primary / 1001 | ? / ? / ? / ? / ? / 0 / 33534209 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / 0 / 28890209 / 0 / 0 / 0 / 0 |
| primary / 1002 | ? / ? / ? / ? / ? / 0 / 22057375 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / 0 / 32480125 / 0 / 0 / 0 / 0 |
| primary / 1003 | ? / ? / ? / ? / ? / 0 / 34622542 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / 0 / 24012416 / 0 / 0 / 0 / 0 |
| primary / 1004 | ? / ? / ? / ? / ? / 0 / 52785833 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / 0 / 39360291 / 0 / 0 / 0 / 0 |
| primary / 1005 | ? / ? / ? / ? / ? / 0 / 34370708 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / 0 / 20265499 / 0 / 0 / 0 / 0 |
| primary / 1006 | ? / ? / ? / ? / ? / 0 / 44223208 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / 0 / 36106500 / 0 / 0 / 0 / 0 |
| primary / 1007 | ? / ? / ? / ? / ? / 0 / 41210209 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / 0 / 39138125 / 0 / 0 / 0 / 0 |
| primary / 1008 | ? / ? / ? / ? / ? / 0 / 17495458 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / 0 / 23047750 / 0 / 0 / 0 / 0 |
| primary / 1009 | ? / ? / ? / ? / ? / 0 / 20990251 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / 0 / 31014000 / 0 / 0 / 0 / 0 |
| primary / 1010 | ? / ? / ? / ? / ? / 0 / 21458667 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / 0 / 37520334 / 0 / 0 / 0 / 0 |
| primary / 1011 | ? / ? / ? / ? / ? / 0 / 32506083 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / 0 / 30695833 / 0 / 0 / 0 / 0 |
| primary / 1012 | ? / ? / ? / ? / ? / 0 / 33881207 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / 0 / 35343000 / 0 / 0 / 0 / 0 |
| primary / 1013 | ? / ? / ? / ? / ? / 0 / 49064250 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / 0 / 50232042 / 0 / 0 / 0 / 0 |
| primary / 1014 | ? / ? / ? / ? / ? / 0 / 33594625 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / 0 / 19055917 / 0 / 0 / 0 / 0 |
| primary / 1015 | ? / ? / ? / ? / ? / 0 / 9303084 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / 0 / 39198084 / 0 / 0 / 0 / 0 |
| primary / 1016 | ? / ? / ? / ? / ? / 0 / 44312625 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / 0 / 43321251 / 0 / 0 / 0 / 0 |
| primary / 1017 | ? / ? / ? / ? / ? / 0 / 43886333 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / 0 / 24425541 / 0 / 0 / 0 / 0 |
| primary / 1018 | ? / ? / ? / ? / ? / 0 / 30465957 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / 0 / 30235583 / 0 / 0 / 0 / 0 |
| primary / 1019 | ? / ? / ? / ? / ? / 0 / 36198126 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / 0 / 32072667 / 0 / 0 / 0 / 0 |
| primary / 1020 | ? / ? / ? / ? / ? / 0 / 60804917 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / 0 / 61031541 / 0 / 0 / 0 / 0 |
| clean / 1001 | 0 / ? / ? / 0 / ? / 0 / 37091708 / 0 / 0 / 0 / 0 | 0 / ? / ? / 0 / ? / 0 / 30261917 / 0 / 0 / 0 / 0 |

Healthy matched clean pair above twice plain-loop steps — ?.

## E2

Primary totals show the sum, measurable count and scheduled count.

| Measure | Plain loop | Purser | Equal verifier |
| --- | ---: | ---: | ---: |
| intervention_reached | 0 / 20 / 20 | 0 / 20 / 20 | 0 / 20 / 20 |
| unaffected_both_retained | ? / 0 / 20 | ? / 0 / 20 | ? / 0 / 20 |
| unaffected_reopened | ? / 0 / 20 | ? / 0 / 20 | ? / 0 / 20 |
| affected_invalid_closure | ? / 0 / 20 | ? / 0 / 20 | ? / 0 / 20 |
| rework_steps | ? / 0 / 20 | ? / 0 / 20 | ? / 0 / 20 |
| final_pass | ? / 0 / 20 | ? / 0 / 20 | ? / 0 / 20 |

Total rework ratio, Purser / loop — ?.

Total rework ratio, Purser / loop_equal_verifier — ?.

### Case measurements

| Track | Seed | Arm | Validity / terminal | intervention_reached | unaffected_both_retained | unaffected_reopened | affected_invalid_closure | rework_steps | final_pass | eligible | publicly_delivered | checkpoint_candidate | stale_at_delivery | new_bad_closure | observed_retention | observed_reopened | reopened_subjects | observed_invalid_closure | rework_observed | final_parent_closed | steps | elapsed_ns | model_calls | input_tokens | output_tokens | spend_usd_micros |
| --- | ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| primary | 2001 | purser | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 128609125 | 2 | 38 | 14 | 0 |
| primary | 2001 | loop_equal_verifier | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 91661291 | 2 | 38 | 14 | 0 |
| primary | 2001 | loop | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 86757500 | 2 | 38 | 14 | 0 |
| primary | 2002 | loop_equal_verifier | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 85440250 | 2 | 38 | 14 | 0 |
| primary | 2002 | loop | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 86793958 | 2 | 38 | 14 | 0 |
| primary | 2002 | purser | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 128895584 | 2 | 38 | 14 | 0 |
| primary | 2003 | loop | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 84397792 | 2 | 38 | 14 | 0 |
| primary | 2003 | purser | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 132475708 | 2 | 38 | 14 | 0 |
| primary | 2003 | loop_equal_verifier | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 91761875 | 2 | 38 | 14 | 0 |
| primary | 2004 | purser | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 125492041 | 2 | 38 | 14 | 0 |
| primary | 2004 | loop_equal_verifier | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 110590417 | 2 | 38 | 14 | 0 |
| primary | 2004 | loop | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 99383500 | 2 | 38 | 14 | 0 |
| primary | 2005 | loop_equal_verifier | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 92321000 | 2 | 38 | 14 | 0 |
| primary | 2005 | loop | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 95778875 | 2 | 38 | 14 | 0 |
| primary | 2005 | purser | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 128976541 | 2 | 38 | 14 | 0 |
| primary | 2006 | loop | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 93877333 | 2 | 38 | 14 | 0 |
| primary | 2006 | purser | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 137412709 | 2 | 38 | 14 | 0 |
| primary | 2006 | loop_equal_verifier | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 88345125 | 2 | 38 | 14 | 0 |
| primary | 2007 | purser | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 127282667 | 2 | 38 | 14 | 0 |
| primary | 2007 | loop_equal_verifier | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 97577625 | 2 | 38 | 14 | 0 |
| primary | 2007 | loop | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 95251875 | 2 | 38 | 14 | 0 |
| primary | 2008 | loop_equal_verifier | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 98234916 | 2 | 38 | 14 | 0 |
| primary | 2008 | loop | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 87513959 | 2 | 38 | 14 | 0 |
| primary | 2008 | purser | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 135374292 | 2 | 38 | 14 | 0 |
| primary | 2009 | loop | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 90960333 | 2 | 38 | 14 | 0 |
| primary | 2009 | purser | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 128311041 | 2 | 38 | 14 | 0 |
| primary | 2009 | loop_equal_verifier | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 142826792 | 2 | 38 | 14 | 0 |
| primary | 2010 | purser | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 126362500 | 2 | 38 | 14 | 0 |
| primary | 2010 | loop_equal_verifier | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 91752875 | 2 | 38 | 14 | 0 |
| primary | 2010 | loop | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 85737292 | 2 | 38 | 14 | 0 |
| primary | 2011 | loop_equal_verifier | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 91899834 | 2 | 38 | 14 | 0 |
| primary | 2011 | loop | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 100762958 | 2 | 38 | 14 | 0 |
| primary | 2011 | purser | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 127374958 | 2 | 38 | 14 | 0 |
| primary | 2012 | loop | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 86272750 | 2 | 38 | 14 | 0 |
| primary | 2012 | purser | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 128085500 | 2 | 38 | 14 | 0 |
| primary | 2012 | loop_equal_verifier | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 87381584 | 2 | 38 | 14 | 0 |
| primary | 2013 | purser | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 128547542 | 2 | 38 | 14 | 0 |
| primary | 2013 | loop_equal_verifier | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 92344208 | 2 | 38 | 14 | 0 |
| primary | 2013 | loop | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 109423375 | 2 | 38 | 14 | 0 |
| primary | 2014 | loop_equal_verifier | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 89424000 | 2 | 38 | 14 | 0 |
| primary | 2014 | loop | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 87886125 | 2 | 38 | 14 | 0 |
| primary | 2014 | purser | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 147565166 | 2 | 38 | 14 | 0 |
| primary | 2015 | loop | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 86538334 | 2 | 38 | 14 | 0 |
| primary | 2015 | purser | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 128669208 | 2 | 38 | 14 | 0 |
| primary | 2015 | loop_equal_verifier | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 90411417 | 2 | 38 | 14 | 0 |
| primary | 2016 | purser | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 131136458 | 2 | 38 | 14 | 0 |
| primary | 2016 | loop_equal_verifier | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 115525625 | 2 | 38 | 14 | 0 |
| primary | 2016 | loop | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 116839875 | 2 | 38 | 14 | 0 |
| primary | 2017 | loop_equal_verifier | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 97962792 | 2 | 38 | 14 | 0 |
| primary | 2017 | loop | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 85610584 | 2 | 38 | 14 | 0 |
| primary | 2017 | purser | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 129166042 | 2 | 38 | 14 | 0 |
| primary | 2018 | loop | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 90660291 | 2 | 38 | 14 | 0 |
| primary | 2018 | purser | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 153130916 | 2 | 38 | 14 | 0 |
| primary | 2018 | loop_equal_verifier | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 92074083 | 2 | 38 | 14 | 0 |
| primary | 2019 | purser | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 162478542 | 2 | 38 | 14 | 0 |
| primary | 2019 | loop_equal_verifier | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 87746916 | 2 | 38 | 14 | 0 |
| primary | 2019 | loop | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 86934708 | 2 | 38 | 14 | 0 |
| primary | 2020 | loop_equal_verifier | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 118378042 | 2 | 38 | 14 | 0 |
| primary | 2020 | loop | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 86495250 | 2 | 38 | 14 | 0 |
| primary | 2020 | purser | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 145279541 | 2 | 38 | 14 | 0 |
| clean | 2001 | purser | incomplete / blocked | ? | ? | ? | ? | ? | no | yes | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 151297792 | 2 | 38 | 14 | 0 |
| clean | 2001 | loop_equal_verifier | incomplete / blocked | ? | ? | ? | ? | ? | no | yes | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 107086500 | 2 | 38 | 14 | 0 |
| clean | 2001 | loop | incomplete / blocked | ? | ? | ? | ? | ? | no | yes | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 99027000 | 2 | 38 | 14 | 0 |
| closed-affected | 2001 | purser | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 129232167 | 2 | 38 | 14 | 0 |
| closed-affected | 2001 | loop_equal_verifier | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 124377708 | 2 | 38 | 14 | 0 |
| closed-affected | 2001 | loop | incomplete / blocked | no | ? | ? | ? | ? | no | no | no | ? | ? | ? | ? | ? | ∅ | ? | ? | no | 8 | 87318458 | 2 | 38 | 14 | 0 |

### Paired differences

Each cell subtracts that comparator from Purser in this order — intervention_reached, unaffected_both_retained, unaffected_reopened, affected_invalid_closure, rework_steps, final_pass, steps, elapsed_ns, model_calls, input_tokens, output_tokens, spend_usd_micros.

| Track / seed | Purser minus plain loop | Purser minus equal verifier |
| --- | --- | --- |
| primary / 2001 | ? / ? / ? / ? / ? / ? / 0 / 41851625 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / ? / 0 / 36947834 / 0 / 0 / 0 / 0 |
| primary / 2002 | ? / ? / ? / ? / ? / ? / 0 / 42101626 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / ? / 0 / 43455334 / 0 / 0 / 0 / 0 |
| primary / 2003 | ? / ? / ? / ? / ? / ? / 0 / 48077916 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / ? / 0 / 40713833 / 0 / 0 / 0 / 0 |
| primary / 2004 | ? / ? / ? / ? / ? / ? / 0 / 26108541 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / ? / 0 / 14901624 / 0 / 0 / 0 / 0 |
| primary / 2005 | ? / ? / ? / ? / ? / ? / 0 / 33197666 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / ? / 0 / 36655541 / 0 / 0 / 0 / 0 |
| primary / 2006 | ? / ? / ? / ? / ? / ? / 0 / 43535376 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / ? / 0 / 49067584 / 0 / 0 / 0 / 0 |
| primary / 2007 | ? / ? / ? / ? / ? / ? / 0 / 32030792 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / ? / 0 / 29705042 / 0 / 0 / 0 / 0 |
| primary / 2008 | ? / ? / ? / ? / ? / ? / 0 / 47860333 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / ? / 0 / 37139376 / 0 / 0 / 0 / 0 |
| primary / 2009 | ? / ? / ? / ? / ? / ? / 0 / 37350708 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / ? / 0 / -14515751 / 0 / 0 / 0 / 0 |
| primary / 2010 | ? / ? / ? / ? / ? / ? / 0 / 40625208 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / ? / 0 / 34609625 / 0 / 0 / 0 / 0 |
| primary / 2011 | ? / ? / ? / ? / ? / ? / 0 / 26612000 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / ? / 0 / 35475124 / 0 / 0 / 0 / 0 |
| primary / 2012 | ? / ? / ? / ? / ? / ? / 0 / 41812750 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / ? / 0 / 40703916 / 0 / 0 / 0 / 0 |
| primary / 2013 | ? / ? / ? / ? / ? / ? / 0 / 19124167 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / ? / 0 / 36203334 / 0 / 0 / 0 / 0 |
| primary / 2014 | ? / ? / ? / ? / ? / ? / 0 / 59679041 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / ? / 0 / 58141166 / 0 / 0 / 0 / 0 |
| primary / 2015 | ? / ? / ? / ? / ? / ? / 0 / 42130874 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / ? / 0 / 38257791 / 0 / 0 / 0 / 0 |
| primary / 2016 | ? / ? / ? / ? / ? / ? / 0 / 14296583 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / ? / 0 / 15610833 / 0 / 0 / 0 / 0 |
| primary / 2017 | ? / ? / ? / ? / ? / ? / 0 / 43555458 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / ? / 0 / 31203250 / 0 / 0 / 0 / 0 |
| primary / 2018 | ? / ? / ? / ? / ? / ? / 0 / 62470625 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / ? / 0 / 61056833 / 0 / 0 / 0 / 0 |
| primary / 2019 | ? / ? / ? / ? / ? / ? / 0 / 75543834 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / ? / 0 / 74731626 / 0 / 0 / 0 / 0 |
| primary / 2020 | ? / ? / ? / ? / ? / ? / 0 / 58784291 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / ? / 0 / 26901499 / 0 / 0 / 0 / 0 |
| clean / 2001 | ? / ? / ? / ? / ? / 0 / 0 / 52270792 / 0 / 0 / 0 / 0 | ? / ? / ? / ? / ? / 0 / 0 / 44211292 / 0 / 0 / 0 / 0 |
| closed-affected / 2001 | 0 / ? / ? / ? / ? / 0 / 0 / 41913709 / 0 / 0 / 0 / 0 | 0 / ? / ? / ? / ? / 0 / 0 / 4854459 / 0 / 0 / 0 / 0 |

Healthy matched clean pair above twice plain-loop steps — ?.

## E3

Primary totals show the sum, measurable count and scheduled count.

| Measure | Plain loop | Purser | Equal verifier |
| --- | ---: | ---: | ---: |
| correct_reconciliation | 20 / 20 / 20 | 20 / 20 / 20 | 20 / 20 / 20 |
| duplicate_count | 0 / 20 / 20 | 0 / 20 / 20 | 0 / 20 / 20 |
| effect_count | 20 / 20 / 20 | 20 / 20 / 20 | 20 / 20 / 20 |
| resolved_by_budget | 20 / 20 / 20 | 20 / 20 / 20 | 20 / 20 / 20 |
| stuck_requires_manual | 0 / 20 / 20 | 0 / 20 / 20 | 0 / 20 / 20 |
| manual_repair | 0 / 20 / 20 | 0 / 20 / 20 | 0 / 20 / 20 |

Each case shows the Git and participant observations its sources establish. Outcome differences require two exposed, usable cases. A later infrastructure failure leaves a witnessed duplicate or ordinary stuck state relevant to the registered adverse predicate.

### Case measurements

| Track | Seed | Arm | Validity / terminal | correct_reconciliation | duplicate_count | effect_count | resolved_by_budget | stuck_requires_manual | manual_repair | eligible | original_truth | original_report | justified_in_order | uncertainty_remaining | steps | elapsed_ns | model_calls | input_tokens | output_tokens | spend_usd_micros |
| --- | ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| primary | 3001 | loop_equal_verifier | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 834586250 | 2 | 38 | 14 | 0 |
| primary | 3001 | loop | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 749055916 | 3 | 57 | 21 | 0 |
| primary | 3001 | purser | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 790511333 | 2 | 38 | 14 | 0 |
| primary | 3002 | loop | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 7 | 942795833 | 4 | 76 | 28 | 0 |
| primary | 3002 | purser | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 8 | 1242731542 | 3 | 57 | 21 | 0 |
| primary | 3002 | loop_equal_verifier | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 8 | 1151384458 | 3 | 57 | 21 | 0 |
| primary | 3003 | purser | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 773901041 | 2 | 38 | 14 | 0 |
| primary | 3003 | loop_equal_verifier | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 750873167 | 2 | 38 | 14 | 0 |
| primary | 3003 | loop | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 743767083 | 3 | 57 | 21 | 0 |
| primary | 3004 | loop_equal_verifier | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 8 | 1212219583 | 3 | 57 | 21 | 0 |
| primary | 3004 | loop | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 7 | 880405292 | 4 | 76 | 28 | 0 |
| primary | 3004 | purser | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 8 | 1211539083 | 3 | 57 | 21 | 0 |
| primary | 3005 | loop | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 763458833 | 3 | 57 | 21 | 0 |
| primary | 3005 | purser | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 769816042 | 2 | 38 | 14 | 0 |
| primary | 3005 | loop_equal_verifier | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 725445666 | 2 | 38 | 14 | 0 |
| primary | 3006 | purser | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 8 | 1195448792 | 3 | 57 | 21 | 0 |
| primary | 3006 | loop_equal_verifier | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 8 | 1268656291 | 3 | 57 | 21 | 0 |
| primary | 3006 | loop | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 7 | 936890792 | 4 | 76 | 28 | 0 |
| primary | 3007 | loop_equal_verifier | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 802723916 | 2 | 38 | 14 | 0 |
| primary | 3007 | loop | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 720389583 | 3 | 57 | 21 | 0 |
| primary | 3007 | purser | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 730736209 | 2 | 38 | 14 | 0 |
| primary | 3008 | loop | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 7 | 916951125 | 4 | 76 | 28 | 0 |
| primary | 3008 | purser | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 8 | 1281980500 | 3 | 57 | 21 | 0 |
| primary | 3008 | loop_equal_verifier | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 8 | 1078749750 | 3 | 57 | 21 | 0 |
| primary | 3009 | purser | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 721471250 | 2 | 38 | 14 | 0 |
| primary | 3009 | loop_equal_verifier | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 725586625 | 2 | 38 | 14 | 0 |
| primary | 3009 | loop | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 716843417 | 3 | 57 | 21 | 0 |
| primary | 3010 | loop_equal_verifier | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 8 | 1109130042 | 3 | 57 | 21 | 0 |
| primary | 3010 | loop | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 7 | 993123958 | 4 | 76 | 28 | 0 |
| primary | 3010 | purser | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 8 | 1200649208 | 3 | 57 | 21 | 0 |
| primary | 3011 | loop | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 697473459 | 3 | 57 | 21 | 0 |
| primary | 3011 | purser | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 754232708 | 2 | 38 | 14 | 0 |
| primary | 3011 | loop_equal_verifier | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 749083500 | 2 | 38 | 14 | 0 |
| primary | 3012 | purser | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 8 | 1271461875 | 3 | 57 | 21 | 0 |
| primary | 3012 | loop_equal_verifier | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 8 | 1227764875 | 3 | 57 | 21 | 0 |
| primary | 3012 | loop | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 7 | 878829375 | 4 | 76 | 28 | 0 |
| primary | 3013 | loop_equal_verifier | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 707008542 | 2 | 38 | 14 | 0 |
| primary | 3013 | loop | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 673184125 | 3 | 57 | 21 | 0 |
| primary | 3013 | purser | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 738003958 | 2 | 38 | 14 | 0 |
| primary | 3014 | loop | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 7 | 865058958 | 4 | 76 | 28 | 0 |
| primary | 3014 | purser | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 8 | 1288097417 | 3 | 57 | 21 | 0 |
| primary | 3014 | loop_equal_verifier | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 8 | 1201576750 | 3 | 57 | 21 | 0 |
| primary | 3015 | purser | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 760504625 | 2 | 38 | 14 | 0 |
| primary | 3015 | loop_equal_verifier | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 673869333 | 2 | 38 | 14 | 0 |
| primary | 3015 | loop | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 706442708 | 3 | 57 | 21 | 0 |
| primary | 3016 | loop_equal_verifier | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 8 | 1145626000 | 3 | 57 | 21 | 0 |
| primary | 3016 | loop | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 7 | 896001791 | 4 | 76 | 28 | 0 |
| primary | 3016 | purser | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 8 | 1130174250 | 3 | 57 | 21 | 0 |
| primary | 3017 | loop | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 698284208 | 3 | 57 | 21 | 0 |
| primary | 3017 | purser | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 729896750 | 2 | 38 | 14 | 0 |
| primary | 3017 | loop_equal_verifier | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 711408750 | 2 | 38 | 14 | 0 |
| primary | 3018 | purser | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 8 | 1202009208 | 3 | 57 | 21 | 0 |
| primary | 3018 | loop_equal_verifier | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 8 | 1042347084 | 3 | 57 | 21 | 0 |
| primary | 3018 | loop | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 7 | 830354333 | 4 | 76 | 28 | 0 |
| primary | 3019 | loop_equal_verifier | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 661115500 | 2 | 38 | 14 | 0 |
| primary | 3019 | loop | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 676042667 | 3 | 57 | 21 | 0 |
| primary | 3019 | purser | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 723868708 | 2 | 38 | 14 | 0 |
| primary | 3020 | loop | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 7 | 928150708 | 4 | 76 | 28 | 0 |
| primary | 3020 | purser | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 8 | 1195156583 | 3 | 57 | 21 | 0 |
| primary | 3020 | loop_equal_verifier | complete / done | yes | 0 | 1 | yes | no | no | yes | unlanded | unlanded | yes | no | 8 | 1157529417 | 3 | 57 | 21 | 0 |
| clean | 3001 | loop_equal_verifier | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 684887125 | 2 | 38 | 14 | 0 |
| clean | 3001 | loop | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 4 | 455209000 | 2 | 38 | 14 | 0 |
| clean | 3001 | purser | complete / done | yes | 0 | 1 | yes | no | no | yes | landed | landed | yes | no | 5 | 716268916 | 2 | 38 | 14 | 0 |
| inconclusive-observation | 3001 | loop_equal_verifier | complete / blocked | ? | 0 | 0 | no | no | no | yes | unknown | unknown | no | yes | 5 | 512737959 | 2 | 38 | 14 | 0 |
| inconclusive-observation | 3001 | loop | complete / blocked | ? | 0 | 0 | no | no | no | yes | unknown | unknown | no | yes | 5 | 457415709 | 3 | 57 | 21 | 0 |
| inconclusive-observation | 3001 | purser | complete / blocked | ? | 0 | 0 | no | no | no | yes | unknown | unknown | no | yes | 5 | 445038917 | 2 | 38 | 14 | 0 |

### Inconclusive-observation stress

| Arm | Published choice | Reason | Next action | Actionable pending held | Uncertainty remaining | Additional attempts | Effects |
| --- | --- | --- | --- | --- | --- | ---: | ---: |
| loop | pending | writer_may_still_apply | Recheck the writer and receipt | yes | yes | 0 | 0 |
| purser | pending | writer_may_still_apply | Recheck the writer and receipt | yes | yes | 0 | 0 |
| loop_equal_verifier | pending | writer_may_still_apply | Recheck the writer and receipt | yes | yes | 0 | 0 |

### Paired differences

Each cell subtracts that comparator from Purser in this order — correct_reconciliation, duplicate_count, effect_count, resolved_by_budget, stuck_requires_manual, manual_repair, steps, elapsed_ns, model_calls, input_tokens, output_tokens, spend_usd_micros.

| Track / seed | Purser minus plain loop | Purser minus equal verifier |
| --- | --- | --- |
| primary / 3001 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 41455417 / -1 / -19 / -7 / 0 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / -44074917 / 0 / 0 / 0 / 0 |
| primary / 3002 | 0 / 0 / 0 / 0 / 0 / 0 / 1 / 299935709 / -1 / -19 / -7 / 0 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 91347084 / 0 / 0 / 0 / 0 |
| primary / 3003 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 30133958 / -1 / -19 / -7 / 0 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 23027874 / 0 / 0 / 0 / 0 |
| primary / 3004 | 0 / 0 / 0 / 0 / 0 / 0 / 1 / 331133791 / -1 / -19 / -7 / 0 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / -680500 / 0 / 0 / 0 / 0 |
| primary / 3005 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 6357209 / -1 / -19 / -7 / 0 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 44370376 / 0 / 0 / 0 / 0 |
| primary / 3006 | 0 / 0 / 0 / 0 / 0 / 0 / 1 / 258558000 / -1 / -19 / -7 / 0 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / -73207499 / 0 / 0 / 0 / 0 |
| primary / 3007 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 10346626 / -1 / -19 / -7 / 0 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / -71987707 / 0 / 0 / 0 / 0 |
| primary / 3008 | 0 / 0 / 0 / 0 / 0 / 0 / 1 / 365029375 / -1 / -19 / -7 / 0 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 203230750 / 0 / 0 / 0 / 0 |
| primary / 3009 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 4627833 / -1 / -19 / -7 / 0 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / -4115375 / 0 / 0 / 0 / 0 |
| primary / 3010 | 0 / 0 / 0 / 0 / 0 / 0 / 1 / 207525250 / -1 / -19 / -7 / 0 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 91519166 / 0 / 0 / 0 / 0 |
| primary / 3011 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 56759249 / -1 / -19 / -7 / 0 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 5149208 / 0 / 0 / 0 / 0 |
| primary / 3012 | 0 / 0 / 0 / 0 / 0 / 0 / 1 / 392632500 / -1 / -19 / -7 / 0 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 43697000 / 0 / 0 / 0 / 0 |
| primary / 3013 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 64819833 / -1 / -19 / -7 / 0 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 30995416 / 0 / 0 / 0 / 0 |
| primary / 3014 | 0 / 0 / 0 / 0 / 0 / 0 / 1 / 423038459 / -1 / -19 / -7 / 0 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 86520667 / 0 / 0 / 0 / 0 |
| primary / 3015 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 54061917 / -1 / -19 / -7 / 0 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 86635292 / 0 / 0 / 0 / 0 |
| primary / 3016 | 0 / 0 / 0 / 0 / 0 / 0 / 1 / 234172459 / -1 / -19 / -7 / 0 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / -15451750 / 0 / 0 / 0 / 0 |
| primary / 3017 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 31612542 / -1 / -19 / -7 / 0 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 18488000 / 0 / 0 / 0 / 0 |
| primary / 3018 | 0 / 0 / 0 / 0 / 0 / 0 / 1 / 371654875 / -1 / -19 / -7 / 0 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 159662124 / 0 / 0 / 0 / 0 |
| primary / 3019 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 47826041 / -1 / -19 / -7 / 0 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 62753208 / 0 / 0 / 0 / 0 |
| primary / 3020 | 0 / 0 / 0 / 0 / 0 / 0 / 1 / 267005875 / -1 / -19 / -7 / 0 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 37627166 / 0 / 0 / 0 / 0 |
| clean / 3001 | 0 / 0 / 0 / 0 / 0 / 0 / 1 / 261059916 / 0 / 0 / 0 / 0 | 0 / 0 / 0 / 0 / 0 / 0 / 0 / 31381791 / 0 / 0 / 0 / 0 |
| inconclusive-observation / 3001 | ? / 0 / 0 / 0 / 0 / 0 / 0 / -12376792 / -1 / -19 / -7 / 0 | ? / 0 / 0 / 0 / 0 / 0 / 0 / -67699042 / 0 / 0 / 0 / 0 |

Healthy matched clean pair above twice plain-loop steps — no.

## Model costs and coverage

Each cost shows how many scheduled cases have an exact measurement. A ≥ total includes the available exact measurements and any observed lower bounds. A question mark means the original evidence supplied no measurement for that field. A model call counts a complete outgoing request to the enrolled service, including one that returns an HTTP error. Elapsed time sums the participants’ active time. Spend uses measured charges in US dollars.

| Population | Complete / incomplete / invalid / missing | Steps | Elapsed s | Model calls | Input tokens | Output tokens | Spend USD |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| All cases | 66 / 129 / 0 / 0 | 1441 (195/195 exact) | 71.656335909 (195/195 exact) | 441 (195/195 exact) | 8379 (195/195 exact) | 3087 (195/195 exact) | 0 (195/195 exact) |
| All · loop | 22 / 43 / 0 / 0 | 473 (65/65 exact) | 21.018313789 (65/65 exact) | 161 (65/65 exact) | 3059 (65/65 exact) | 1127 (65/65 exact) | 0 (65/65 exact) |
| All · purser | 22 / 43 / 0 / 0 | 484 (65/65 exact) | 26.430475121 (65/65 exact) | 140 (65/65 exact) | 2660 (65/65 exact) | 980 (65/65 exact) | 0 (65/65 exact) |
| All · loop_equal_verifier | 22 / 43 / 0 / 0 | 484 (65/65 exact) | 24.207546999 (65/65 exact) | 140 (65/65 exact) | 2660 (65/65 exact) | 980 (65/65 exact) | 0 (65/65 exact) |
| E1 · primary · loop | 0 / 20 / 0 / 0 | 160 (20/20 exact) | 1.777054249 (20/20 exact) | 40 (20/20 exact) | 760 (20/20 exact) | 280 (20/20 exact) | 0 (20/20 exact) |
| E1 · primary · purser | 0 / 20 / 0 / 0 | 160 (20/20 exact) | 2.473819916 (20/20 exact) | 40 (20/20 exact) | 760 (20/20 exact) | 280 (20/20 exact) | 0 (20/20 exact) |
| E1 · primary · loop_equal_verifier | 0 / 20 / 0 / 0 | 160 (20/20 exact) | 1.796373208 (20/20 exact) | 40 (20/20 exact) | 760 (20/20 exact) | 280 (20/20 exact) | 0 (20/20 exact) |
| E1 · clean · loop | 0 / 1 / 0 / 0 | 8 (1/1 exact) | 0.084908542 (1/1 exact) | 2 (1/1 exact) | 38 (1/1 exact) | 14 (1/1 exact) | 0 (1/1 exact) |
| E1 · clean · purser | 0 / 1 / 0 / 0 | 8 (1/1 exact) | 0.12200025 (1/1 exact) | 2 (1/1 exact) | 38 (1/1 exact) | 14 (1/1 exact) | 0 (1/1 exact) |
| E1 · clean · loop_equal_verifier | 0 / 1 / 0 / 0 | 8 (1/1 exact) | 0.091738333 (1/1 exact) | 2 (1/1 exact) | 38 (1/1 exact) | 14 (1/1 exact) | 0 (1/1 exact) |
| E2 · primary · loop | 0 / 20 / 0 / 0 | 160 (20/20 exact) | 1.843876667 (20/20 exact) | 40 (20/20 exact) | 760 (20/20 exact) | 280 (20/20 exact) | 0 (20/20 exact) |
| E2 · primary · purser | 0 / 20 / 0 / 0 | 160 (20/20 exact) | 2.680626081 (20/20 exact) | 40 (20/20 exact) | 760 (20/20 exact) | 280 (20/20 exact) | 0 (20/20 exact) |
| E2 · primary · loop_equal_verifier | 0 / 20 / 0 / 0 | 160 (20/20 exact) | 1.953660667 (20/20 exact) | 40 (20/20 exact) | 760 (20/20 exact) | 280 (20/20 exact) | 0 (20/20 exact) |
| E2 · clean · loop | 0 / 1 / 0 / 0 | 8 (1/1 exact) | 0.099027 (1/1 exact) | 2 (1/1 exact) | 38 (1/1 exact) | 14 (1/1 exact) | 0 (1/1 exact) |
| E2 · clean · purser | 0 / 1 / 0 / 0 | 8 (1/1 exact) | 0.151297792 (1/1 exact) | 2 (1/1 exact) | 38 (1/1 exact) | 14 (1/1 exact) | 0 (1/1 exact) |
| E2 · clean · loop_equal_verifier | 0 / 1 / 0 / 0 | 8 (1/1 exact) | 0.1070865 (1/1 exact) | 2 (1/1 exact) | 38 (1/1 exact) | 14 (1/1 exact) | 0 (1/1 exact) |
| E2 · closed-affected · loop | 0 / 1 / 0 / 0 | 8 (1/1 exact) | 0.087318458 (1/1 exact) | 2 (1/1 exact) | 38 (1/1 exact) | 14 (1/1 exact) | 0 (1/1 exact) |
| E2 · closed-affected · purser | 0 / 1 / 0 / 0 | 8 (1/1 exact) | 0.129232167 (1/1 exact) | 2 (1/1 exact) | 38 (1/1 exact) | 14 (1/1 exact) | 0 (1/1 exact) |
| E2 · closed-affected · loop_equal_verifier | 0 / 1 / 0 / 0 | 8 (1/1 exact) | 0.124377708 (1/1 exact) | 2 (1/1 exact) | 38 (1/1 exact) | 14 (1/1 exact) | 0 (1/1 exact) |
| E3 · primary · loop | 20 / 0 / 0 / 0 | 120 (20/20 exact) | 16.213504164 (20/20 exact) | 70 (20/20 exact) | 1330 (20/20 exact) | 490 (20/20 exact) | 0 (20/20 exact) |
| E3 · primary · purser | 20 / 0 / 0 / 0 | 130 (20/20 exact) | 19.712191082 (20/20 exact) | 50 (20/20 exact) | 950 (20/20 exact) | 350 (20/20 exact) | 0 (20/20 exact) |
| E3 · primary · loop_equal_verifier | 20 / 0 / 0 / 0 | 130 (20/20 exact) | 18.936685499 (20/20 exact) | 50 (20/20 exact) | 950 (20/20 exact) | 350 (20/20 exact) | 0 (20/20 exact) |
| E3 · clean · loop | 1 / 0 / 0 / 0 | 4 (1/1 exact) | 0.455209 (1/1 exact) | 2 (1/1 exact) | 38 (1/1 exact) | 14 (1/1 exact) | 0 (1/1 exact) |
| E3 · clean · purser | 1 / 0 / 0 / 0 | 5 (1/1 exact) | 0.716268916 (1/1 exact) | 2 (1/1 exact) | 38 (1/1 exact) | 14 (1/1 exact) | 0 (1/1 exact) |
| E3 · clean · loop_equal_verifier | 1 / 0 / 0 / 0 | 5 (1/1 exact) | 0.684887125 (1/1 exact) | 2 (1/1 exact) | 38 (1/1 exact) | 14 (1/1 exact) | 0 (1/1 exact) |
| E3 · inconclusive-observation · loop | 1 / 0 / 0 / 0 | 5 (1/1 exact) | 0.457415709 (1/1 exact) | 3 (1/1 exact) | 57 (1/1 exact) | 21 (1/1 exact) | 0 (1/1 exact) |
| E3 · inconclusive-observation · purser | 1 / 0 / 0 / 0 | 5 (1/1 exact) | 0.445038917 (1/1 exact) | 2 (1/1 exact) | 38 (1/1 exact) | 14 (1/1 exact) | 0 (1/1 exact) |
| E3 · inconclusive-observation · loop_equal_verifier | 1 / 0 / 0 / 0 | 5 (1/1 exact) | 0.512737959 (1/1 exact) | 2 (1/1 exact) | 38 (1/1 exact) | 14 (1/1 exact) | 0 (1/1 exact) |

## Retained model evidence

A collector invocation can end before a request reaches the service. The first confirmed send links to its original request digest. A sealed reply can survive the loss of its participant.

| Case | Collector invocations | Transport receipts | First confirmed send | Model IDs in responses |
| --- | ---: | ---: | --- | --- |
| E1/primary/1001/loop | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1001/purser | 2 | 2 | 1 · `549bb407d642f5ed2971c0039e0268f7e2ee1d70ea3485821ad209ade46c3e6f` | full-schedule-canned-control |
| E1/primary/1001/loop_equal_verifier | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1002/purser | 2 | 2 | 1 · `549bb407d642f5ed2971c0039e0268f7e2ee1d70ea3485821ad209ade46c3e6f` | full-schedule-canned-control |
| E1/primary/1002/loop_equal_verifier | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1002/loop | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1003/loop_equal_verifier | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1003/loop | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1003/purser | 2 | 2 | 1 · `549bb407d642f5ed2971c0039e0268f7e2ee1d70ea3485821ad209ade46c3e6f` | full-schedule-canned-control |
| E1/primary/1004/loop | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1004/purser | 2 | 2 | 1 · `549bb407d642f5ed2971c0039e0268f7e2ee1d70ea3485821ad209ade46c3e6f` | full-schedule-canned-control |
| E1/primary/1004/loop_equal_verifier | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1005/purser | 2 | 2 | 1 · `549bb407d642f5ed2971c0039e0268f7e2ee1d70ea3485821ad209ade46c3e6f` | full-schedule-canned-control |
| E1/primary/1005/loop_equal_verifier | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1005/loop | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1006/loop_equal_verifier | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1006/loop | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1006/purser | 2 | 2 | 1 · `549bb407d642f5ed2971c0039e0268f7e2ee1d70ea3485821ad209ade46c3e6f` | full-schedule-canned-control |
| E1/primary/1007/loop | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1007/purser | 2 | 2 | 1 · `549bb407d642f5ed2971c0039e0268f7e2ee1d70ea3485821ad209ade46c3e6f` | full-schedule-canned-control |
| E1/primary/1007/loop_equal_verifier | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1008/purser | 2 | 2 | 1 · `549bb407d642f5ed2971c0039e0268f7e2ee1d70ea3485821ad209ade46c3e6f` | full-schedule-canned-control |
| E1/primary/1008/loop_equal_verifier | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1008/loop | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1009/loop_equal_verifier | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1009/loop | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1009/purser | 2 | 2 | 1 · `549bb407d642f5ed2971c0039e0268f7e2ee1d70ea3485821ad209ade46c3e6f` | full-schedule-canned-control |
| E1/primary/1010/loop | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1010/purser | 2 | 2 | 1 · `549bb407d642f5ed2971c0039e0268f7e2ee1d70ea3485821ad209ade46c3e6f` | full-schedule-canned-control |
| E1/primary/1010/loop_equal_verifier | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1011/purser | 2 | 2 | 1 · `549bb407d642f5ed2971c0039e0268f7e2ee1d70ea3485821ad209ade46c3e6f` | full-schedule-canned-control |
| E1/primary/1011/loop_equal_verifier | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1011/loop | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1012/loop_equal_verifier | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1012/loop | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1012/purser | 2 | 2 | 1 · `549bb407d642f5ed2971c0039e0268f7e2ee1d70ea3485821ad209ade46c3e6f` | full-schedule-canned-control |
| E1/primary/1013/loop | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1013/purser | 2 | 2 | 1 · `549bb407d642f5ed2971c0039e0268f7e2ee1d70ea3485821ad209ade46c3e6f` | full-schedule-canned-control |
| E1/primary/1013/loop_equal_verifier | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1014/purser | 2 | 2 | 1 · `549bb407d642f5ed2971c0039e0268f7e2ee1d70ea3485821ad209ade46c3e6f` | full-schedule-canned-control |
| E1/primary/1014/loop_equal_verifier | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1014/loop | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1015/loop_equal_verifier | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1015/loop | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1015/purser | 2 | 2 | 1 · `549bb407d642f5ed2971c0039e0268f7e2ee1d70ea3485821ad209ade46c3e6f` | full-schedule-canned-control |
| E1/primary/1016/loop | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1016/purser | 2 | 2 | 1 · `549bb407d642f5ed2971c0039e0268f7e2ee1d70ea3485821ad209ade46c3e6f` | full-schedule-canned-control |
| E1/primary/1016/loop_equal_verifier | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1017/purser | 2 | 2 | 1 · `549bb407d642f5ed2971c0039e0268f7e2ee1d70ea3485821ad209ade46c3e6f` | full-schedule-canned-control |
| E1/primary/1017/loop_equal_verifier | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1017/loop | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1018/loop_equal_verifier | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1018/loop | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1018/purser | 2 | 2 | 1 · `549bb407d642f5ed2971c0039e0268f7e2ee1d70ea3485821ad209ade46c3e6f` | full-schedule-canned-control |
| E1/primary/1019/loop | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1019/purser | 2 | 2 | 1 · `549bb407d642f5ed2971c0039e0268f7e2ee1d70ea3485821ad209ade46c3e6f` | full-schedule-canned-control |
| E1/primary/1019/loop_equal_verifier | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1020/purser | 2 | 2 | 1 · `549bb407d642f5ed2971c0039e0268f7e2ee1d70ea3485821ad209ade46c3e6f` | full-schedule-canned-control |
| E1/primary/1020/loop_equal_verifier | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/primary/1020/loop | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/clean/1001/loop | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E1/clean/1001/purser | 2 | 2 | 1 · `549bb407d642f5ed2971c0039e0268f7e2ee1d70ea3485821ad209ade46c3e6f` | full-schedule-canned-control |
| E1/clean/1001/loop_equal_verifier | 2 | 2 | 1 · `d8d2de0656b2b226b7bb56fefe2c59931e6d41ed6cf5206ee9c6c24b1e0f1138` | full-schedule-canned-control |
| E2/primary/2001/purser | 2 | 2 | 1 · `97235d98675bc6b4d903ddd8e522ab8eb68cee592097232cfa80e6f1e2351c46` | full-schedule-canned-control |
| E2/primary/2001/loop_equal_verifier | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2001/loop | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2002/loop_equal_verifier | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2002/loop | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2002/purser | 2 | 2 | 1 · `97235d98675bc6b4d903ddd8e522ab8eb68cee592097232cfa80e6f1e2351c46` | full-schedule-canned-control |
| E2/primary/2003/loop | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2003/purser | 2 | 2 | 1 · `97235d98675bc6b4d903ddd8e522ab8eb68cee592097232cfa80e6f1e2351c46` | full-schedule-canned-control |
| E2/primary/2003/loop_equal_verifier | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2004/purser | 2 | 2 | 1 · `97235d98675bc6b4d903ddd8e522ab8eb68cee592097232cfa80e6f1e2351c46` | full-schedule-canned-control |
| E2/primary/2004/loop_equal_verifier | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2004/loop | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2005/loop_equal_verifier | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2005/loop | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2005/purser | 2 | 2 | 1 · `97235d98675bc6b4d903ddd8e522ab8eb68cee592097232cfa80e6f1e2351c46` | full-schedule-canned-control |
| E2/primary/2006/loop | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2006/purser | 2 | 2 | 1 · `97235d98675bc6b4d903ddd8e522ab8eb68cee592097232cfa80e6f1e2351c46` | full-schedule-canned-control |
| E2/primary/2006/loop_equal_verifier | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2007/purser | 2 | 2 | 1 · `97235d98675bc6b4d903ddd8e522ab8eb68cee592097232cfa80e6f1e2351c46` | full-schedule-canned-control |
| E2/primary/2007/loop_equal_verifier | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2007/loop | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2008/loop_equal_verifier | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2008/loop | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2008/purser | 2 | 2 | 1 · `97235d98675bc6b4d903ddd8e522ab8eb68cee592097232cfa80e6f1e2351c46` | full-schedule-canned-control |
| E2/primary/2009/loop | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2009/purser | 2 | 2 | 1 · `97235d98675bc6b4d903ddd8e522ab8eb68cee592097232cfa80e6f1e2351c46` | full-schedule-canned-control |
| E2/primary/2009/loop_equal_verifier | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2010/purser | 2 | 2 | 1 · `97235d98675bc6b4d903ddd8e522ab8eb68cee592097232cfa80e6f1e2351c46` | full-schedule-canned-control |
| E2/primary/2010/loop_equal_verifier | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2010/loop | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2011/loop_equal_verifier | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2011/loop | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2011/purser | 2 | 2 | 1 · `97235d98675bc6b4d903ddd8e522ab8eb68cee592097232cfa80e6f1e2351c46` | full-schedule-canned-control |
| E2/primary/2012/loop | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2012/purser | 2 | 2 | 1 · `97235d98675bc6b4d903ddd8e522ab8eb68cee592097232cfa80e6f1e2351c46` | full-schedule-canned-control |
| E2/primary/2012/loop_equal_verifier | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2013/purser | 2 | 2 | 1 · `97235d98675bc6b4d903ddd8e522ab8eb68cee592097232cfa80e6f1e2351c46` | full-schedule-canned-control |
| E2/primary/2013/loop_equal_verifier | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2013/loop | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2014/loop_equal_verifier | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2014/loop | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2014/purser | 2 | 2 | 1 · `97235d98675bc6b4d903ddd8e522ab8eb68cee592097232cfa80e6f1e2351c46` | full-schedule-canned-control |
| E2/primary/2015/loop | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2015/purser | 2 | 2 | 1 · `97235d98675bc6b4d903ddd8e522ab8eb68cee592097232cfa80e6f1e2351c46` | full-schedule-canned-control |
| E2/primary/2015/loop_equal_verifier | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2016/purser | 2 | 2 | 1 · `97235d98675bc6b4d903ddd8e522ab8eb68cee592097232cfa80e6f1e2351c46` | full-schedule-canned-control |
| E2/primary/2016/loop_equal_verifier | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2016/loop | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2017/loop_equal_verifier | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2017/loop | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2017/purser | 2 | 2 | 1 · `97235d98675bc6b4d903ddd8e522ab8eb68cee592097232cfa80e6f1e2351c46` | full-schedule-canned-control |
| E2/primary/2018/loop | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2018/purser | 2 | 2 | 1 · `97235d98675bc6b4d903ddd8e522ab8eb68cee592097232cfa80e6f1e2351c46` | full-schedule-canned-control |
| E2/primary/2018/loop_equal_verifier | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2019/purser | 2 | 2 | 1 · `97235d98675bc6b4d903ddd8e522ab8eb68cee592097232cfa80e6f1e2351c46` | full-schedule-canned-control |
| E2/primary/2019/loop_equal_verifier | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2019/loop | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2020/loop_equal_verifier | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2020/loop | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/primary/2020/purser | 2 | 2 | 1 · `97235d98675bc6b4d903ddd8e522ab8eb68cee592097232cfa80e6f1e2351c46` | full-schedule-canned-control |
| E2/clean/2001/purser | 2 | 2 | 1 · `97235d98675bc6b4d903ddd8e522ab8eb68cee592097232cfa80e6f1e2351c46` | full-schedule-canned-control |
| E2/clean/2001/loop_equal_verifier | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/clean/2001/loop | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/closed-affected/2001/purser | 2 | 2 | 1 · `97235d98675bc6b4d903ddd8e522ab8eb68cee592097232cfa80e6f1e2351c46` | full-schedule-canned-control |
| E2/closed-affected/2001/loop_equal_verifier | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E2/closed-affected/2001/loop | 2 | 2 | 1 · `02ee1d00f73eaeee3e4fa56c8b5fbd26a5b4fb3e50cd2e56806c5a47e3b0ea74` | full-schedule-canned-control |
| E3/primary/3001/loop_equal_verifier | 2 | 2 | 1 · `a95b6c1e208fd64f2364c646c113f737f4ee90096c808b25075cbe5b6252d021` | full-schedule-canned-control |
| E3/primary/3001/loop | 3 | 3 | 1 · `a95b6c1e208fd64f2364c646c113f737f4ee90096c808b25075cbe5b6252d021` | full-schedule-canned-control |
| E3/primary/3001/purser | 2 | 2 | 1 · `3267e72da455b5f4fce5e68dba132f2f2f48a38678e1845601cbac0bf1b6d47b` | full-schedule-canned-control |
| E3/primary/3002/loop | 4 | 4 | 1 · `81819b59f6c428996a5fa82b17b6ae13e780f8d51d8f221318b3c8c259afb639` | full-schedule-canned-control |
| E3/primary/3002/purser | 3 | 3 | 1 · `1bbbed1a02d6d4a5ea5c8f6e8070f84085a77274ab12db2ead8d11217c16f713` | full-schedule-canned-control |
| E3/primary/3002/loop_equal_verifier | 3 | 3 | 1 · `81819b59f6c428996a5fa82b17b6ae13e780f8d51d8f221318b3c8c259afb639` | full-schedule-canned-control |
| E3/primary/3003/purser | 2 | 2 | 1 · `24baf6e6704d94078c017ab6123b097741dd7627d592715d0eba2e4a9aee89f5` | full-schedule-canned-control |
| E3/primary/3003/loop_equal_verifier | 2 | 2 | 1 · `8b0afe6603a2794a927a8d65d0cacbc57efacc1a9054e06029f9af61f6a34149` | full-schedule-canned-control |
| E3/primary/3003/loop | 3 | 3 | 1 · `8b0afe6603a2794a927a8d65d0cacbc57efacc1a9054e06029f9af61f6a34149` | full-schedule-canned-control |
| E3/primary/3004/loop_equal_verifier | 3 | 3 | 1 · `24221f25b0e6212351275c2abd7c081775b4cff00b2942038cdffdd182a61250` | full-schedule-canned-control |
| E3/primary/3004/loop | 4 | 4 | 1 · `24221f25b0e6212351275c2abd7c081775b4cff00b2942038cdffdd182a61250` | full-schedule-canned-control |
| E3/primary/3004/purser | 3 | 3 | 1 · `a7a170682d3abbb5832defa1a9a72042296661e85109c5b93fff9724a3e659a3` | full-schedule-canned-control |
| E3/primary/3005/loop | 3 | 3 | 1 · `abc3f7ff53b861c2e947c4a77a249824cfd463980b12ad34a9a1dd5e81cb55c7` | full-schedule-canned-control |
| E3/primary/3005/purser | 2 | 2 | 1 · `1b201dd509a4e66dcf6d5ff617f3fa24b0b71b1008d493dbe1361e8a79bc12df` | full-schedule-canned-control |
| E3/primary/3005/loop_equal_verifier | 2 | 2 | 1 · `abc3f7ff53b861c2e947c4a77a249824cfd463980b12ad34a9a1dd5e81cb55c7` | full-schedule-canned-control |
| E3/primary/3006/purser | 3 | 3 | 1 · `740f4031f6c64168ff67d02085e1cef6b40e438e55187040e3bbbd91b4a350f6` | full-schedule-canned-control |
| E3/primary/3006/loop_equal_verifier | 3 | 3 | 1 · `3d6adaf1c55db3027385b258d2b651801132f12c74df7bc351837eaa3c513d50` | full-schedule-canned-control |
| E3/primary/3006/loop | 4 | 4 | 1 · `3d6adaf1c55db3027385b258d2b651801132f12c74df7bc351837eaa3c513d50` | full-schedule-canned-control |
| E3/primary/3007/loop_equal_verifier | 2 | 2 | 1 · `98865b20ef0467913ba1008db03fc97ececaa7eb7abc404d63fc5a85c7f3b8ab` | full-schedule-canned-control |
| E3/primary/3007/loop | 3 | 3 | 1 · `98865b20ef0467913ba1008db03fc97ececaa7eb7abc404d63fc5a85c7f3b8ab` | full-schedule-canned-control |
| E3/primary/3007/purser | 2 | 2 | 1 · `7311ff435da6f5e8318ba1af920ec8c6cf4fa5076ca7488948812ee620781d68` | full-schedule-canned-control |
| E3/primary/3008/loop | 4 | 4 | 1 · `f0ead4652f85ea96f56b820182d607b3eac9c53d2615cd637f7dcdc6a49cf76d` | full-schedule-canned-control |
| E3/primary/3008/purser | 3 | 3 | 1 · `8b732f831b4b463f75dba600f67c78f7c8e489a344af4265aea5fe3abcb66967` | full-schedule-canned-control |
| E3/primary/3008/loop_equal_verifier | 3 | 3 | 1 · `f0ead4652f85ea96f56b820182d607b3eac9c53d2615cd637f7dcdc6a49cf76d` | full-schedule-canned-control |
| E3/primary/3009/purser | 2 | 2 | 1 · `ad929827cb8d7fe18aeecd3ca1bee60e5e6f0bc2d32a65eb1dd28c4cead08c36` | full-schedule-canned-control |
| E3/primary/3009/loop_equal_verifier | 2 | 2 | 1 · `9ae3d9385821338d4424d5c91ddca1fb8df28b472f3e171d348edf306a84705f` | full-schedule-canned-control |
| E3/primary/3009/loop | 3 | 3 | 1 · `9ae3d9385821338d4424d5c91ddca1fb8df28b472f3e171d348edf306a84705f` | full-schedule-canned-control |
| E3/primary/3010/loop_equal_verifier | 3 | 3 | 1 · `c34acb7cad72c96ba6b6b8fe79dbc73440d1f520c3b3f242e339c1e4863d2df7` | full-schedule-canned-control |
| E3/primary/3010/loop | 4 | 4 | 1 · `c34acb7cad72c96ba6b6b8fe79dbc73440d1f520c3b3f242e339c1e4863d2df7` | full-schedule-canned-control |
| E3/primary/3010/purser | 3 | 3 | 1 · `e1c5a5697d435484e6a46bcb11aa260bc07f1ab23051d1b20bface6569d49f02` | full-schedule-canned-control |
| E3/primary/3011/loop | 3 | 3 | 1 · `4b05d239432e2ec6d741f34c10e02ceecc35e646da5e804ac58bf895350b1604` | full-schedule-canned-control |
| E3/primary/3011/purser | 2 | 2 | 1 · `0e4c048c90683b835f5526b1b1eb7d84d530a1d812aba8b828101e3d51fdc1fe` | full-schedule-canned-control |
| E3/primary/3011/loop_equal_verifier | 2 | 2 | 1 · `4b05d239432e2ec6d741f34c10e02ceecc35e646da5e804ac58bf895350b1604` | full-schedule-canned-control |
| E3/primary/3012/purser | 3 | 3 | 1 · `cee7ab3f6144db1a2de111eff27e1aee6e321491a8a5dcbe3be5872a249df6c1` | full-schedule-canned-control |
| E3/primary/3012/loop_equal_verifier | 3 | 3 | 1 · `437e0c73439aef14001290e39723466c25ca0cd775ecd095b486432f9888f988` | full-schedule-canned-control |
| E3/primary/3012/loop | 4 | 4 | 1 · `437e0c73439aef14001290e39723466c25ca0cd775ecd095b486432f9888f988` | full-schedule-canned-control |
| E3/primary/3013/loop_equal_verifier | 2 | 2 | 1 · `e660a3904c5c862083861ab6dd3c80a9a84d81b316d9de6e3ea4f4729f522fb4` | full-schedule-canned-control |
| E3/primary/3013/loop | 3 | 3 | 1 · `e660a3904c5c862083861ab6dd3c80a9a84d81b316d9de6e3ea4f4729f522fb4` | full-schedule-canned-control |
| E3/primary/3013/purser | 2 | 2 | 1 · `afe65ebe6f4fd677d92efef5242584ea79cd7e3b05901f3f26062c7977717e97` | full-schedule-canned-control |
| E3/primary/3014/loop | 4 | 4 | 1 · `8d12c6537efb76c0ebf0a2cda51f88bdbec38414f2c08d2143e9f1de9034bf95` | full-schedule-canned-control |
| E3/primary/3014/purser | 3 | 3 | 1 · `3db4ae3cb7041cd73c77a785a9ea249831aae39f1dc7a93baf9f1348f230135f` | full-schedule-canned-control |
| E3/primary/3014/loop_equal_verifier | 3 | 3 | 1 · `8d12c6537efb76c0ebf0a2cda51f88bdbec38414f2c08d2143e9f1de9034bf95` | full-schedule-canned-control |
| E3/primary/3015/purser | 2 | 2 | 1 · `cc0e3d849ab10e2b92a870646860b3ce0796cbe79aa3a9e603eb3aa7b6af36a7` | full-schedule-canned-control |
| E3/primary/3015/loop_equal_verifier | 2 | 2 | 1 · `9c6af0e0b491f118fceb37f7cb467925735eaaf5bc44f9f6773bedc7431b9b08` | full-schedule-canned-control |
| E3/primary/3015/loop | 3 | 3 | 1 · `9c6af0e0b491f118fceb37f7cb467925735eaaf5bc44f9f6773bedc7431b9b08` | full-schedule-canned-control |
| E3/primary/3016/loop_equal_verifier | 3 | 3 | 1 · `40658ef70cd7ceb623a5436d97bb4a6c5126d1488018afc09010f04203e6ea41` | full-schedule-canned-control |
| E3/primary/3016/loop | 4 | 4 | 1 · `40658ef70cd7ceb623a5436d97bb4a6c5126d1488018afc09010f04203e6ea41` | full-schedule-canned-control |
| E3/primary/3016/purser | 3 | 3 | 1 · `86d70d7f32e4d1dee6005a53ab2fe4884406f7f337969e2398a2bb09f93f2d3f` | full-schedule-canned-control |
| E3/primary/3017/loop | 3 | 3 | 1 · `d7ae56e854a126f9bf6436de2e5252120dd128be852db21cd05ba5cd8e62cc7d` | full-schedule-canned-control |
| E3/primary/3017/purser | 2 | 2 | 1 · `805689f79fbfa3826b356f8f081dbae8c519c3f8f0e8dcf30e9e7d6d955be5b9` | full-schedule-canned-control |
| E3/primary/3017/loop_equal_verifier | 2 | 2 | 1 · `d7ae56e854a126f9bf6436de2e5252120dd128be852db21cd05ba5cd8e62cc7d` | full-schedule-canned-control |
| E3/primary/3018/purser | 3 | 3 | 1 · `251921a8f917cdbf3370eb23528c5a2bbde60200e15cae6d7ec6cc29408a751d` | full-schedule-canned-control |
| E3/primary/3018/loop_equal_verifier | 3 | 3 | 1 · `26c1c91aec6ab4dec416ea6df030611958b383df19d8c1c161df16fe536868f0` | full-schedule-canned-control |
| E3/primary/3018/loop | 4 | 4 | 1 · `26c1c91aec6ab4dec416ea6df030611958b383df19d8c1c161df16fe536868f0` | full-schedule-canned-control |
| E3/primary/3019/loop_equal_verifier | 2 | 2 | 1 · `f6a13e437a3dbeaf4f661bc4959bb251b747a011176019ebe70a10c3d5661506` | full-schedule-canned-control |
| E3/primary/3019/loop | 3 | 3 | 1 · `f6a13e437a3dbeaf4f661bc4959bb251b747a011176019ebe70a10c3d5661506` | full-schedule-canned-control |
| E3/primary/3019/purser | 2 | 2 | 1 · `e5514a6e19d56db448b601ad017159c4bc7c9e5bdb5c3df22e7c5727509f025b` | full-schedule-canned-control |
| E3/primary/3020/loop | 4 | 4 | 1 · `9a7936d3aba5169a250dc4d4f5094ae4f4da2a4d89702bea200c3bce58467e12` | full-schedule-canned-control |
| E3/primary/3020/purser | 3 | 3 | 1 · `868f22570fec4c19f9eebee5bb17ec03d8c6b53549378d30c353970d485374b3` | full-schedule-canned-control |
| E3/primary/3020/loop_equal_verifier | 3 | 3 | 1 · `9a7936d3aba5169a250dc4d4f5094ae4f4da2a4d89702bea200c3bce58467e12` | full-schedule-canned-control |
| E3/clean/3001/loop_equal_verifier | 2 | 2 | 1 · `a95b6c1e208fd64f2364c646c113f737f4ee90096c808b25075cbe5b6252d021` | full-schedule-canned-control |
| E3/clean/3001/loop | 2 | 2 | 1 · `a95b6c1e208fd64f2364c646c113f737f4ee90096c808b25075cbe5b6252d021` | full-schedule-canned-control |
| E3/clean/3001/purser | 2 | 2 | 1 · `3267e72da455b5f4fce5e68dba132f2f2f48a38678e1845601cbac0bf1b6d47b` | full-schedule-canned-control |
| E3/inconclusive-observation/3001/loop_equal_verifier | 2 | 2 | 1 · `a95b6c1e208fd64f2364c646c113f737f4ee90096c808b25075cbe5b6252d021` | full-schedule-canned-control |
| E3/inconclusive-observation/3001/loop | 3 | 3 | 1 · `a95b6c1e208fd64f2364c646c113f737f4ee90096c808b25075cbe5b6252d021` | full-schedule-canned-control |
| E3/inconclusive-observation/3001/purser | 2 | 2 | 1 · `3267e72da455b5f4fce5e68dba132f2f2f48a38678e1845601cbac0bf1b6d47b` | full-schedule-canned-control |

## Original errors

No error was recorded in the available original artifacts.
