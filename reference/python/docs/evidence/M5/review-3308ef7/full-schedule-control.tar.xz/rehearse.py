"""Private zero-cost rehearsal of a single 195-unit CLI collection and restart."""
from contextlib import contextmanager
from dataclasses import asdict
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
from threading import Thread
import time

repo = Path.cwd()
sys.path.insert(0, str(repo))
from experiments.e1.artifacts import encoded, sha
from experiments.model_budget import ModelBudget, SpendingAuthority
from purser.adapters.model import LocalEndpoint
from tests.test_model_e3 import response_for

root = Path.home() / '.local/state/purser/development/m5/full-schedule-142c973'
archives = root.parent / 'isolator-feasibility'
expected_source = '142c9735f52d470686fbe82dfb0a3c83afa1295b'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == expected_source
assert archives.is_dir()

def save(path, obj):
    with path.open('xb') as output:
        output.write(encoded(obj))

def cli(*arguments):
    return subprocess.run([sys.executable,'-B','-m','experiments.model_study',*map(str,arguments)], cwd=repo,
                          capture_output=True,check=True).stdout

def code_digest(path):
    return sha(path.read_bytes())

class Wire(BaseHTTPRequestHandler):
    def log_message(self,*args):
        pass

    def do_POST(self):
        arrived = time.monotonic_ns()
        wire = self.rfile.read(int(self.headers['Content-Length']))
        body = json.loads(wire)
        prompt = json.loads(body['messages'][1]['content'])
        if 'stop' in prompt['actions']:
            view = json.loads(prompt['observation'])
            if view['assignment_contexts']:
                choice = {'action':'inspect','arguments':{'work':'W1'}}
            else:
                choice = {'action':'stop','arguments':{'reason':'The full-schedule control ends after reading one work item.'}}
        else:
            choice = response_for(body, 'evidence')
        answer = encoded({'model':body['model'],'choices':[{'index':0,'finish_reason':'stop','message':{
            'role':'assistant','content':encoded(choice).decode()}}],'usage':{'prompt_tokens':19,'completion_tokens':7}})
        self.server.post_count += 1
        number = self.server.post_count
        (root/'wire'/f'{number:04d}.request.json').write_bytes(wire)
        (root/'wire'/f'{number:04d}.response.json').write_bytes(answer)
        item = {'index':number,'received_monotonic_ns':arrived,'path':self.path,'http_status':200,
                'request_sha256':sha(wire),'response_sha256':sha(answer),'action':choice['action'],
                'input_tokens':19,'output_tokens':7}
        with (root/'posts.jsonl').open('ab') as log:
            log.write(encoded(item)+b'\n')
            log.flush()
            os.fsync(log.fileno())
        self.send_response(200)
        self.send_header('Content-Type','application/json')
        self.send_header('Content-Length',str(len(answer)))
        self.end_headers()
        self.wfile.write(answer)

def seals():
    cases=root/'series'/'cases'
    result={}
    for case in sorted(cases.glob('*/*/*/*')):
        result[str(case.relative_to(cases))]={name:code_digest(case/name) for name in ('raw.json','started.json','session.json')}
    return result

def budget_state():
    with sqlite3.connect(f'file:{root / "budget.sqlite"}?mode=ro', uri=True) as connection:
        tables=[r[0] for r in connection.execute("select name from sqlite_master where type='table' order by name")]
        assert all(name.replace('_','').isalnum() for name in tables)
        # The only data in this private store are the synthetic qualification authority and its receipts.
        return {name: {'rows':len(rows), 'sha256':sha(encoded(sorted(map(repr,rows))))}
                for name in tables for rows in [connection.execute('select * from '+name).fetchall()]}

def evidence_before_or_after(which, spent):
    sample={'phase':which,'physical_posts':spent,'posts_sha256':code_digest(root/'posts.jsonl'),
            'case_hashes':seals(),'budget':budget_state()}
    save(root/f'{which}.json',sample)
    return sample

def run():
    root.mkdir(mode=0o700,exist_ok=False)
    (root/'wire').mkdir(mode=0o700)
    with ThreadingHTTPServer(('127.0.0.1',0),Wire) as server:
        server.post_count = 0
        server_thread=Thread(target=server.serve_forever,kwargs={'poll_interval':0.1},daemon=True)
        server_thread.start()
        try:
            service=LocalEndpoint(server.server_port,'full-schedule-canned-control',code_digest(Path(__file__)),8000,
                                  provider='private-loopback-qualification',provider_version='1',model_revision='no-trained-model')
            authority=SpendingAuthority(sha(b'sole private zero-price accounting rehearsal'),service.service_sha256,0,0,0)
            ModelBudget.enroll(root/'budget.sqlite',authority)
            observer={'status':'qualified','host_basis_sha256':code_digest(repo/'docs/evidence/M5/isolation-qualification.md'),
                      'integrated_review_sha256':code_digest(repo/'docs/evidence/M5/review-3308ef7/review.md')}
            config={'service':service.profile(),'authority':asdict(authority),'observer':observer,
                    'data':'synthetic-notification-and-arm-public-context'}
            save(root/'conditions.json',config)
            series=root/'series'
            cli('freeze',series,'--population','canned_control','--conditions',root/'conditions.json','--budget',root/'budget.sqlite')
            start=time.monotonic()
            save(root/'run-start.json',{'source':expected_source,'freeze_sha256':code_digest(series/'freeze.json'),
                'command':['collect','series','--wasi-archives','qualified-archives'],'population':'canned_control',
                'coding_behavior':'inspect one work item, then stop','git_behavior':'choose from public observations',
                'cash_usd':0,'original_model_trials':0,'physical_post_log':'posts.jsonl'})
            (root/'collect.out').write_bytes(cli('collect',series,'--wasi-archives',archives))
            elapsed=time.monotonic()-start
            before=evidence_before_or_after('before-reentry',server.post_count)
            assert len(before['case_hashes'])==195
            (root/'report-before.md').write_bytes(cli('report',series))
            cli('collect',series,'--wasi-archives',archives)
            after=evidence_before_or_after('after-live-reentry',server.post_count)
            assert {k:v for k,v in before.items() if k!='phase'}=={k:v for k,v in after.items() if k!='phase'}
        finally:
            server.shutdown()
            server_thread.join()
    cli('collect',series)
    after=evidence_before_or_after('after-offline-reentry',server.post_count)
    assert {k:v for k,v in before.items() if k!='phase'}=={k:v for k,v in after.items() if k!='phase'}
    (root/'report-offline.md').write_bytes(cli('report',series))
    assert (root/'report-before.md').read_bytes()==(root/'report-offline.md').read_bytes()
    save(root/'run-complete.json',{'source':expected_source,'population':'canned_control','present':len(seals()),
        'physical_posts':server.post_count,'seconds_collecting':round(elapsed,3),'original_model_trials':0,
        'report_sha256':code_digest(root/'report-offline.md'),'wire_log_sha256':code_digest(root/'posts.jsonl'),
        'charged_usd':0})
    print((root/'run-complete.json').read_text(), flush=True)

if __name__ == '__main__':
    run()
