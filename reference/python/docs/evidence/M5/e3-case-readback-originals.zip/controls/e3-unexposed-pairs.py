"""Compare an originally unexposed arm with matched E3 clean and live-writer controls."""
import json
import subprocess
import sys
from pathlib import Path

repo, output = map(lambda p: Path(p).resolve(), sys.argv[1:]); output.mkdir(exist_ok=False)
sys.path.insert(0,str(repo))
from tests.test_model_study import cli,enroll
from tests.test_model_e3 import canned_service
from experiments.e1.artifacts import sha,encoded,git
from experiments.model_study.registration import schedule
from experiments.model_study.collector import case_path
from experiments.model_study.report import inspect

units = [u for u in schedule() if u[0]=='E3' and u[1] in ('clean','inconclusive-observation')]
wire = {}
with canned_service() as s:
    s.model='counted-notification-control'
    series=enroll(output,s.server_port,observer='unavailable')
    for unit in units:
        s.variant = 'decline' if unit[3]=='loop' else 'evidence'
        label='/'.join(map(str,unit)); n=len(s.received)
        cli('collect',series,'--unit',label); wire[label]=s.received[n:]
        count=len(s.received); cli('collect',series,'--unit',label); assert len(s.received)==count
(output/'requests.json').write_bytes(encoded(wire))
report=cli('report',series); assert cli('report',series)==report
(output/'report.md').write_text(report)
e3=report.split('\n## E3\n',1)[1]; _,cases=inspect(series)
rows={}
for unit in units:
    label='/'.join(map(str,unit)); f=cases[unit]['facts']; path=case_path(series,unit)
    raw=json.loads((path/'raw.json').read_bytes())
    native=git(path/'trial/canonical.git','reflog','show','--format=%H%x09%gs','refs/heads/notify').decode().splitlines()
    assert f['effect_count']==sum('\tpurser.effect ' in line for line in native)
    if unit[3]=='loop':
        assert raw['validity']=='arm_incomplete' and f['eligible'] is not True and f['effect_count']==0
    else:
        assert raw['validity']=='complete' and f['eligible'] is True
    key=f'| {unit[1]} / {unit[2]} |'
    line=next(ln for ln in e3.splitlines() if ln.startswith(key))
    paired=[c.strip().split(' / ') for c in line.strip('|').split('|')[1:]]
    assert paired[0][:6]==['?']*6
    assert paired[0][8]!='?' and paired[1][2]=='0'
    rows[label]={'raw_validity':raw['validity'],'original_truth':f['original_truth'],'original_report':f['original_report'],'eligible':f['eligible'],'effect_count':f['effect_count'],'pending':f['stress_held_pending'],'native_reflog':native,'posts':len(wire[label]),'comparisons':line}
data={'source':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'cases':rows,'posts':sum(map(len,wire.values())),'clean_overhead':next(l for l in e3.splitlines() if l.startswith('Healthy matched clean pair ')),'report_sha':sha(report.encode())}
(output/'result.json').write_bytes(encoded(data));print(data['posts'],data['clean_overhead'],sha((output/'result.json').read_bytes()))
