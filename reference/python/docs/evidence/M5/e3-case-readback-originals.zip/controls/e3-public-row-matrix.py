"""Collect public-CLI boundary controls for E3 case measurement and comparison eligibility."""
import json
import shutil
import subprocess
import sys
from pathlib import Path

source, target = map(lambda name: Path(name).resolve(), sys.argv[1:])
target.mkdir(exist_ok=False)
sys.path.insert(0, str(source))
from experiments.e1.artifacts import encoded, sha
from experiments.model_study.registration import schedule
from experiments.model_study.collector import case_path
from experiments.model_study.report import inspect
from tests.test_model_study import enroll, cli
from tests.test_model_e3 import canned_service

samples = {}
def add(track, seed, arm, error=None, mode='evidence'):
    samples['E3', track, seed, arm] = mode, error

add('primary', 3008, 'loop', 4)
for arm in ('loop', 'purser', 'loop_equal_verifier'):
    add('primary', 3013, arm, 2 if arm == 'loop' else None)
add('primary', 3014, 'loop', 1)
add('primary', 3014, 'purser', None, 'wrong_completion')
for arm in ('loop', 'purser', 'loop_equal_verifier'):
    add('primary', 3015, arm, 2 if arm == 'purser' else None)
    add('clean', 3001, arm, 2 if arm == 'purser' else None)
    add('inconclusive-observation', 3001, arm, 2 if arm == 'purser' else None)

def as_key(unit):
    return '/'.join(map(str, unit))

def write(path, value):
    path.write_bytes(encoded(value))

wire = {}
with canned_service() as service:
    service.model = 'counted-notification-control'
    series = enroll(target, service.server_port, observer='unavailable')
    for unit in schedule():
        if unit not in samples:
            continue
        service.variant, nth = samples[unit]
        first = len(service.received)
        service.error_at = first + nth if nth else None
        args = 'collect', series, '--unit', as_key(unit)
        cli(*args)
        length = len(service.received)
        cli(*args)
        assert len(service.received) == length
        native_requests = service.received[first:]
        wire[as_key(unit)] = native_requests
        print(as_key(unit), len(native_requests), 'physical posts', flush=True)
write(target / 'requests.json', wire)
output = cli('report', series)
assert cli('report', series) == output
(target / 'report.md').write_text(output)
_, cases = inspect(series)
individuals, deltas, totals = {}, {}, {}
group = output.split('## E3\n', 1)[1]
headers = None
for line in group.splitlines():
    cells = [item.strip() for item in line.strip('|').split('|')]
    if not line.startswith('|'):
        continue
    if cells[:3] == ['Track', 'Seed', 'Arm']:
        headers = cells
    elif len(cells) >= 4 and cells[0] in ('primary', 'clean', 'inconclusive-observation'):
        individuals[as_key(('E3', cells[0], int(cells[1]), cells[2]))] = dict(zip(headers, cells, strict=True))
    elif cells[0] in ('effect_count', 'correct_reconciliation', 'duplicate_count', 'resolved_by_budget'):
        totals[cells[0]] = cells[1:]
    elif len(cells) == 3 and cells[0].split(' / ')[0] in ('primary', 'clean', 'inconclusive-observation'):
        deltas[cells[0]] = cells[1:]

details = {}
for unit, case in cases.items():
    path = case_path(series, unit)
    raw = json.loads((path / 'raw.json').read_bytes())
    reflog = subprocess.check_output(['git','--git-dir',str(path/'trial/canonical.git'),'reflog','show','--format=%H%x09%gs','refs/heads/notify'],text=True).splitlines()
    facts = case['facts']
    key = as_key(unit)
    names = ['eligible','original_truth','original_report','effect_count','physical_count_lower_bound','duplicate_count','justified_in_order','correct_reconciliation','resolved_by_budget','stuck_requires_manual','manual_repair','uncertainty_remaining','stress_held_pending']
    details[key] = {'wire_posts':len(wire[key]), 'reflog':reflog, 'raw_validity':raw['validity'],'raw_score':raw['score'],'raw_sha':sha((path/'raw.json').read_bytes()),'facts':{n:facts.get(n) for n in names},'rendered':individuals[key], 'deltas':deltas[f'{unit[1]} / {unit[2]}'], 'errors':case['errors']}
    assert facts['effect_count'] == sum('\tpurser.effect ' in entry for entry in reflog)
    assert len(wire[key]) == case['cost'].exact['model_calls']

one = ('E3','primary',3013,'loop')
path = case_path(series, one)
bad = target/'missing-native-source'
(bad/'cases').mkdir(parents=True)
shutil.copyfile(series/'freeze.json', bad/'freeze.json')
duplicate = case_path(bad, one)
shutil.copytree(path, duplicate)
raw = json.loads((duplicate/'raw.json').read_bytes())
native = json.loads((duplicate/raw['artifacts']['platform']['path']).read_bytes())
badref = native['e3']['external'] if 'external' in native['e3'] else raw['artifacts']['platform']
if not isinstance(badref,dict) or not isinstance(badref.get('path'),str):
    badref = raw['artifacts']['platform']
(duplicate / badref['path']).unlink()
failed = inspect(bad)[1][one]
assert failed['cost'].validity == 'infrastructure_invalid' and failed['facts'].get('effect_count') is None
missing = cli('report',bad)
(target/'missing.md').write_text(missing)
keylines = [line for line in group.splitlines() if line.startswith('Healthy matched clean pair')]
decision = [line for line in output.splitlines() if line.startswith('| E3 |')][0]
facts={'source':subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip(),'rows':details,'n':len(cases),'posts':sum(map(len,wire.values())),'totals':totals,'threshold':decision,'clean':keylines[0],'raw_missing':badref,'missing_errors':failed['errors'],'missing_exact_costs':failed['cost'].exact,'report_sha':sha(output.encode())}
write(target/'result.json',facts)
print('case/count/requests/digest',len(details),len(samples),facts['posts'], sha((target/'result.json').read_bytes()))
