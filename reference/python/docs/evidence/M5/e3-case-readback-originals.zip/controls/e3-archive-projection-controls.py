"""Package the original control bytes and verify four cold CLI reports without a network."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from zipfile import ZipFile, ZIP_DEFLATED

repo = Path(sys.argv[1]).resolve()
root = Path(__file__).resolve().parent
sys.path.insert(0,str(repo))
from experiments.e1.artifacts import encoded, sha
from experiments.e1.report import Objects
from experiments.e3.observations import Native
from experiments.model_study.collector import case_path
from experiments.model_study.report import Archive, case_measurement, e3_predicates, inspect
from purser.kernel.wire import digest

folders = {'late-429':'e3-public-observation-control-3308ef7','duplicate':'e3-proved-duplicate-3308ef7',
           'matrix':'e3-public-row-matrix-3308ef7','pair-exposure':'e3-unexposed-pairs-3308ef7'}
focus = {'late-429','duplicate'}
case_unit = ('E3','primary',3013,'purser')
series = root/folders['duplicate']/'series'; path = case_path(series,case_unit)
raw = json.loads((path/'raw.json').read_bytes()); objects = Objects(Archive(path))
platform = objects.item(raw['artifacts']['platform']); e3=platform['e3']
key = digest('effect', e3['intent']); snaps = {}
for action,ref in e3['observations'].items():
    snap = Native.read(objects.item(ref),e3['binding'],e3['receipt_ref']); original=snap.publications(key)
    if len(original)>1:
        assert snap.end<=platform['end_monotonic_ns']
        snaps[action]={'observation_ref':ref,'publications':original,'observed_end':snap.end,'cutoff':platform['end_monotonic_ns']}
assert len(snaps)==1
full=inspect(series)[1][case_unit]; assert full['facts']['eligible'] is True
maybe={case_unit:{'cost':full['cost'],'facts':{'eligible':True,'physical_count_lower_bound':2}}}
report={'source':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'native_observations':snaps,'original_effect_qualified':full['facts']['eligible'], 'registered_lower_bound_projection':{k:case_measurement(maybe,case_unit,k) for k in ('effect_count','duplicate_count','correct_reconciliation')},'registered_predicates':e3_predicates(maybe),'method':'Hand-score of the case-qualified original pre-cutoff native snapshot alone; exact total and subsequent events intentionally withheld. No original registration or artifact was modified.'}
assert report['registered_predicates']==(False,True)
assert report['registered_lower_bound_projection']=={'effect_count':'≥2','duplicate_count':'≥1','correct_reconciliation':'?'}
(root/folders['duplicate']/'partial-witness.json').write_bytes(encoded(report))

disabled = """import runpy,socket
def offline(*args,**kwargs):
    raise AssertionError('cold report attempted a network connection')
socket.socket.connect=socket.socket.connect_ex=socket.create_connection=offline
runpy.run_module('experiments.model_study',run_name='__main__')
"""
def package(archive, groups):
    entries={}
    def add(label,p):
        assert label not in entries
        entries[label]=p.read_bytes()
    for label in groups:
        location=root/folders[label]
        for p in location.glob('*.json'):
            if p.name!='conditions.json':
                add(f'{label}/{p.name}',p)
        add(f'{label}/report.md',location/'report.md')
        add(f'{label}/series/freeze.json',location/'series/freeze.json')
        for c in (location/'series/cases').glob('*/*/*/*'):
            for name in ('raw.json','started.json','session.json','dispute.json'):
                if (c/name).is_file():
                    add(f'{label}/{(c/name).relative_to(location)}',c/name)
            for p in (c/'objects').iterdir():
                if p.is_file():
                    add(f'{label}/{p.relative_to(location)}',p)
    for p in [root/'architect-e3-late-error-probe.py',root/'e3-proved-duplicate.py',root/'e3-public-row-matrix.py',root/'e3-unexposed-pairs.py',Path(__file__)]:
        add(f'controls/{p.name}',p)
    add('controls/hand-scored-thresholds.json',root/'e3-public-projection-hand-score-3308ef7.json')
    manifest={n:sha(data) for n,data in entries.items()}
    entries['manifest.json']=encoded(manifest)
    with ZipFile(archive,'x',compression=ZIP_DEFLATED,compresslevel=6) as z:
        for n in sorted(entries):z.writestr(n,entries[n])
    with ZipFile(archive) as z, tempfile.TemporaryDirectory(prefix='purser-e3-case-report-') as temp:
        assert set(z.namelist())==set(entries) and len(z.namelist())==len(entries)
        assert all(sha(z.read(name))==expected for name,expected in json.loads(z.read('manifest.json')).items())
        z.extractall(temp)
        for label in groups:
            directory=Path(temp)/label
            cold=subprocess.check_output([sys.executable,'-B','-c',disabled,'report',str(directory/'series')],cwd=repo)
            assert cold==(directory/'report.md').read_bytes(),label
    return {'members':len(entries), 'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'series':sorted(groups),'manifest_sha256':sha(entries['manifest.json'])}

focal = repo/'docs/evidence/M5/e3-case-readback-originals.zip'; complete=root/'e3-case-readback-all-3308ef7.zip'
out={p.name:package(p, gs) for p,gs in ((focal,focus),(complete,folders))}
print(json.dumps(out,indent=2));(root/'e3-case-readback-archives-3308ef7.json').write_bytes(encoded(out))
