"""Exercise the M0 adverse predicate with a genuine same-intent duplicate in one disposable Git fixture."""
import json
import runpy
import subprocess
import sys
from pathlib import Path

source = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(source))
from experiments.e1.artifacts import encoded, sha, START, git
from experiments.e3.observations import TARGET

if sys.argv[2] == '--fixture':
    from experiments.e3.actions import Tools
    from purser.kernel.wire import digest
    observed = Tools._observation
    out = Path(sys.argv[3]).resolve()
    def add_duplicate(tools, intent, attempt, delivery):
        if attempt == 'T1' and not (out/'intervention.json').exists():
            bare = Path(tools.repository.binding['git_dir']).resolve()
            assert bare.is_relative_to(out) and bare.name == 'canonical.git'
            resource = intent['resource']
            same_intent = digest('effect', intent)
            git(bare,'update-ref','-m','fixture restores starting policy',resource,START,TARGET)
            git(bare,'update-ref','-m','purser.effect '+same_intent+' Alternate',resource,TARGET,START)
            (out/'intervention.json').write_bytes(encoded({'same_intent':same_intent,'resource':resource,'attempt':attempt,'delivery':delivery}))
        return observed(tools,intent,attempt,delivery)
    Tools._observation = add_duplicate
    sys.argv = ['study', 'collect', str(out/'series'), '--unit', 'E3/primary/3013/purser']
    runpy.run_module('experiments.model_study', run_name='__main__')
    raise SystemExit

from tests.test_model_e3 import canned_service
from tests.test_model_study import cli,enroll
from experiments.model_study.report import inspect
from experiments.model_study.collector import case_path
target = Path(sys.argv[2]).resolve(); target.mkdir(exist_ok=False)
unit = ('E3','primary',3013,'purser')
with canned_service() as service:
    service.model='counted-notification-control'; service.error_at=2
    series=enroll(target,service.server_port,observer='unavailable')
    child = subprocess.run([sys.executable,'-B',str(Path(__file__).resolve()),str(source),'--fixture',str(target)],cwd=source,capture_output=True,text=True)
    assert child.returncode==0,child.stderr
    cli('collect',series,'--unit','/'.join(map(str,unit)))
    (target/'wire.json').write_bytes(encoded(service.received))
    assert len(service.received)==2

report=cli('report',series); (target/'report.md').write_text(report)
assert cli('report',series)==report
rawdir=case_path(series,unit); raw=json.loads((rawdir/'raw.json').read_bytes()); c=inspect(series)[1][unit]; f=c['facts']
lines=[line for line in report.splitlines() if line.startswith('| E3 |') or line.startswith('| primary | 3013 | purser |')]
native=git(rawdir/'trial/canonical.git','reflog','show','--format=%H%x09%gs','refs/heads/notify').decode().splitlines()
data={'source':subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip(),'reflog':native,'raw_validity':raw['validity'],'raw_score':raw['score'],'facts':{k:f.get(k) for k in ('eligible','physical_count_lower_bound','duplicate_count','effect_count','original_truth','correct_reconciliation','resolved_by_budget')},'threshold_and_public_row':lines,'errors':c['errors']}
(target/'result.json').write_bytes(encoded(data)); print(json.dumps(data,indent=2)); print('digest',sha((target/'result.json').read_bytes()))
assert len([r for r in native if '\tpurser.effect ' in r])==2
assert data['raw_validity']=='infrastructure_invalid' and data['raw_score'] is None
assert f['eligible'] is True and f['effect_count']==2 and f['duplicate_count']==1
assert lines[0]=='| E3 | no | yes | no / yes |'
